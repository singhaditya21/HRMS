## 08. Functional Requirements — Payroll & Statutory Filing Engine

This section specifies **what the payroll and statutory-filing engine must do**. It is
the functional companion to §06 (the statutory compliance spine, which specifies the
*rules* — every rate, slab, ceiling, penalty and cadence) and §05.5 (the module
sequencing, which specifies *when* each capability ships). §06 answers "what does the
law require"; this section answers "what does the software do about it, step by step,
and how do we know it is correct." Every rate/slab reference resolves to §06, and every
§06 rule carries its own gazette/notification provenance; the source cues repeated here
are the load-bearing ones an engineer reads while building the FR.

Two framing rules govern everything below and are not restated per-FR:

- **Rules-first, LLM-last (§12.1, [Verified]).** No statutory or monetary figure in this
  engine is ever model-generated. Every FR here is a specification for a deterministic,
  effective-dated, retrospectively-recomputable rule. The assistant explains, drafts and
  routes; it never computes a number that lands on a payslip, a challan or a return.
  (Source: §12.1 design principle P1, [Verified].)
- **The filing, not the payslip, is the unit of delivery (§01, §04.1, [Verified]).** The
  headline acceptance metric for this engine is not "payslip generated" but "return
  filed on time and accepted." Payslip generation is a byproduct of a correct pay run;
  the pay run exists to feed ECR, ESI, PT, Form 138, the Form 130 inputs and the bonus
  return. (Source: §01 thesis; §04.1 ICAI fee schedule prices filings, not payroll
  processing, [Verified].) **What "delivery" means is fixed by K-13:** every statutory
  surface is an attended portal — EPFO's interactive login with CAPTCHA, the TDS
  statement that the deductor validates through the FVU utility and uploads, ESIC's
  template upload, and one manual portal per PT state. The engine's deliverable is a
  **portal-accepted artefact plus attended, assisted filing under the employer's written
  authority to act**; the employer's and deductor's statutory liability is
  non-delegable and stays with the customer. No vendor in the six-vendor set claims to
  submit any filing (EV-030; published material as of September 2026), which is why
  attended submission is a real differentiator rather than a promise of automation. The
  runbooks are §22; the legality of acting on portals under employer credentials is
  under counsel review (§23.13, Part D-17).

**Numbering.** Requirements are numbered `FR-PAY-###` within functional groups
(100s = compensation, 200s = statutory computation, 300s = pay-run lifecycle, and so
on). Each FR carries a **phase tag** (P0 / P1 / P2, per §05.5), a one-line statement,
detail, and **acceptance criteria** (AC) that are testable. Confidence markers appear
where a claim's status is load-bearing; every **[Hypothesis]** carries a
kill/validation criterion inline.

<!-- DIAGRAM: journey-run-payroll -->

---

### 08.1 Engine principles and the data spine every FR reads from

Before the numbered requirements, seven architectural invariants. These are not
negotiable per-feature; every FR below assumes them and several would be incorrect
without them. I1–I5 restate §06.12 R1–R3 and R7 as engine invariants; I6 and I7 are
the engine-purity and fixed-point corrections (Part E-3, E-4), shared with §15.

| # | Invariant | Why it is an invariant, not a feature | Source |
| --- | --- | --- | --- |
| I1 | **Multiple concurrent wage bases per employee per period** — the PF/gratuity add-back base, the ESI gross base, the capped bonus base, and the payment-of-wages base coexist on one payslip | The 50% add-back creates a PF base that excludes HRA/conveyance/overtime; ESI is computed on gross which *includes* them; bonus is capped at the notified amount or the minimum wage, whichever is higher (legacy notified amount ₹7,000; the Code-era amount is per appropriate Government and unconfirmed, §06.7). A single "wage" field is a design error. | §06.10, §06.3, §06.7 [Verified]; (Source: Code on Wages s.2(y) / CoSS s.2(88); Code on Wages s.26(2)) |
| I2 | **Every rate, slab and definition is effective-dated and versioned** — 12% PF, the 50% add-back percentage, PT/LWF slabs, TDS regime parameters, bonus ceilings, wage ceilings | The statute makes 50% "or such other per cent as may be notified" — a standing variable. The same holds for the ₹15,000 PF ceiling and ₹21,000 ESI ceiling. | §06.10, §06.2, §06.3, §06.7 [Verified] |
| I3 | **Retrospective recompute against the period's rule version** — arrears and retro runs recompute using the rule that was in force *for the period being corrected*, never the rule in force today | A March correction filed in September must use March's slabs, not September's. | §06.10 [Verified]; §06.14 TV12 |
| I4 | **Deterministic, replayable pay run** — given the same input snapshot, rule versions and evaluation context (I6), a pay run reproduces byte-identical figures; every figure traces to (input × rule-version × formula). **Replay is scoped by entity class (K-24):** the run's input snapshot and the bitemporal classes — rules, salary structures, assignments, statutory attributes — are retained and replayable; the erasable classes — punches, rendered documents, biometric templates, consent artefacts — are never evaluation inputs, so erasing one never changes a replayed figure (a payslip PDF erased under its retention class is re-rendered from the snapshot and marked as a re-rendering). The erasure mechanism is §14's. | A wrong payroll number is a legal problem; auditability is the defence. | §12.1 [Verified]; Part E-2 |
| I5 | **Immutable audit trail on every monetary field** — who changed what, when, from what value, under what authority, with the rule version applied | Required for the six employer registers plus the wage slip (EV-053), retained per each rule-set's own wording rather than a flat five years (EV-054), for CA read-only audit, and for dispute defence. | §06.9, §06.12 R10, §16 [Verified — central sphere] |
| I6 | **Engine purity** — evaluation is a pure function of **(input snapshot, rule-set version, evaluation context)**: no I/O, no clock, no database read inside evaluation. The evaluation context is enumerated and closed: **disbursal date**, **as-of decision time**, **jurisdiction set**, **tax-regime election** (FR-PAY-210) | PF liability on arrears dates from the disbursal date (Part E-9), and the Form 138 deductee date of payment must fall inside the quarter and tax year being filed (r5/02 finding 32) — both keyed to external, later-known facts. Without an explicit context the "pure" engine would read them from the clock or the database and replay would break. | Part E-3; §15 |
| I7 | **Bounded fixed-point nodes are permitted in the calculation graph** — a node may iterate to convergence under a maximum iteration count and a tolerance; a topological one-pass DAG is not assumed (FR-PAY-211) | The s.2(y) 50% add-back re-bases components that feed its own test, and net-of-tax gross-up is fixed-point by construction. A one-pass engine publishes a first iterate as the answer. | Part E-4; §06.10; §15 |

The engine reads from a single employee-period fact set. Each fact is stamped with the
effective-dated rule version that produced it, so the same run can be **replayed** for
audit or **recomputed** for retro without re-deriving today's rules.

<!-- DIAGRAM: payroll-data-spine -->

---

### 08.2 Compensation and CTC structures

The compensation model is where the two-wage-base problem originates, so it is P0 and
must be right before any statutory computation is meaningful.

**FR-PAY-101 · CTC structure builder** · **P0**
The engine shall let an admin define one or more **salary structures** as an ordered
set of **pay components**, each with a type (earning / deduction / reimbursement /
statutory / employer-cost), a calculation basis (fixed / percentage-of-basic /
percentage-of-CTC / slab / formula / balance-figure), a taxability treatment, and
per-component flags for PF-wage inclusion, ESI-wage inclusion, gratuity-wage inclusion,
bonus-wage inclusion, and payment-of-wages inclusion.
- *Detail.* A structure is a template; an employee is assigned a structure with
  component values (or the structure computes them from CTC). The "special allowance"
  as a **balance figure** (CTC minus the sum of all other annual components) is a
  required component type — it is how virtually every Indian offer letter closes CTC.
  The **five wage-base flags** (not one taxability flag) are what make I1 executable —
  the same "conveyance" component is excluded from PF but included in ESI gross and
  payment-of-wages. Special allowance is **wages**, not an excluded head, so its default
  flags include the PF and gratuity bases (§06.10); a balance figure that closes a CTC
  carrying a wage-linked employer cost creates a loop the engine resolves as a bounded
  fixed point (FR-PAY-211).
- **AC-101.1** — Creating a component with `pf_wage=true, esi_wage=false` and another
  with `pf_wage=false, esi_wage=true` yields two different bases for the same employee,
  verifiable on the payslip breakdown.
- **AC-101.2** — A structure whose components do not sum to CTC is rejected with the
  exact rupee gap named, unless a balance-figure component is present to absorb it.
- **AC-101.3** — Assigning a structure to an employee with a stated annual CTC produces
  monthly component values whose 12× sum equals CTC to the rupee (rounding rule
  configurable; default: round each monthly component, reconcile the residue into the
  balance-figure component in the final month — see FR-PAY-209).
- **AC-101.4** — A component with **no wage-base flags set at all** is a blocking
  validation error (FR-PAY-1004), because a silently un-flagged component would drop out
  of every statutory base and file a wrong return.

**FR-PAY-102 · Employer-cost components inside CTC** · **P0**
The engine shall model **employer statutory contributions and other employer costs
(employer EPF, EPS, EDLI, EPF/EDLI admin charges, employer ESI, gratuity accrual,
employer LWF, statutory-bonus accrual, group-insurance premia) as CTC components** that
appear in the CTC build but **not** in gross earnings and **not** in net pay.
- *Detail.* Indian CTC is cost-to-company, so employer PF (₹1,800 typical), the ₹1,250
  EPS cap allocation, EDLI, admin charges and gratuity accrual are all part of the
  ₹X CTC the employee was quoted, but none of them are paid to the employee. The engine
  must present CTC, gross, and net as three distinct totals that reconcile.
- **AC-102.1** — For an employee on ₹15,000 PF wages contributing on the ceiling, the
  CTC view shows employer EPF ₹550, EPS ₹1,250, EDLI ₹75, EPF admin ₹75 as employer
  cost (the §06.2 worked example: the 1,800 / 1,250 / 550 split is EPFO's own Help File
  fixture, EV-035; EDLI 0.50% per EPFO's EDLI page; the 0.50% admin rate rests on
  pre-Code EPFO circulars, is **[Hypothesis]** and is applied with the establishment
  minimum `epf.admin_charge.minimum`, §06.13), none of which appear in gross or net.
- **AC-102.2** — `CTC = gross earnings (annual) + total employer statutory cost + other
  employer cost` holds to the rupee for every employee.

**FR-PAY-103 · Effective-dated compensation revisions** · **P0**
The engine shall store every compensation change (increment, promotion, structure
change) as an **effective-dated revision**, never an overwrite, and shall support a
revision **effective in a past period** (the trigger for arrears — FR-PAY-401).
- **AC-103.1** — A ₹60,000→₹70,000 monthly revision effective 1 April, entered in July,
  is stored with effective date 1 April and flags April–June as requiring arrears.
- **AC-103.2** — Querying an employee's compensation "as of" any historical date returns
  the value in force on that date, not the current value (supports I3, retro recompute).

**FR-PAY-104 · Proration** · **P0**
The engine shall prorate earnings for **partial-period employment** (mid-period join,
exit, unpaid leave, mid-period structure change) on a configurable per-pay-group basis:
**fixed 30-day** (salary ÷ 30), **calendar days in the month**, or
**pay-for-actual-attendance** — the three day-rate conventions practitioners use.
- *Detail.* The proration basis is a tenant/pay-group policy, not a global constant.
  No single national convention exists and the choice is a recurring source of
  disputes (r3/02 finding 6 — **[low]** confidence, practitioner-forum evidence read
  second-hand); the conventions give different results, so the one applied is printed
  on the payslip and reflected in the payment-of-wages register. LOP (loss of pay) days
  from attendance/leave (§09) reduce the paid-day count. **[Hypothesis]** — the ESI
  coverage test for a mid-month joiner reads the contracted monthly wage, not the
  prorated figure, so a part-month gross **below** ₹21,000 does not by itself pull an
  otherwise-out employee into ESI. §06.3 does not state the part-month rule; **kill
  criterion: confirm against ESIC's wage and coverage guidance before this drives a
  coverage decision (§20).**
- **AC-104.1** — An employee joining on the 16th of a 30-day month on ₹60,000/month, on
  calendar-day basis, earns ₹60,000 × 15/30 = ₹30,000 gross for the month (worked in
  full at §08.12, Example B), and PF/ESI/PT are computed on the **prorated** base per
  §06, not the full base.
- **AC-104.2** — Changing the proration basis for a tenant does not retroactively alter
  already-finalised pay runs; it applies from the next open period (effective-dated).

**FR-PAY-105 · Multi-establishment awareness** · **P2**
The engine shall support employees assigned to different **establishments** (PF/ESI
codes, PT/LWF states) within one tenant, computing each employee's statutory
obligations against **their establishment's** registrations and the PT/LWF rules of
**their assignment's work location**.
- *Detail.* Deferred to P2 (§05.5 item 22) because the single-site beachhead does not
  need it — but every employee-period must resolve `establishment_id` and its
  jurisdiction from v1 so the P2 build is additive, not a migration. Jurisdiction sits on
  the **work location** — state, sphere (central/state) and the applicable Code-regime
  commencement date — never on the employee record (Part E-5, §14); it enters
  evaluation as the jurisdiction set in the evaluation context (FR-PAY-210).
- **AC-105.1** — [P2] Two employees in the same tenant, one in Karnataka and one in
  Maharashtra, receive PT computed on Karnataka and Maharashtra slabs respectively in
  the same pay run.

**FR-PAY-106 · Perquisite valuation** · **P1**
The engine shall value **taxable perquisites** by the valuation rule in force for each
applicable head and feed the taxable value into the TDS base (FR-PAY-205), storing the
valuation basis so it is auditable and effective-dated.
- *Detail.* The common heads and their valuation method (1961-Act s.17(2) and 1962-Rules
  Rule 3 — v0.3's citations, carried, not re-captured in any research round; the
  valuation rules for Tax Year 2026-27 sit in the Income-tax Rules 2026 and are routed
  to §20 with the other perquisite items; the per-head valuation catalogue is §11's, and
  this FR consumes it): **rent-free / concessional accommodation** —
  a percentage of salary by city-population band, held as `perq.accommodation.slabs`
  (v0.3's slab percentages and the notification it cited are carried, not re-captured,
  **[Hypothesis]**); **motor car** — a per-month value by engine-capacity band plus a
  driver value, held as `perq.car.value.<band>` and `perq.car.driver_value`, with **no
  shipped default**: v0.3's figures are carried, not re-captured, and a reported
  revision for Tax Year 2026-27 was retracted in r1 because its only source cited no
  notification — yet the meal figure in that same reported table was later
  corroborated (r2/02, EV-019) — so the current values are unknown and v0.3's must not
  ship as a default; **interest-free/concessional loan**
  — a benchmark rate on the maximum monthly outstanding, with a small-aggregate and a
  medical-loan exemption, held as `perq.loan.benchmark_rate` and
  `perq.loan.exempt_aggregate` (**[Hypothesis]**); **ESOP** — perquisite = FMV on the
  exercise date minus the exercise price, with the eligible-startup TDS deferral under
  1961-Act s.192(1C) whose trigger events and window are held as `tds.esop_deferral.*`
  (carried, not re-captured, **[Hypothesis]**); **meal and gift vouchers** at the
  01.04.2026 thresholds (₹200 per meal; ₹15,000 per year for gifts — EV-019,
  **[Hypothesis]**, §20 V-18; §06.5, §11), with the meal exemption **conditional**
  (K-19): meals provided during working hours at office or factory premises, or
  non-transferable vouchers usable only at eating outlets. The conditions are engine
  constraints, not a wallet limit — a meal benefit that fails them is valued as a fully
  taxable perquisite, because otherwise the payslip under-deducts and the demand plus
  interest lands on the employer. The rule citation is not stated here; it is routed to
  §20 validation (§06.13). The section and rule numbers in this FR are 1961-Act /
  1962-Rules numbering; their 2025-Act / 2026-Rules equivalents are unmapped and are
  carried as rule-version data under both labels (§06.12 R13, §06.13).
  Perquisite valuation is **rules-first** (I4) — no perquisite value is model-generated.
- **AC-106.1** — A ₹5,00,000 interest-free loan outstanding for a full year is valued at
  `perq.loan.benchmark_rate` on the maximum monthly outstanding and added to the TDS
  base; a loan whose aggregate is at or below `perq.loan.exempt_aggregate` adds nothing.
  With either parameter empty the valuation raises a configuration task instead of
  guessing.
- **AC-106.2** — An eligible-startup ESOP perquisite defers TDS under 1961-Act
  s.192(1C); the engine tracks the deferral clock and triggers the deduction on the
  earliest event configured in `tds.esop_deferral.*`, not on exercise.
- **AC-106.3** — Rent-free accommodation is valued on the **effective-dated** slab version
  of `perq.accommodation.slabs` in force for the period, so a retro recompute (I3) uses
  the period's slab, not today's.
- **AC-106.4** — A motor-car perquisite with `perq.car.*` unset for the period is not
  valued at zero and not valued at a guessed figure. The operator is asked to enter the
  value in force with its source, recorded on the rule version (the same pattern as the
  bonus ceiling, AC-208.4); until then it is a blocking validation (FR-PAY-1004),
  because an unvalued perquisite under-deducts TDS. The value is confirmed through §20.

**FR-PAY-107 · Worker classification and the contractor scope boundary** · **P0**
The engine shall carry a **worker class** on every payee — *employee* (salary under
s.392, ex-s.192; PF/ESI/PT/gratuity apply), *contractor/professional* (1961-Act
s.194C/194J, whose 2025-Act equivalents are unmapped, §06.13; **no** salary statutory
heads), or *gig/platform worker* — and route each to the correct TDS section and
statutory obligation set, refusing to silently treat a contractor as an employee or
vice versa.
- *Detail.* Misclassification is the most common source of a wrong return: a consultant
  paid via payroll and put through the salary section (s.392, ex-s.192) + PF is a filed
  error, and an employee paid as a "contractor" to dodge PF is a liability the engine
  should flag, not enable. Contractor
  payments are **out of the salary engine's statutory scope** but in scope for TDS routing,
  at the rates held as `tds.contractor_rates.<section>` (v0.3's 1961-Act s.194C/194J
  rates are carried, not re-captured, and the 2025-Act sections are unmapped — routed to
  §20). The **Code on Social Security 2020 s.114** makes aggregators engaging gig and
  platform workers contribute between 1% and 2% of annual turnover, capped at 5% of the
  amount paid or payable to those workers (MoLE handbook, r3/04 finding 20) —
  **[Hypothesis]** for the operative scheme, the rate the Government actually fixes
  inside that band and the collection mechanism, none of which is captured. **Kill/validation
  criterion: build the `gig` worker class and a placeholder aggregator-contribution hook,
  but leave the rate and scheme `blocked-pending-notification` and escalated until the
  scheme is gazetted; do not compute a guessed contribution (§06.13, the same
  escalate-not-guess pattern as §20 V-08).**
- **AC-107.1** — A payee flagged *contractor* is deducted TDS under the contractor or
  professional-fee section (1961-Act s.194C/194J), not the salary section (s.392,
  ex-s.192), carries **no** PF/ESI/PT/gratuity, and appears on the Form 140 (ex-26Q)
  pipeline (EV-050; out of scope here), never on ECR/ESI.
- **AC-107.2** — An *employee* flagged with a contractor-style component set (no wage-base
  flags, no PF) trips the FR-PAY-1004 validation gate rather than filing a zero-PF ECR.

**FR-PAY-108 · The component catalogue** · **P0**
The engine shall ship a **seeded component catalogue** — one row per standard pay
component — carrying, for each component, its class, salary-TDS treatment, s.2(y)
head (which decides PF/gratuity wage membership and the 50% test), ESI
contribution-base membership, proration rule and rounding rule. A tenant component is
created by **cloning a catalogue row**, never from a blank form, so the five wage-base
flags of FR-PAY-101 are inherited with their source and only a recorded override can
change them. This is the table §06.10 commits §08 to: the nine in-scope s.2(y) heads
(a)–(i) are tagged here one by one.
- *Detail.* Each cell is rule data with a source and a status, not code (I2). Where no
  research round captured a treatment, the cell says **payload** — the tenant or our
  compliance analyst sets it on the component with a recorded source, and the
  component cannot be used in a run until that is done (the FR-PAY-1004 "no flags"
  block, AC-101.4). The **bonus base** follows the resolved s.2(y) wage and is then
  capped (FR-PAY-208); the **payment-of-wages base** is every earning paid in the wage
  period (FR-PAY-201) and is the base for the s.18(3) deduction cap (FR-PAY-403).
  Every ESI cell inherits §06.3's status: the separate coverage and contribution bases
  are verified, but the component-by-component list is carried, not re-captured, and
  is **[Hypothesis]** until ESIC's wages page is re-captured (§06.13). Rounding codes: **R0** — no component-level rounding, full internal precision until
  the statutory head is formed (AC-209.3); **RS** — the statutory head's own rule from
  the FR-PAY-209 table; **RW** — whole-rupee slab value.

| Component | Class | Salary-TDS treatment | s.2(y) head → PF / gratuity wage | ESI contribution base | Proration | Rounding |
| --- | --- | --- | --- | --- | --- | --- |
| Basic | Earning, fixed | Taxable salary | Wages — **in** | In (§06.3) | Pay-group day-rate convention (FR-PAY-104) | R0 |
| Dearness allowance | Earning, fixed | Taxable salary | Wages — **in** | In (§06.3) | Day-rate convention | R0 |
| Special allowance (balance figure) | Earning, fixed | Taxable salary | Wages — **in**; not an excluded head (§06.10) | In | Day-rate convention; closes CTC (FR-PAY-101) | R0; absorbs the CTC residue (AC-101.3) |
| House rent allowance | Earning, fixed | Taxable, less the old-regime exemption (AC-503.2) | Excluded — head (f) | In (§06.3) | Day-rate convention | R0 |
| Conveyance allowance | Earning, fixed | Taxable unless an exemption is configured (`tax.exemptions.conveyance`, payload) | Excluded — head (d) | In (§06.3) | Day-rate convention | R0 |
| Overtime | Earning, variable | Taxable salary | Excluded — head (h) | In for contribution, out of the coverage test — **[Hypothesis]**, TV5 | Not prorated; hours × a rate not less than twice the normal rate (Code on Wages s.14, §06.9) | R0 |
| Commission | Earning, variable | Taxable salary | Excluded — head (i) | In if paid at intervals not exceeding two months; out otherwise (§06.3, component list **[Hypothesis]**) | Not prorated | R0 |
| Other incentive (not commission) | Earning, variable | Taxable salary | **payload** — wages unless the payload classes it under a head | Interval test as for commission | Not prorated | R0 |
| Statutory bonus | Annual, statutory | Taxable in the year of receipt (§06.7) | Excluded — head (a) | Out — interval exceeds two months (§06.3, §06.7) | Not prorated; accrued monthly (FR-PAY-208) | R0 |
| Remuneration under an award, settlement or court order | Earning | Taxable salary | Excluded — head (g) | **payload** | Per the award | R0 |
| Special-expense sums (paid to defray expenses the job entails) | Earning or reimbursement | Exempt to the extent spent, if so configured (**payload**) | Excluded — head (e) | **payload** | Not prorated | R0 |
| House accommodation, light, water, medical attendance, other amenity | Perquisite, in kind | Valued per FR-PAY-106 / §11 | Excluded — head (b) | **payload** | Per valuation rule | R0 |
| Other remuneration in kind (meal and gift vouchers, car, loan) | Perquisite, in kind | Meal and gift: exempt only within EV-019 and the K-19 conditions (**[Hypothesis]**); others per FR-PAY-106 / §11 | In-kind value counted in wages up to 15% of total wages (s.2(88) Explanation, §06.10) — a separate, capped input | **payload** | Per valuation rule | R0 |
| Reimbursement against proof (fuel, telephone, books) | Reimbursement | Exempt within proof and limit; excess taxable (FR-PAY-502) | **payload** (head (e) only where it is a special-expense sum) | **payload** | Not prorated | R0 |
| Leave travel allowance | Reimbursement | Exempt against travel proof, old regime (FR-PAY-502; carried) | **payload** | **payload** | Not prorated | R0 |
| Arrears | Earning, derived | Treatment of the component in arrear; s.157(1) / Form 39 relief (AC-205.7) | Membership of the component in arrear; PF liability from the disbursal date (AC-401.2) | Membership of the component in arrear | Recomputed per past period (FR-PAY-401) | Per underlying component |
| Leave encashment — in service | Earning | Fully taxable (AC-801.4) | **payload** | **payload** | Days × the tenant's encashment base | R0 |
| Leave encashment — on exit | F&F earning | Exempt up to `tax.leave_encashment_exemption_ceiling` (AC-801.4) | **payload** | Out — encashment on discharge (§06.3, list **[Hypothesis]**) | F&F only | R0 |
| Gratuity payout | F&F earning | Exempt up to `tax.gratuity_exemption_ceiling` (FR-PAY-206) | Outside the test — head (j) | Out (§06.3) | F&F only; 15/26 formula | R0 |
| Retrenchment compensation | F&F earning | **payload** (`tax.exemptions.retrenchment`, carried) | Outside the test — head (k) | Out (§06.3) | F&F only | R0 |
| Employer PF, EPS, EDLI, EPF admin | Employer cost | Not the employee's salary, save the excess over `tax.retiral_aggregate_cap` (§11; carried, **[Hypothesis]**) | Excluded — head (c) | Out — not paid to the employee | Derived from the prorated PF base | RS |
| Employer NPS | Employer cost | Deduction within `tax.nps_employer_deduction_pct.<regime>`; counts toward `tax.retiral_aggregate_cap` (§11) | Excluded — head (c) | Out | Derived from its base | R0 |
| Employer ESI | Employer cost | Not the employee's salary | Not remuneration paid | — | Derived from the ESI base | RS |
| Gratuity accrual | Employer cost | Not the employee's salary until paid | Not remuneration paid; outside the test (Example G reading) | — | Monthly accrual on the uncapped gratuity wage | R0 |
| Employee PF and VPF | Deduction | Old-regime deduction under 80C / s.123 (carried); VPF above the statutory rate under Scheme para 29(2) (r5/02 finding 14) | — | — | Derived | RS |
| Employee ESI | Deduction | — | — | — | Derived | RS |
| Professional Tax | Deduction | Reduces taxable salary before TDS (FR-PAY-209 ordering) | — | — | Monthly slab on the month's earned wage, not day-prorated | RW |
| LWF (employee and employer) | Deduction / employer cost | — | — | — | Per state periodicity (FR-PAY-207) | RW |
| TDS | Deduction | — | — | — | Projection spread (FR-PAY-205) | RS |
| Advance, loan, asset recovery | Deduction, post-tax | Does not reduce the tax base (AC-403.1) | — | — | Instalment; within the s.18(3) cap | R0 |
| Notice-pay recovery or payment | F&F | **payload** | **payload** | **payload** | Days × the tenant's notice base | R0 |

- **AC-108.1** — Every seeded row carries, per cell, a source reference (a §06 entry,
  an EV ID, a research finding) or the literal status **payload**; a catalogue row with
  an unsourced non-payload cell fails the catalogue's own build check.
- **AC-108.2** — A tenant component cloned from "House rent allowance" is excluded from
  the PF/gratuity wage and counted in the (a)–(i) test under head (f) with no manual
  flag-setting; relabelling it "special allowance" without a recorded override does not
  move it (§06.10, TV6).
- **AC-108.3** — A component whose s.2(y) or ESI cell is **payload** cannot enter a run
  until the payload is set with a source; the attempt is the FR-PAY-1004 blocking item
  of AC-101.4, naming the cell.
- **AC-108.4** — Changing a catalogue cell is a new effective-dated rule version (I2);
  closed periods recompute against the version in force for them (I3), so a corrected
  classification produces arrears or a correction run, never a silent restatement.

---

### 08.3 Statutory computation engine

This group **orchestrates** the deterministic rules specified in §06. It does not
re-specify rates; it specifies how the engine applies them, in what order, with what
edge-case handling. All rate/slab references point to §06, and the golden cases are
§06.14 TV1–TV25.

<!-- DIAGRAM: fr-payroll-wage-base-fanout -->


**FR-PAY-201 · Dual/triple wage-base resolver** · **P0**
For every employee-period the engine shall compute, as separate stored figures: the
**PF wage base** (with the 50% add-back applied per §06.10), the **ESI gross base**, the
**gratuity wage base**, the **bonus wage base**, and the **payment-of-wages base**.
- *Detail.* This is I1 made executable. The add-back logic (Source: Code on Wages
  s.2(y) / CoSS s.2(88)): sum excluded components; if they exceed 50% of total
  remuneration, add the excess back into the PF/gratuity base (worked at §06.10 and
  §08.12 Example D; golden cases §06.14 TV6/TV7).
- **AC-201.1** — For the §06.10 illustration (remuneration ₹1,00,000, excluded
  components 65%), the engine adds back ₹15,000 and reports a PF wage base of ₹50,000
  **before** the ₹15,000 statutory ceiling is applied — both figures visible (TV6).
- **AC-201.2** — For excluded components at 45% (below the half), **no** add-back is
  applied and the PF base is the wage components alone — Basic ₹55,000 in the §06.10
  counter-case (TV7) — the engine does not add back unnecessarily. Special allowance is
  never counted among the excluded heads (TV6).
- **AC-201.3** — All bases are independently auditable and each is stamped with the
  wage-definition rule version used.

**FR-PAY-202 · EPF computation** · **P0**
The engine shall compute employee EPF, the **three-way employer split (EPS capped at
₹1,250, balance to EPF), EDLI, EPF admin and EDLI admin** exactly per §06.2, honouring
per-employee **ceiling-vs-actual** election, the **excluded-employee** flag, and the
**EPS-closure rule** for high-earner first-joiners.
- *Detail.* The classic bug §06.2 warns of — applying 8.33% to actual wages above the
  ceiling instead of capping EPS at ₹1,250 — is an explicit negative test (TV1).
  (Source: EPFO EPF and EPS Scheme pages, 8.33% capped at 8.33% of ₹15,000 = ₹1,250, and
  EPFO's Help File fixture 1,800 / 1,250 / 550, EV-035; §06.2 [Verified].)
- **AC-202.1** — For an employee on actual PF wages ₹30,000 with employer opting for
  ceiling contribution: employee EPF and employer split both computed on ₹15,000; EPS =
  ₹1,250 (not 8.33% of ₹30,000 = ₹2,499), employer EPF = ₹550. This exact case is a
  regression test (TV1).
- **AC-202.2** — For an employee opting actual-wage contribution on ₹30,000: employee
  EPF = ₹3,600, EPS still capped at ₹1,250, employer EPF = ₹3,600 − ₹1,250 = ₹2,350.
- **AC-202.3** — An "excluded employee" (joined above ₹15,000, never a prior member) is
  computed with zero EPF unless voluntarily enrolled; the exclusion basis is recorded.
- **AC-202.4** — An employee who **first joined EPF on or after 01.09.2014 with PF wages
  above ₹15,000** is closed to EPS: the full 12% employer share goes to EPF and EPS = 0
  (TV2; Source: EPFO revamped-ECR FAQ Q6, Q8(a) and Q14 and circular para 8(iii), r5/02
  finding 11; the legacy EPS paragraph and amendment date are carried, not re-captured,
  §06.2). EPFO's FAQ is inconsistent on the boundary day ("after" in Q8, "on or after" in
  Q14), so a member who first joined on exactly 01.09.2014 follows
  `epf.eps_closure_boundary_inclusive`, default "on or after" (TV17). Splitting EPS for
  such a member is a filed error — and one the portal will **not** catch: the revamped
  ECR only **flags** this case before filing, it does not reject it (EV-040). The
  engine, not EPFO, is the control.
- **AC-202.5** — Admin charges are computed on the correct minimum-per-establishment
  floor where applicable, not a bare percentage, and the EPF/EDLI admin rate is an
  effective-dated rule version (I2), so a re-notified admin rate is a config change.
- **AC-202.6** — A member who has attained **58** and is not marked for deferred pension
  is computed with **EPS = 0**, so the whole employer share falls to EPF under this FR's
  split rule. This is the **only** EPS rule the revamped ECR hard-blocks — the portal
  disallows the EPS component outright (EV-040) — so an engine that splits EPS here
  produces a return EPFO will not take.

**FR-PAY-203 · ESI computation with contribution-period state machine** · **P0**
The engine shall compute ESI at the §06.3 rates (employee 0.75%, employer 3.25%; Source:
ESIC contribution page, rates w.e.f. 01.07.2019, §06.3 — the legacy ESI rule numbers are
unmapped to the Social Security (Central) Rules 2026, §06.13) on the gross base, apply
per-employee **rupee rounding**, handle the **low-wage employer-only** case, and
**hold an employee in ESI to the
contribution-period boundary** (Apr–Sep / Oct–Mar) after their gross crosses ₹21,000
mid-period.
- *Detail.* This is the ESI trap from §06.3: an employee crossing ₹21,000 in, say, July
  continues to contribute through September, then exits from October. Dropping them in
  July files a wrong return (TV3). Overtime is **excluded from the ₹21,000 coverage
  test** but **included in the contribution base** once covered (TV5) — a subtle routing
  the wage-base resolver (FR-PAY-201) must encode. The separate coverage and
  contribution bases are verified; the overtime split itself is carried, not
  re-captured, so TV5 is a **[Hypothesis]** vector and the split is held as rule data,
  re-baselined once ESIC's wages page is re-captured (§06.3, §06.13).
- **AC-203.1** — An employee at ₹20,000 in June who is revised to ₹23,000 effective July
  continues ESI (on the full ₹23,000 gross) for July, August, September; ESI stops from
  October (TV3).
- **AC-203.2** — Contributions are rounded per employee, per side, by
  `esi.rounding_rule`, and the rounding is reproducible. v0.3's "round up to the next
  rupee" is the carried default, **[Hypothesis]** until re-captured from ESIC's
  contribution page (§06.3, §06.13).
- **AC-203.3** — An employee whose **average daily wage is ≤ ₹176** has the **employee
  0.75% share waived** while the **employer 3.25% share is still charged** (TV4; Source:
  ESIC contribution page, r1 [Verified]; the legacy ESI (Central) Rules r.52 citation is
  carried and unmapped to the 2026 Rules, §06.13). Charging both or waiving both is a
  filed error.
- **[Hypothesis / blocked]** — **AC-203.4** — ESI computation for periods **after the
  ~21 Nov 2026 one-year saving expires** depends on the unresolved successor instrument
  (§06.9, §06.13, §20 V-08). **Kill/gate criterion: if no successor is notified before the
  cliff, ESI for post-cliff periods is escalated and blocked, never guessed** — the
  filing calendar renders it `blocked-pending-regime` (FR-PAY-710).

**FR-PAY-204 · Professional Tax computation (per-state, effective-dated)** · **P0**
The engine shall deduct PT per the employee's **work-state** slab from the maintained
per-state PT table (§06.4), respecting gender variants, the **Article 276 ₹2,500/year
cap** (Source: Constitution of India, Art. 276; §06.4), and state-specific quirks (e.g.,
Maharashtra's and Karnataka's ₹300 February deduction; Source: state primary sources,
§06.4 [Verified]).
- *Detail.* PT follows place of employment, not residence — critical for remote/
  multi-state. Maharashtra and Odisha are verified at state primary sources; Karnataka's
  effect is verified but its instrument was not retrieved; every other state —
  Telangana's slab included — is unverified, and aggregator tables are disputed (§06.4,
  §06.13). The all-states PT table is a maintained-dataset build dependency, so v1 ships
  only states whose slabs are gazette-sourced, one design-partner state at a time
  (§05.5 item 5); all-states is P2 (§20 V-09). Neither Frappe HR nor TallyPrime ships a
  state PT slab table (EV-031 — Frappe's source repository read, not executed; EV-032 —
  TallyPrime's product documentation read, not executed; r3/r5 captures), so this table
  is differentiation, not parity.
- **AC-204.1** — A Maharashtra man with monthly salary above ₹10,000 is deducted ₹200 in
  each of the eleven months other than February and ₹300 in February, totalling exactly
  ₹2,500 for the year (TV10); at ₹7,500–₹10,000 the monthly figure is ₹175, and a woman
  is nil up to ₹25,000 (§06.4).
- **AC-204.2** — An employee in a state whose rule table records no PT levy has zero PT
  and no PT return is generated for that establishment. (Delhi, Haryana and Uttar
  Pradesh are listed as no-levy in §06.4, but the levy/no-levy list is **[Hypothesis]**
  until each state is verified against its own Act.)
- **AC-204.3** — Cumulative PT for any employee never exceeds ₹2,500 in a financial year
  even across multiple structures or mid-year revisions (Art. 276 cap enforced as a
  running annual ceiling, not a per-month rule).
- **[Hypothesis]** — **AC-204.4** — For a **fully-remote employee with no fixed work
  situs**, the engine applies the tenant's configured fallback (deduct at the
  registered-establishment state). **Kill criterion: replace the fallback with the
  verified state position once obtained (§06.13 open item); until then the conservative
  deduct-at-registered-state policy is flagged, not silently trusted.**

**FR-PAY-205 · TDS u/s 392 (ex-s.192), dual-regime** · **P0**
The engine shall compute monthly TDS by projecting annual tax under **both the new
default regime (s.115BAC) and the old regime**, honour the employee's **election** (and
new-regime default if silent), spread the liability across remaining months, and
**true-up** on every declaration, revision or perquisite change.
- *Detail.* Per §06.5: new-regime slabs (FY2025-26 verified, ITD portal AY 2026-27
  tables, r1) and the standard deduction per regime, held as
  `tds.standard_deduction.<regime>` (v0.3's ₹75,000 new / ₹50,000 old are carried
  parameter values, **[Hypothesis]**) vs old-regime Chapter VI-A (80C → s.123 at
  ₹1,50,000; 80D → s.126, r3/02 finding 19); s.87A rebate (FY2025-26: nil tax up to
  ₹12,00,000 taxable under the new regime, rebate up to ₹60,000, with marginal relief
  just above; §06.5 [Verified]); the inoperative-PAN branch, counsel-gated and held as
  `tds.inoperative_pan_rule` (AC-205.3); previous-employer income and other TDS/TCS via
  Form 122 (ex-12B/12BAA) for mid-year joiners; NPS employer contribution under
  s.80CCD(2), whose per-regime cap is held as `tax.nps_employer_deduction_pct.<regime>`
  (the §11 parameter; v0.3's "10% of Basic+DA old regime, 14% new regime" is carried,
  not re-captured, **[Hypothesis]**, routed to §20). Surcharge — 10% (₹50 lakh–1 crore), 15% (₹1–2 crore),
  25% (₹2–5 crore) in both regimes, and above ₹5 crore 37% in the old regime while the
  new stays at 25% — and cess at 4% on tax plus surcharge sit on the projected liability,
  with **marginal relief** at each surcharge threshold and at the rebate edge (ITD portal
  AY 2026-27 surcharge table, r1; §06.5 [Verified]). Three edge mechanics the engine
  must own, not the employee: **s.192(2B)** other-income and other-TDS declaration (may
  *increase* salary TDS but a declared loss under "income from house property" is the only
  head that may *reduce* it — no other loss can); **s.192(1A)** where the employer *bears*
  the tax on a non-monetary perquisite instead of deducting it from the employee; and
  **s.89(1) relief via Form 10E** — s.157(1) via Form 39 from Tax Year 2026-27 — when
  arrears or advance salary bunch income into one year (CBDT form mapping 10E→39 and
  s.89→s.157(1), r5/02 findings 27–28; the legacy rule reference v0.3 cited is carried,
  not re-captured). The substance of the s.192(2B) and s.192(1A) mechanics, like the
  80CCD(2) cap, is carried from v0.3 and was not re-captured in any research round:
  each is built as rule data under its 1961-Act label and is **[Hypothesis]** until read
  against the Income-tax Act 2025 and Rules 2026 text (§20). **Dual vocabulary
  (EV-050).** Tax Year 2026-27 onward runs under the Income-tax Act 2025 (s.392, ex-s.192; Forms 122, 123, 124 for ex-12B,
  12BA, 12BB); FY 2025-26 and earlier keep the 1961-Act labels, corrections included.
  The provisions named in this FR without a verified 2025-Act mapping — s.115BAC, s.87A,
  s.206AA, s.206AB, s.80CCD(2) and the s.192 sub-sections — are held as rule-version
  data under their 1961-Act label with the successor field left unmapped (§06.13); the
  engine never guesses a 2025-Act section number.
- **AC-205.1** — For a given gross and declaration set, the engine reports the tax under
  **both** regimes and the monthly TDS under the elected one; switching the election
  inside `tds.regime_switch_window` (FR-PAY-503) re-projects the remaining months
  without altering already-deducted amounts, and a switch outside it is refused with the
  reason (worked at §08.12 Example F).
- **AC-205.2** — A mid-year salary revision (FR-PAY-103) re-projects annual tax and
  redistributes the delta across remaining months (no lump-sum in the revision month
  unless remaining months = 1).
- **AC-205.3** — An employee with an **inoperative PAN** is flagged before the quarter's
  statement, and the deduction branch reads `tds.inoperative_pan_rule`, which **ships
  dark** with no default: with the parameter empty the run raises a configuration task
  (TV11, a counsel-gated vector). The higher-rate consequence and the short-deduction
  exposure are real (r5 counsel review), but the rate and section are not captured in
  any research round; v0.3's "higher of the applicable rate or 20% under s.206AA" and
  "s.206AB does not reach salary" are carried, not re-captured, and are **not** built as
  law (§06.5, §06.13). The employee's pay is never blocked, and no product copy states
  the employer's exposure either way until counsel opines (§23).
- **AC-205.4** — Perquisite values feed the TDS base at their taxable portion. The meal
  benefit is exempt up to ₹200 per meal from 01.04.2026 **only** where the K-19
  conditions hold — meals during working hours at office or factory premises, or
  non-transferable vouchers usable only at eating outlets; a meal benefit whose
  configuration fails either condition is valued as fully taxable, not capped. The
  gift/voucher threshold (₹15,000 per year) is carried the same way. Both figures are
  EV-019, **[Hypothesis]** (dated secondary sources; gazette text not read), and are
  effective-dated values owned by §11; the rule citation is routed to §20 V-18
  (§06.13), not stated here.
- **AC-205.5** — A mid-year joiner's **previous-employer income and TDS** (Form 122,
  ex-12B/12BAA) are added to the projection so the annual liability is not
  under-deducted; if the employee
  declines to declare, the engine projects on current-employer income only and records
  the election.
- **[Hypothesis]** — **AC-205.6** — The **Tax Year 2026-27 slabs, rebate and surcharge
  parameters** are loaded as an effective-dated rule version. **Kill criterion: re-verify
  the Tax Year 2026-27 slabs, rebate ceiling and standard deduction against the rates
  in force for Tax Year 2026-27 (and any corrigendum) before the first Tax Year 2026-27 run — FY2025-26 is verified, the
  current year is pending (§06.13).**
- **AC-205.7** — When a run pays **arrears/advance salary** that bunches income into the
  year, the engine computes the arrears-relief figure — **s.89(1) / Form 10E** for
  FY 2025-26 and earlier, **s.157(1) / Form 39** from Tax Year 2026-27 (r5/02 finding
  27) — and generates a relief-ready worksheet (per-year re-spread of the arrears to the
  years they relate to), so the employee's TDS reflects the relief where they elect it.
  The relief is computed deterministically, never estimated by the assistant (Source:
  CBDT form mapping 10E→39, s.89→s.157(1), r5/02 finding 27; §06.14 TV14). Example C's
  ₹30,000 arrears is the trigger case.
- **AC-205.8** — An employee's **s.192(2B) declaration** of other income raises the TDS
  base; a declared **house-property loss** (e.g., self-occupied home-loan interest, old
  regime only, within the cap held as `tax.house_property_loss_cap` — v0.3's ₹2,00,000
  carried, **[Hypothesis]**) reduces it; **any other head's loss is ignored** for salary
  TDS. Declaring a business loss to cut salary TDS is rejected with the reason shown
  (Source: 1961-Act s.192(2B), proviso — carried, not re-captured, §20).
- **AC-205.9** — For a **non-monetary perquisite on which the employer elects to bear the
  tax (s.192(1A))**, the borne tax is **not grossed into the employee's income** and is
  **not deductible** as the employee's TDS; it is recorded as an employer cost
  (FR-PAY-102) and reported correctly in the Form 138 data from which TRACES builds
  Form 130 (EV-048) and on the perquisite statement, Form 123 (ex-12BA) (EV-050)
  (Source: 1961-Act s.192(1A) and the s.40(a)(v) treatment — v0.3's reading, carried,
  not re-captured, **[Hypothesis]** until read against the 2025 Act, §20; Form 123's
  field layout is itself not yet captured, §06.13).

**FR-PAY-206 · Gratuity accrual and payout** · **P0**
The engine shall maintain a **running gratuity accrual ledger** per eligible employee
(from the 10-employee latch, §06.1/§06.6) and compute the **payout** on exit using
`(15/26) × last-drawn wages × completed years`, the 6-month rounding, the 5-year
qualifying rule (not applied on death, disablement or fixed-term expiry, where payment is
pro rata), the ceiling on gratuity **payable**, and the **tax-exemption** ceiling — two
different numbers that never share a field. "Wages" is the CoSS s.2(88) wage with the
50% add-back (§06.10), not Basic + DA alone, for Code-era periods. (Source: CoSS
ss.53–56 [Verified] — the Payment of Gratuity Act is repealed; its s.4 and the other
legacy references are carried, not re-captured, §06.6. The payable ceiling is "such
amount as may be notified" under CoSS s.53(3) and is held as `gratuity.payable_ceiling`:
the familiar ₹20 lakh is a legacy of the repealed Act, **[Hypothesis]** until a
Code-era notification is located. The exemption ceiling is a lifetime, cross-employer
aggregate held as `tax.gratuity_exemption_ceiling` under 1961-Act s.10(10): v0.3's
₹20 lakh and the notification it cited are carried, not re-captured, **[Hypothesis]**,
and the 2025-Act equivalent is unmapped — §06.6, §06.13.)
- **AC-206.1** — For last-drawn wages ₹52,000 (Basic + DA, no other wage component)
  and 7 years 8 months service, payout =
  (15/26) × 52,000 × 8 = **₹2,40,000**, taxed per `tax.gratuity_exemption_ceiling`
  net of the exemption the employee declares as already used (§06.6 worked example reproduced as a
  test).
- **AC-206.2** — 6-month rounding runs **both directions** (TV8): 7y 8m → 8 completed
  years; 7y 4m → 7 completed years. Rounding the two the same direction is a defect.
- **AC-206.3** — An employee dying at 3 years' service receives gratuity (5-year rule
  waived); an employee resigning at 4 years 5 months does not qualify.
- **AC-206.4** — The accrual ledger value is queryable as-of any date for the books
  (AS 15 / Ind AS 19), independent of whether payout has occurred.

**FR-PAY-207 · LWF deduction** · **P0**
The engine shall deduct employee LWF and accrue employer LWF per the maintained
per-state LWF table (§06.8), on that state's **periodicity** (monthly / half-yearly /
annual).
- *Detail.* LWF rupee values and periodicity vary by state and are **not** yet verified
  per state (§06.8, §06.13 open item); no LWF rate or split has been verified from a
  government source in any state, and the only verified periodicity is Karnataka's
  calendar-year cycle due 15 January. **[Reversed]** An earlier draft cited "Frappe
  corroborates ~14 LWF states" and, with it, the conclusion that LWF earned no
  differentiation credit. Frappe HR v16 has no LWF at all (EV-031, source repository
  read, not executed) and TallyPrime has no LWF engine (EV-032, product documentation
  read, not executed), so a maintained LWF table is greenfield in both incumbents
  (K-01).
- **AC-207.1** — A Karnataka employee is deducted the employee share, and the employer
  share accrued, once per calendar year for remittance by **15 January** — not monthly
  (§06.8, periodicity **[Verified]**; amounts **[Hypothesis]**). A half-yearly state is
  deducted only in its deduction months; Maharashtra's June and December cycle is the
  expected example but is **[Hypothesis]** until verified against the state Act (§06.8).
- **AC-207.2** — Employees in no-LWF states have zero LWF and no LWF remittance.
- **[Hypothesis]** — **AC-207.3** — The per-state LWF rupee values are loaded from the
  maintained table as `lwf.<state>.employee`, `lwf.<state>.employer` and
  `lwf.<state>.wage_threshold` — for Maharashtra and Karnataka the compilations disagree
  on the amounts themselves (§06.8), so no figure ships as a default. **Kill criterion:
  verify each state's rupee value and periodicity against that state's LWF Act before it
  drives a deduction (§06.13); an unverified value is flagged, not deducted silently.**

**FR-PAY-208 · Statutory bonus (Code on Wages s.26; legacy Payment of Bonus Act)** · **P0**
The engine shall compute **statutory bonus** for eligible employees, accrue it monthly,
and pay it on the annual cadence, using the correct eligibility ceiling, calculation
ceiling, and minimum/maximum percentages.
- *Detail.* The Payment of Bonus Act 1965 is subsumed by the Code on Wages (§06.7).
  Code on Wages s.26 fixes the percentages — minimum 8.33% of wages earned or ₹100,
  whichever is higher; maximum 20% — and delegates the calculation ceiling to "such
  amount per mensem, as determined by notification by the appropriate Government", or
  the minimum wage, whichever is higher **[Verified]**. The familiar figures are legacy:
  eligibility wage ≤ ₹21,000/month and calculation ceiling ₹7,000, the Payment of Bonus
  (Amendment) Act 2015 values per a law-firm note (r1, medium; the POB section
  references are carried, not re-captured); no Code-era re-notification, central or
  state, has been located **[Hypothesis]**. Eligibility also needs at least 30 working
  days in the accounting year (Code on Wages s.26(1), r1). The legacy payment deadline
  (within 8 months of the accounting year's close — **30 November** for April–March)
  and the legacy return (**Form D**, with registers maintained) rest on compliance
  blogs only (r1, low) and are unresolved for Code-era
  years, so both are named configurable parameters — `bonus.payment_deadline` and
  `bonus.annual_return_form` — never hard-coded, and routed to §20 (§06.7). The bonus
  wage base (I1) is the capped figure, **not** actual wages — TV9 is the golden case.
  A statutory bonus is **invisible to ECR/ESI** but **visible to Form 138** (§06.12
  R12) — the same rupee routes differently per return.
- **AC-208.1** — For an employee on ₹18,000/mo wages in a scheduled employment with
  minimum wage ₹10,000, the bonus base is **₹10,000** (not ₹18,000, not a flat ₹7,000)
  and bonus at the declared percentage is computed on ₹10,000 × 12 (TV9).
- **AC-208.2** — An employee on wages **above ₹21,000/mo** is **not eligible** for
  statutory bonus (the legacy eligibility ceiling; the Code-era ceiling is per the
  appropriate Government, AC-208.4); any ex-gratia paid instead is flagged as ex-gratia, taxed, and
  excluded from the bonus return.
- **AC-208.3** — Bonus accrues monthly to an employer-cost ledger (FR-PAY-102), the
  payout run computes TDS on the bonus at the marginal projected rate (FR-PAY-205), and
  the bonus is included in Form 138 but **not** in that month's ECR/ESI wage base.
- **[Hypothesis]** — **AC-208.4** — The ₹21,000/₹7,000 ceilings are the legacy 1965-Act
  values. **Kill criterion: verify whether the Central Government or the tenant's state
  has notified Code-era ceilings under Code on Wages s.26 before computing bonus for any
  accounting year after 21.11.2025 (§06.7, §06.13); until then the legacy figures drive
  only a provisional computation, clearly labelled, and a bonus payout requires the
  operator to confirm the ceiling in force and record its source.**

**FR-PAY-209 · Computation ordering and rounding policy** · **P0**
The engine shall apply statutory computations in a **defined, documented order**
(earnings → wage-base resolution → PF/ESI/PT/LWF/bonus-accrual → taxable income → TDS →
net), with a single tenant-level **rounding policy** applied consistently and
reproducibly.
- *Detail.* Order matters: PT and PF (old regime) are deductions that affect taxable
  income; TDS is computed after them. The order is a dependency graph, not a strict
  one-pass sequence: where a dependency loops back on itself — the s.2(y) add-back
  inside a balance-figure CTC, or a net-of-tax gross-up — the loop is evaluated as a
  bounded fixed-point node (FR-PAY-211), and statutory rounding is applied **once, after
  convergence**, never inside the iteration. Rounding must be defined per statute and
  must not drift between runs. The rounding policy is a versioned rule (I2), not code.
  Where the evidence does not state a rounding method, the method is a named
  configurable parameter routed to §20 — never a guessed statutory rule.

| Head | Rounding rule | Source |
| --- | --- | --- |
| ESI (each side, per employee) | v0.3's round **up** to the next rupee, carried as the default | `esi.rounding_rule` — carried, not re-captured, **[Hypothesis]** until re-captured from ESIC's contribution page (§06.3, §06.13) |
| EPF (each head) | The EPFO Help File's sample return lines carry whole-rupee amounts (r5/02 finding 3; §06.14 TV16); the published manual states neither a rounding method nor whether decimals are accepted | `epf.rounding_method` — configurable, routed to §20 |
| PT | Whole-rupee slab value, no rounding | State PT Acts (§06.4) |
| TDS | The Form 138 file carries amounts to two decimals (r5/02); the rounding of the monthly deduction and of the annual liability is not established in this PRD's evidence | `tds.rounding_method` — configurable, routed to §20 |
| Net pay | Round to the rupee; residue absorbed per FR-PAY-101 AC-101.3 | tenant policy |

- **AC-209.1** — Re-running an unchanged period reproduces byte-identical figures (I4).
- **AC-209.2** — The sum of employee-level rounded figures reconciles to the challan
  total the return expects (no penny-rounding gap that fails ECR/ESI validation).
- **AC-209.3** — **Global precision policy.** Every monetary value is held as an exact
  decimal, never a binary float, at the internal scale `money.internal_scale` (a design
  parameter, not a statutory one). Components carry code R0 (FR-PAY-108): nothing is
  rounded until a statutory head or a payable figure is formed, and each rounding
  point — a statutory head, net pay, a file amount — applies its own rule from the
  table above exactly once. A figure written to a statutory file is rendered at the
  precision that file's layout specifies (whole rupees in the ECR sample lines; two
  decimals in the Form 138 file, r5/02), never at the internal scale.
- **AC-209.4** — **Statutory exceptions win over tenant policy.** A tenant rounding
  preference applies only where the table says "tenant policy"; it can never override
  a head whose rule is statutory or pending as a named parameter (`esi.rounding_rule`,
  `epf.rounding_method`, `tds.rounding_method`). Changing any of them is a new rule
  version, never a retroactive re-rounding of a LOCKED month (AC-104.2 pattern).

**FR-PAY-210 · Engine purity and the enumerated evaluation context** · **P0**
The engine shall evaluate every employee-period as a pure function of **(input
snapshot, rule-set version, evaluation context)** (I6, Part E-3), where the evaluation
context is a closed, enumerated record — **disbursal date**, **as-of decision time**,
**jurisdiction set**, **tax-regime election** — stored with the run.
- *Detail.* The four context fields are the only facts evaluation may use that are not
  in the input snapshot or the rule set. **Disbursal date:** planned when the month is
  APPROVED, replaced by the actual date captured at DISBURSED (bank confirmation,
  FR-PAY-903). **As-of decision time:** the transaction-time cut that fixes which rule versions and
  facts were known — replay uses the original, a retro recompute uses a new one against
  the period's rule versions (I3). **Jurisdiction set:** per employee-period, resolved
  from the assignment's work location — state, sphere, Code-regime commencement date
  (Part E-5). **Tax-regime election:** the employee's election in force at the decision
  time, new regime if silent (FR-PAY-205).
- **AC-210.1** — An evaluator run with clock and database access removed produces the
  same figures as the production evaluator; any read outside (snapshot, rule set,
  context) is a build failure, not a runtime warning.
- **AC-210.2** — Every run record carries its full evaluation context, and the audit
  answer for any figure (FR-PAY-1001) includes it.
- **AC-210.3** — When the actual disbursal date differs from the planned one, the engine
  re-evaluates only the date-keyed outputs — the PF due month for arrears (Part E-9,
  FR-PAY-401), the Form 138 deductee date of payment and its quarter and tax year
  (r5/02 finding 32), and the start of any interest exposure — and records the change as
  a diff against the approved figures. An approved figure is never silently changed; a
  date change that moves a deduction into a different quarter or tax year is surfaced to
  the approver before PAYMENT_INITIATED.
- **AC-210.4** — Replaying a run with its stored context reproduces it byte-identically
  (I4); recomputing it with a new decision time is labelled a recompute, and both
  results keep their own context in the audit trail.

**FR-PAY-211 · Bounded fixed-point nodes in the calculation graph** · **P0**
The engine's calculation graph shall permit explicitly declared **fixed-point nodes**
that iterate to convergence under a maximum iteration count and a tolerance (I7,
Part E-4), instead of assuming a one-pass topological evaluation.
- *Detail.* Two loops are known. (1) **The s.2(y) add-back inside a balance-figure
  CTC.** When CTC closes on a special-allowance balance figure (FR-PAY-101) and carries an
  employer-cost line computed on statutory wages — the gratuity accrual (FR-PAY-102,
  FR-PAY-206) — the add-back raises wages, which raises the accrual, which lowers the
  balance figure, which lowers "all remuneration", which changes the add-back: the
  add-back re-bases a component that feeds its own test (§06.10). Worked at §08.12
  Example G. (2) **Net-of-tax gross-up**, where gross pay is solved from a target net
  and the tax depends on the gross. The iteration limit and tolerance are versioned
  engine parameters — `fixed_point.max_iterations` and `fixed_point.tolerance` — not
  statutory values; statutory rounding happens once, after convergence (FR-PAY-209).
- **AC-211.1** — Fixed-point nodes are declared in the graph, each with its loop members,
  iteration limit and tolerance; every node outside a declared loop evaluates once, in
  dependency order. An undeclared cycle is a build-time error.
- **AC-211.2** — Example G reproduces exactly: convergence at iteration 5 (change in
  wages under ₹0.01) to wages ₹48,826.29, gratuity accrual ₹2,347.42, special allowance
  ₹7,652.58 and add-back ₹11,173.71; CTC reconciles to the rupee (AC-102.2) only at the
  converged values.
- **AC-211.3** — A node that has not converged at its iteration limit stops the run at
  PROCESSED with a blocking validation (FR-PAY-1004) naming the node, the employee and
  the last two iterates. A first or intermediate iterate is never published as a figure.
- **AC-211.4** — Convergence is deterministic: the same snapshot, rule-set version,
  context and parameters produce the same iteration count and figures (I4).

---

### 08.4 Pay-run lifecycle

The pay run is the transactional heart of the engine. Its state machine is what makes
payroll auditable and reversible. **[Reversed]** Earlier drafts specified
Draft → Inputs Locked → Computed → Review → Approved → Paid → Filed → Closed. That
machine had no payment-initiation state, so the one irreversibility line the revamped
ECR creates had nowhere to live, and its post-filing "file a revised return" loop
ignored the EV-037 guards — a Revised ECR is impossible once payment is initiated
(Part E-1). It is replaced by the machine below; the diagram illustrates, the
transition table is the specification.

<!-- DIAGRAM: payrun-state-machine -->

**FR-PAY-301 · Payroll-month state machine** · **P0**
A payroll month (one pay group × establishment × wage month) shall progress through
explicit, logged states: **OPEN → INPUTS_CLOSED → PROCESSED → APPROVED → LOCKED →
DISBURSED → PAYMENT_INITIATED → FILED**, reversible **before LOCKED** and immutable
from LOCKED onward. The **statutory verification gate sits immediately before
PAYMENT_INITIATED** (EV-037), and a correction after LOCKED — including after FILED —
is a **diff, never a mutation**.
- *Detail.* Each transition is an audit event (I5). PROCESSED may repeat: the operator
  processes, inspects and reprocesses until satisfied — the product is built for
  iterate-and-diff, not one clean run. The gate is placed where it is because the
  revamped ECR separates return submission from payment (EV-036): an approved return
  can never be cancelled, and a Revised return — the only way to correct downward — is
  allowed only while no payment has been initiated for the wage month (EV-037). After
  PAYMENT_INITIATED a downward EPF correction is impossible, so every check that could
  prevent one must run before it. FILED is distinct from DISBURSED because the filing is
  the unit of delivery: a month is not done when salaries reach bank accounts.

| # | From → To | Event | Guard | Side effect | Who may trigger |
| --- | --- | --- | --- | --- | --- |
| M1 | *(none)* → OPEN | Period opened | Pay group, establishment and the period's rule-set versions resolve | Filing instances for the period created as SCHEDULED (FR-PAY-711) | System scheduler, or payroll operator |
| M2 | OPEN → INPUTS_CLOSED | Close inputs | Pre-payroll checklist items closed or waived with a recorded reason | Input snapshot frozen (FR-PAY-302); later source edits queue as adjustments | Payroll operator (maker) |
| M3 | INPUTS_CLOSED → OPEN | Reopen inputs | State is before LOCKED | Snapshot superseded; both versions kept | Payroll operator |
| M4 | INPUTS_CLOSED → PROCESSED | Process | Evaluation context complete (FR-PAY-210) | Gross-to-net, wage bases, variance view (FR-PAY-303); fixed-point nodes converge (FR-PAY-211) | Payroll operator; repeatable |
| M5 | PROCESSED → PROCESSED | Reprocess | Snapshot unchanged, or reopened via M3 | New result version; prior versions kept for diff | Payroll operator |
| M6 | PROCESSED → APPROVED | Approve | No blocking validation open (FR-PAY-1004); approver is not the maker (FR-PAY-304) | Approval artefact recorded — totals, variance with per-employee drivers, statutory liability with due dates; planned disbursal date fixed in the context | Approver (checker) |
| M7 | APPROVED → PROCESSED | Return for correction | State is before LOCKED | Approval voided, reason recorded | Approver |
| M8 | APPROVED → LOCKED | Lock | Approval current | Results immutable; payslips published (FR-PAY-601); bank file generated (FR-PAY-901); filing artefacts may be generated from the locked snapshot (FR-PAY-711) | Approver |
| M9 | LOCKED → DISBURSED | Salaries released | Release by a payment approver distinct from the processor (FR-PAY-904) | Actual disbursal date replaces the planned one (FR-PAY-210 AC-210.3); UTRs captured (FR-PAY-903) | Payment approver |
| M10 | DISBURSED → PAYMENT_INITIATED | Initiate statutory payment | **Verification gate:** every statutory payment the month owes reconciles to the locked snapshot; for the ECR, the approved return statement matches it line for line; no downward correction is pending; any s.7Q interest the portal has auto-calculated is included, because it must be paid with the contribution (EV-039); the named approver confirms | Challan payment initiated in an attended portal session (§22); from here a Revised ECR is impossible (EV-037) | Named approver (customer); executed by the customer or our operator under written authority to act |
| M11 | PAYMENT_INITIATED → FILED | Monthly filings complete | Every monthly filing instance for the period is FILED — acknowledgement and payment receipt captured (FR-PAY-711); quarterly and annual statements run on their own instances | Month counted for the on-time metric (§01, §19) | System on acknowledgement capture, or operator |
| M12 | LOCKED, DISBURSED, PAYMENT_INITIATED or FILED → same state | Correction required | — | No mutation: a correction run (arrears, off-cycle, F&F) is created as a diff against the locked snapshot (FR-PAY-306); its filings follow EV-037 guards, the fenced arrear flow (EV-043) or a Form 138 correction statement (FR-PAY-708) | Payroll operator (maker) plus approver |

- **AC-301.1** — No payroll month reaches APPROVED while any blocking validation
  (FR-PAY-1004) is unresolved.
- **AC-301.2** — Every state transition records actor, timestamp, and (for APPROVED,
  LOCKED, DISBURSED and PAYMENT_INITIATED) the authorising role.
- **AC-301.3** — A month cannot reach PAYMENT_INITIATED while the verification gate
  (M10) fails; the failure names the reconciling item. A downward difference found at
  the gate is corrected by a Revised return before payment, never after.
- **AC-301.4** — Any attempt to edit a figure in a LOCKED or later month is refused and
  redirected to a correction run; the locked snapshot and every filed artefact stay
  byte-identical.

**FR-PAY-302 · Input locking** · **P0**
On entering INPUTS_CLOSED, the engine shall **snapshot** all inputs that feed the run
(attendance/LOP, variable pay, reimbursement claims, declaration changes, joins/exits,
compensation revisions) so later edits to source data do not silently alter a computed
run.
- **AC-302.1** — An attendance correction made after inputs are locked does not change
  the current run; it surfaces as an arrears/adjustment item for the next run
  (FR-PAY-401) or requires an explicit reopen.

**FR-PAY-303 · Compute and preview** · **P0**
On each entry to PROCESSED, the engine shall produce, for every employee, the full
gross-to-net breakdown, all statutory figures, employer costs, and a **variance view** against the
prior period (new joiners, exits, absolute and % change per employee, flagged outliers).
- **AC-303.1** — The variance view flags any employee whose net changed by more than a
  configurable threshold (default ±25%) with the driver (revision / LOP / arrears /
  declaration / one-time).
- **AC-303.2** — Run totals (gross, deductions, net, employer cost, each statutory head)
  are shown and reconcile to the sum of employee figures to the rupee.

**FR-PAY-304 · Maker-checker approval** · **P0**
The engine shall enforce **segregation of duties**: the actor who computes/edits a run
cannot be the sole approver; approval requires a distinct authorised role.
- **AC-304.1** — A single user cannot both edit figures and approve the same run unless
  explicitly granted a combined role with that combination logged as a policy exception.

**FR-PAY-305 · Off-cycle pay runs** · **P0**
The engine shall support **off-cycle runs** (bonus, incentive, one-time payout,
correction) that are computed, taxed and filed correctly alongside the regular monthly
run, feeding the same statutory returns for the period.
- **AC-305.1** — A mid-month bonus off-cycle run computes TDS on the bonus at the
  marginal projected rate and its PF/ESI treatment per the component's wage-base flags.
- **AC-305.2** — Off-cycle PF contributions for a wage month consolidate into that
  month's **Regular** ECR return when the off-cycle run is LOCKED before the Regular
  return is generated — never a second Regular return. After the Regular return is
  approved, the engine routes by the EV-037 guards: members absent from every prior
  return for the month go on a **Supplementary** return; a change for members already
  returned goes on a **Revised** return only while no payment has been initiated for the
  month; otherwise the amount is held for the separate arrear flow, which is fenced
  (EV-043). ESI off-cycle amounts consolidate into the month's contribution upload when
  LOCKED before it is prepared; ESIC's correction path after upload is not established
  in this PRD's evidence and is routed to §20. (An off-cycle *pay run* is not an EPFO
  Supplementary *return*; the two are named apart everywhere in the product.)

**FR-PAY-306 · Reopen and correction** · **P0**
The engine shall support **reopening** a payroll month before LOCKED (FR-PAY-301
M3, M7) and **correcting** a LOCKED or later month only through a compensating
correction run — a diff against the locked snapshot, with full audit lineage — never by
editing or deleting history.
- **AC-306.1** — Correcting a disbursed month creates an offsetting correction run; the
  original remains in history byte-identical; net effect on the employee and on
  statutory totals is traceable.
- **AC-306.2** — A month that has reached FILED cannot be silently reopened; a
  correction after filing forces the correction path — Supplementary or Revised ECR
  within the EV-037 guards, the fenced arrear flow (EV-043), or a Form 138 correction
  statement (FR-PAY-708).

---

### 08.5 Arrears, retrospective recompute, and adjustments

This group is where I3 (retro against the period's rule version) becomes a feature, and
where spreadsheet workflows break: "difference × months" is the spreadsheet method and
it is wrong whenever a rule moved inside the retro window. (Whether TallyPrime recomputes
arrears per period against the period's rules is not established in our evidence —
EV-032 does not cover it — so no competitive claim is made here.)

**FR-PAY-401 · Arrears from effective-dated revisions** · **P0**
When a compensation revision is effective in a closed period (FR-PAY-103), the engine
shall compute **arrears** by recomputing each affected past period **against that
period's rule versions and inputs**, and pay the delta in the current run.
- *Detail.* This is not "difference × months." It is a full recompute per past period:
  the revised gross changes PF, ESI, PT and TDS for each of those months, computed with
  the slabs and ceilings that were in force then (I3; §06.14 TV12). Worked at §08.12
  Example C.
- **AC-401.1** — A ₹60,000→₹70,000 revision effective 1 April, processed in July,
  recomputes April, May, June each against April/May/June rules; the arrears line shows
  the per-head delta (gross, PF, ESI, PT, TDS) per month, summed.
- **AC-401.2** — Arrears PF is **computed** against the wage months, and the rule
  versions, to which the arrears relate, but the PF **liability** on them dates from the
  **disbursal date**, not the wage month (Part E-9; §06.2). The PF due month is derived
  from the disbursal date held in the evaluation context (FR-PAY-210), and the product
  distinguishes true arrears (e.g., a revision) from merely belated salary, as EPFO's
  revamped-ECR FAQ does (§06.2). Arrears PF is **not** written into the monthly ECR files
  of the corrected months: EPFO takes arrears through a separate "File Arrear Return"
  flow whose layout is not published, so the arrear file generator is **fenced** (EV-043)
  and the arrears liability is carried on the filing ledger as BLOCKED-pending-layout
  (FR-PAY-711, FR-PAY-712) with its due month shown. Arrears TDS is trued-up in the
  current projection.
- **AC-401.3** — If a rule changed between the corrected period and today (e.g., a PT
  slab revision), the recompute uses the **old** slab for the old months (TV12).
- **AC-401.4** — When the arrears batch is **approved** (FR-PAY-301 M6), the approval
  artefact states the PF liability date computed from the planned disbursal date and the
  resulting due month, so the approver sees the cash and filing consequence before
  money moves; a change in the actual disbursal date re-derives it under AC-210.3.

**FR-PAY-402 · Retrospective statutory recompute** · **P1**
The engine shall support recomputing a closed period when a **rule** changes
retroactively (e.g., the 12% PF re-notified retrospective to 21.11.2025 by S.O.
3582(E), §06.9), producing the corrected figures and the delta to file. (Source: S.O.
3582(E), re-notification of EPF Scheme 2026 rate.)
- **AC-402.1** — Applying a retroactive rate change to a range of past periods produces,
  per period, the recomputed figures, the delta, and a filing-correction task
  (FR-PAY-708) routed by the EV-037 guards or to the fenced arrear flow (EV-043).

**FR-PAY-403 · Ad-hoc adjustments and recoveries** · **P0**
The engine shall support one-time **additions** (reimbursement top-ups, incentives) and
**deductions/recoveries** (salary advance recovery, notice-pay recovery, excess-payment
recovery, canteen/asset recovery) with their correct tax and wage-base treatment.
- *Detail.* Recoveries must respect the payment-of-wages deduction ceiling: total
  deductions in any wage period may not exceed 50% of wages, and any excess "may be
  recovered in such manner, as may be prescribed" (Code on Wages s.18(3)–(4), verified
  verbatim, r1). The prescribed manner under the Wages Rules is not captured, so the
  carry-forward method is held as `wages.deduction_overflow_method` and routed to §20 — a
  recovery that would breach the cap is flagged and spread, never silently applied.
- **AC-403.1** — A salary-advance recovery of ₹5,000/month reduces net by ₹5,000, does
  not reduce the PF/ESI/tax base (it is a post-tax recovery), and tracks the outstanding
  advance balance to zero.
- **AC-403.2** — A recovery that would push total deductions above the Code on Wages cap
  is blocked/spread with the ceiling shown, not silently applied.

---

### 08.6 Reimbursements and Flexible Benefits (FBP)

Per §11, the FBP data model is P1 (build the model, defer monetisation) but its tax
treatment touches TDS, so the computation hooks are P0.

**FR-PAY-501 · FBP declaration and wallet** · **P1**
The engine shall let employees allocate a **flexible benefit budget** across declared
heads (fuel/conveyance, LTA, telephone, books/periodicals, meal cards, NPS employer
contribution, etc.), within statutory tax-exemption limits, and shall reflect the
declaration in the TDS projection.
- *Detail.* The 01.04.2026 expansion — meal perquisite ₹50→₹200 per meal, gift/voucher
  ₹5,000→₹15,000 per year (EV-019, **[Hypothesis]**: dated secondary sources, gazette
  text not read; §20 V-18) — is a config value in the exemption
  table, effective-dated, not a code change (§11). **The meal figure is only half the
  rule (K-19):** the exemption holds only for meals provided during working hours at
  office or factory premises, or for non-transferable vouchers usable only at eating
  outlets. Those conditions are **engine constraints on the wallet configuration**, not
  a wallet limit: a meal instrument configured as transferable, or redeemable outside
  eating outlets, is valued as a fully taxable perquisite. Without the constraints the
  perquisite is taxable, every affected payslip under-deducts, and the demand plus
  interest lands on the employer. The rule citation is routed to §20 validation
  (§06.13); no rule number is stated here.
- **AC-501.1** — An employee declaring ₹2,400/month meal-card allocation, on a card
  configured as non-transferable and usable only at eating outlets, has it treated as
  tax-exempt up to the ₹200-per-meal × working-meals limit; the excess is taxable and
  flows to TDS. The same allocation on an instrument that fails either condition is
  taxable in full, and the configuration screen says why.

**FR-PAY-502 · Reimbursement claim and proof-of-spend** · **P1**
The engine shall accept reimbursement **claims with proof (bill upload)**, run them
through an approval workflow, and pay approved claims through payroll or off-cycle, with
the **tax-exempt vs taxable split** determined by proof and limit.
- **AC-502.1** — A ₹30,000 LTA claim with valid travel proof, within the block-year
  exemption, is paid tax-exempt; without proof it is paid as a **taxable** allowance and
  TDS is adjusted.
- **AC-502.2** — Unclaimed FBP balances at year-end are paid out as **fully taxable**
  special allowance and the TDS is trued-up in the final run of the tax year.

**FR-PAY-503 · Investment declaration and proof workflow** · **P0 (tax hook)**
The engine shall support the **declaration** (provisional, drives TDS from the start of
the year) and later **proof submission** (actuals, trues up TDS in the last quarter) for
old-regime Chapter VI-A and HRA claims.
- *Detail.* This was once mis-named as a P0 differentiator — against Zoho it is
  **table stakes**, present even in the free tier ([Killed] as a differentiator; Source:
  Zoho Payroll's rendered pricing page lists "Proof of investments approval" in its ₹0
  tier — documentation read, not executed, r2/01 finding 5; §21.6). The declaration is
  Form 124 (ex-12BB) from Tax Year 2026-27 (EV-050). It is built because it is required
  for correct TDS, not because it wins deals. Phase-tagged **P0 (tax hook)**: the FBP UI
  is P1 but the declaration→TDS computation path is P0. The declaration window's lock
  date and the true-up month are employer choices (r3/02 finding 23). When an employee
  may switch regime is held as `tds.regime_switch_window`: Zoho's documentation allows a
  switch only before the year's first payroll (r3/02 finding 22), but that is one
  vendor's product rule, not a statutory one, and the legal position is routed to §20.
- **AC-503.1** — A declared ₹1,50,000 80C (s.123 from Tax Year 2026-27, r3/02 finding
  19) reduces monthly TDS from April (old regime); if proof of only ₹1,00,000 is
  submitted by the proof deadline, TDS in the employer's configured true-up month is
  increased to recover the shortfall.
- **AC-503.2** — HRA exemption is computed as the least of (actual HRA; rent minus a
  percentage of salary; a metro or non-metro percentage of salary) and drives the
  old-regime TDS base. The percentages and the metro-city list are held as
  `tax.hra.rent_offset_pct`, `tax.hra.metro_pct`, `tax.hra.nonmetro_pct` and
  `tax.hra.metro_cities`: v0.3's 10% / 50% / 40% and its 1961-Act s.10(13A) and
  Rule 2A citation are carried, not re-captured, **[Hypothesis]**, and a reported
  extension of the metro list was retracted in r1 for want of a legal anchor (§20).
  Landlord PAN is captured above the annual-rent threshold held as
  `tax.hra.landlord_pan_threshold` (₹1,00,000 in Zoho's declaration form, r3/02 finding
  21 — vendor documentation, confirmed against the Form 124 guidance note before use,
  §06.13).

---

### 08.7 Payslips

**FR-PAY-601 · Payslip generation** · **P0**
The engine shall generate a per-employee **payslip** for each finalised run, itemising
earnings, deductions, employer contributions (informational), net pay in figures and
words, paid/LOP days, and YTD figures, in a **prescribed-compliant wage-slip format**
— in the central sphere, Form V under the Code on Wages (Central) Rules 2026 and Form XVI
under the OSH (Central) Rules 2026 — with the form number configurable per state,
because state rules prescribe their own forms (EV-053; §06.9).
- **AC-601.1** — The payslip reconciles: gross earnings − total deductions = net pay,
  to the rupee, matching the pay run.
- **AC-601.2** — The payslip shows the statutory identifiers required (UAN, PF number,
  ESI IP number where applicable, PAN) and the employer's establishment details.
- **AC-601.3** — Payslips are **immutable once published**; a correction produces a
  revised payslip with a visible revision marker, never a silent overwrite (I5).

**FR-PAY-602 · Payslip distribution and self-service** · **P0**
Employees shall access current and historical payslips through the employee surface
(web/mobile app), with password/OTP protection on downloads. The employee surface is
parity with Frappe's PWA (source repository read, not executed, r3/01 finding 14);
whether TallyPrime ships employee self-service is one of the four deliberately
unresolved parity cells (EV-032) — Tally's marketing claims a self-service portal that
its help documentation does not show — so it is not claimed as a differentiator
against Tally (§04.1, §21.3).
- **AC-602.1** — An employee can retrieve any historical payslip for the retention
  period without an admin request.

**FR-PAY-603 · Tax-projection statement** · **P1**
The engine shall provide employees a **tax computation sheet** (both regimes, current
projection, declarations applied, TDS to date and remaining) so the payslip is
explainable.
- **AC-603.1** — The projection statement's remaining-months TDS sums with TDS-to-date
  to the projected annual liability under the elected regime.

---

### 08.8 Statutory returns and certificates

This is the delivery layer — the artefacts §01 and §04.1 say the customer actually pays
for. The computation is §06; this group specifies **generation, validation, attended
submission support and correction** of each return. The engine generates the artefact
and mirrors the checks the portal is documented to run; **submission is an attended
portal session** —
performed by the employer, or by our operator under the employer's written authority to
act — because we are not aware of any statutory portal offering a submission API as of
September 2026, and the employer's and deductor's liability is non-delegable (K-13;
runbooks in §22; legality under counsel review, §23.13, Part D-17). All file layouts are **versioned schemas** (I2, §06.12 R6):
field numbers are never hard-coded. Every filing moves through the filing-instance state
machine (FR-PAY-711).

<!-- DIAGRAM: journey-month-end-filing -->

**FR-PAY-701 · EPF ECR return file, part-payment file and attended return flow** · **P0**
The engine shall generate the **Electronic Challan-cum-Return (ECR)** return file exactly
to the published layout (EV-035) and, as a separate export, the part-payment
contribution file (EV-044); pre-validate both against the checks EPFO runs, at EPFO's
own block/flag severity (EV-040); and support the attended upload → validate → return
statement → approve → Due Deposit Balance Summary → challan with TRRN → pay → receipt
flow (EV-036), reconciling the portal's return statement and challan against the
computed contributions. The engine does not submit; the upload is an attended session
(K-13, §22).
- *Detail.* ECR is the master EPF filing (§06.2), contributions due by the 15th, built
  against **Scheme 2026** (§06.9; Source: EPF Scheme 2026 / S.O. 3582(E)). The
  re-engineered ECR (beta, from wage month September 2025) changed workflow, validation and the
  payment lifecycle but **not** the file layout (EV-035), so the generator is buildable
  now and is no longer fenced (§05.5 item 3); the engineering effort is in the state
  machine, sequencing and pre-validation, not in file I/O. EPFO mandates no filename
  pattern (EV-035); the upload notice requires an alphanumeric filename, a lowercase
  `.txt` extension, at most 8 MB, compression above 2 MB, and exactly one text file per
  zip (r5/02 finding 5). NIL months use no file (EV-042, FR-PAY-712); arrears are not in
  this file (EV-043, FR-PAY-401); VPF and International Workers stay within it (EV-045).
- **AC-701.1** — The file's member lines sum to the computed contributions and, after
  upload, to the portal's return statement and Due Deposit Balance Summary (EV-036);
  employer EPS never exceeds ₹1,250 per member (the §06.2 TV1 negative test surfaced at
  file level).
- **AC-701.2** — Members with **un-seeded/KYC-incomplete UANs** are flagged **before**
  file generation (§06.12 R9), not after portal rejection. The default is
  **exclude-and-flag**, with notices to the operator and the employee — **never a
  payroll block**, because the product treats Aadhaar as optional in EPF flows too
  (Part E-11; §06.2; §06.14 TV13). Whether Aadhaar submission may be made a condition of
  payroll or of a benefit is not stated here (Part D-10), and no hard-block configuration
  ships; the alternatives and the final choice sit with counsel (§07, §23).
- **AC-701.3** — The engine can reproduce a **3A/6A-equivalent register** for audit and
  for Tally migration (§06.12 R10).
- **AC-701.4** — The return file is one line per member, **no header row**, exactly
  **11 fields** in the EV-035 order — UAN; Member Name as per UAN; Gross Wages; EPF
  Wages; EPS Wages; EDLI Wages; Employee PF Contribution; Employer EPS Contribution;
  Employer PF Contribution; NCP Days; Refund of Advance — separated by the
  **three-character** delimiter `#~#` (10 delimiters per line), with Gross Wages always
  populated. The EPFO Help File sample line reproduces byte-identically (§06.14 TV16).
- **AC-701.5** — Wage Month, Return Type (Regular / Supplementary / Revised),
  Contribution Rate (12% or 10%) and Remark are surfaced to the operator at export time
  as the values to enter in the portal's form controls, and are **never** written into
  the file (EV-035).
- **AC-701.6** — Pre-validation mirrors EPFO's severity exactly (EV-040). Among the EPS
  rules **only one blocks**: EPS for a member who has attained 58 and is not marked for
  deferred pension (AC-202.6). The post-01.09.2014 high-earner rule is a **flag, never a
  block**: EPFO flags such EPS before filing but accepts it, so the engine — which
  computes EPS = 0 for these members itself (AC-202.4) — raises the same flag on any line
  where EPS survives (a manual override, imported history) instead of refusing the file.
  Beyond EPS, EPFO permits contributions only between the valid date of joining and date
  of leaving, and only at the statutory rate or higher (EV-040); the engine checks both
  before export. An exempted establishment still populates EPF wages, PF contribution,
  EPS wages, EPS contribution and EDLI wages (r5/02 finding 12). The engine adds no
  block EPFO does not impose.
- **AC-701.7** — **[P1]** The part-payment contribution file is a separate export with
  its own fixtures: 6 fields separated by `#~#` — UAN, MEMBER_NAME, EPF_CONTRIBUTION,
  EPS_CONTRIBUTION, EPF_EPS_DIFF_CONTRIBUTION, REFUND_OF_ADVANCES (EV-044). Its upload
  screen carries only Wage Month, Contribution File and Remark (r5/02 finding 6).
- **AC-701.8** — The payment step shows the **s.7Q interest** the portal auto-calculates
  as mandatory with the monthly contribution, in both the payment screen and the
  cash-flow forecast; **s.14B damages**, which the employer may deposit forthwith or
  later, are tracked as an open liability until paid (EV-039). Multiple challans per
  wage month are permitted (EV-036); the engine refuses a second payment for the same
  member and month.

**FR-PAY-702 · ESI challan/return** · **P0**
The engine shall prepare the monthly **ESI contribution** upload from ESIC's template —
submitted in an attended session on the ESIC portal, where the challan is generated
(K-13, §06.3, §22) — and the half-yearly reconciliation across the two contribution
periods (§06.3), due by the 15th.
- **AC-702.1** — Contribution-period boundary re-evaluation (FR-PAY-203) is reflected:
  an employee held to the boundary appears in the correct months' filings (TV3).
- **[Hypothesis / blocked]** — **AC-702.2** — Post-22-Nov-2026 ESI computation and
  filing depend on the unresolved successor to the one-year saving (§06.9, §06.13,
  §20 V-08). **Kill/gate criterion: ESI filing for periods after the cliff must be
  escalated and blocked, not guessed, if no successor instrument is notified.** This is a
  payroll-correctness blocker on the validation gate, not a build detail.

**FR-PAY-703 · Professional Tax returns** · **P0**
The engine shall generate the **PT return and challan data per state**, on that state's
frequency and due date (monthly/annual; Maharashtra assigns frequency per registration
each year, §06.4), with one-click export for the CA console (§16). Each state is its own
manual portal, so submission is attended, one portal per state (K-13, §22).
- **AC-703.1** — A multi-state tenant gets one PT return per state per that state's
  cadence, each reconciling to the PT deducted from employees in that state.

**FR-PAY-704 · LWF remittance** · **P0**
The engine shall generate the **LWF remittance** per state on that state's periodicity
(§06.8).
- **AC-704.1** — LWF remittances appear only for LWF states and only in the correct
  periods — Karnataka once a year, due 15 January (periodicity **[Verified]**, §06.8);
  half-yearly states such as Maharashtra (June/December, **[Hypothesis]**) only in their
  deduction months.

**FR-PAY-705 · Statutory bonus return and registers** · **P0**
The engine shall generate the **statutory bonus registers and the annual bonus return**
the period's regime requires, and schedule the payout by the configured deadline. For
legacy accounting years that is the **Form D** return with the legacy registers
maintained, and payout within 8 months of the accounting year's close (30 November for
April–March) — legacy practice per compliance blogs (r1, low); the register form letters
and the Payment of Bonus Rules citation v0.3 gave are carried, not re-captured, and are
held in `bonus.legacy_register_forms`. For Code-era years the deadline and
the return are unresolved, so they are the named parameters `bonus.payment_deadline`
and `bonus.annual_return_form`, never hard-coded, and routed to §20 (§06.7, §06.11).
- **AC-705.1** — The bonus return reconciles to the bonus computed under FR-PAY-208 and
  to the bonus payout run; ineligible employees paid ex-gratia are excluded; a Code-era
  return is not generated until `bonus.annual_return_form` carries a verified source.

**FR-PAY-706 · TDS — Form 138 (ex-24Q) quarterly statement, Q1–Q3; Q4 fenced** · **P0**
The engine shall generate the quarterly TDS statement (**Form 138**, ex-24Q; Rule 219 of
the Income-tax Rules 2026, EV-049) for **Q1–Q3** in the versioned layout, with challan
reconciliation, and support the **correction-statement** structure. The artefact is the
statement `.txt` ready for validation: the **deductor** runs the File Validation Utility
and uploads — or our operator does so in an attended session under written authority
(K-13, §22). The **Q4 generator is fenced** (EV-046).
- *Detail.* Form 138 is a **breaking layout change** (EV-051): challan sub-headings
  301–312 remap to A–K with 303 removed; Annexure I 313–327 remap to C–N with 313, 321,
  322 and 325 removed; Surcharge, Education Cess and Penalty/Others are deleted; Interest
  Allocation and Others Allocation are added; Token No. becomes "Return Receipt Number";
  TAN Registration No. is deleted; the form auto-populates from the deductor's TRACES
  profile. Physical format: ASCII `.txt`, `^`-delimited variable-width fields, every
  record CRLF-terminated, record types FH / BH / CD / DD, file type `SL1` (EV-051). Form 138
  has **three annexures** — Annexure I every quarter; Annexure II (salary summary) and
  Annexure III (pension and interest of specified senior citizens) in Q4 only (EV-047).
  The Q1–Q3 regular format file is dated 22 July 2026 and the Q1–Q3 correction format
  file 4 August 2026 (the dates in Protean's download filenames; r5/02 findings 19–20);
  Protean's page labels the
  Q1–Q3 format "Version 1.2" while the workbook itself says "Version 1.1", so versions
  are pinned to the downloaded artefact, not the label (r5/02 finding 35). **Dual FVU
  stack (EV-052):** RPU 1.2 + FVU 1.2 for Tax Year 2026-27 onward; RPU 6.0 + FVU 9.5 for
  FY 2010-11 to FY 2025-26; mixing them causes rejection, so every statement — original
  or correction — routes by its **period**, never by today's date. Labels, search and
  imports accept both vocabularies (EV-050).
- **AC-706.1** — Field mapping is **schema-driven**; no field number (301–312 etc.) is
  hard-coded — swapping the schema version reshapes the file without a code change
  (§06.12 R6). Protean's `138RQ1.txt` sample is a golden fixture for the Q1–Q3 writer
  (r5/02 finding 30).
- **AC-706.2** — Challan totals reconcile to deducted-and-deposited amounts before the
  file is emitted, using the mandatory `.csi` import from the TIN Challan Status Inquiry
  (the TAN and TAN name in the statement must match the `.csi`); a mismatch blocks
  generation (r5/02 finding 30; §06.5).
- **[Verified as absent]** — **AC-706.3** — The **Q4 regular format and the Q4
  correction format are both unpublished** ("Expected to be released soon", no link;
  re-checked September 2026, EV-046). Q4 (Annexures II and III) is a pluggable schema
  slot the engine loads when the format is released; until then Q4 generation is
  **BLOCKED-pending-layout** (FR-PAY-711), visible on the filing calendar (§06.11) and to
  the statutory-change watcher (§22). The legacy 24Q Q4 layout is never used as a proxy
  (§06.12 R16). The Q4 due date (31 May of the year following the Tax Year, EV-049) sits
  fifteen days before the Form 130 date, so the two cannot be planned apart.
- **AC-706.4** — A statement for FY 2025-26 or earlier (an original or a correction) is
  generated on the legacy 24Q layout and routed to RPU 6.0 / FVU 9.5; a statement for
  Tax Year 2026-27 onward is generated as Form 138 and routed to RPU 1.2 / FVU 1.2; the
  product surfaces the FVU/RPU version to use and never mixes the two (EV-052).

**FR-PAY-707 · Annual certificate — Form 130 (ex-Form 16): data preparation and distribution** · **P0**
The engine shall **prepare the Form 138 data from which TRACES builds Form 130**, and
**distribute** the TRACES-downloaded, signed certificate to each employee by 15 June of
the year following the Tax Year (Rule 215 of the Income-tax Rules 2026; §06.5). It shall
never generate the certificate itself.
- *Detail.* **[Reversed]** Earlier drafts had the engine generate Form 130 Part A
  (TRACES-sourced) and Part B (the annual salary/tax computation). Two findings reverse
  that. Form 130 is **valid only if generated from TRACES** and signed by the deductor
  (EV-048). And it has **Part A, Part B and Part C** — the per-employee salary breakdown
  sits in Part C Annexure-I, not Part B (EV-048; r5/02 finding 23). TRACES prepares Form
  130 from Annexure I (quarterly) and Annexure II (Q4) of Form 138, so the certificate is
  downstream of the fenced Q4 statement (EV-046). The product's role is the data that
  TRACES reads, the reconciliation around it, and distribution of what TRACES issues.
- **[Verified as blocked]** — **AC-707.1** — For **Tax Year 2026-27 onward**, Form 130
  preparation is **BLOCKED-pending-layout** until the Q4 Form 138 format is published
  (EV-046; §06.12 R16) — never emitted with guessed fields. For FY 2025-26 and earlier,
  the legacy 24Q / Form 16 stack applies (EV-052).
- **AC-707.2** — Before distribution, the certificate's figures reconcile to the four
  quarterly statements and to the sum of the year's payslips under the elected regime; a
  mismatch holds distribution and names the difference. A certificate not downloaded
  from TRACES is never distributed.

**FR-PAY-708 · Correction / revised returns** · **P0**
The engine shall generate the correction artefact the portal accepts for any filed
return when a correction run (FR-PAY-306) or retro recompute (FR-PAY-402) changes a filed
period, recording each correction in our ledger as a **diff** against the filed return,
never a mutation of it (§06.12 R14). For the ECR the routes are the EV-037 return types:
a **Supplementary** return (needs an approved Regular; only members absent from every
prior return for that month; may be filed repeatedly) or a **Revised** return (needs an
approved Regular, no other return in process and **no payment initiated**; it overwrites
the portal's data). For Form 138 the route is a correction statement on the period's
format family (EV-052) — the Q1–Q3 correction format (4 August 2026) for Tax Year
2026-27, while the Q4 correction format is unpublished and fenced (EV-046).
- **AC-708.1** — Correcting an approved April ECR produces a Supplementary or Revised
  return within the EV-037 guards, never a duplicate Regular return; an arrears
  recompute is routed to the fenced arrear flow (EV-043, FR-PAY-401), not into the April
  file.
- **AC-708.2** — A downward ECR correction requested after payment initiation is refused
  with the reason (EV-037). **[Hypothesis]** — EPFO's circular (para 5(ii)) states
  upward revision has no such restriction while para 5(iii) requires no payment
  initiated for any Revised return, and the FAQ hedges upward revision after payment to
  "in many cases" (r5/02 finding 9). The product does not rely on post-payment upward
  revision; **kill/validate via §20 against a live portal before offering it.**

**FR-PAY-709 · The statutory registers — six employer registers plus the wage slip** · **P0**
The engine shall maintain the **six employer registers plus the wage slip** as one
canonical set, derived from pay-run and attendance data, not hand-maintained (EV-053):
Wages Rules 2026 r.51(1) Forms I, IV and IX plus the Form V wage slip; OSH Forms XIII,
XIV, XV, XIX and XX plus the Form XVI wage slip; SS r.53(1)(a) Form XXII. Form numbers
are configuration per state. Retention follows each rule-set's own wording, not a flat
five years (EV-054). **[Reversed]** Earlier drafts specified "four consolidated
registers with five-year retention"; §06.9 withdraws that framing.
- **AC-709.1** — Each register is reproducible for any month in the retention window and
  reconciles to the corresponding pay runs and filings; Form IX carries per-day IN and
  OUT timestamps (EV-055, §09 owns the time model); a finalised register is immutable.
- **AC-709.2** — Retention is per rule-set: "five years after the date of last entry"
  (Wages r.51(4)) or "five calendar years from the date of last entry" (OSH r.72(1)(vii),
  SS r.53(1)(e)); OSH r.76(2) bars destruction even after five years unless transferred
  to a new register (EV-054). State-sphere periods are unknown and go to counsel (§23);
  no other retention period is hard-coded (Part D-11).

**FR-PAY-710 · Filing calendar and status tracking** · **P0**
The engine shall present the **per-(tenant × state × obligation) filing calendar**
(§06.11) with each filing instance's state from the filing state machine (FR-PAY-711) —
including REJECTED, SUPPLEMENTARY, REVISED and BLOCKED with its reason
(pending-layout / pending-regime / chronology / joint-declaration) — and shall surface
the headline metric **"filings completed on time"** (§01, §19).
- **AC-710.1** — A rejected filing (e.g., an ECR upload failing validation on an
  un-seeded UAN) shows the rejection reason and the remediation task, and does not count
  as "completed" (§01 AC-01.2).
- **AC-710.2** — The calendar correctly renders **state-varying** PT/LWF/bonus due dates
  and the **Q4 Form 138 / Form 130 BLOCKED-pending-layout** and **post-cliff ESI
  BLOCKED-pending-regime** states.

The central (non-state-varying) due dates the calendar seeds from — each an
effective-dated rule (I2), each a filing whose on-time completion is the headline metric
(§01, §19):

| Filing | Statutory due date | Cadence | Source cue |
| --- | --- | --- | --- |
| EPF ECR return, approved before the challan; s.7Q interest paid with the contribution | 15th of following month | Monthly | EPF Scheme 2026 (§06.2); EV-036, EV-039 |
| ESI contribution | 15th of following month | Monthly | ESI subordinate law saved to the cliff (§06.3, §06.9) |
| TDS deposit | 7th of following month (30 Apr for March) — carried from the 1962 Rules | Monthly | Income-tax Rules 2026 r.218 — the dates are **[Hypothesis]** until read against r.218 (§06.5, §06.13) |
| Form 138 (ex-24Q) | 31 Jul / 31 Oct / 31 Jan; 31 May of the year following the Tax Year | Quarterly | Income-tax Rules 2026 r.219 (EV-049); Q4 BLOCKED-pending-layout (EV-046) |
| Form 130 (ex-Form 16) — TRACES-generated; distribution | 15 June of the year following the Tax Year | Annual | Income-tax Rules 2026 r.215 (EV-048); BLOCKED behind Q4 for Tax Year 2026-27 |
| Statutory bonus payout and return | `bonus.payment_deadline` (legacy: 30 November) | Annual | Code on Wages s.26; legacy POB practice, r1 low (§06.7) |
| PT return | State-specific; per registration where the state assigns it | Per state | State PT Acts (§06.4) |
| LWF remittance | State-specific (Karnataka: 15 January) | Per state | State LWF Acts (§06.8) |

- **AC-710.3** — For each filing the calendar computes the due date from the
  effective-dated rule (never a hard-coded constant), rolls a due date falling on a
  Sunday/gazetted holiday to the next working day where the statute so provides, and
  surfaces the **late-filing exposure** so a slip is quantified, not merely flagged:
  simple interest at 12% p.a. on late EPF and ESI deposits (§06.2, §06.3) — for EPF,
  auto-calculated by the portal and payable with the contribution (EV-039); EPF and ESI
  damages read `epf.damages_scale` and `esi.damages_scale`, which ship with no default,
  so the exposure is shown as "rate unverified" until the Code-era scale is confirmed
  (**[Hypothesis]**, §06.13 — v0.3's graded-by-delay legacy percentages are carried, not
  re-captured, and are never quoted to a customer as current); the TDS late-statement
  fee under 1961-Act s.234E reads `tds.late_fee_per_day` and `tds.late_fee_cap`, whose
  carried ₹200-a-day figure rests on a secondary source (**[Hypothesis]**, not
  primary-verified, 2025-Act equivalent unmapped; §06.5). Any exposure figure shown to
  a customer is product surface with a named owner and clears the §23 claim rule first
  (Part D-20).

**FR-PAY-711 · Filing-instance state machine** · **P0**
Every filing instance — one registration × obligation × period — shall move through
explicit, logged states: **SCHEDULED, BLOCKED, GENERATED, VALIDATED, SUBMITTED,
REJECTED, ACCEPTED, REVISED, SUPPLEMENTARY, PAYMENT_INITIATED, FILED** (Part E-1). Only
FILED counts toward "filings completed on time" (§01 AC-01.2, §19), and the metric's
rejection and correction counts are computed off REJECTED, REVISED and SUPPLEMENTARY.
- *Detail.* **[Reversed]** An earlier draft's filing machine (draft → generated →
  validated → submitted → acknowledged → corrected) had no REJECTED state, so the portal
  rejection rate §01 names could not be computed from it, no payment-initiation state,
  and no Supplementary or Revised return types (r5 engineer review). Here a correction is
  a new attempt linked to the accepted one and recorded as a diff (§06.12 R14), even
  where the portal itself overwrites. The diagram illustrates; the table specifies.

<!-- DIAGRAM: fr-payroll-filing-state-machine -->

| # | From → To | Event | Guard | Side effect | Who may trigger |
| --- | --- | --- | --- | --- | --- |
| F1 | *(none)* → SCHEDULED | Payroll month opened (FR-PAY-301 M1), or the calendar rolls a quarterly or annual instance | Obligation latched for the registration (§06.1) | Due date computed (FR-PAY-710) | System |
| F2 | SCHEDULED → BLOCKED | A guard fails | Format unpublished (Form 138 Q4 and Tax Year 2026-27 Form 130, EV-046; ECR arrear return, EV-043); regime unresolved (post-cliff ESI, §06.9); chronology gap (FR-PAY-712); joint declaration pending (EV-041) | Reason, owner and unblocking trigger recorded; the deadline clock stays visible | System |
| F3 | BLOCKED → SCHEDULED | Guard clears | A published rule or format version (§22), a closed ledger gap, or an accepted joint declaration | Instance re-evaluated | System, or payroll operator |
| F4 | SCHEDULED → GENERATED | Generate | Source payroll month(s) LOCKED; the format version for the **period** resolved (EV-052) | Artefact generated from the locked snapshot; format version and snapshot bound to it | Payroll operator |
| F5 | GENERATED → VALIDATED | Validate | Format checks (EV-035, EV-044, EV-051), EPFO severity mirror (EV-040), `.csi` challan match for TDS (FR-PAY-706) | Flags recorded for acknowledgement; a block stops here | System |
| F6 | VALIDATED → SUBMITTED | Upload in an attended session | Written authority to act on file where our operator submits; return type chosen within the EV-037 guards | Session logged — who, on whose credentials, when, which file (§22) | Employer, or our operator under written authority |
| F7 | SUBMITTED → REJECTED | Portal rejects the upload or return | — | Reason or error file captured and mapped to employee records | Operator records; system parses |
| F8 | REJECTED → GENERATED | Fix and regenerate | Fix made through identifier state or a correction run, never by editing the locked snapshot | New attempt linked to the rejected one | Payroll operator |
| F9 | SUBMITTED → ACCEPTED | Portal accepts; for the ECR, the employer approves the return statement | — | Acknowledgement captured — return file ID and, at challan, TRRN for the ECR (EV-036); Return Receipt Number for Form 138 (EV-051). An approved ECR return can never be cancelled (EV-036) | Employer approves on the portal; operator records |
| F10 | ACCEPTED (ECR) or FILED (Form 138) → REVISED | Revised return or correction statement raised | ECR: approved Regular exists, no other return in process, **no payment initiated** (EV-037). Form 138: the correction format for the period is published (Q4 correction fenced, EV-046) | Correction generated as a diff against the accepted return | Payroll operator plus approver |
| F11 | REVISED → ACCEPTED or FILED | Revision accepted | — | Ledger keeps the prior and the revised return; the diff is the audit record | Operator records |
| F12 | ACCEPTED or FILED → SUPPLEMENTARY | Supplementary ECR raised | Approved Regular exists; only members absent from every prior return for the month (EV-037) | Supplementary generated; repeatable | Payroll operator plus approver |
| F13 | SUPPLEMENTARY → FILED | Supplementary accepted and, where it carries a payment, receipted | — | — | Operator records |
| F14 | ACCEPTED → PAYMENT_INITIATED | Initiate payment on a payment-bearing filing | The month's verification gate has passed (FR-PAY-301 M10) | Challan with TRRN; from here a Revised ECR is impossible (EV-037) | Named approver; executed in an attended session |
| F15 | PAYMENT_INITIATED → FILED | Payment receipt captured | Acknowledgement and receipt stored and reconciled | Terminal for the on-time metric | System, or operator |
| F16 | ACCEPTED → FILED | Filing without a payment leg accepted (e.g., a Form 138 statement, whose deposits preceded it) | Acknowledgement stored and reconciled | Terminal for the on-time metric | System, or operator |

- **AC-711.1** — The on-time count, the rejection count and the correction count for any
  period are reproducible from the transition log alone (§19).
- **AC-711.2** — No transition skips a state: an artefact cannot be SUBMITTED without
  VALIDATED, and cannot be FILED without a stored acknowledgement.
- **AC-711.3** — A REVISED transition on an ECR instance whose payment has been initiated
  is refused with the EV-037 reason; the operator is offered the routes that remain
  (Supplementary for absent members; the fenced arrear flow).

**FR-PAY-712 · Per-establishment ECR filing ledger** · **P0**
The engine shall keep, per EPF establishment, an **unbroken, month-by-month filing
ledger** that refuses silent abandonment (Part E-10, EV-038): every wage month from
coverage onward carries an entry, and the ledger enforces EPFO's chronological rule
before EPFO does.
- *Detail.* The revamped ECR mandates strict month-wise chronological filing. After a
  four-month transitional relaxation, a Regular return for month M is allowed only if
  returns for **all active members of month M−4** have been filed, so a skipped month
  blocks later months (EV-038); the exit-marking relaxation also expires after four
  months (r5/02 finding 10). A date of exit recorded in error can be corrected only by a
  **joint declaration** of employer and employee — an offline dependency that can stall
  a month (EV-041). NIL months use no file: admin and inspection charges go through
  Direct Challan Entry, enabled only when there are no active members (EV-042).
- **AC-712.1** — Every wage month from the establishment's coverage date to the current
  one has exactly one ledger status — in progress (a FR-PAY-711 state short of FILED),
  FILED, NIL, or BLOCKED with an owner and a reason. A month cannot be deleted or
  skipped, "abandon" is not an available action, and a later month's Regular return is
  not generated while an earlier month has none (strict month-wise chronology, EV-038).
- **AC-712.2** — The dashboard warns, before the window, when an unfiled month will block
  a later month's Regular return under the M−4 rule, naming the members and the month.
- **AC-712.3** — An exit date recorded in error puts the member's later months into
  BLOCKED-joint-declaration with an offline task for employer and employee; no
  contribution for any period after the recorded exit date is attempted until the
  correction is accepted (EV-041). Marking a date of exit needs no member-detail or
  Aadhaar update (EV-041).
- **AC-712.4** — A NIL month generates no file; the operator is routed to Direct Challan
  Entry for admin and inspection charges, and the ledger records NIL with the receipt
  (EV-042).
- **AC-712.5** — Each ledger entry stores return type, return file ID, TRRN, approval
  timestamp and every linked Supplementary or Revised return; a post-approval correction
  appears as a diff against the approved return, never a replacement of it (§06.12 R14).

**FR-PAY-713 · Error taxonomy for statutory artefacts** · **P0**
Every error or flag the engine raises against a statutory artefact — before
generation, at validation, at the payment gate, or after a portal rejection — shall
carry one code from a closed set of families, so that remediation is routed, the
filing metrics (§19) can say *why* filings fail, and the operator never meets a free-
text error.

| Family | What failed | Sourced examples | Detected at | Severity | Remediation route |
| --- | --- | --- | --- | --- | --- |
| **SA-FMT** — layout | The bytes do not match the published layout | ECR: 11 fields, 10 three-character `#~#` delimiters, no header row (EV-035); part-payment file: 6 fields (EV-044); Form 138: one caret fewer than fields per record, CRLF on every record, FH / BH / CD / DD, file type `SL1` (EV-051); ECR packaging: letters and digits in the filename, lower-case `.txt`, at most 8 MB, zipped above 2 MB, one file per zip (r5/02 finding 5; TV18) | Generator self-check, F4 → F5 (FR-PAY-711) | Block — the portal would reject it | Fix the generator or schema version; the artefact is never hand-edited |
| **SA-VER** — format family | The period's format is wrong or does not exist | A Tax Year 2026-27 statement routed to RPU 6.0 / FVU 9.5, or the reverse (EV-052); a version pinned to Protean's page label instead of the downloaded workbook (r5/02 finding 35); Form 138 Q4, Tax Year 2026-27 Form 130, ECR arrear return (EV-046, EV-043) | F4 guard | Block; an unpublished format sends the instance to BLOCKED-pending-layout | Watcher publishes the schema (§22, FR-PAY-1005); deadline stays visible |
| **SA-ID** — identifiers | A member or deductor identifier is unusable | Un-seeded or KYC-incomplete UAN (AC-701.2); inoperative PAN (AC-205.3); statement TAN or TAN name not matching the `.csi` (AC-706.2) | Pre-run (FR-PAY-1004) and F5 | UAN and PAN: flag, exclude-and-flag or configuration task, never a payroll block; TAN mismatch: block generation | Seeding or joint-declaration queue (§07); correct the deductor master |
| **SA-RULE** — authority's eligibility checks | A line breaks a rule the portal enforces or flags | EPS for a member who has attained 58 and is not marked for deferred pension — block; EPS for a post-01.09.2014 high earner — flag; contribution outside the date-of-joining to date-of-leaving window; rate below statutory (EV-040); exempted-establishment fields left empty (r5/02 finding 12); Form 138 deductee date of payment outside the quarter or tax year (r5/02 finding 32) | F5 | **Exactly the authority's own** — the engine adds no block the authority does not impose (AC-701.6) | Correct through identifier state or a correction run |
| **SA-REC** — reconciliation | Two figures that must agree do not | File lines vs computed contributions vs the portal's return statement and Due Deposit Balance Summary (EV-036, AC-701.1); challan vs liability (FR-PAY-902); `.csi` challan match (AC-706.2); bank file vs net pay (AC-901.1); payslips vs registers vs returns (G2) | F5 and the M10 verification gate | Block — a figure would be wrong | Named reconciling item; fix before PAYMENT_INITIATED, since a downward ECR correction is impossible after it (EV-037) |
| **SA-SEQ** — lifecycle and sequencing | The action is out of order for the authority's lifecycle | A Regular return for month M with month M−4 unfiled (EV-038); a Revised ECR after payment initiation, a Supplementary carrying an already-returned member, a second Regular (EV-037); a contribution after a wrongly recorded exit date (EV-041); a file for a NIL month (EV-042); a second payment for the same member and month (AC-701.8) | F4, F6, F10, F12 guards | Block — the portal would refuse it | Offer the route that remains: Supplementary, the fenced arrear flow, the joint-declaration task, Direct Challan Entry |
| **SA-PORT** — portal rejection | The authority rejected a submitted artefact | ECR upload failing validation, with EPFO's downloadable error file (r5/02; schema undocumented, captured from a real rejection, §06.13); an FVU rejection | F7 → REJECTED | Not "done"; the on-time clock keeps running (AC-710.1) | Error file parsed and mapped to employee records; regenerate (F8) |
| **SA-CALC** — computation defect | A golden vector fails | §06.14 TV1–TV25; Example G convergence (AC-211.2) | Rule-version release, not the run | Blocks publishing the rule version (G11) | Fix the rule payload; re-run the golden suite |

- **AC-713.1** — Every error or flag recorded against a statutory artefact carries one
  family code, a severity (block or flag), its detection point (pre-run, F4, F5, M10,
  F6, F7, F10, F12 or release), the affected employee or record, and a remediation
  route. An uncoded error cannot be recorded.
- **AC-713.2** — SA-RULE severities equal the authority's own (EV-040); SA-FMT,
  SA-VER, SA-REC and SA-SEQ block because the artefact would be wrong or refused;
  SA-ID never blocks payroll for an Aadhaar-, UAN- or PAN-state reason (Part E-11).
- **AC-713.3** — The rejection and correction counts of §19 are reproducible per family
  from the transition log alone (AC-711.1), so the metric can report which family
  drives rejections for any period, registration or state.
- **AC-713.4** — A portal rejection whose error text maps to no known code is recorded
  as SA-PORT-UNMAPPED with the raw error file attached and routed to §22 to extend the
  mapping; it is never dropped or recoded as a generic failure.

---

### 08.9 Full-and-final settlement (F&F)

Exit settlement concentrates the hardest edge cases — proration, arrears, recoveries,
gratuity, leave encashment, and final TDS true-up — into one computation. §05.6 names
mid-year cutover and continuity as the most-cited churn trigger, and F&F is where a
departing employee's certificate continuity is won or lost.

<!-- DIAGRAM: fnf-waterfall -->


**FR-PAY-801 · F&F computation** · **P0**
On an employee exit the engine shall compute a **full-and-final settlement** comprising:
prorated final-month salary; unpaid arrears; **leave encashment** (per policy, on the
correct wage base); **gratuity payout** (FR-PAY-206) if qualified; **statutory bonus**
accrued to date (FR-PAY-208); pending reimbursements; **notice-pay recovery or
payment**; advance/loan/asset recoveries; and the **final TDS true-up** for the
year-to-date.
- **AC-801.1** — F&F net = (all final earnings + encashment + gratuity + accrued bonus +
  pending reimbursements) − (all recoveries + final TDS), shown line-by-line and
  reconciling to the rupee (worked at §08.12 Example E).
- **AC-801.2** — Gratuity is included only if the 5-year rule is met (or does not apply —
  death, disablement, fixed-term expiry), is capped at `gratuity.payable_ceiling`, and is
  tax-exempt up to `tax.gratuity_exemption_ceiling` net of the exemption the employee
  declares as already used with earlier employers (1961-Act s.10(10); v0.3's ₹20 lakh
  carried, **[Hypothesis]**; 2025-Act equivalent unmapped, §06.6).
- **AC-801.3** — Final TDS is computed on **actual** year-to-date income (not the annual
  projection), applying actual proof-verified declarations, and can result in a **refund
  adjustment** where excess was deducted.
- **AC-801.4** — **Leave encashment on retirement/resignation** is exempt for a non-
  government employee up to a lifetime ceiling held as
  `tax.leave_encashment_exemption_ceiling` (1961-Act s.10(10AA)(ii); v0.3's ₹25 lakh and
  the CBDT notification it cited are carried, not re-captured in any research round,
  **[Hypothesis]**, routed to §20; the 2025-Act equivalent is unmapped and carried under
  both labels, §06.13); the ceiling is a
  **lifetime aggregate across employers**, so the engine caps on the balance the employee
  declares as already used, and the excess is taxed and flows to the final TDS true-up.
  Encashment *during* service (not on exit) is fully taxable — the engine distinguishes
  the two.

**FR-PAY-802 · Statutory exit processing and continuity** · **P0**
On exit the engine shall prepare the **EPF exit** marking (the date of exit that frees
the employee's UAN for withdrawal or transfer), the **ESI exit**, and preserve **UAN/ESI
IP continuity** data for the employee's next employer (§05.6 continuity requirement).
- **AC-802.1** — An exited employee's date of exit is marked on the EPFO portal in an
  attended session (§22) — it is not a field of the ECR return file (EV-035) — so their
  UAN is free for transfer; marking needs no member-detail or Aadhaar update, and an exit
  date recorded in error can be corrected only by a joint declaration (EV-041,
  FR-PAY-712). The final month's ECR carries contributions only up to the date of
  leaving (EV-040). The engine does not require the *next* employer to be in the system.
- **AC-802.2** — The exit produces the data an incoming HRMS needs (YTD earnings, TDS
  deducted, UAN, ESI IP, leave balance, gratuity accrual) as an **exportable continuity
  packet** — the mirror of the migration import (§05.6, §16).

**FR-PAY-803 · F&F approval and settlement window** · **P0**
F&F shall pass the same maker-checker approval (FR-PAY-304) and produce a **settlement
payment** via the bank file (FR-PAY-901) and a **final payslip**. The partial-year
Form 130 is the TRACES-generated certificate, distributed after the year's Q4 statement
(FR-PAY-707; EV-048) — for Tax Year 2026-27 it is blocked behind the unpublished Q4
format (EV-046), and the exit continuity packet (AC-802.2) carries the YTD figures in
the meantime.
- **AC-803.1** — Gratuity, once payable, is flagged for payment **within 30 days**, with
  the simple-interest exposure for delay surfaced if the window is missed (CoSS s.56
  [Verified]; the legacy POG reference is carried, not re-captured; §06.6).
- **AC-803.2** — The final **wages** carry their own, shorter clock: payable within **two
  working days** of removal, dismissal, retrenchment or resignation (Code on Wages
  s.17(2), verified verbatim, r1/06; §06.9), subject to any other time limit the
  appropriate Government provides under s.17(3), held per jurisdiction as
  `wages.final_settlement_working_days`. The clock starts from the exit date on the
  service record, counts working days on the establishment's calendar, and is shown
  on the F&F screen; approval (FR-PAY-304) and the settlement bank file (FR-PAY-901)
  are sequenced to meet it, and a breach is surfaced to the approver, never hidden.

---

### 08.10 Bank / NEFT payment files

**FR-PAY-901 · Salary bank-file generation** · **P0**
The engine shall generate **bank-upload files for net-salary disbursement** in the
formats of the major Indian banks (per-bank fixed-width/CSV/Excel templates for
NEFT/RTGS/IMPS bulk upload) and a **generic NEFT/H2H** format, from the net figures of a
LOCKED payroll month (FR-PAY-301 M8).
- *Detail.* Bank formats differ per bank (HDFC, ICICI, SBI, Axis, Kotak, YES, etc.);
  the format is a **versioned, per-bank template**, not hard-coded, so a bank changing
  its layout is a config update (§06.12 R6 shape, applied to bank files).
- **AC-901.1** — The bank file's total credit amount equals the sum of employee net pay
  in the LOCKED month, to the rupee; a mismatch blocks file generation.
- **AC-901.2** — Each line carries the employee's beneficiary account, IFSC, name and a
  narration; an employee with missing/invalid bank details (an IFSC failing the §14.9
  format rule or absent from the maintained IFSC directory — IFSC carries no check
  digit) is flagged **before** file generation, not rejected at the bank.
- **AC-901.3** — Regenerating the file for the same run is **idempotent** — it does not
  produce a second payment; a reissue requires an explicit correction run (FR-PAY-306).

**FR-PAY-902 · Statutory payments and challans** · **P0**
The engine shall compute the **payment figure** for each statutory head — PF, ESI, PT
and the TDS deposit — and reconcile it to the challan the authority's portal produces:
for EPF, the challan with TRRN generated after the return is approved (EV-036),
including any s.7Q interest the portal computes (EV-039); for ESI, the challan
generated on the ESIC portal (§06.3); for TDS, the deposit's challan identification
(CIN) captured on payment. Payment is initiated only through the payroll-month
verification gate (FR-PAY-301 M10).
- **AC-902.1** — Each statutory challan total equals the computed liability for that head
  and period; the CIN captured on payment feeds Form 138 reconciliation through the
  `.csi` import (AC-706.2).

**FR-PAY-903 · Payment status reconciliation** · **P1**
The engine shall record **payment confirmation** (bank return file, UTR, challan CIN)
and reconcile it against the pay run, flagging **failed/returned** credits for reissue.
- **AC-903.1** — A returned NEFT (wrong account) is flagged against the specific
  employee and re-queued, without re-paying the successful lines.

**FR-PAY-904 · Payment approval and segregation** · **P0**
Bank-file release shall require an authorised **payment approver** distinct from the
payroll processor (extends FR-PAY-304 to disbursement).
- **AC-904.1** — Generating a bank file and releasing it for payment cannot be done by a
  single unauthorised actor; the release is logged with actor and timestamp.

---

### 08.11 Audit trail, controls and access

**FR-PAY-1001 · Immutable audit trail** · **P0**
Every create/update/delete of a monetary field, rule assignment, approval, filing and
payment shall be recorded immutably: actor, timestamp, before/after value, rule version
applied, and reason where required (I5).
- **AC-1001.1** — For any figure on any historical payslip or return, the engine can
  answer "who set this, when, from what, under which rule version" without reconstruction.

**FR-PAY-1002 · Replay and recompute audit** · **P0**
The engine shall **replay** any historical pay run to reproduce its figures from its
input snapshot, rule-set version and stored evaluation context (I4, I6), and
**recompute** it against the period's rules (I3), showing any difference — the audit
primitive behind arrears (FR-PAY-401) and corrections (FR-PAY-708). Replay covers the
bitemporal classes and the snapshot, not the erasable classes (I4, K-24); it supports
evidence production in an audit or inspection and does not by itself discharge any
contractual audit, access or inspection obligation (K-21).
- **AC-1002.1** — Replaying a closed period with unchanged rules and inputs reproduces
  identical figures; any difference indicates a rule/input change and is itemised
  (§06.14 TV12).

**FR-PAY-1003 · Role-based access and data-minimisation** · **P0**
Payroll data (salary, PAN, bank, statutory IDs) shall be governed by **role-based
access** — an ESS employee sees only their own; a manager sees none by default; a
payroll admin sees their establishment; a CA console gets **read-only audit access**
(§16).
- *Detail.* **[Reversed]** An earlier draft stated that DPDP s.7(i) removes the consent
  requirement for employment-purpose processing, as current law. It is not in force:
  DPDP's substantive provisions, s.7(i) included, commence on or about 13 May 2027
  (EV-058). DPDP itself creates no sensitive category of personal data (s.2(t),
  EV-059) — **and** the SPDI Rules 2011 are live today: SPDI r.3 lists financial
  information as sensitive personal data, and r.5(1) requires consent in writing before
  it is collected (EV-060). Whether the SPDI Rules survive the omission of IT Act s.43A
  when DPDP s.44(2) commences is a counsel question (Part D-12). Payroll therefore
  captures written consent for the financial
  information it collects, through the versioned consent entity (§07, §14), and cannot
  backfill it for migrated employees (Part E-12). Who owes the SPDI written-consent duty
  is a counsel question; consent capture is built either way (Part D-4, §23). When
  s.7(i) commences it disapplies consent and notice for employment purposes only; it
  does not disapply the s.8 duties (K-03). Access control and CERT-In logging bind from
  day one (EV-062, §17).
- **AC-1003.1** — A manager cannot view a report's salary figures; an ESS user cannot
  query another employee's payslip; every access to salary/PAN/bank is logged, with ICT
  logs kept for 180 days within Indian jurisdiction (CERT-In Directions 28.04.2022,
  EV-062).
- **AC-1003.2** — Every collection of a bank-account or other financial-information field
  records either the written-consent artefact under the regime in force on the
  collection date (EV-060) or its absence; an absent artefact is surfaced to the operator
  as a consent task (§07), never silently ignored.

**FR-PAY-1004 · Pre-run validation gate** · **P0**
Before a month can be APPROVED (FR-PAY-301 M6), the engine shall run a validation suite
that separates **blocking** failures from **non-blocking flags**, and surface every item
with its remediation.
- **Blocking** (a figure would be wrong): negative net; structure not summing to CTC;
  missing work location for PT/LWF; a component with no wage-base flags set
  (AC-101.4); a fixed-point node that has not converged (AC-211.3); missing or invalid
  bank details for an employee paid by bank transfer; a valuation parameter a figure
  needs that is unset for the period — a perquisite value (AC-106.4) or, on a bonus
  payout run, a bonus ceiling not yet confirmed with its source (AC-208.4) — resolved by
  the operator entering the value in force with its source.
- **Non-blocking flags** (the pay run proceeds; the item routes to a queue): an
  un-seeded or KYC-incomplete UAN — **exclude-and-flag** from the ECR with notices to
  the operator and the employee (AC-701.2); an inoperative PAN — flagged, with a
  configuration task while `tds.inoperative_pan_rule` is empty (AC-205.3, TV11); a
  statutory threshold crossing (§06.1 latch — e.g., a tenant crossing 20 turns on EPF);
  a filing instance BLOCKED pending layout, regime, chronology or joint declaration
  (FR-PAY-711) — shown against its deadline, never a reason to hold salaries.
- *Detail.* The product treats Aadhaar as optional everywhere, EPF and ESI flows
  included, so no Aadhaar- or UAN-seeding state may ever block payroll and no hard-block
  configuration ships (Part E-11; Part D-10 keeps the statutory question with counsel;
  §06.14 TV13). §05.6
  Example A names the **20-crossing detected inside the product** as "the single
  highest-intent acquisition moment in the beachhead" — this suite is where the engine
  detects it and moves the tenant from "not registered for EPF" to "first ECR accepted,
  approved and paid", with every portal step prepared in-product and performed in an
  attended session under written authority to act (K-13, §22).
- **AC-1004.1** — A month with any blocking failure cannot be APPROVED; each failure
  links to its fix. A non-blocking flag never prevents approval.
- **AC-1004.2** — When the establishment's count, in the counting unit the statute uses,
  crosses 20 for the first time, the engine raises EPF registration, UAN-generation and
  first-ECR tasks automatically, prepared for the employer's attended portal session
  (§06.1 product implication; Source: CoSS First Schedule, Ch. III, EV-057 — the
  scheduled-employments limitation is removed), without the customer needing to know
  the threshold exists. The counting unit and sphere are schema fields, never assumed
  (EV-057; §06.13).
- **AC-1004.3** — When the count crosses **10** (the ESI and gratuity thresholds, on
  the look-back each statute uses), the engine latches the obligation on and does not
  silently drop it if headcount later dips (§06.1, §06.12 R4). A class-specific
  threshold overrides the default (the central-sphere ESI extension at 20 is §06.14
  TV23).

**FR-PAY-1005 · Statutory-change watcher integration** · **P0**
The engine's rule tables shall be updatable only through the compliance data pipeline
and its **statutory-change watcher** (§22), which catches **amendments and corrigenda,
not just new instruments** — because a watcher keyed only to new notifications would
have missed the corrigendum that inverted the entire November 2026 EPF analysis (§06.9).
(Source: §06.9 cliff analysis — the uncorrected S.O. 5319(E) enumeration versus
corrigendum S.O. 5936(E) of 19.12.2025; §02.4.)
- **AC-1005.1** — A notified rate/slab change becomes an **effective-dated rule version**
  (I2) with a documented source (gazette/notification URL + date) and a corrigendum check
  before it applies; no rule ships without provenance (§02.4 corrigendum standing rule,
  §02.5 source-capture discipline).
- **AC-1005.2** — The fenced formats are named watcher dependencies: the Form 138 Q4
  regular and correction formats are monitored on Protean's regular and correction
  download pages, keyed on the Q4 anchors ceasing to be dead links — never on the pages'
  "Updated As On" footer, which is client-side script printing the visitor's own date
  (r5/02 findings 19–20, 36; EV-046). A release moves the dependent filing instances out
  of BLOCKED (FR-PAY-711 F3) only after the new schema version is published through §22.

---

### 08.12 Worked examples

These are the end-to-end computations the acceptance tests are built from. All rates
trace to §06 and to the golden vectors §06.14. Figures are illustrative but internally
exact; TDS figures use the **FY2025-26 verified** slabs and rebate (Tax Year 2026-27 is
[Hypothesis] pending verification against the rates in force for that year, §06.13). Wage bases follow the Code definition:
special allowance is wages, not an excluded head (§06.10).

#### Example A — Standard monthly payslip (single, full-month, Karnataka)

Employee: monthly gross ₹75,150 (annual ₹9,01,800; CTC ≈ ₹9.6L with employer costs
inside per FR-PAY-102). Structure: Basic ₹40,000, HRA ₹20,000, special allowance
₹15,150. Work state Karnataka. New default tax regime, no declarations. PF on ceiling.

| Head | Basis | Amount (₹) | Note |
| --- | --- | --- | --- |
| Basic | fixed | 40,000 | wages — PF/gratuity base |
| HRA | fixed | 20,000 | excluded head — in the ESI and payment-of-wages bases, not the PF/gratuity base (employee above the ESI ceiling anyway) |
| Special allowance | balance | 15,150 | wages — PF/gratuity base (not an excluded head, §06.10) |
| **Gross earnings** | | **75,150** | |
| Employee EPF | 12% × min(PF base, 15,000) | −1,800 | PF base = Basic + special ₹55,150 (no add-back: excluded HRA is 26.6% < 50%), capped at ₹15,000 (TV7) |
| Professional Tax | KA slab: ₹25,000 or above | −200 | a non-February month; ₹300 in February (§06.4) |
| TDS u/s 392 (ex-s.192) | new-regime projection ÷ 12 | −0 | see note below |
| **Total deductions** | | **−2,000** | |
| **Net pay** | gross − deductions | **73,150** | to bank (FR-PAY-901) |
| *Employer EPF (CTC, not paid to emp)* | | *550* | ₹550 of the ₹1,800; balance to EPS |
| *Employer EPS* | 8.33% capped | *1,250* | §06.2 cap (TV1) |
| *EDLI + EPF admin* | 0.5% + 0.5% | *75 + 75* | employer cost; the admin rate is **[Hypothesis]** (§06.2) |
| *Gratuity accrual* | (15/26) × wages ₹55,150 ÷ 12 | *2,651.44* | accrual ledger (FR-PAY-206) |

Two teaching points. First, the **add-back does not trigger**: the only excluded head
here is HRA (₹20,000 = 26.6% of ₹75,150), below one-half, so the PF/gratuity wage is
Basic + special allowance = ₹55,150 — capped at the ₹15,000 ceiling for PF (TV7) but
**uncapped for the gratuity accrual**. **[Reversed]** An earlier version of this example
counted special allowance as an excluded component and set the PF base, and the gratuity
accrual, on Basic alone (₹1,923 a month). Special allowance is not an excluded head
(§06.10), so the accrual is ₹2,651.44. The employee is **outside ESI** (gross >
₹21,000), so no ESI. Second, **TDS projects to ₹0** here: annual gross ₹9,01,800 −
₹75,000 standard deduction (the carried value of `tds.standard_deduction.new`,
**[Hypothesis]**) = ₹8,26,800 taxable, and the FY2025-26 new-regime **s.87A rebate (nil
tax to ₹12L taxable)** zeroes the liability — as it would with no standard deduction
at all, since ₹9,01,800 is itself under ₹12L. This is itself a golden
behaviour — a naive engine that applies slab tax without the rebate over-deducts.
*(Tax Year 2026-27 [Hypothesis]: re-verify the rebate ceiling against the rates in force for the year before
the year's run; AC-205.6.)* Example F shows a higher earner where TDS bites.

#### Example B — Mid-month join proration (FR-PAY-104)

Same structure as A, employee joins **16 September** (30-day month, calendar-days
basis). Paid days 15/30.

- Gross = ₹75,150 × 15/30 = **₹37,575**.
- PF: wage base = prorated wages (Basic ₹20,000 + special ₹7,575) = ₹27,575, capped at
  the ₹15,000 ceiling → employee EPF ₹1,800 (the ceiling still binds; it is not
  pro-rated for a part month unless `epf.ceiling_prorate_part_month` says so — a
  carried, not re-captured item with no shipped default, §06.13). *If* the employer
  elected actual-wage below ceiling, PF would prorate; here the ceiling absorbs it.
- PT (Karnataka): ₹200 for the month (PT is a monthly slab on the month's earned wage,
  not day-prorated; the ₹37,575 earned still exceeds the ₹25,000 KA threshold).
- ESI: out of coverage — the contracted monthly wage (₹75,150) is above ₹21,000, and the
  prorated ₹37,575 is above it too, so the part-month question in FR-PAY-104
  (**[Hypothesis]**) does not arise here.
- TDS: annual projection now spans 6.5 months of earning; the September run projects
  full-year tax on the prorated year and spreads it (FR-PAY-205 AC-205.2).
- **Acceptance:** the payment-of-wages register and the payslip show 15 paid days and the
  day-rate convention applied; PF/PT are computed on the prorated base (AC-104.1).

#### Example C — Arrears from a back-dated increment (FR-PAY-401)

Employee on ₹60,000/month gets a revision to ₹70,000 **effective 1 April**, entered and
processed in the **July** run. April–June are closed. Employee is on the **old regime**
with no Chapter VI-A declarations, to keep the arithmetic visible (the old regime is
chosen deliberately here: under the new regime the FY2025-26
s.87A rebate zeroes tax up to ₹12L taxable, so this earner's TDS would be nil and the
arrears would carry no tax delta — see the note below).

Per-month recompute (each against **that month's** rules, I3; TV12):

| Month | Old gross | New gross | Δ gross | Δ PF (emp) | Δ PT | Δ TDS | Δ net |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Apr | 60,000 | 70,000 | 10,000 | 0 (ceiling) | 0 (already max slab) | 2,080 | 7,920 |
| May | 60,000 | 70,000 | 10,000 | 0 | 0 | 2,080 | 7,920 |
| Jun | 60,000 | 70,000 | 10,000 | 0 | 0 | 2,080 | 7,920 |
| **Arrears** | | | **30,000** | **0** | **0** | **6,240** | **23,760** |

Paid in July as an **arrears line**; July's own run also reflects the new ₹70,000. PF is
0 in the delta because the PF wages at both ₹60,000 and ₹70,000 exceed the ₹15,000
ceiling; PT is 0 because both figures already sit in Karnataka's top ₹200/mo slab. The
₹10,000/mo increment falls entirely in the old-regime 20% slab (taxable moves ₹6.70L →
₹7.90L after the carried ₹50,000 old-regime standard deduction, **[Hypothesis]**; both
figures sit between ₹5L and ₹10L with or without it), so marginal TDS ≈ **20.8%** (20% +
4% cess) = ₹2,080/mo.
**Teaching point on regime dependence:** had the employee been on the new default regime,
Δ TDS would be **0** — the arrears would still recompute PF/ESI/PT per month, but the tax
delta vanishes under the rebate. If a PT slab or PF rate had changed between April and
July, the recompute would use the **April-in-force** version (AC-401.3, TV12), not
July's. Arrears PF (if a base moved below ceiling) would **not** be written into April–
June's ECR files: it is computed against those wage months but its liability dates from
the July disbursal date (Part E-9, AC-401.2), and it goes through EPFO's separate "File
Arrear Return" flow, which is fenced until a layout is published (EV-043). Note too that
a lump-sum arrears payment can trigger arrears relief for the employee — s.89(1) / Form
10E for FY 2025-26, s.157(1) / Form 39 from Tax Year 2026-27 — see AC-205.7.

#### Example D — The 50% wage add-back (FR-PAY-201, §06.10, TV6)

Monthly remuneration ₹1,00,000: Basic ₹35,000, HRA ₹20,000, conveyance ₹10,000,
commission ₹35,000. Excluded components (HRA + conveyance + commission, all among heads
(a)–(i)) = ₹65,000 = **65%** of ₹1,00,000. Half of remuneration = ₹50,000. Excess over
50% = **₹15,000 added back**. (Source: Code on Wages s.2(y) / CoSS s.2(88); §06.10.)
**[Reversed]** An earlier version reached 65% by counting a ₹35,000 "special allowance"
as excluded. Special allowance is not an excluded head, and relabelling universal pay
does not move it out of wages (§06.10, §06.2) — with special allowance in that slot the
excluded share is 30% and nothing is added back.

- **PF wage base** = Basic ₹35,000 + add-back ₹15,000 = **₹50,000**, then capped at the
  ₹15,000 statutory ceiling for PF (or actual, if the employer opts in).
- **Gratuity wage base** = ₹50,000 (the add-back raises gratuity even though the PF
  ceiling absorbs it — which is exactly why gratuity and PF cannot share one base field,
  I1).
- **ESI base** = gross (not applicable here, above ceiling).
- **Bonus wage base** = the notified amount (legacy ₹7,000) or the scheduled-employment
  minimum wage, whichever is higher (FR-PAY-208) — a fourth, unrelated base on the same
  payslip.
- **Payment-of-wages base** = full ₹1,00,000.

**Acceptance:** the engine reports all bases distinctly, each stamped with the
wage-definition rule version (AC-201.1, AC-201.3).

#### Example E — Full-and-final settlement (FR-PAY-801)

Employee resigns effective **20 September** after **6 years 4 months** (rounds down to 6,
TV8), last-drawn wages ₹52,000 (the CoSS s.2(88) wage with no add-back triggered —
§06.6), monthly gross ₹75,150, 12 days of leave to encash, a ₹40,000 salary advance
outstanding, one month notice served (no recovery), pending ₹8,000 reimbursement with
proof.

| Component | Basis | Amount (₹) |
| --- | --- | --- |
| Sept salary (20/30 days) | proration | +50,100 |
| Leave encashment (12 days) | (wages ÷ 26) × 12, the tenant's encashment base | +24,000 |
| Gratuity | (15/26)×52,000×6 | +1,80,000 |
| Pending reimbursement | proof-verified | +8,000 |
| Salary-advance recovery | balance | −40,000 |
| Final TDS true-up | actual YTD | −X |
| **F&F net** | | **= sum, to the rupee** |

Gratuity ₹1,80,000 is **tax-free** if the employee's unused lifetime exemption under
`tax.gratuity_exemption_ceiling` covers it (v0.3's carried ₹20 lakh, **[Hypothesis]**,
§06.6), which it does here unless earlier employers' gratuity has used it. Note the **6-month rounding
rounds 6y 4m down to 6 years** (TV8) — 6y 8m would have rounded up to 7. Final TDS is
computed on **actual** year-to-date income with proof-verified declarations (AC-801.3),
possibly producing a refund adjustment. Gratuity is flagged for payment within **30
days** (AC-803.1). September's ECR carries contributions only up to 20 September
(EV-040); the **date of exit is marked on the EPFO portal** in an attended session — it
is not an ECR file field (AC-802.1). The exit emits a **continuity packet** (YTD, TDS,
UAN, ESI IP, leave, gratuity accrual) for the next employer (AC-802.2) and a final
payslip; the partial-year Form 130 is the TRACES-generated certificate, distributed after
the year's Q4 statement (FR-PAY-707, FR-PAY-803).

#### Example F — Dual-regime TDS comparison (FR-PAY-205)

Employee: annual gross ₹18,00,000 (₹1,50,000/mo), declares old-regime 80C ₹1,50,000,
80D ₹25,000, HRA exemption computed at ₹1,80,000. FY2025-26 slabs (verified, §06.5);
standard deductions are the carried values of `tds.standard_deduction.<regime>`
(**[Hypothesis]**, as in §06.5's own worked example).

| | New regime (s.115BAC) | Old regime |
| --- | --- | --- |
| Gross | 18,00,000 | 18,00,000 |
| Standard deduction (carried, [Hypothesis]) | −75,000 | −50,000 |
| HRA exemption | — | −1,80,000 |
| Chapter VI-A (80C + 80D) | — | −1,75,000 |
| **Taxable income** | **17,25,000** | **13,95,000** |
| Tax (before cess) | 1,45,000 | 2,31,000 |
| + 4% cess | 5,800 | 9,240 |
| **Annual TDS** | **1,50,800** | **2,40,240** |
| **Monthly TDS (÷12)** | **≈ 12,567** | **≈ 20,020** |

New-regime tax builds from the FY2025-26 slabs: 5% on ₹4–8L (₹20,000) + 10% on ₹8–12L
(₹40,000) + 15% on ₹12–16L (₹60,000) + 20% on ₹16–17.25L (₹25,000) = **₹1,45,000**.
Old-regime: 5% on ₹2.5–5L (₹12,500) + 20% on ₹5–10L (₹1,00,000) + 30% on ₹10–13.95L
(₹1,18,500) = **₹2,31,000**. Here the **new regime is cheaper** (₹1.51L vs ₹2.40L), so a
silent employee defaults to it and pays ≈ ₹12,567/mo. **Acceptance:** the engine reports
both figures, and switching the election inside `tds.regime_switch_window` re-projects
the remaining months without disturbing amounts already deducted (AC-205.1). The
ranking is robust for this employee: adding a ₹2L home-loan interest deduction (s.24)
takes old-regime taxable income to ₹11,95,000 and tax to ₹1,71,000 + ₹6,840 cess =
₹1,77,840, still above the new regime's ₹1,50,800. For a different income and deduction
mix the ranking can flip (§06.5), which is precisely why both projections run every
period and the golden suite carries a case on each side of the crossover. *(Slab
figures illustrative on FY2025-26; Tax Year 2026-27 pending AC-205.6.)*

#### Example G — The add-back as a bounded fixed point (FR-PAY-211, I7)

A sales role on a fixed monthly CTC of ₹1,00,000: Basic ₹30,000, HRA ₹15,000,
conveyance ₹5,000, commission ₹40,000, a special allowance that closes CTC as the balance
figure (FR-PAY-101), and a gratuity accrual carried inside CTC as an employer-cost line
(FR-PAY-102) at (15/26) × wages ÷ 12 = 15/312 of the s.2(88) wage, because gratuity
wages include the add-back (§06.6). Employer PF is quoted outside CTC in this structure,
to keep the illustration to one loop. Excluded heads paid — HRA, conveyance and
commission — total ₹60,000.

The loop: special = ₹10,000 − gratuity accrual; all remuneration = ₹90,000 + special;
add-back = ₹60,000 − half of all remuneration; wages = Basic + special + add-back;
gratuity accrual = 15/312 × wages. The add-back re-bases the accrual, the accrual moves
the balance figure, and the balance figure moves the add-back's own denominator. A
one-pass evaluator has to pick an order and publish a first iterate. Iteration 1 starts
from an accrual on Basic (₹1,442.31); tolerance ₹0.01 on wages:

| Iteration | Accrual in (₹) | Special (₹) | All remuneration (₹) | Add-back (₹) | Wages (₹) | Change in wages (₹) |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 1,442.31 | 8,557.69 | 98,557.69 | 10,721.15 | 49,278.85 | — |
| 2 | 2,369.18 | 7,630.82 | 97,630.82 | 11,184.59 | 48,815.41 | 463.43 |
| 3 | 2,346.89 | 7,653.11 | 97,653.11 | 11,173.45 | 48,826.55 | 11.14 |
| 4 | 2,347.43 | 7,652.57 | 97,652.57 | 11,173.72 | 48,826.28 | 0.27 |
| 5 | 2,347.42 | 7,652.58 | 97,652.58 | 11,173.71 | 48,826.29 | 0.006 (under tolerance) |

Converged: wages **₹48,826.29**, gratuity accrual **₹2,347.42**, special allowance
**₹7,652.58**, add-back **₹11,173.71**; the add-back triggers (TV6 behaviour) and the PF
base is then capped at ₹15,000. The loop gain is 15/624 per iteration, so convergence is fast — but a
one-pass engine is still wrong in one of two ways: it accrues gratuity on Basic
(₹1,442.31 — ₹905.11 short of ₹2,347.42), or it accrues on the first-iterate wage
(₹2,369.18) and CTC stops reconciling by ₹926.87 (₹90,000 + ₹8,557.69 + ₹2,369.18 =
₹1,00,926.87), failing AC-102.2. **Acceptance:** AC-211.2 reproduces this table exactly,
and statutory rounding applies only to the converged values (FR-PAY-209). (Illustrative
reading: the gratuity accrual is not remuneration paid and does not enter the (a)–(i)
test; the reading is carried in the wage-definition rule payload, §06.10.)

---

### 08.13 Cross-cutting acceptance criteria — the engine's definition of done

These are the run-level and product-level gates. A build that passes every per-FR AC but
fails these is not shippable.

| # | Gate | Ties to |
| --- | --- | --- |
| G1 | **Determinism** — re-running any unchanged period with its stored evaluation context reproduces byte-identical figures and files; fixed-point nodes converge to the same iterate | I4, I6, I7, FR-PAY-209–211, 1002 |
| G2 | **Reconciliation** — for every run: Σ employee net = bank-file total; Σ each statutory head = its challan; Σ payslips = registers = returns, all to the rupee | FR-PAY-303, 701–709, 901, 902 |
| G3 | **Retro correctness** — arrears/retro recompute uses the period's rule version, not today's; arrears PF liability dates from the disbursal date | I3, FR-PAY-401, 402; TV12; Part E-9 |
| G4 | **No model-generated figures** — no statutory or monetary value on any payslip, challan or return originates from the assistant | §12.1 [Verified], I-wide |
| G5 | **Filing is the metric** — the product reports "filings completed and accepted on time," computed off the filing state machine including REJECTED, REVISED and SUPPLEMENTARY; a rejected filing is not "done" | §01, §19, FR-PAY-710, 711 |
| G6 | **Schema-driven file formats** — Form 138 (incl. the Q4 slot), the ECR return and part-payment files, ESI, the bonus return, bank templates are versioned schemas routed by period; no field number or column is hard-coded | §06.12 R6, FR-PAY-701–706, 708, 901 |
| G7 | **Blocked states are honest** — Q4 Form 138 and Tax Year 2026-27 Form 130 preparation (BLOCKED-pending-layout), the ECR arrear return (fenced, EV-043) and post-cliff ESI (BLOCKED-pending-regime) render as blocked, never silently emitted with guessed values or a legacy proxy | FR-PAY-401, 702, 706, 707, 710, 711 |
| G8 | **Segregation of duties** — no single unauthorised actor can compute, approve, and pay the same run | FR-PAY-304, 904 |
| G9 | **Migration parity** — the engine reproduces migration-grade registers (3A/6A-equiv, ESI 5/6, PT/LWF, the legacy bonus registers and Form D) and ingests mid-year YTD without breaking certificate continuity | §05.6, §06.12 R10, FR-PAY-709, 802 |
| G10 | **Provenance** — every rule version carries a gazette/notification source (URL + date); "check for a corrigendum" is enforced in the watcher path | §02.4, §02.5, FR-PAY-1005 |
| G11 | **Golden vectors pass** — the engine passes all §06.14 TV1–TV25 and the §08.12 examples before any rate-change release; a [Hypothesis] vector passes against its current parameter value and is re-baselined when the rule is confirmed | §06.14, FR-PAY-108, 201–211, 701, 713 |
| G12 | **The irreversibility line is guarded** — no month reaches PAYMENT_INITIATED past a failing verification gate, and no establishment's ECR ledger carries a silent gap | FR-PAY-301 M10, 711, 712; EV-037, EV-038 |
| G13 | **Attended, never autonomous, submission** — every portal submission is logged as an attended session by the employer or by our operator under written authority; the engine never submits | K-13, FR-PAY-711 F6, §22 |

**Bottom line for the engine.** The payroll & statutory-filing engine is the P0 core of
the product (§05.5 item 1) and the direct expression of the thesis (§01): it exists to
**produce portal-accepted statutory artefacts, submitted in attended sessions under the
employer's written authority**, and the payslip, the bank file and the FBP wallet are
the byproducts and the acquisition surface around that core. Its correctness is not a
UX concern but a legal one, which is why every FR here reduces to a deterministic,
effective-dated, retrospectively-recomputable, fully-audited rule. The competitive
position (§21) is stated carefully. **[Reversed]** Earlier drafts concluded "parity
with Zoho on computation, and differentiation only … on filing execution and the
maintained-update SLA, not on statutory breadth", on the belief that Frappe HR shipped
PT and LWF free. That is false from source code: Frappe HR v16's India payroll is three
files overriding three functions, with no Indian state anywhere in the tree and no
ECR, ESI, PT slabs, LWF, TDS statement or certificate artefacts (EV-031 — source
repository read, not executed); TallyPrime generates the central artefacts but has no
state PT slab table and no LWF engine (EV-032 — product documentation read, not
executed; both r3/r5 captures, 2026). So against Frappe and Tally, **multi-state PT and LWF are a genuine
differentiator — greenfield in both** (K-01). Gross-to-net is not: Frappe's salary
structure is genuinely strong and the bake-off will not be won there (EV-031). No vendor
in the six-vendor set claims to submit any filing (EV-030, published material as of
September 2026), so attended submission is unclaimed ground. We have no evidence of a statutory-breadth gap at Zoho and plan on
parity there.
