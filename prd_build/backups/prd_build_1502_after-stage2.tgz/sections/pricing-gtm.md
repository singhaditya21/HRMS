## 18. Pricing Architecture, GTM & Channel

This section converts the two most consequential findings in the document into a pricing and go-to-market plan: **the price floor of computation is zero and it is defended by well-capitalised incumbents** (§04), and **the statutory filing — not the payslip — is the unit of delivery** (§04). Those two facts are in tension. A zero floor says "you cannot charge for HR software as such." The filing thesis says "you can charge for the one thing the free alternatives structurally do not do — carry the filing to portal acceptance and stand behind that service." The deliverable is a portal-accepted artefact plus attended, assisted submission under the employer's written authority to act; the employer's and deductor's statutory liability is non-delegable and stays with them (K-13, §22). The whole pricing architecture below is the resolution of that tension: **price the guarantee, not the seat; publish the price; and let the free tiers do the top-of-funnel work Zoho and Kredily are already paying to do.**

Two standing rules from Draft 1 govern everything here and are not re-argued per subsection:

- **No number in this section may enter a financial model until the §20.6 validation programme reports.** Every competitor figure is *list price* from the vendors' own pages — the six priced suites captured on 5 Sep 2026 and normalised to 50 employees (EV-021–EV-027), the freemium and open-source rows from research rounds two and three (r2/01, r3/01, r3/03) — excluding GST, setup and term discounts. Realised ARPU is unmeasured. What the evidence supports is **shape, not level** (§04, [Verified]). Accordingly, every rupee figure below that describes *our* pricing, and every buyer-side number (bureau fees, CAC, conversion, willingness to pay), is tagged **[Hypothesis]** with a kill criterion; only competitor list prices and statutory facts are **[Verified]**.
- **AI is cost-of-goods and an acquisition weapon, not the revenue line** (§13, [Verified]). Seven vendors price HR AI at zero. The assistant is bundled into every paid plan. Monetisation appears only where the unit of value is legibly incremental — and even those SKUs carry a kill criterion (§18.5).

---

### 18.1 The price floor, restated as a design constraint

The single most consequential correction across both research rounds was that **the marginal price of HR-and-payroll software in the beachhead is zero, set there deliberately by vendors with more capital than us.** Any pricing conversation that does not begin here is fiction. This subsection restates the floor from §04 and adds, for each free alternative, the *displacement narrative* — not "why they are worse" (they frequently are not) but "on what specific axis we take the customer, and where we concede."

| Alternative | Price (list, ex-GST) | What it already does for free / cheap | The axis we win on | The axis we concede |
| --- | --- | --- | --- | --- |
| **TallyPrime** — incumbent for accounting and the statutory artefacts (one of two incumbents; greytHR holds the HRMS job — K-23) | ₹0 incremental; ₹22,500 Silver perpetual (single-PC), ₹67,500 Gold (multi-user, 3× the price — EV-032) | Ships the central statutory artefacts in the licence: PF 3A/5/6A/10/12A + ECR, ESI 3/5/6, PT statement, Form 16, 24Q annexures, 27A, 12BA, NPS, gratuity — but **no state PT slab table** (slabs hand-entered), **no LWF engine**, no leave module, cannot calculate leave encashment, attendance by manual voucher (EV-032 — product documentation read, not executed, 2026). Payroll *adoption*, as distinct from capability, is unknown (§20 V-02) | Attended, assisted submission (K-13); the state PT and LWF layer (EV-032); leave, employee/mobile surface, CA console, maintained statutory updates, a supported SLA | Central-artefact generation parity, offline operation, entrenched accountant muscle memory |
| **Kredily** | ₹0 forever, unlimited headcount; Payroll OS ₹1,249/mo up to 25, then ₹50/emp (r3/03) | PF, ESI, PT and TDS *calculation* in the free tier (Source: Kredily pricing page, read in rounds two and three, 2026 — r2/01, r3/03) | The outputs layer — bank payout files, PF/ESI challans, Form 12BB/124 and Form 16/130 are paywalled above free (EV-029) — and attended submission, which no vendor in the priced set claims to offer (EV-030); Kredily's feature-gate model has **no automatic conversion trigger** | Price at the very bottom; a firm that never files through software can stay free forever |
| **Zoho Payroll** | ₹0 to 10 emp; Standard ₹1,000/mo incl. 25 on annual billing (₹1,250 monthly), then ₹40 (₹50 monthly) per additional employee (r3/03) | Free tier already includes investment-declaration + proof workflow and bank salary payouts (through one named bank — r3/03); statutory form generation and TDS challan recording start at the paid tier — the outputs paywall of EV-029 (Source: Zoho Payroll India pricing, captured 2026; r2/01) | Attended submission, filing SLA, CA console, multi-state PT/LWF *maintenance*, deskless attendance — the surface Zoho treats as add-on | The ESS declaration workflow we once called a differentiator; against Zoho it is table stakes ([Killed] in Draft 1) |
| **Zoho People** | ₹0 to 5 users; ₹48/user/mo entry paid | Zia AI ships in the **cheapest paid tier at ₹48** (Source: Zoho People India pricing, captured 2026) | Payroll-and-filing depth (Zoho People is core-HR; payroll is a separate product the customer must also buy and wire) | AI as a line item — Zoho already gives it away at ₹48 |
| **Frappe HR** | ₹0 self-host; from ₹410/mo cloud | Genuinely strong gross-to-net salary structure. Its whole India payroll layer is 3 files / 549 lines overriding 3 functions (HRA exemption ×2, marginal relief); no Indian state name anywhere in the v16 tree; no ECR, ESI, PT slabs, LWF, 24Q/138, Form 16/130, 12BA or 27A. ERPNext v16 removed payroll; `india-compliance` is GST/vendor-TDS only (EV-031 — source repository read, v16, Sep 2026; not executed) | The Indian statutory layer — ECR, ESI, state PT, LWF, the TDS return — plus maintained updates under contract, attended submission and a support SLA. The real competing price is a Frappe partner's charge to build and then maintain that layer, not the ₹0 licence — unknown (r3/01 open question, §20) | Gross-to-net at ₹0 for a customer with IT capacity: **the bake-off will not be won on gross-to-net** (EV-031). **[Reversed]** earlier drafts credited Frappe v16 with PT across 15+ states and LWF across 14 and conceded multi-state PT/LWF; the source contains neither (K-01) |
| **CA / payroll bureau** | ₹3,000–15,000/mo **[Hypothesis]** (unvalidated; see §20 V-01) | Prepares the filings, carries the relationship, absorbs the judgement calls | Not a competitor to displace — a **channel and a price anchor** (§18.7). We arm the CA, we do not replace them | The trusted-advisor relationship; the CA's standing with the employer who signs off the return |

**[Verified]** The floor of *computation* is zero and defended: Kredily free-forever, Zoho ₹0 gates on a size proxy, Frappe ₹0 self-host, Tally ₹0 incremental (Source: respective vendor pages, captured 2026). Among priced suites the floor is not zero: list prices form **two anchors** at 50 employees — a value floor near ₹50 PEPM (Qandle, greytHR) and a mid-market clearing band of ₹80–200 PEPM (Zimyo, HROne, Keka) (EV-006, EV-027; §18.3). **[Hypothesis]** The bureau price band ₹3,000–15,000/mo is the single most important unknown in the whole model — it is the budget line we are actually competing for. Kill/validate: §20 V-01 mystery-shops 6–8 CAs and bureaus across two city tiers. If the real price to run 50-employee monthly payroll is under ₹2,000/mo, our ₹80–150 PEPM target (§18.3) loses its bureau justification, re-anchors toward the ~₹50 value floor, and the beachhead economics must be rebuilt.

The uncomfortable implication of the table: **on a computation-parity axis we lose to something free in almost every row** — the exception is the state PT and LWF layer against the two parity comparators, which neither Frappe nor TallyPrime ships (EV-031, EV-032). Against the SaaS rows it is claimed parity, not a gap: Zoho Payroll's free tier lists "Statewise PT, LWF" (r2/01) and greytHR's payroll page says "PT with all state-specific rules built-in" (r5/03, captured 5 Sep 2026) — page claims, not tested, where our edge is maintenance under contract, jurisdiction on the work location and attended submission (§21.3). The plan does not fight on computation. It fights on *attended submission, maintenance and guarantee* — which is why the pricing metric has to be the filing (§18.3) and the company has to be structured as a compliance-maintenance operation, not a feature-velocity startup (§05).

One correction we carry forward from §04 and must never re-introduce: the beachhead is **not** a "competitive vacuum." Zoho serves 25 at ₹1,000/mo, HivePayroll 25 at ₹1,499, RazorpayX 20 at ₹2,499, Kredily free — the band is *over-served by cheap product and under-served by product that files* (Source: vendor pricing pages, r2/05, r1/08 — **[Verified]** as list prices; the "under-served" reading is **[Hypothesis]**). Several of these are blocks too — Zoho and HivePayroll include 25, RazorpayX's entry plan caps at 20 — so the buyer at 21 employees is already being pushed across a plan boundary. Among the priced suites it is also **structurally overcharged**: six of six bill a 50-employee minimum block (Keka's was 100), so a 20-person firm pays ₹122.50–349.95 effective PEPM for seats it does not have (EV-026, EV-027). The pricing plan is therefore a quality-of-delivery and no-seat-floor wedge (P6), not an availability wedge, and every claim below that implies "nobody serves this band" is wrong on its face.

---

### 18.2 Pricing shape principles

Six shape decisions are supported by verified evidence even though no *level* is. They are the invariants; the tier table in §18.4 is one instantiation of them.

#### P1 — Size gate, never feature gate

**[Verified]** All three Zoho India free tiers gate on a *size proxy* — 10 employees, 5 users, ₹25 lakh revenue — rather than crippled features or a time limit (Source: Zoho Payroll / People / Books pricing, captured 2026). That shape converts automatically as the customer grows: the customer is never asked to notice a missing feature, only to cross a headcount they were going to cross anyway. Kredily made the opposite choice — unlimited headcount, features withheld — and consequently **has no conversion trigger at all**; a free Kredily user can run forever.

Design consequence: our free tier (§18.4) is gated at **< 20 employees** — precisely the headcount below which EPF does not apply (§06). The gate is therefore *statutory*, not arbitrary: the customer converts at the exact moment their compliance surface discontinuously expands. This is the cleanest possible size gate because it coincides with a real change in the customer's problem.

A subtlety the gate must respect: several obligations bind *below* 20, some on a trailing test, so "under 20 = no compliance" is false and the Free tier must still be genuinely useful. Per §06.1 (Source: Code on Social Security 2020, notified Central Rules 8 May 2026, [Verified]): ESI binds from **10** persons (EV-057), gratuity and maternity benefit from **10** employees (§06.1); gratuity and maternity benefit latch on "any day of the preceding twelve months", so a firm that touched 10 once stays in scope after shrinking, while ESI's Code-era latch wording is unconfirmed (§06.13). TDS on salary (s.392, ex-s.192 — EV-050), minimum wages and the POSH Internal Committee (EV-056) bind **from employee one**; Shops & Establishments registration follows each state Act. The prescribed-format appointment letter binds once the establishment has **10 or more workers**, on a form prescribed by the appropriate Government — state-sphere (OSH Code s.6(1)(f), EV-057). **[Reversed]** earlier drafts placed it "from employee one" (K-18). The Free tier therefore computes ESI and TDS and issues wage slips and, from 10 workers, the state-configured appointment letter; it withholds only *attended submission and the SLA*. The headcount gate that matters commercially is 20 (EPF), but the product below 20 is not empty.

Acceptance criterion (gate integrity): the system must compute each threshold test on the latch logic its statute uses (§06.1), must surface a countdown/alert as a tenant approaches a threshold, and must never silently down-tier a firm that has crossed 20 even if current headcount dips below it. A firm that hits 20 and drops to 18 is treated as still EPF-obliged for the covered members — the legacy EPF Act latched once covered and the Code-era wording is unconfirmed (§06.13) — and must not be pushed back to Free.

#### P2 — The cliffs are the attack surface; design a continuous ramp

**[Verified]** Zoho Payroll jumps ₹0 → ₹1,000/month between employee 10 and 11 (annual billing; ₹1,250 on monthly — r3/03); Zoho People jumps ₹0 → ₹48/user between user 5 and 6 (Source: Zoho pricing pages, captured 2026 — r2/01). **[Hypothesis]** Those discontinuities are moments of *forced re-evaluation* — the bill appears from nothing on a single hire, and the customer shops. We attack there and we do not reproduce the pattern: a customer crossing our own tier boundary should see a **continuous, predictable ramp**, ideally previewable in the price card before they hire the marginal employee.

Worked example of the attack **[Hypothesis]**: a firm at 10 employees on free Zoho Payroll hires its 11th and 12th (crossing 20 within a quarter is common in the 10–19 band). At 11 they are pushed to ₹1,000/mo *and* they have just triggered EPF at 20. That is the single highest-intent acquisition moment in the market. GTM (§18.6) instruments for it: the "you just crossed 20 — here is what turns on" campaign is aimed exactly at Zoho's own cliff. Kill criterion: if §20 V-03 shows Zoho discounts the cliff away in practice (realised ₹0 well past 11), the attack loses its edge and we compete on filing SLA alone.

Acceptance criterion (no self-inflicted cliff): at *no* headcount between 20 and 200 may a single marginal hire increase the monthly bill by more than (list PEPM × 1), i.e. the ramp is strictly linear-or-tapering with headcount and never step-shaped. The price card's headcount slider must render the exact incremental cost of employee *n+1* before the customer commits to the hire.

#### P3 — Publish the price card

**[Verified]** Keka — the most expensive vendor in the priced set — has withdrawn its live card: its pricing page carries no live price and the rate card survives only as HTML comments, and the suppression is global across its India, US and UAE pages — a company-wide move to a sales-qualified motion, which is itself the opening for a published-price competitor (EV-021, EV-024). Darwinbox and PeopleStrong route to "request a quote" (captured 2026). greytHR, Qandle, Pocket HRMS, Zimyo and HROne do publish (EV-027), but every one sells a 50-employee block (EV-026). **[Reversed]** earlier drafts listed greytHR as quote-only; it publishes a full card (EV-027). Publishing a price is not the same as selling self-serve: among the vendors checked, only Zoho Payroll completes a purchase online and publishes payment methods, while greytHR, Keka and Kredily route pricing-page calls to action to a trial, a free plan or sales (r3/03, medium — CTA census carried from an earlier sweep). **[Hypothesis]** A 30-person company will not sit through a demo to learn a price, so **self-serve INR pricing on the marketing site, through to checkout with GSTIN capture and a compliant invoice (§18.13), is the only way to be evaluable by the beachhead's lower half.** Publishing is also a competitive weapon: it forces the quote-only field to be compared against a number, and it disproportionately helps the low-ACV segment that cannot command sales attention. The published card carries GST-inclusive and GST-exclusive columns, per-band annual and monthly, and a headcount slider that previews the ramp (P2).

**[Reversed]** Earlier drafts said the mid-market comparison could not be made because Keka, Zimyo, HROne, Qandle and Pocket HRMS were TLS-blocked; the block was one fetch tool's failure, not the sites', and the rate cards are now captured (EV-009, EV-021–EV-027). ZingHR and Ramco publish no price and are enterprise adjacency, outside the set (EV-033). Publishing our own card does not require their numbers. Any *comparative* claim on the card ("cheaper than X") must carry its capture date, state whether it rests on a price page or an executed product, be re-captured before use and clear the competitor-claim rule (§21). We publish our price; we never quote a competitor's price as a third party reported it. The card's own statements about the SLA, the remedy and what the tier gates are customer-facing legal claims: each has a named owner and clears counsel before publication (Part D-20, §23).

#### P4 — Taper above 200

**[Verified]** Frappe's per-site model and Zoho's base-plus-overage both beat flat per-employee at scale (Source: Frappe HR cloud pricing; Zoho Payroll overage structure, captured 2026). A flat PEPM that is fair at 50 is punitive at 800 and loses the expansion band (§05). Above 200 the model tapers — declining marginal PEPM, or a base-plus-metered-filings structure — so that the per-employee cost at 500 is materially below the cost at 50. This is designed into the tier boundary (§18.4) rather than negotiated per deal, to preserve P3.

#### P5 — Price the guarantee, not the software

This is the shape decision that ties to the filing thesis and is developed fully in §18.3. The billable object is **portal-accepted filings — the artefact plus attended, assisted submission under the employer's written authority to act — under a maintained-compliance SLA** (K-13, §22; the operator-attended route is counsel-gated, §18.3). No vendor in the six-vendor priced set claims to submit any filing; greytHR publishes only generation language, and MYND/Qandle's outsourced filing operation is unpriced and demo-sold (EV-030). Tally generates the central artefacts (EV-032), the freemium players paywall them (EV-029), and Frappe generates no Indian statutory return (EV-031). The statutory liability stays with the employer and deductor — it is non-delegable (K-13); what we sell is the service and a capped contractual remedy, never a transfer of that liability. Everything the free tiers give away (calculation, generation) is below the line; everything they cannot give away (submission, maintenance, guarantee) is above it.

#### P6 — No seat floor: bill actual headcount from employee one

**[Verified]** Six of six priced competitors bill a 50-employee minimum block (Keka's was 100); a 20-person company cannot buy 20 seats from any of them, and pays ₹122.50 (Qandle) to ₹349.95 (Keka) effective PEPM at 20 employees (EV-026, EV-027). No competitor in the priced set bills actual headcount from employee one (K-25). Design consequence: the File tier bills the tenant's actual headcount — no minimum block, no included-seat bundle — so billable seats equal employees from the first paid employee, including a sub-20 tenant that elects File for attended ESI or TDS submission. It is the single most defensible pricing-*structure* differentiator in the evidence, and it compounds with P2's continuous ramp; the taper above 200 (P4) is the only place a base component appears. Acceptance criterion: for any headcount *n* on the File tier, the platform fee equals *n* × the tier's PEPM plus any multi-registration line (§18.3) — never a block price — and the price card's slider renders that exact fee for every *n*, including *n* below 50.

Two limits on the wedge, stated so collateral does not overreach. First, the claim is made against the six priced suites, dated, never against "the market": the freemium players' paid tiers also sell blocks, only smaller ones — Zoho Payroll Standard includes 25 employees and Kredily Payroll OS covers up to 25 (r3/03) — so against them the seat-floor gap exists only between 20 and 25 employees, and per-user structures exist elsewhere (§21). Second, the wedge can be closed by a card change: Keka's live small-business page says "starts at ₹90 per employee/month" while its withdrawn card was block-plus-overage, and whether the per-employee rate coexists with or replaces the block is unresolved (r5/03 open question). **[Hypothesis]** If any of the six publishes a per-employee card with no block, P6 stops being a differentiator against that vendor and the File tier competes on attended submission and the SLA alone; the trigger and response are H-P14 (§18.16) and §21's competitive-response scenario CRS-10.

---

### 18.3 Filing-as-the-unit pricing

The positioning claim (§04) is that the buyer's artefact is the filing, not the payslip — **ICAI's recommended fee schedule has no payroll-processing line item at all; it prices TDS return filing, PT registration, PT returns and TDS compliance review** (Source: ICAI recommended fee schedule, full-text searched, [Verified] — EV-017). The buyer already thinks in filings and already pays their CA per-filing-ish. Pricing should meet them there. (Note: the specific ₹37,500/yr ICAI figure is **banned** — pre-GST, carries Wealth Tax heads, 9+ years stale, §20.4 banned list. We use the *structure* of the schedule as evidence, never the number.)

But **pure per-filing pricing is rejected** for three concrete reasons:

1. **Adverse selection on cadence.** EPF ECR and ESI are monthly, PT is monthly-to-annual by state, TDS is quarterly, Form 16/130 annual. A pure per-filing meter would charge a Karnataka 50-person firm (monthly PT deduction with a February top-up — EV-014) far more than an identical firm in a state with a lighter PT cadence or none, for no difference in the value the buyer perceives. (Which states levy no PT is itself unverified — no negative has been verified for any jurisdiction, r2/10 — so the product never treats non-levy as fact, §06.4.) That is unsellable. Our *cost* does differ — supervised filing scales per registration × state × filing type (EV-088) — and that difference is recovered through the registration allowance below, not by metering filings. **[Reversed]** earlier drafts said the difference cost us nothing.
2. **Unpredictability the buyer hates.** The beachhead buyer is buying *away* from the CA precisely to stop getting variable monthly invoices. A meter re-introduces the variance they are fleeing (§18.13).
3. **It caps our own upside at the low end.** A 22-employee firm has few filings; per-filing would price it below sustainable, undoing the point of converting it off free.

The resolution is a **blended model: a per-employee-per-month platform fee that carries an explicit, contractual filing-and-compliance SLA, with the filing as the *value metric and the guarantee*, not the *meter*.** In plain terms: you pay per head, but what you are buying — and what the price card foregrounds — is "every statutory filing your headcount obliges, prepared as a portal-accepted artefact, carried through attended, assisted submission under your written authority (§22), acknowledged, and maintained against every rule change — or we remediate and pay the capped remedy the SLA defines." The statutory liability for the filing stays with the employer and deductor (K-13); the remedy is a contract term, and its allocation and insurability are under counsel review (Part D-17, §23).

**The attended-submission promise is itself counsel-gated.** Four questions are open (Part D-17, §23): whether our operators may act on government portals under the employer's credentials; whether each portal's terms of use permit third-party credential use; whether filing a TDS statement for a deductor engages the e-Return Intermediary route; and how the authorised signatory's personal DSC is handled. Until counsel clears them, operator-attended submission (§22 Mode C) is fenced (§05.7, §22.2.3) and is described anywhere customer-facing as a product capability whose statutory basis is under counsel review. The launch posture is employer-attended (Mode A) and co-attended (Mode B) submission — the employer's own user signs in, we supply the artefact, the form-control values, the checklist and live guidance, and we capture the acknowledgement (§22 FR-OPS-001). The price architecture must therefore survive a "no": **[Hypothesis]** the File tier at launch sells Modes A and B with the SLA covering artefact correctness, statutory currency, format-break coverage and the causation record, and adds Mode C per portal as each fence clears; if counsel's answer is "no" for a portal, the tier stays at Mode A/B for it and the price is re-tested against that scope in §20 (H-P15, §18.16).

#### The registration allowance — where the cost unit and the price unit diverge

**[Verified structure / unsized lines]** Revenue scales per employee; the dominant cost line — supervised filing — scales per registration × state × filing type (EV-088; §13). A 60-person, three-state, two-entity tenant can therefore pay less than a 150-person single-registration tenant and cost several times more to serve (r5 CFO review). A per-head fee alone cannot carry that. **[Hypothesis]** The File tier's per-head fee therefore includes a **registration allowance** — a stated number of statutory filing registrations (PF establishment code, ESI code, PT registration per state — the employer's PTRC and the entity's own PTEC are separate registrations, §06.4 — and TAN) held as the parameter `included_registrations_per_tenant` — and each registration above it is billed on a **multi-registration line**, `multi_registration_line_price`, per registration per month. Both are unsized and routed to §20; they are sized from §22.7's filing-instance counts and minutes per filing per registration, and from `max_supervised_minutes_per_filing_cycle`, which §13.19 derives and versions against these two parameters. The per-head card stays the headline (P3); the line appears only for multi-registration tenants, and the slider shows it before purchase.

#### The filing surface a 50-person firm actually owes, itemised

To price "every filing your headcount obliges," we must enumerate it. This is the recurring obligation set for a single-state 50-employee firm (EPF + ESI + PT-state), with cadence and due date — the concrete content of the SLA (Source: EPF Scheme / EPFS 2026, ESI Act & Central Rules, state PT Acts, Income-tax Act 2025 and Income-tax Rules 2026; [Verified] on instruments, [Hypothesis] on any date not re-checked for corrigendum per the §02 standing rule):

| Filing | Instrument | Cadence | Statutory due date | Notes |
| --- | --- | --- | --- | --- |
| **EPF ECR** | Electronic Challan-cum-Return | Monthly | 15th of following month | 12% employee + 12% employer (3.67% A/c 1 + 8.33% EPS), 0.50% EDLI (A/c 21); admin charges 0.50% (A/c 2 — rate not re-verified under the Code, **[Hypothesis]**, §06.2); EPS capped at ₹15,000 wage → ₹1,250. 11-field `#~#` file (EV-035); return approved before payment, an approved return can never be cancelled (EV-036); Regular / Supplementary / Revised (EV-037) |
| **ESI contribution** | Monthly challan | Monthly | 15th of following month | 0.75% employee + 3.25% employer on gross ≤ ₹21,000 (₹25,000 for persons with disability); contribution periods Apr–Sep / Oct–Mar |
| **PT return + payment** | State PT return | Monthly to annual (state-dependent) | State-specific | Slabs verified at state source for Maharashtra and Odisha, and in effect for Karnataka (EV-014); Maharashtra's return periodicity is assigned per registration each year by the department — ingested, never derived (§06.4); Odisha files annually; Karnataka's periodicity and every other state's slabs and cadence are not yet captured (EV-015, §20 V-09) |
| **LWF** | State LWF return | Per state | State-specific | The one verified periodicity is Karnataka's calendar-year cycle, due 15 January (r2/10); no LWF rate or split is verified from a government source in any state (EV-015, §06.8) |
| **TDS return** | Form 138 (ex-24Q) | Quarterly | 31 Jul / 31 Oct / 31 Jan / 31 May (Q4, of the year following the Tax Year) — Rule 219 (EV-049) | Breaking format change (EV-051) on a dual FVU stack (EV-052); Q4 regular format not yet released — Q4 generator fenced (EV-046) |
| **TDS deposit** | ITNS-281 / e-pay | Monthly | Prescribed by Rule 218, Income-tax Rules 2026 — date to be read from the notified text (§20); the "7th of the following month" carried in earlier drafts has not been checked against Rule 218 **[Hypothesis]** | Late-deposit interest was s.201(1A) under the 1961 Act; the 2025-Act equivalent is not mapped in our evidence (EV-050 maps only ss.192, 194P, 197, 200(3)) — §20 |
| **Form 130 (ex-Form 16)** | Annual TDS certificate | Annual | 15 June of the year following the Tax Year (Rule 215; r5/02) | Valid only if TRACES-generated — our role is data preparation and distribution (EV-048); Part B generation fenced on the unreleased Q4 format (EV-046) |
| **Statutory registers** | Six employer registers + Form V wage slip, one canonical set (EV-053) | Continuous | Electronic; retained five years (Wages r.51(4)) or five calendar years (OSH r.72(1)(vii), SS r.53(1)(e)) from last entry; state periods unknown (EV-054) | Wages Forms I, IV, IX; OSH Forms XIII, XIV, XV, XIX, XX + XVI; SS Form XXII; form numbers configurable per state (EV-053) |

**[Hypothesis]** A single-state 50-person firm therefore owes on the order of **~60+ discrete statutory events per year** (12 ECR + 12 ESI + 12 TDS challans + 4 TDS returns + monthly-to-annual PT + LWF + 1 annual certificate + registers). A two-state firm roughly doubles the state-tax portion. This count is the concrete thing the SLA absorbs and the concrete thing per-filing pricing would meter — and exactly why we price the *guarantee* per head rather than the *count*, with a registration allowance because the count scales our cost (EV-088).

#### The SLA is the product, and it is the thing free alternatives cannot copy

**[Hypothesis]** The guaranteed-compliance SLA is the core monetisable asset. Its terms (illustrative, to be validated in §20):

| SLA element | Commitment | Why free alternatives cannot match it |
| --- | --- | --- |
| **Attended submission** | Every obliged return (ECR, ESI, PT, Form 138 Q1–Q3) prepared in the period's notified format and carried to portal acceptance by the statutory due date — through attended, assisted submission (K-13, §22) — employer-attended or co-attended at launch, operator-attended under the employer's written authority per portal once counsel clears Part D-17 (§18.3). Form 130 data prepared for TRACES generation (EV-048); Form 138 Q4 and Form 130 Part B fenced (EV-046) | No vendor in the six-vendor priced set claims to submit any filing (EV-030); Tally generates artefacts (EV-032); Frappe generates no Indian statutory return (EV-031). Every statutory surface is an attended portal, so this is a service, not an API (K-13) |
| **Statutory currency** | Every rate/slab/format change (Budget, wage-ceiling, state PT/LWF, Code rules) reflected before its effective date | Open-source has no contractual maintenance obligation; Tally ships updates but not as a per-tenant SLA |
| **Contractual remedy (the penalty-exposure backstop)** | If a filing is late or rejected *due to our system or a submission we contracted to make*, we remediate and pay a contractual remedy up to a tiered cap. The statutory liability itself stays with the employer and deductor — non-delegable (K-13) | We are not aware, as of September 2026, of a free tier that carries a remedy; a CA answers to the client professionally, but the employer's statutory liability is not delegable to the CA either |
| **Format-break coverage** | Breaking changes (e.g. Form 138 replacing 24Q, EV-051; Q4 format not yet released, EV-046) absorbed by us, not the customer | This is the maintenance burden §05 says is the whole operating model — it *is* a cost of goods (compliance curation, EV-088), sold back as the value |
| **Retro-recompute correctness** | Arrears/retro runs recompute against the *rule version in force for the period corrected*, with audit trail — not today's version | §06's versioned, effective-dated wage engine is the only way to honour this; a spreadsheet or single-version tool cannot |

**[Verified]** The format-break risk is real and current: Form 138 replaces 24Q with a remapped record layout (challan 301–312 → A–K, 303 deleted; Annexure I 313–327 → C–N), Q1–Q3 v1.2 shipped 22 July 2026, and the **Q4 regular format is not released** — re-checked September 2026 — which also blocks the annual salary certificate (Source: TDS/CPC file-format notifications, 2026; EV-011, EV-046, EV-051). A customer on Tally or a spreadsheet owns that break themselves; on our SLA it is our problem. That is the concrete, dated instance of what the SLA sells.

##### Bounding the penalty-exposure backstop (so it is insurable, not open-ended)

The backstop is the most commercially dangerous SLA clause: an uncapped remedy would make the product uninsurable and the unit economics unmodellable. It is a **contractual** remedy — the statutory liability for every filing stays with the employer and deductor and cannot be delegated to us (K-13) — and it must be bounded against the actual penalty regimes (Source: EPF interest u/s 7Q is mandatory and auto-calculated, and damages u/s 14B may be deposited later at the employer's option, EV-039 **[Verified]**; the EPF and ESI damages scales are parameters `epf.damages_scale` and `esi.damages_scale` with no shipped default, §06.2–§06.3; the TDS-statement late fee — legacy s.234E, a ₹200/day figure carried from a secondary source — and the legacy s.271H penalty are **[Hypothesis]**, held as `tds.late_fee_per_day`, `tds.late_fee_cap` and `tds.penalty.statement_default`, with 2025-Act equivalents unmapped, §06.5, §20):

- **Scope**: covers penalty/interest that arises **solely from a defect in our system or a missed submission we contracted to make** — not from customer data errors, customer-caused delays, or funds the customer failed to remit. The remedy is set on the basis of a portal-accepted artefact plus best-efforts assisted submission under written authority (§22); liability allocation and insurability are open counsel questions (Part D-17, §23).
- **Cap**: tiered, e.g. capped at *N months of that tenant's platform fee* per incident and per annum (parameter `sla_remedy_cap_months`; level set in §20). This makes worst-case exposure a known multiple of ARPU, not a function of the customer's payroll size.
- **Carve-outs**: EPF and ESI damages (scales `epf.damages_scale`, `esi.damages_scale`), 7Q interest and the TDS-statement late fee (`tds.late_fee_per_day`, `tds.late_fee_cap`) are the concrete exposures; the SLA covers them within cap only where causation is ours. No damages percentage or fee cap is quoted in any contract until §06's parameters are re-captured from the notified text (§20).
- **Acceptance criterion**: every filing carries a machine-readable causation record (who supplied the data, when we generated, who submitted under which written authority, the acknowledgement — return file ID and TRRN for the ECR, EV-036; Return Receipt Number for Form 138, EV-051) so that a penalty claim can be adjudicated as "ours" vs "theirs" without dispute. Without this record the backstop is unpriceable.

Kill/validate: if buyer research shows the remedy must be *uncapped* to be credible (buyers do not value a capped guarantee), the SLA-premium thesis (H-P3, H-P11) weakens and we re-price on submission + maintenance alone. No current §20 item tests willingness to pay for a capped remedy — route to §20 as an addition to the V-07 instrument, alongside V-16's baseline miss-rate.

#### Why the 50% wage add-back makes per-head pricing *more* defensible, not less

**[Verified]** The identical text in Code on Wages s.2(y) and Code on Social Security s.2(88) deems the excess as wages when excluded components exceed one-half of remuneration, re-basing PF, gratuity and more — and it creates **two concurrent wage bases on one payslip** (§06.10; EV-010). This is the hardest single calculation in the build. Its pricing consequence is direct: the value of "we compute it correctly, per employee, versioned and retro-recomputable" scales with *how hard the computation is*, and the add-back is what makes it hard. A per-head fee is the honest metric for a per-head computation whose difficulty (dual wage base, effective-dating, the "or such other per cent as may be notified" variable) is invisible on the price card but drives the engine's build and curation cost (the dominant *running* cost is supervised filing, EV-088). Per-filing pricing would hide this value; per-head pricing surfaces it as "correct for every one of your people, every period, forever."

#### The two anchors, and where our target sits between them

**[Verified]** Captured list prices at 50 employees, entry tier, form **two anchors**, not a ceiling (EV-006, EV-027): a **value floor near ₹50 PEPM** — Qandle ₹49.00 annual / ₹59.00 monthly, greytHR ₹49.90 — and a **mid-market clearing band of ₹80–200 PEPM** — Zimyo ₹80.00, HROne ₹99.00, Keka ₹139.98 at its live ₹6,999 floor or ₹199.98 on the archived card (Pocket HRMS ₹59.90 annual sits just above the floor). The two realised points — **₹52** (greytHR, SMB) and **₹126** (PeopleStrong, enterprise), from filed revenue over claimed platform scale and biased *downward* because platform users exceed billed seats (EV-006; [Verified] inputs / [Hypothesis] derivation) — sit on the floor and inside the band respectively. **[Hypothesis]** Our File-tier target is **₹80–150 PEPM**: inside the clearing band, above the value floor because portal-accepted artefacts plus attended submission are what the floor does not sell. It is a target inside a band, not a price ceiling (K-09).

**[Reversed]** Earlier drafts derived the anchor from the two realised points alone and banned Keka's price as unobtainable. Keka's figures are now obtained from its own pages (EV-021–EV-023, K-10); no Keka capture in our evidence contains the "₹99" figure that circulated earlier, so that figure stays out of every model and deck.

Kill/validate: §20 V-03 (realised ARPU vs list). If realised ARPU runs 30–40% below list, the target re-bases toward the value floor and the four-line COGS stack (§13, EV-088) is re-run against it. **No PEPM number ships to a contract until V-01 (bureau price) and V-03 (realised ARPU) both report.**

#### Worked pricing example (all figures [Hypothesis], pending §20)

A 50-employee Karnataka firm (PT-liable, EPF + ESI obliged), on the beachhead tier at an illustrative ₹110 PEPM:

- Platform fee: 50 × ₹110 = **₹5,500/mo** ex-GST → ₹6,490 incl. 18% GST.
- Bundled, inside one registration allowance (one PF code, one ESI code, one PT state, one TAN — §18.3): monthly ECR + ESI + PT filings carried to portal acceptance through attended submission (§22), quarterly Form 138 Q1–Q3 (Q4 fenced, EV-046), Form 130 data preparation for TRACES issue (EV-048), the six registers + wage slip (EV-053), the assistant, ESS/mobile, one CA-console seat.
- Compare to the anchor it displaces: a bureau at the *midpoint* of the unvalidated ₹3,000–15,000 band ≈ ₹9,000/mo **[Hypothesis]**, with variable per-filing extras. Our ₹5,500 is below the bureau midpoint **and** fixed. Compare to Zoho Payroll: 50 emp ≈ ₹2,000/mo list (base ₹1,000 incl. 25 + 25 × overage) — **we are 2.5–3× Zoho's list.** Against the priced suites, ₹110 sits inside the ₹80–200 clearing band: above greytHR Essential (₹2,495/mo at 50) and below Keka's live floor (₹6,999/mo) (EV-027). The gap over Zoho is the SLA-and-submission premium, and its defensibility is exactly what §20 must test (V-07 instrument, V-16).

#### Second worked example — multi-state, where our value is largest [Hypothesis]

A 120-employee firm with establishments in Karnataka, Maharashtra and Tamil Nadu — three different PT regimes (Karnataka: monthly-salary base with a February top-up; Maharashtra: monthly-salary base with gender-differentiated thresholds, a February top-up and a department-assigned return periodicity — both EV-014; Tamil Nadu: a local-body levy whose slabs are not captured, §06.4), up to three LWF regimes (Karnataka's calendar-year cycle due 15 January is the one verified periodicity; the others are not captured — EV-015, §06.8), and consolidated central EPF/ESI/TDS:

- Platform fee at ₹110 PEPM: 120 × ₹110 = **₹13,200/mo** ex-GST → ₹15,576 incl. GST — plus the multi-registration line for every registration above the allowance: at least two additional PT registrations here (three states' PTRCs against one included, before counting each state's PTEC — §06.4), and more if the establishments carry separate PF or ESI codes (`multi_registration_line_price`, unsized — §18.3). This tenant's supervised-filing cost is a multiple of a single-state tenant's at the same headcount (EV-088), which is what the line recovers.
- The bureau alternative for a *three-state* firm is materially above the single-state midpoint because the CA is coordinating three state portals and three cadences — the multi-state case is where a single bureau relationship strains and where §18.1's "multi-state PT/LWF maintenance" axis is decisive.
- **[Reversed]** Earlier drafts said Frappe also covers this case on paper (PT across 15+ states, LWF across 14) at ₹0 self-host, so the pitch could only be maintenance. Frappe v16 contains no Indian state name and no PT slab or LWF logic, and TallyPrime has no state PT slab table and no LWF engine (EV-031, EV-032): multi-state PT/LWF is greenfield in both parity comparators, Frappe and Tally. Against a prospect coming from Frappe or Tally the pitch is coverage *and* maintenance under SLA plus attended submission (§18.11); against greytHR or Zoho, whose pages claim state PT, it is maintenance, work-location scoping and attended submission — never presence (§21.3). The competitor-claim rule still governs what collateral says (§21): describe what our product does and cite dated evidence; never say a competitor's published material is wrong.

The examples make the strategic bet explicit: **we are not the cheapest software; we are cheaper than the bureau and dearer than the self-serve floor, and the premium buys the guarantee.** If buyers will not pay a premium over Zoho for submission + SLA (§20 V-07 instrument, V-16), the beachhead thesis narrows to displacing only the bureau, not the software field.

#### The state PT/LWF surface — the concrete basis of the multi-state value

The multi-state pricing premium (second worked example above) rests on a real, dispersed statutory surface. Professional Tax is a *state* levy capped at ₹2,500 a year under Article 276 of the Constitution, run under roughly twenty separate State Acts by separate departments, and in Tamil Nadu and Kerala by local bodies rather than a state tax department (r2/10); each sets its own slab base, slabs, gender variants, periodicity and dates. LWF sits outside the four Labour Codes entirely and is less verified still. §06.4 and §06.8 are the canonical statement; the table below keeps only what pricing needs — which parts of the surface are verified and therefore sellable as coverage today, and which are a build dependency (§20 V-09). **[Reversed]** Earlier drafts said "only Telangana is verified"; only Telangana's employer-registration wording was ever verified, never its slab, and Maharashtra, Odisha and (in effect) Karnataka are now verified at state sources (EV-014).

| State | PT slab base and structure | PT periodicity | LWF | Evidence status | Pricing relevance |
| --- | --- | --- | --- | --- | --- |
| **Maharashtra** | Monthly salary; men nil to ₹7,500, ₹175 to ₹10,000, then ₹200 × 11 + ₹300 in February; women nil to ₹25,000, then the same split | Assigned per registration each year by the department — ingested, never derived | Not captured (amounts disputed, §06.8) | PT slabs **[Verified]** (EV-014) | Gender variant and February top-up: the engine edge cases the SLA absorbs |
| **Karnataka** | Monthly salary; ₹200 at ₹25,000 or above, ₹300 in February; no gender variant | Not captured | Calendar-year cycle, due 15 January; amounts not captured | PT effect **[Verified]** on the state portal, instrument not retrieved (EV-014); LWF periodicity **[Verified]** (r2/10) | High-volume beachhead state |
| **Odisha** | Annual income; nil below ₹1.6 lakh, ₹125/month to ₹3 lakh, then ₹200 × 11 + ₹300 in "the last month" (month undefined) | Annual, online | Not captured | PT **[Verified]** (EV-014); top-up month and a reported repeal both open (r1/06, r2/10) | A different slab base in kind — a flat monthly rule is wrong here |
| **Tamil Nadu** | Local-body levy; slabs per local body, not captured (`pt.TN.<local_body>.slabs`) | Not captured | Not captured | Levy structure **[Verified]** (r2/10); values **[Hypothesis]** | One state, many rate-setters |
| **Telangana, West Bengal, Gujarat and every other levying state** | Not captured (`pt.<state>.slabs`); earlier drafts' figures are not shipped | Not captured | Not captured | **[Hypothesis]** (EV-015) | Coverage is a build dependency, not yet a sellable claim |
| **States reported as not levying PT** | — | — | — | No negative verified for any jurisdiction (r2/10) | The product never treats non-levy as fact (§06.4) |

(Source: EV-014, EV-015, r2/10; §06.4 and §06.8 carry the full per-state specification. Aggregator PT tables are materially disputed, and at least one widely-cited 2026 table reproduces a superseded Karnataka structure — EV-015.)

Two pricing consequences fall directly out of this table:

1. **It is why the meter is rejected (§18.3).** A Karnataka firm deducts PT every month with a February top-up; Maharashtra's return cadence is set per registration by the department; Odisha files once a year; a three-state firm carries three different cadences. Metering the *count* would price identical firms wildly differently for zero difference in the value the buyer perceives. A per-head fee is neutral to this dispersion on the revenue side; our cost is not (EV-088), and the registration allowance with its multi-registration line (§18.3) is what absorbs the difference.
2. **It is why multi-state PT/LWF is a differentiator, and why maintenance keeps it one.** **[Reversed]** Earlier drafts said Frappe already covers PT across 15+ states and LWF across 14 at ₹0, so we could never out-cover it and could only out-maintain it. Neither Frappe nor TallyPrime ships a state PT slab table or an LWF engine (EV-031, EV-032): the state layer is greenfield in both parity comparators, Frappe and Tally (K-01), while the SaaS field claims it (§21.3). Coverage against the comparators is therefore ours to build — once the gazette-sourced dataset exists (§20 V-09) — and maintenance is what keeps it: the February cap-adjustment month, a slab revision notified mid-year, a new state bringing an establishment in scope are the moving parts an SLA absorbs and a free tool leaves to the customer.

---

### 18.4 The tier architecture

Three tiers plus a documentary enterprise gate, mapped to the headcount bands in §05. Feature gates are *statutory* wherever possible (P1). Every rupee figure is **[Hypothesis]** pending §20.

<!-- DIAGRAM: pricing-gtm-tiers -->

| | **Free — "Comply"** | **Beachhead — "File"** | **Growth — "Scale"** | **Enterprise — "Assure"** |
| --- | --- | --- | --- | --- |
| **Band** | < 20 employees | 20–199 | 200–1,999 | 2,000+ |
| **Gate type** | Size (statutory: EPF off) | Size + SLA | Size + taper (P4) | Documentary (§05) |
| **List price [Hypothesis]** | ₹0 | ₹80–150 PEPM target inside the ₹80–200 clearing band (EV-006); actual headcount, no seat floor (P6); registration allowance + multi-registration line (§18.3) | Tapered PEPM, base + metered | Bespoke; residency/cert-gated |
| **Core included** | Core HR, ESS, attendance, payroll *calculation* (incl. ESI and TDS, and the state-prescribed appointment letter once the establishment has 10+ workers — EV-057), Tally/Zoho/Kredily import | Everything in Free + **attended-submission SLA**, ECR/ESI/PT/Form 138 Q1–Q3 (Q4 fenced, EV-046), Form 130 data preparation (TRACES-issued, EV-048), six registers + wage slip (EV-053), CA-console seat, deskless/ADMS receiver | Everything in File + multi-entity, multi-state config, SSO/SCIM, deeper integrations, priority SLA | Everything in Scale + in-country inference, residency-selectable provider matrix, right-to-audit contract terms, ISO/SOC evidence pack |
| **Assistant (AI)** | Bundled (deflection) | Bundled | Bundled | Bundled |
| **Filing** | Generated artefacts only (customer submits) | **Portal-accepted artefacts + attended, assisted submission under SLA** — employer-attended and co-attended at launch (§22 Modes A, B); operator-attended under written authority per portal once counsel clears Part D-17 (Mode C, fenced — §18.3) | Same, priority | Same, with a regulator-grade audit trail |
| **Statutory liability** | Employer / deductor | Employer / deductor — non-delegable (K-13); our remedy is contractual and capped (§18.3) | Same | Same |
| **Sales motion** | Self-serve | Self-serve + light-touch, CA-referred | Light-touch + AE | AE + SI/procurement (deferred, §05) |
| **Role in model** | Funnel / land | **Revenue core** | Expansion | Vision (deferred ~3 yrs) |

Design notes:

- **Free is deliberately generous — it *calculates* everything.** We match Kredily and Zoho on calculation (giving it away costs us nothing incremental once built) and withhold only *attended submission and the SLA* (P1: size-gated, so a firm crossing 20 converts at the statutory moment, not because a feature was crippled). This is the opposite of Kredily's no-trigger model. Free must still compute ESI and TDS (s.392, ex-s.192 — EV-050) and issue the wage slip and, from 10 workers, the state-prescribed appointment letter (EV-057), because those obligations exist from employee 1 or 10 (§06.1) — a Free tier that could not do statutory calc would not be trusted at conversion.
- **Payroll is never an upsell.** Every vendor that publishes tiers puts payroll in its entry tier and gates performance, recruitment, engagement, analytics and workflow upward (EV-028). Payroll computation and artefact generation therefore sit in Free, attended submission and the SLA in File — the first paid tier — and no payroll capability is held back for Scale.
- **The Free→File boundary is the whole business.** A < 20 firm has no EPF; at 20 the surface jumps (ECR, a Grievance Redressal Committee at 20 or more *workers*, EV-057) and a spreadsheet stops being safe. Zoho's free payroll tier stops at 10, Kredily's has no headcount gate, and none of the six priced suites has a free tier (r5/03). One vendor's free boundary does sit at the EPF line: a round-one capture (4 Sep 2026) shows factoHR offering "Free ₹0/forever, Up to 20 employees" (r1/08), with a narrower scope than ours — employee data, letters and payslips — and it was not re-checked in later rounds (re-capture routed as §21 CQ-15). The gate position is therefore not unique; what is ours is the combination at that line — full statutory computation and artefact generation below it, attended submission and the SLA above it. That is the conversion engine, and no collateral claims the gate itself as a first.
- **File→Scale taper (P4)** avoids punishing growth: PEPM declines with headcount and a base-plus-metered-filings option appears above ~300 employees where multi-establishment filing volume, not seat count, drives cost. Note the mid-band obligations that arrive inside File/Scale and should be feature-gated to mirror them (§06.1, [Verified]): **crèche at 50, canteen at 100, standing orders at 300 and retrenchment/closure approval at 300** (the last raised from 100 by the Codes; EV-057), plus **a works committee at 100 or more workers only where the appropriate Government orders one** — not automatic (IR Code; r3/04, §05.1). Each is counted in its statute's unit — workers or employees — which is a schema field, not prose (EV-057). These are not price tiers but are product-surface changes the tier must accommodate.
- **Enterprise ("Assure") is priced but not sold in v1** — it exists on the card so the vision is legible, but the §05 documentary gate (ISO 27001 seasoning, references, residency) means no revenue is modelled from it for ~3 years.

Acceptance criterion (tier mapping): every headcount-driven feature gate in the product must be traceable to a named statutory threshold (10/20/50/100/300) or to the §05 documentary gate — no arbitrary "Pro-only" feature walls, because an arbitrary wall recreates the feature-gate anti-pattern P1 exists to avoid.

---

### 18.5 Packaging and monetised add-ons

The assistant is bundled everywhere (§12). Monetisation appears only where the unit of value is *legibly incremental* and does not track headcount — otherwise it reads as a surcharge on an expected feature ([Killed]: premium AI SKU, §20).

| Add-on | Pricing unit | Why it is separable from PEPM | Status |
| --- | --- | --- | --- |
| **Recruiting** | Per requisition or per hire (not per employee) | **[Verified]** Recruiting cost does not track headcount — a tenant hiring 15%/mo vs 3%/mo is a ~15× inference-cost difference on identical PEPM (resume screening ₹1.13 vs ₹17.00 per employee-month, r2/03; §13.7 — the hiring rate is 5× and CVs per hire and tokens per CV compound it, §19). greytHR already prices Recruit per recruiter, not per employee (₹2,500/recruiter/month — Source: greytHR pricing, captured 5 Sep 2026, r5/03); Keka's archived card priced Hiring at ₹1,500 and ₹2,500 per recruiter per month (EV-022) | Ship metered in v2 (§05); recruiting is inbound-only given the Naukri/Resdex dependency (§10) |
| **Location / GPS tracking** | Per tracked user/mo | **[Verified]** greytHR prices GPS live tracking at ₹140/user/mo against its ₹45 Essential marginal seat rate — **3.1×** (Source: greytHR pricing, captured 5 Sep 2026, r5/03). Location is monetisable and under-exploited | Add-on for deskless-heavy tenants; kill if attach < 10% of eligible tenants |
| **Bulk document generation** | Per document batch / metered tokens | Legibly incremental AI output (offer letters, F&F letters at scale); cost tracks volume not headcount | Metered AI SKU (§13); kill per §20 V-07 |
| **HR-analyst copilot** | Per admin seat/mo | Heavy-user AI consumption concentrated on a few admin seats; **[Verified]** an HRMS is priced per employee but consumed per user, and one heavy user can exceed a seat's entire ARPU (§13) | Per-admin-seat SKU; kill per §20 V-07 |
| **Self-hosted / dedicated** | Priced compliance SKU | **[Verified]** Serverless beats dedicated H100 ~74× at real utilisation (§13); self-host is *only* a compliance SKU for named regulated accounts, never a cost play | Enterprise gate only |

**[Hypothesis]** The metered-AI SKUs (bulk docs, analyst copilot) share one kill criterion: §20 V-07 (Van Westendorp / conjoint, 30–40 buyers). If willingness-to-pay for HR AI is genuinely zero everywhere, **drop the metered AI SKUs entirely** and keep AI purely as deflection/COGS. The recruiting and location add-ons survive that kill because their value is not "AI" — it is a distinct job (hiring, field tracking) with its own non-headcount cost driver.

**Benefits/FBP is built but not monetised in v1.** Per §11, build FBP declarations, wallet configuration, proof-of-spend, dependant records and endorsement history in v1 — they are the option value on any future attach business and are expensive to retrofit — but model **software PEPM and any attach revenue as two separate lines that are never blended** (§11 [Verified]). One dated product hook to design for: effective **1 April 2026** the tax-free meal perquisite rose ₹50 → ₹200/meal and the gift/voucher threshold ₹5,000 → ₹15,000/yr (EV-019, **[Hypothesis]** — two dated secondary reads and a counsel spot-check concur; the gazette text is not yet read and the rule citation is routed to §20). The ₹200 is tax-free **only** for meals during working hours at office or factory premises, or non-transferable vouchers usable only at eating outlets; without those conditions the perquisite is taxable, payslips under-deduct, and the demand plus interest lands on the employer — so the wallet enforces the conditions as engine constraints (§08, §11), not as a limit field (K-19). This changes FBP *configuration* surface, not our pricing.

Explicitly **not packaged**: a premium AI tier (seven vendors at zero, §12 [Killed]); interchange/benefits-float revenue (Zaggle economics, §11/§20 [No]); any per-employee AI surcharge.

---

### 18.6 GTM motion by band

The motion is **product-led at the bottom, CA-referred in the middle, and AE-assisted at the top of the beachhead** — with no enterprise field motion in v1. The full channel map — CAs, payroll service providers, Tally partners, bank alliances, review and Indian marketplaces, device dealers — with each channel's evidence, build prerequisites and revenue gate is §18.18.

#### Free (< 20): pure product-led, statutory-trigger acquisition

- **Acquisition channels:** SEO/content on the exact statutory questions this band searches ("EPF registration 20 employees," "how to file ECR," "PT slab Karnataka 2026," "what changes at 20 employees India"), the free importers as landing pages (§18.9), and the Zoho-cliff campaign (P2). The content is a natural fit for the compliance-maintenance operating model (§05) — the statutory-change watcher's output *is* the content engine, and it must catch *amendments not just new instruments* (the corrigendum lesson, §06).
- **Activation metric:** first successful *calculation* run (payroll computed for real employees), not signup. **North-star for the tier:** crossing 20 while still on us.
- **Cost discipline:** the assistant deflects support (the reason AI is COGS); a free tenant that requires human support is unit-negative and is nudged to self-serve or to convert. Per-tenant and per-user AI rate limits are P0 (§13) precisely so a free tenant cannot run up inference cost that has no revenue behind it.

#### Beachhead (20–199): self-serve price card + light-touch, CA-referred

- **[Hypothesis]** self-serve INR pricing is the only way to be evaluable by a 30-person firm (P3). The 20–49 lower half is expected to close self-serve off the published card; the 50–199 revenue core is self-serve *or* light-touch with an AE and, frequently, a **CA referral** (§18.7).
- **[Verified]** The buyer committee in Indian SMB HRMS spans HR, finance and the founder — finance is a first-class buyer, not a rubber stamp (r3/03). The card, the SLA wording and the billing mechanics (§18.13) are therefore sales collateral for the finance buyer, not back-office detail.
- **Sales-motion shape.** **[Verified]** Keka advertises separate business-development roles for the India SMB and mid-market segments alongside enterprise account executives — a split SDR/AE motion — and the earlier claim that this segment is sold by inexpensive full-cycle reps rested on one small vendor's job advertisement and is retracted (r3/03). **[Hypothesis]** Assume a split motion, and at least two cost lines per assisted close, until our own funnel data says otherwise; no rep-cost figure enters the CAC frame (§18.14) until it comes from salary data or our own hiring (§20).
- **The trigger event is the sale.** Highest-intent moments: crossing 20 (EPF turns on), a statutory format break (Form 138/Q4, §06), a failed/late filing under their current setup, the November 2026 ESI-regime uncertainty (§06.9 — the saved ESI schemes expire on or about 21 Nov 2026 and the regime from 22 Nov 2026 is unresolved; EV-004, §20 V-08), or bureau-fee sticker shock. GTM instruments to detect and target each.
- **Migration is the objection to neutralise** (§18.9): **[Hypothesis]** the beachhead's most-cited churn/switching fear is cutover pain. The demo *is* the import.

#### Growth (200–1,999): AE-assisted, expansion-led

- Reached primarily by **expansion from the beachhead** (§18.10), not net-new cold. Same product shape, more config (multi-entity, SSO/SCIM). Motion is a named AE + solution-consultant, still with a published anchor to avoid the quote-wall (P3), custom only above ~500. Private-sector only at first (§05).

#### Enterprise (2,000+): deferred, documentary

- **[Verified]** Foreclosed ~3 years on arithmetic, not eligibility (§05): 30k-employee prior-implementation criteria (SBI Criterion 7), the Appendix-T 150-mark incumbency-weighted matrix, GFR 2017 Rule 173(i)/170(i) startup exemption that is a *buyer's permission not a bidder's entitlement*, ISO 27001:2022 one-year seasoning clock (held ≥1 year before RFP), and sectoral overlays: RBI's outsourcing obligations — localisation, audit including by RBI, sub-contractor consent — which are **materiality-gated, entity by entity** (EV-087, mirror-sourced — pull from the primary source before customer use); SEBI's cloud framework, which requires in-India residency and reaches SaaS providers through the MeitY-empanelled-infrastructure rule (EV-085); and IRDAI, which imposes **no** localisation beyond policy records (EV-086) (Source: SBI/Indian Bank HRMS RFPs; GFR 2017; RBI Outsourcing of IT Services Directions, effective 1 October 2023). **[Reversed]** earlier drafts said "RBI/IRDAI residency and right-to-audit with no turnover threshold" — RBI's test is materiality, not turnover (K-22), and IRDAI has no general localisation rule (K-08). Whether a given arrangement is material is a counsel question (§23). No field motion, no revenue modelled. The only month-zero action is starting ISO 27001 (§05) so the seasoning clock is spent, not wasted — "the cheapest year you will ever buy."

---

### 18.7 Channel A — the CA / consultant console

This is **the most consequential GTM recommendation in the document, and it carries the least evidence.** Draft 1 is explicit: *no CA has been asked a single question* ([Hypothesis], §20). The console is designed as if the channel works; the §20 programme decides whether it does.

#### Why the channel is plausible

**[Verified]** The bureau/CA is a real budget line and the trusted party who prepares the return for the employer to sign off; ICAI prices filing work, not payroll processing (EV-017, §04). The level of that line — ₹3,000–15,000/mo — is **[Hypothesis]** (§20 V-01). A CA serving 20–80 small clients (**[Hypothesis]** on the count, §20 V-05) is *already* the aggregator of exactly our beachhead. If we arm the CA rather than replace them, one CA relationship is a distribution channel to dozens of tenants. **[Verified]** eSSL markets integration with six named HRMS vendors on its own site (§09) — the ecosystem norm is partner-not-compete, and the CA is the human analogue.

**[Verified]** The accountant channel is the most consistently evidenced channel in this market, and it is already contested (vendor pages read in research round three, 2026 — r3/03; programmes not joined or executed): Kredily runs a CA Program distinct from its white-label Partner Program for payroll service providers, on a multi-company dashboard ("Switch between every client from one login") that tracks PF, ESI, PT and TDS across the client book, with clients landing on the Free Forever plan and monetising when they need payouts, challans or Form 16; factoHR names "CA/Tax Consultant" among six recruited partner classes; Zimyo recruits tax consultants and financial advisors by name; greytHR productises a payroll-service-provider landing page. **A multi-client console is therefore the entry ticket to the channel, not a differentiator.** Our console is positioned on what it carries — the filing state across the book, attended submission under the client's authority (§22 Mode D) and the SLA — never on its existence (§21).

#### The console specification (functional requirements)

**[Hypothesis]** The CA-facing console is a first-class product surface, not a report export. Requirements:

| Capability | Detail | Statutory / product basis |
| --- | --- | --- |
| **Multi-client switching** | One CA login, N tenant workspaces, sub-second context switch, per-client role scoping | The CA's actual workflow is N clients, not one |
| **Per-client compliance calendar** | Consolidated due-date board across all clients: ECR (15th), ESI (15th), TDS deposit (Rule 218 date, §20), PT (state cadence), Form 138 quarterly (Rule 219, EV-049), Form 130 annual (15 June), LWF — with each filing's state from the filing state machine: SCHEDULED, BLOCKED, GENERATED, VALIDATED, SUBMITTED, REJECTED, ACCEPTED, REVISED, SUPPLEMENTARY, PAYMENT_INITIATED, FILED (FR-PAY-711, §08) | §06.11 filing calendar; the CA's core anxiety is "which client's filing is due" — and, since a rejected filing is not done, "which one bounced" |
| **One-click statutory export** | Form 138 Q1–Q3 (Q4 fenced, EV-046) and PT/LWF return export per client in the period's notified format | §06 format currency. In v1 the CA submits through the portal under the employer's or deductor's authority, as today; whether a third party filing Form 138 for a deductor engages the e-Return Intermediary route is a counsel question (Part D-17, §23) |
| **Read-only audit access** | Immutable, timestamped view of every computation and filing for a client, for the CA's own review before the employer signs off | Rules-first audit trail (§08); the CA answers to the client professionally and needs to inspect — the employer's statutory liability is non-delegable (K-13) |
| **Client invitation & billing modes** | CA can invite a client onto the platform; billing either to the client direct or to the CA (agency/reseller mode) | Determines whether the CA is a referrer or a reseller — the pivotal economics question |

Acceptance criterion (console viability): a CA managing 20 client tenants must be able to see, in one screen, every filing due in the next 30 days across all clients with its status, and export the current-format return for any one in a single action. If the console cannot compress a 20-client due-date view to one board, it is a report export, not a channel product, and the channel thesis is not tested fairly.

#### The economics question that inverts the channel

**[Hypothesis]** The channel works only if CAs see us as *leverage*, not *disintermediation*. Two possible relationships:

1. **Referral / arm-the-CA:** CA keeps the client relationship and their advisory fee; we take platform PEPM; CA gets a referral share or a discounted agency rate. CA's incentive: serve more clients per hour of their time. This is the intended model.
2. **Disintermediation (the failure mode):** the CA perceives that a self-filing HRMS removes their monthly payroll-processing revenue. They then steer clients *away* from us. The channel inverts into an opponent with trusted-advisor access to every one of our prospects.

The referral-share economics must be modelled as **CAC, not COGS** (§18.14): a referral share paid to the CA is a customer-acquisition cost that is capped so blended payback holds, not a recurring margin leak. In agency/reseller mode (mode 1 made explicit), the CA buys at a discounted rate and resells — here the discount is a *channel margin* and the tenant relationship is legally the CA's; ICAI's rules on a member's permissible commercial arrangements must be checked before offering a reseller rate (Source: ICAI Code of Ethics on fees/commission — [Hypothesis], confirm with counsel before launch, §23).

**Kill/validate:** §20 V-05 (20–30 practising CA interviews, both city tiers). If CAs predominantly see us as disintermediation, the console is repositioned as a pure agency/reseller tool (mode 1 economics made explicit and generous) or the channel is abandoned and the beachhead goes direct-only. **No revenue forecast may depend on the CA channel until V-05 reports.** The related risk (Zoho widening free gates) makes the CA console *more* valuable, not less — we are not aware, as of September 2026, of a Zoho CA console, though Kredily sells one (r3/03), so the defence rests on the submission and SLA the console carries (§20.8). The commission and referral mechanics the channel needs — term, tiering, attribution window, deal registration, payout cap — are specified as parameters in §18.18.

---

### 18.8 Channel B — the Tally ecosystem

**[Hypothesis], and load-bearing.** Draft 1: the Tally-partner channel is *equally unvalidated* — no revenue may depend on it (§20).

#### The two distinct Tally plays

1. **Tally as migration source (P1 — first within the importer set, §05.5 item 17; §18.9).** Tally is one of two incumbents with two jobs: it owns accounting and the statutory artefacts (EV-032), while greytHR owns the HRMS job (K-23). The import is the wedge into Tally's accounting relationship. This is a product surface, not a partnership, and it is committed regardless of whether the channel works.
2. **Tally partners as a distribution channel (unvalidated).** Tally runs a four-grade partner channel (3-Star and 5-Star Certified, Associate, GVLA) plus a separate CA Community; its public locator listed 1,257 partners — a directory count, not an audited network size — and it publishes no partner margins (r3/03). That channel already sells and services accounting software to exactly our beachhead. If partners resell or refer us, that is a ready-made field force we cannot afford to build. (The "~25,000-partner" figure in earlier drafts has no source in the evidence and is withdrawn.) One HRMS vendor already recruits this class by name — factoHR lists "Tally/CRM/ERP Reseller" among its six partner categories (r3/03) — but there is no public evidence of how many Tally partners carry an HRMS line or at what attach rate (r3/03 open question). The precondition on our side is concrete: a payroll journal export in a TallyPrime-importable format, with ledger and cost-centre mapping configurable per client, so that the partner's accounting stack is left untouched (r3/03; §16).

#### The hard prerequisite: how many Tally businesses run Tally *payroll*?

**[Verified] as a question, unresolved as a fact.** **[Reversed]** Earlier drafts framed this as "is Tally even the incumbent?"; the incumbency question is settled — two incumbents, two jobs (K-23) — and what stays open is Tally payroll *adoption*, as distinct from capability (EV-032). §20 V-02 asks what share of Tally's ~2.5m businesses actually *enable the payroll module.* The answer swings the entire channel: **at ~5% enablement, the Tally-partner channel is a footnote for payroll; at ~40%, it is the channel that matters.** Method: 15–25 Tally-partner interviews + buyer survey. **No Tally-channel investment beyond the importer proceeds until V-02 reports.**

#### Channel conflict to design around

**[Verified]** We explicitly decline hardware (§09/§20 [No]): devices are ₹4,000–25,000 one-time, no margin, and reselling them creates direct conflict with the dealer/eSSL networks that could otherwise distribute for us. The same logic governs Tally: **do not compete with the partner's existing revenue.** We are the payroll-and-filing layer the partner attaches to their accounting sale, not a Tally replacement. If a partner reads us as "sell against Tally," the channel dies — so collateral positions us as complementary (the state PT slab table, LWF engine and leave module Tally lacks — EV-032 — plus the employee surface, mobile, attended submission, filing SLA and CA console, §18.1).

---

### 18.9 Migration and switching strategy

**[Hypothesis], first-class product surface.** Implementation friction is the most-cited churn trigger in the market, and mid-year cutover is where it concentrates. Migration is **budgeted as acquisition infrastructure, not a services task** (§16).

#### The mid-year cutover problem, itemised

A customer switching in, say, August must carry across without loss or double-counting:

| Migrated object | Why it is hard | Correctness requirement |
| --- | --- | --- |
| **Opening balances & YTD earnings** | Payroll is cumulative within a Tax Year (Apr–Mar; "Financial Year" in 1961-Act periods — EV-050); a mid-year switch inherits YTD gross, deductions, PF/ESI/PT/TDS already paid | YTD must reconcile to the prior system's last payslip *and* to filed challans |
| **TDS already deducted + regime** | TDS on salary (s.392, ex-s.192 — EV-050) is computed on projected annual income; mid-year switch must import cumulative TDS and the employee's regime election (new regime by default unless the old is opted — ex-s.115BAC, its 2025-Act counterpart held as rule-version data, §05.5 item 6) so the annual projection is continuous | The year's Form 138 salary data must stitch two systems, because TRACES generates Form 130 from it (EV-048); our Form 130 data preparation is fenced until the Q4 format is released (EV-046) |
| **Previous-employer income** | Employees who joined mid-year declared prior-employer income; must survive migration | Or the annual TDS projection is wrong |
| **Investment declarations mid-cycle** | Declarations (and proofs) made in the old system must carry, or the employee re-enters them and trust is lost on day one | Import declaration + proof state |
| **EPF UAN & ESI IP continuity** | UAN and ESI IP are employee-lifetime identifiers; discontinuity breaks the employee's statutory record | Preserve UAN/IP linkage; never mint duplicates |
| **50% add-back wage-base history** | The dual wage base (§06) is period-specific and effective-dated; importing only a single "gross" loses the split | Import must reconstruct both wage bases per period, or arrears/retro recompute wrongly |
| **Leave balances & gratuity accrual** | Accrued leave and gratuity (eligibility, continuous-service counting and computation per §06.6) are liabilities that must transfer exactly | Balance parity with prior system as of cutover date |
| **Contribution-period boundaries** | ESI contribution periods (Apr–Sep, Oct–Mar) and PF wage-ceiling application mid-period affect the running totals | Import at a clean period boundary or reconcile the partial period |
| **Certificate continuity** | Form 130 (ex-16) is valid only if TRACES-generated (EV-048), so continuity means the year's Form 138 data spans both systems without gaps | One continuous Form 138 salary record for the Tax Year; Form 130 data preparation fenced until the Q4 format is released (EV-046) |

#### The importers, as acquisition infrastructure

Importers are **P1** in the v1 scope (§05.5 item 17), Tally first within them because Tally owns the accounting and statutory-artefact job (EV-032) — though how many beachhead firms run Tally *payroll* is unknown (§20 V-02). Importers from Zoho Payroll, Kredily and Frappe are *acquisition infrastructure, not integrations*, and are budgeted as such (§16). Each importer is a landing page and a demo-that-is-the-migration:

- **Tally importer (P1, first):** parse Tally payroll masters + YTD; the migration path whose volume V-02 will size.
- **Zoho / Kredily / Frappe importers (P1):** direct switch paths from the free-tier field. A Kredily/Zoho user churning up to a paid product that carries filings to portal acceptance is our best-qualified lead; the importer removes the only real objection.
- **Spreadsheet importer (priority to be set in §05.5 — not yet listed there):** the true incumbent for much of the beachhead is Excel + a CA. A forgiving, template-guided spreadsheet importer with validation-on-ingest is table stakes.

**[Hypothesis]** Migration success is an activation metric, not a support ticket. Acceptance criteria:
- A 50-employee tenant completes a mid-year import — with YTD, UAN/IP, declarations, both wage bases and leave balances reconciled — self-serve or with light-touch, inside one pay cycle.
- Import reconciliation report shows zero unexplained variance between imported YTD and the prior system's filed challans; any variance is surfaced for the customer to resolve before the first live run, never silently absorbed.
- No duplicate UAN or ESI IP is ever created for an employee who has one.

Kill: if median assisted migration exceeds a full pay cycle, migration cost re-enters CAC and the low-ACV lower-half economics (§05) break (H-P7; first dataset test in §20 V-15).

---

### 18.10 Land-and-expand

The model is **land free or low in the lower beachhead, expand up the bands on the same product shape.** It is the reason the 20–49 half is acquired at all despite likely-negative unit economics at list PEPM (§05).

#### The expansion ladder

| Stage | Trigger | Motion | Value captured |
| --- | --- | --- | --- |
| **Land — Free** | Firm < 20 adopts for calculation + free importer | Product-led | ₹0; option on conversion at 20 |
| **Convert — Free → File** | Crossing 20 (EPF turns on) | Statutory-trigger, in-product | PEPM begins; the core conversion |
| **Grow within File** | Headcount rises 20 → 199; more states (PT/LWF); deskless hires | Automatic (per-employee) + add-on attach (location, recruiting) | PEPM × growing headcount + add-ons |
| **Expand — File → Scale** | Crossing 200; multi-entity; SSO/SCIM need | Light-touch + AE | Tapered PEPM at larger base + metered filings |
| **Enterprise (deferred)** | 2,000+; documentary gate met | AE + procurement | Vision only, ~3 yrs out |

#### Why land-and-expand, not land-and-monetise-immediately

**[Hypothesis]** The 20–49 lower half is net-negative on unit economics at list PEPM and is justified *only* as a funnel into 50–199 (§05). At the lower half, ACV lands around ₹24,000–60,000/yr (§05.1, [Hypothesis]) — below where self-serve CAC comfortably clears without expansion. The whole model rests on cohort progression. Kill criterion (inherited from §05): if cohort analysis at month 18 shows **< 25% of 20–49 lands crossing into 50+ within 12 months**, stop acquiring the lower half and raise the commercial floor to 50 (H-P8). This is also the pre-agreed response if Zoho widens its free gate (§20.8): the beachhead floor moves up and we lean harder on the filing SLA and attended submission — neither of which, as of September 2026, we are aware of Zoho selling — carried to CAs through the console.

#### Net revenue retention as the expansion metric

**[Hypothesis]** The expansion thesis lives or dies on NRR, not logo growth. Target: NRR > 100% driven by (a) headcount growth within accounts (automatic PEPM), (b) band graduation (File → Scale), and (c) add-on attach (location, recruiting, analyst copilot). Because pricing is per-employee and the beachhead is *growing* firms, *headcount-driven expansion is structural* — a 50-person customer that becomes 90 people pays 80% more with zero sales effort. Kill: if NRR < 95% at 12 months post-launch cohort, the expansion model is broken and the CAC math (which assumes expansion) must be re-run at flat-account economics (H-P9).

#### Retention, renewal and the seasonality of churn

**[Hypothesis]** Retention is not symmetric across the year, and the pricing/renewal calendar must respect the Indian financial year. Concrete mechanics:

- **The switching-cost moat is real but time-shaped.** Once we are filing-critical, the mid-year cutover pain that was our acquisition *objection* becomes our retention *moat* (§18.9): a customer cannot cleanly leave mid-year without inheriting the same YTD/UAN/TDS-continuity problem in reverse. The dangerous window is therefore the **Tax Year boundary (Feb–Apr)** — the only clean cutover point — which is exactly when annual-prepay renewals and any competitive re-evaluation concentrate. Renewal motion and any price change must be timed and resourced around this window, not spread flat.
- **Form 130 (ex-16) issuance is a retention event, not just a compliance one.** The annual certificate is due by 15 June (Rule 215; r5/02); it is generated by TRACES from the year's Form 138 data we prepare (EV-048), and it is blocked while the Form 138 Q4 format is unreleased (EV-046). A customer whose Form 130s issued cleanly and on time for all employees has just experienced the product's single most visible statutory deliverable right before the renewal window. Instrument certificate-issuance success as a leading retention indicator.
- **Price changes grandfather the installed base.** A list-PEPM increase (e.g. after §20 V-03 revises the target upward) applies to new logos immediately and to existing accounts only at their FY-boundary renewal, with notice — churning an existing filing-critical account over a price step is strictly worse than the incremental ARPU it captures.
- **Win-back is cheap for us and expensive for the customer.** A churned tenant retains their imported history; re-onboarding them is near-zero cost on our side and spares them a second migration. Win-back offers target the FY boundary and lead with "your data and filing history are still here," not a discount.

Kill/validate: if gross logo churn concentrates *away* from the FY boundary (i.e. customers leave mid-year despite the switching cost), the moat thesis is weaker than claimed and CAC payback (§18.14) must assume shorter tenure. Track churn-by-month as a first-class cohort metric.

---

### 18.11 Defences against the price-floor attack

The floor is zero *and moving*. Three verified threats and the pre-agreed pricing response (cross-referenced to the §20.8 risk register):

| Threat | Observable trigger | Pricing/GTM response |
| --- | --- | --- |
| **Zoho widens free gates** 10 → 25 or 50 | Zoho Payroll pricing page changes its headcount ceiling (Source: monitor Zoho pricing page) | Move beachhead floor up; re-anchor on 50–200; lean on the filing SLA and attended submission, which we are not aware (September 2026) of Zoho selling, delivered through the CA console. Do not build a plan requiring Zoho not to widen (§04 [Verified]) |
| **Fintech-subsidised HRMS** zero-prices software to sell interchange | A neobank/card issuer acquires an HRMS (Jupiter/sumHR precedent) and zero-prices it | Precedent valued the software asset at ~₹7.5 Cr — cheap for an acquirer (Source: Jupiter/sumHR, [Verified]). Defend on **attended submission + switching cost**, not price. We do not fight an interchange subsidy on price (Zaggle economics, §11) |
| **Frappe v16 bake-off** | A prospect runs the comparison | Concede gross-to-net — Frappe's salary structure is genuinely strong and **the bake-off will not be won on gross-to-net** (EV-031). Run it on the statutory outputs — ECR, ESI, the state PT slab table, LWF, Form 138 — which Frappe v16's source does not contain (EV-031; repository read Sep 2026, not executed), plus maintained updates, attended submission and a support SLA. Never claim a generic "more complete India compliance" (§20 R-7), and never say Frappe's published material is wrong (§21). **[Reversed]** the earlier trigger "finds parity" assumed Frappe shipped the state layer (K-01) |

Two further defences from §12/§06 that belong here:

- **Enterprise assistant convergence on Copilot/Glean** — if buyers ask for MCP access rather than our assistant, the AI differentiation collapses to data quality (§12 [Verified]). Response: own the data and the tools the assistant calls, never claim the assistant as the moat; this does not touch pricing but does mean we never price the assistant.
- **Uneven state-rule notification** under the four Codes — multi-state customers hit conflicting state/central positions. Response: effective-dated rules *per state* from v1 (§06). This is a *pricing asset*, not just a risk: the harder multi-state maintenance is, the more the §18.3 multi-state value holds.

The through-line: **every defence is "move up-market or lean on the SLA," never "match the price."** We cannot win a price war against free incumbents with more capital (§04). We can win a guarantee war, because the guarantee is the one thing that costs money to provide and therefore cannot be given away by someone whose revenue is elsewhere.

#### Competitive battle cards (objection → response)

The sales-facing form of the defences above. Each pairs the prospect's most likely objection with the move that keeps the conversation on submission/SLA, never on sticker price. All competitor facts are **[Verified]** from §04/§18.1 and carry their capture date; every card clears the competitor-claim rule (§21) before use; the responses are the standing GTM position.

| If the prospect says… | …the move is | Never say |
| --- | --- | --- |
| "Kredily is free forever." | Agree — and show the paywall boundary: bank payout files, PF/ESI challans, Form 12BB/124 and Form 16/130 are paid (EV-029), and they are artefacts for the customer to submit — we carry the filing to portal acceptance in an attended session with you, and by our operator under your written authority where that route is cleared (K-13, §18.3). Anchor on the crossing-20 moment when free calculation stops being enough. | "Kredily is worse" (it computes PF/ESI/PT/TDS fine, §18.1) |
| "Zoho does all this for ~₹2,000." | Agree on calculation parity (it is table stakes, [Killed]). Move to the two columns Zoho lacks: *attended, assisted submission* and a *maintained-compliance SLA* (§18.12). Frame the 2.5–3× as the price of not carrying the filing work yourself — the statutory liability stays yours either way (K-13). | "We have features Zoho doesn't" — the ESS/declaration diff was killed; "we take on your liability" — it is non-delegable |
| "Frappe is free and open-source." | Concede gross-to-net (EV-031). Offer the bake-off on statutory outputs for the prospect's own states — ECR, ESI, the PT slab table, LWF, Form 138 — which Frappe v16's source does not contain (EV-031; repository read Sep 2026, not executed); then maintenance under contract and attended submission. **[Reversed]** the old card conceded "PT 15+, LWF 14" (K-01). | "Frappe's documentation is wrong"; a generic "we cover more India compliance" (§20 R-7, §21) |
| "Our CA already handles all this for ₹8,000." | Do not attack the CA. Position as arming them (§18.7) or as a fixed, predictable sub-bureau price that removes their variance. The CA is a channel and a price anchor, not a rival. | "You don't need your CA anymore" — this inverts the channel (§18.7) |
| "We already own Tally." | Agree — Tally ships the central statutory artefacts (EV-032). Position as the state PT slab table, LWF, leave, employee/mobile, CA-console and attended-submission layer Tally lacks (EV-032, §18.1); we attach to Tally, we do not replace it (§18.8). | "Switch off Tally" — kills the partner channel (§18.8) |
| "Keka starts at ₹90." | Agree — its small-companies page says "starts at ₹90 per employee/month" and "from ₹6,999 per month" (EV-023, captured 5 Sep 2026); its pricing page carries no live price (EV-021). At 20 employees that floor is ₹349.95 effective PEPM (EV-027). Re-anchor on no seat floor (P6), a published price, attended submission and the SLA. | "Keka renewals run below list" — its ToS clause 15 says renewal fees are "subject to an increase" (EV-025, K-17); the withdrawn ₹9,999 card as a current price (EV-022 is archived); "₹99" as a Keka price (§18.3) |

#### Discounting discipline (protecting a published price)

Publishing the card (P3) is worthless if field discounting quietly reintroduces a quote-wall. Rate-card governance is therefore part of the pricing architecture, not a sales-ops afterthought:

- **Self-serve = list, always.** The 20–49 lower half and any self-serve close pays list off the card. No discount codes at the bottom — a discount there just burns the funnel margin the land-and-expand model (§18.10) is already stretching.
- **Discount authority is bounded and logged.** Light-touch/AE deals in the 50–199 core may discount only within a pre-set band (e.g. up to the annual-prepay equivalent), with anything deeper escalated and logged — the same "logged escalation" discipline §13 demands of the model router, applied to price.
- **Trade discount for term or commitment, never for nothing.** A deeper discount buys annual prepay, a multi-year term, or a case-study/reference — it never simply lowers ARPU. This keeps realised ARPU (the §20 V-03 number) close to list so the target stays meaningful.
- **Kill/validate:** if realised discount consistently exceeds the annual-prepay band across the 50–199 core, the published list is fictional and either the card is re-priced downward or the discount authority is revoked. Track realised-vs-list as a first-class metric feeding §20 V-03.

---

### 18.12 Competitor list-price comparison at a common point

**[Verified]** as *list price*, **not** as realised price. Figures are the vendors' own published cards — pricing pages, raw HTML and pricing config files — captured 5 Sep 2026 (EV-021–EV-027) and normalised to **50 employees, ex-GST, monthly, entry tier**; the 20-employee column shows the seat-floor effect (EV-026). Realised ARPU is unmeasured for all of them (§20 V-03). This is the table the published price card (P3) is implicitly compared against by every prospect, so we state it explicitly — and no row leaves the building without a fresh capture and §21 clearance. **[Reversed]** Earlier drafts marked the mid-market rows incomplete behind a TLS block and showed greytHR and Keka as quote-only; the block was one fetch tool's failure and the cards are captured (EV-009).

| Vendor | ~50-emp monthly list (ex-GST) | Implied PEPM at 50 | Effective PEPM at 20 | Claims to submit filings? | Maintained-compliance SLA? | Price published? |
| --- | --- | --- | --- | --- | --- | --- |
| **Kredily** | ₹0 (free forever) | ₹0 | ₹0 | No — outputs paywalled (EV-029) | No | Yes |
| **Zoho Payroll** | ~₹2,000 (Standard, annual billing: ₹1,000 incl. 25 + 25 × ₹40) | ~₹40 | ₹50 (₹1,000 block incl. 25) | No (generates; customer files) | No | Yes |
| **Frappe HR (cloud)** | from ₹410 + scale | low | low | No — no Indian statutory return in v16 (EV-031) | No (open-source, no contract) | Yes |
| **TallyPrime** | ₹0 incremental (perpetual licence sunk) | ₹0 | ₹0 | No — generates artefacts (EV-032) | No (updates shipped, not per-tenant SLA) | Licence yes; module free |
| **Qandle (MYND)** | ₹2,450 annual / ₹2,950 monthly (block incl. 50) | ₹49.00 / ₹59.00 | ₹122.50 (annual) | No — an unpriced "Compliance Assistance" add-on; MYND's outsourced filing is demo-sold (EV-030, EV-034) | Not assessed | Yes |
| **greytHR** | ₹2,495 (Essential, incl. 50) | ₹49.90 | ₹124.75 | No — generation language only (EV-030) | Not assessed | Yes |
| **Pocket HRMS** | ₹2,995 (annual, incl. 50) | ₹59.90 | ₹149.75 | No (EV-030) | Not assessed | Yes |
| **Zimyo** | ₹4,000 (minimum billing 50) | ₹80.00 | ₹200.00 | No (EV-030) | Not assessed | Yes |
| **HROne** | ₹4,950 (block for 50) | ₹99.00 | ₹247.50 | No (EV-030) | Not assessed | Yes |
| **Keka** | ₹6,999 live floor / ₹9,999 archived card | ₹139.98 / ₹199.98 | ₹349.95 | No — "pre-built" statutory reports (EV-030) | Not assessed | No live price on its pricing page (EV-021); floor on its small-companies page (EV-023) |
| **PeopleStrong** | enterprise quote (realised PEPM ≈ ₹126, EV-006) | ~₹126 realised | — | Not assessed (enterprise; outside the six-vendor set) | Not assessed | No (quote-wall) |
| **Us — "File" tier [Hypothesis]** | ~₹5,500 (₹110 PEPM target) | ₹80–150 | ₹80–150 — actual headcount, no seat floor (P6) | **Portal-accepted artefacts + attended, assisted submission (K-13, §22)** | **Yes — the product** | **Yes** |

(Sources: Kredily, Zoho, Frappe and Tally pricing pages read in rounds two and three, 2026 — r2/01, r3/01, r3/03; Qandle, greytHR, Pocket HRMS, Zimyo, HROne and Keka captured 5 Sep 2026 — EV-021–EV-027, r5/03, 20-employee arithmetic on the verified block prices; PeopleStrong realised PEPM derived from filed financials ÷ claimed platform scale, EV-006 — [Verified] inputs / [Hypothesis] derivation. "Claims to submit" reflects published pricing, payroll and feature pages, not product documentation or a live tenant — absence of a claim is not proof of absent capability, EV-030.)

Reading the table honestly: at ₹110 we sit **inside the ₹80–200 clearing band** — above the ~₹50 value floor (Qandle, greytHR), above Zimyo and HROne, below Keka's live floor — and 2.5–3× Zoho's list. We are not aware, as of September 2026, of another option that both carries filings to portal acceptance under contract and publishes a per-head price with no seat floor. The two rightmost columns are the entire justification for the price. If a prospect values neither attended submission nor a maintained-compliance SLA, the comparison collapses to sticker price and we lose to the value floor — which is precisely the risk §20 must measure (V-07 instrument, V-16). The realised points — greytHR ~₹52 and PeopleStrong ~₹126 (EV-006) — sit on the floor and inside the band; the target is not aggressive relative to the clearing band, only relative to the *free* floor.

Scale-realism check (§05): greytHR currently claims "30,000+ companies" (EV-091, captured Sep 2026; earlier captures said 34,000) — about 3.9% of the 7,66,254 contributing establishments (EV-016, EV-001; 4.4% on the older 34,000 figure). That is what leadership looks like here, and it is a ceiling on any share assumption baked into a revenue model built on this section's pricing. The figure must travel with its capture date (K-16).

---

### 18.13 Billing and payment mechanics (India-specific)

Pricing shape is incomplete without the invoicing reality of selling SaaS to Indian SMBs. These are product-and-finance requirements, not marketing choices.

| Mechanic | Requirement | Basis |
| --- | --- | --- |
| **GST rate + invoice** | GST at the rate held in `gst_rate_saas` (18% as vendors disclose it today); show GST-inclusive and exclusive on the card (P3); issue GST-compliant tax invoices with our GSTIN and the customer's GSTIN; capture the GSTIN at self-serve checkout | **[Verified — vendor disclosures]** Indian HRMS list prices are ex-GST with 18% added on top, and disclosure is uneven — three vendors say so on the page, the rest do not (r1/08, captured 4 Sep 2026). The rate itself is to be confirmed against the current CBIC rate notification before build (§20) |
| **GST place of supply / CGST-SGST vs IGST** | Bill IGST for inter-state B2B customers and CGST+SGST for intra-state, resolving place of supply from the registered recipient's GSTIN state; the tax split is a rule-table entry, not code | **[Hypothesis]** — the IGST Act's place-of-supply rules for services; the provision is not in our evidence and is read from the bare Act before build (§20). A pan-India SaaS biller must get this right or every out-of-state invoice is defective |
| **e-invoicing (IRN/QR)** | Issue B2B invoices with IRN + signed QR once *our own* aggregate turnover crosses the e-invoicing threshold (`einvoice_turnover_threshold`) — applicability turns on the supplier's turnover, not the customer's; report each invoice to the IRP within the reporting window (`einvoice_reporting_window_days`) that applies to our turnover band | **[Hypothesis]** Both parameters are read from the current CBIC/GSTN notifications before build (§20). The ₹5 Cr threshold and 30-day window carried in earlier drafts have no source in our evidence and are not shipped as defaults |
| **TDS on our invoices** | Business customers deduct TDS when paying us; the billing system must treat short-payment-by-TDS as normal, not as a dispute, and reconcile credits against the TDS credit statement (Form 168, ex-26AS — r5/02) | **[Hypothesis]** The deducting provision, rate and annual threshold under the Income-tax Act 2025 are not in our evidence — EV-050 maps only ss.192, 194P, 197 and 200(3) — and are held as `inbound_tds_rate` and `inbound_tds_threshold`, read from the 2025 Act and Rules 2026 before build (§20); the 1961-Act section, rate and threshold carried in earlier drafts are not shipped as defaults. Both vocabularies are accepted in the billing UI (EV-050). Ironic and useful: a filing product must itself handle inbound TDS cleanly |
| **Autopay / collections** | e-NACH / UPI-Autopay mandate for monthly plans (Razorpay/Cashfree); UPI one-time for annual prepay; card recurring payments run under RBI's e-mandate regime — pre-debit notification, additional-factor authentication and a per-transaction exemption ceiling (`card_emandate_afa_exempt_ceiling`) — so mandate-based rails are primary and a failed card debit is a dunning event, not a churn event | **[Hypothesis]** The RBI e-mandate framework's notification period and exemption ceiling are not in our evidence and are read from the current RBI directions before build (§20); the figures carried in earlier drafts are not shipped as defaults. That mandate rails are more durable than card autopay for SaaS is a design judgement to be tested against our own collection data (§19) |
| **Annual prepay discount** | Offer an annual-prepay discount, `annual_prepay_discount_pct`, applied to the PEPM and to the multi-registration line alike, to pull cash forward and cut monthly churn | **[Verified]** market reference: Zoho Payroll applies exactly 20% to both base and overage across all three paid tiers (r3/03); Qandle's annual card implies 16.9–20.2% against monthly (r5/03). **[Hypothesis]** our level — earlier drafts' "~2 months free, ≈16%" sits at the bottom of that range; set in §20 and validate realised uptake in V-03 (H-P12) |
| **Setup / onboarding fee** | Default **₹0 setup**, stated on the card — migration is acquisition infrastructure (§18.9), not a revenue line; charging setup re-introduces the friction we are removing. Reserve paid onboarding for Scale/Enterprise only; where a partner implements, the fee line is assignable to the partner (§18.18) | **[Verified]** market context: setup fees are an admitted but unquantified norm — Keka's pricing FAQ says a nominal setup fee applies while its small-companies page says none (EV-025); Pocket HRMS cites an unquantified implementation fee and HROne none except possible enterprise implementation (r5/03); Zoho People publishes a one-time onboarding fee (r1/08). **[Hypothesis]** our ₹0 default — kill if free migration proves unsustainable at lower-half ACV (H-P7) |
| **Proration & the cliff (P2)** | Mid-month headcount changes prorate continuously; no step-change on the marginal hire — the explicit anti-pattern to Zoho's ₹0→₹1,000 cliff | **[Verified]** the cliffs are the attack surface (§04) |
| **SEZ / export / RCM edges** | Handle zero-rated supply to SEZ units under a letter of undertaking, and reverse-charge scenarios; a growing beachhead will include SEZ tenants | **[Hypothesis]** — zero-rating of supply to SEZ units under the IGST Act; the provision and the LUT conditions are not in our evidence and are read from the bare Act and current notifications before build (§20). An edge, but a real one in the 200+ band |

The strategic point buried in this table: **[Hypothesis]** **the beachhead buyer's dominant billing complaint about the bureau is variance** (to be tested in the §20 V-01 mystery-shop and the V-16 buyer interviews) — a different invoice every month as filings and headcount move. Our billing must therefore be *predictable to the rupee*: published PEPM × current headcount + any multi-registration line + fixed add-ons, prorated smoothly, on a mandate. Predictability is part of the product, not just the finance stack.

Acceptance criterion (billing correctness): (1) every invoice states GST-exclusive base, correct CGST+SGST *or* IGST split resolved from the customer's GSTIN state, and GST-inclusive total; (2) a customer who deducts TDS on our invoice and short-pays by exactly that amount is reconciled automatically against the TDS credit statement and never flagged as delinquent; (3) a mid-month hire or exit produces a prorated line the customer can reconcile to the day, with no step-jump; (4) once our turnover brings us under the e-invoicing mandate, every B2B invoice carries a valid IRN and QR within the applicable reporting window.

---

### 18.14 Unit-economics frame (structure only — no validated numbers)

Every number here is **[Hypothesis]** and exists to show the *shape* of the model the §20 programme must fill in. None may enter a deck.

**Illustrative File-tier account (50 employees, single registration set, ₹110 PEPM target):**

- Gross revenue: 50 × ₹110 × 12 = **₹66,000/yr** ex-GST.
- **COGS is a four-line stack, and inference is the smallest line** (EV-088; §13):
  1. *Inference* — per employee/query. ₹0.15–3.27 PEPM are placeholders pending prototype instrumentation (EV-008, §20 V-04); only the 52.7× model-choice spread is load-bearing, because it is FX-invariant (EV-007, EV-089). FX is modelled at ₹94.43/USD (not the banned ₹83.3) and Gemini 3.x Flash at 2× from 1 Jan 2027 as the *base* case, not the downside (EV-089).
  2. *WhatsApp* — per message since 1 Jul 2025; employee-initiated conversations are free inside the 24-hour window; the WABA must migrate to INR billing by 31 Dec 2026 or delivery stops on 1 Jan 2027 (EV-088).
  3. *Supervised filing* — per registration × state × filing type; **the dominant line, unsized** (EV-088; sized in §22 against `max_supervised_minutes_per_filing_cycle`, §13).
  4. *Compliance curation* — per state maintained; unsized (EV-088; §22).
- **[Reversed]** Earlier drafts stated a 93–99% gross margin on inference and read it as proof that bundling AI never threatens margin — a margin on one input, withdrawn (K-02). No gross-margin figure is stated in this section until lines 3 and 4 are sized.
- **[Reversed]** Earlier drafts called statutory maintenance and filing execution a *fixed* team cost amortised across tenants, so that gross margin improves with scale. Curation is per state maintained, but supervised filing scales per registration × state × filing type (EV-088) — a per-tenant marginal cost that the registration allowance and multi-registration line (§18.3) exist to recover. The contractual remedy (§18.3) is a *provisioned* cost — accrue against it per the tiered cap, do not treat it as zero.

**CAC / payback (structure):**

- Lower half (20–49): self-serve, product-led → target CAC low, but ACV also low (~₹24,000–60,000/yr, §05.1); payback only works via land-and-expand into 50+ (H-P8). At list PEPM the lower half may be net-negative standalone (§05) — acquired as funnel, not revenue.
- Revenue core (50–199): self-serve or light-touch/CA-referred → CAC must be recovered inside 12–18 months on ACV alone, *before* counting expansion. If CA-referred deals carry a referral share (§18.7), that share is CAC, not COGS, and is capped so blended payback holds.

**LTV (structure):** driven by (a) low logo churn once filing-critical (switching cost is high mid-year, §18.9 — the same friction that is our acquisition objection is our retention moat once we are the incumbent), (b) headcount-driven expansion (structural, §18.10), (c) add-on attach. **Kill:** the entire frame is invalid until V-01 (bureau price), V-03 (realised ARPU), the supervised-filing sizing (§22) and the cohort metrics (H-P8, H-P9) report. **Do not compute an LTV:CAC ratio from these placeholders** — a ratio built on placeholder numerator and denominator invents precision the evidence forbids (§02 standing rule).

---

### 18.15 GTM funnel (hypothesised, for instrumentation not forecasting)

The funnel below is **[Hypothesis]** — its purpose is to name the stages we instrument (§19 metrics), not to forecast revenue. Conversion rates are placeholders to be replaced by real cohort data, and there is nothing external to borrow: **[Verified]** no vendor, marketplace or third party publishes CAC, CAC payback, sales-cycle length, win rate, demo-to-close ratio, marketplace CPL/CPC for the category, free-to-paid conversion or partner-sourced revenue share for this market (r3/03, confirmed on a second sweep). Every such number will come from our own instrumented funnel, segmented by acquisition source and by partner (§18.18, §19).

| Stage | Definition | Instrumented event | Placeholder benchmark [Hypothesis] |
| --- | --- | --- | --- |
| **Reach** | Statutory-intent search / cliff-triggered / importer landing | Page/tool visit | — |
| **Signup (Free)** | Tenant created | Account created | — |
| **Activation** | First real *calculation* run on real employees | Payroll computed | activation is the leading indicator, not signup |
| **Statutory conversion** | Crossing 20 → File tier | First portal-accepted filing under SLA (attended, §22; ACCEPTED or FILED in FR-PAY-711) | the core conversion; coincides with EPF turning on |
| **Expansion** | Headcount growth / band graduation / add-on attach | NRR events | target NRR > 100% (H-P9) |
| **Advocacy / channel** | CA refers additional clients | CA-invited tenant activated | validates §18.7 economics |

The funnel makes one point unmissable: **the money is made at the Free→File statutory conversion, and that conversion is a headcount event we do not control the timing of — the customer hires their 20th employee on their own schedule.** GTM's job is therefore less "convert now" and more "be the obvious, already-installed choice at the moment the cliff arrives." That is why Free is generous (P1) and why the importers are landing pages (§18.9): we want to already be the system of record when EPF turns on. Kill for the whole funnel logic: if §20 V-01/V-03 show the beachhead will not pay a premium at the conversion moment, the funnel still fills but never monetises, and the thesis narrows to bureau displacement only.

<!-- DIAGRAM: gtm-funnel -->

---

### 18.16 Consolidated pricing hypotheses and kill criteria

Every commercial claim in this section is a hypothesis. This table is the single place a reader checks what must be validated before any number ships, and maps each to the §20 programme.

| # | Hypothesis | Kill / validation criterion | §20 gate |
| --- | --- | --- | --- |
| H-P1 | Bureau/CA charges ₹3,000–15,000/mo, so a fixed sub-bureau price is compelling | If real 50-emp bureau price < ₹2,000/mo, the ₹80–150 target loses its bureau justification and re-anchors toward the ~₹50 value floor (EV-006, EV-027) | V-01 |
| H-P2 | Our list target of ₹80–150 PEPM holds inside the ₹80–200 clearing band (EV-006) | If realised ARPU is 30–40% below list, re-base toward the value floor and re-run the four-line COGS stack (EV-088) | V-03 |
| H-P3 | Buyers pay a 2.5–3× premium over Zoho for attended submission + SLA | If WTP over Zoho ≈ 0, narrow thesis to displacing the bureau only | V-07 instrument (to be extended to the SLA premium), V-16 |
| H-P4 | Metered AI SKUs (bulk docs, analyst copilot) monetise | If HR-AI WTP is zero everywhere, drop the metered AI SKUs; keep AI as COGS | V-07 |
| H-P5 | CA console is a channel, not a disintermediation threat | If ≥40% of interviewed CAs read the product as disintermediation (the §01 kill line; V-05 passes only when ≥60% describe workable referral or reseller economics), reposition as agency tool or abandon channel | V-05 |
| H-P6 | Tally partners are a distribution channel | Depends on V-02: at ~5% Tally-payroll enablement, channel is a footnote | V-02 |
| H-P7 | Migration is self-serve within one pay cycle | If median assisted migration > one cycle, migration cost re-enters CAC | V-15; (build metric) |
| H-P8 | 20–49 lands convert upward (land-and-expand) | If < 25% of 20–49 lands cross into 50+ within 12 mo, raise floor to 50 | (cohort, mo 18) |
| H-P9 | NRR > 100% via headcount + band + add-on expansion | If NRR < 95% at 12 mo, re-run CAC at flat-account economics | (cohort) |
| H-P10 | Location/GPS add-on attaches (greytHR ₹140 vs ₹45 seat, 3.1×) | Kill if attach < 10% of deskless-eligible tenants | (attach metric) |
| H-P11 | The contractual remedy (penalty-exposure backstop) can be capped and still credible | If buyers require an uncapped guarantee to value it, SLA-premium thesis weakens; allocation and insurability also need counsel (Part D-17, §23) | V-07 instrument (to be extended), V-16 |
| H-P12 | An annual-prepay discount (`annual_prepay_discount_pct`; market reference 16.9–20%, r3/03, r5/03) pulls cash forward without eroding ARPU | If prepay uptake < 20% or discount cannibalises monthly ARPU, drop the term discount | V-03 |
| H-P13 | A registration allowance plus a multi-registration line recovers supervised-filing cost without breaking the per-head card (EV-088) | Kill if the allowance that covers a single-registration tenant's supervised minutes pushes list above the ₹80–200 band, or if multi-registration buyers reject the line | §20 (parameters `included_registrations_per_tenant`, `multi_registration_line_price`; sized from §22) |
| H-P14 | The 20–50 band is won on no seat floor (P6) plus quality of delivery (EV-026) | If realised win-rate against Zoho in 20–50 is below one-in-four across the first 40 contested deals, the band is not winnable and v1 re-anchors on 50–200 | (deal metric; §01) |
| H-P15 | The File tier holds its price with employer-attended and co-attended submission (§22 Modes A, B) while operator-attended submission (Mode C) is fenced on counsel (Part D-17) | If buyers value the File tier only with Mode C, or counsel returns "no" for the EPFO or TRACES route, re-test the price against the Mode A/B scope and cut the SLA to artefact correctness, currency and causation (§18.3) | V-07 instrument (extended), V-16; §23 counsel register |
| H-P16 | A bank alliance is a distribution channel for us, not merely a salary-payout integration (§18.18) | If bank conversations run alongside the V-05 field window produce no offer of placement inside a bank's SME channel on terms that clear blended CAC payback, keep bank work to payout-file adapters (§16) and carry no bank-channel revenue | (channel test; §20 addition) |
| H-P17 | Paid marketplace placement converts at our ACV (§18.18) | If a committed package's cost per closed-won deal exceeds the CAC ceiling set for its band after one package term, do not renew; commit to G2-owned sites only in short increments until its pay-per-lead pricing is published | (attribution metric; §19) |

**Standing rule (restated):** no PEPM, ACV, CAC or LTV figure enters a financial model, deck or contract until V-01 and V-03 report. Every rupee in §18.3–§18.5 is a placeholder anchoring a *shape* the evidence supports, not a *level* the evidence supports (§04 [Verified]).

---

### 18.17 What this section deliberately does not do

Recorded so it is not resurrected in a later deck (§20.1):

- **No premium AI SKU.** Seven vendors price HR AI at zero; a surcharge reads as a surcharge on an expected feature ([Killed], §12).
- **No free-HRMS-monetised-on-interchange.** 9–10% margins against a listed incumbent (Zaggle) with 19 bank partners and 50mn cards, using our own balance sheet for float ([No], §11). Software PEPM and any future attach revenue are modelled as **two separate lines that are never blended** (§11 [Verified]).
- **No hardware resale** — ₹4,000–25,000 one-time devices, no margin, direct channel conflict with the dealer/eSSL networks (§09 [No]).
- **No self-hosting as a cost play** — serverless beats dedicated H100 ~74× at real utilisation; self-host is a priced compliance SKU for named regulated accounts only (§13 [No]).
- **No paid-only product below 10 employees** — Kredily is free forever with real statutory calculation (§05 [No]).
- **No revenue modelled from the CA channel, the Tally-partner channel, or the MCP server** until §20 V-02/V-05 report — all three carry zero validating evidence today (§20). The same holds for bank alliances and paid marketplaces until H-P16 and H-P17 report (§18.18).
- **No enterprise revenue in v1** — documentary gate, ~3 years (§05).
- **No comparative price claim** on the published card without a dated capture, a re-capture before use, and clearance under the competitor-claim rule (§21). The mid-market prices are now captured (EV-021–EV-027), which makes a comparison *possible*, not automatically safe. ZingHR and Ramco publish no price and are enterprise adjacency, outside the set (EV-033).
- **No seat floor, ever** — no minimum billing block on the File tier (P6); a block would re-create the overcharge the six priced competitors impose on the 20–50 band (EV-026).
- **No transfer of statutory liability** — the employer's and deductor's liability is non-delegable; we sell attended submission and a capped contractual remedy (K-13, §22, §23).
- **No banned figures.** ₹37,500 ICAI CA fee (pre-GST, 9+ yrs stale, a pricing recommendation once rested on it), ₹161 PEPM Zaggle attach (contaminated denominator), ₹83.3/USD (13.4% wrong — use ₹94.43), "Frappe ships PT across 15+ states and LWF across 14" (false on source — EV-031, K-01), a 93–99% gross margin (a margin on one COGS line — K-02), greytHR "34,000 customers" as an undated fixed figure (K-16), "Keka renewals below list" (EV-025, K-17) and "₹99" as a Keka price (no Keka capture contains it) — all on or routed to the §20.4 banned list and absent from every number above. **[Reversed]** Keka's price itself is no longer banned: it is obtained from Keka's own pages (EV-021–EV-025, K-10).

---

### 18.18 Channel map — who carries the product to the 20–200 employer

§18.6 sets the motion by band and §18.7–§18.8 treat the two load-bearing channels in depth. This subsection is the whole map: every route to the buyer the evidence names, what is known about each, what we must build to use it, and the gate that must report before any revenue depends on it. The evidence splits cleanly (r3/03): **channel *structure* is trustworthy** — partner archetypes, programme tracks, marketplace package costs and the freemium paywall were re-verified at vendor-primary sources — while **channel *economics* are largely unknown**, because no vendor, marketplace or third party publishes CAC, win rates, CPL or partner-sourced revenue share for this market. Every economic cell below is therefore either a dated competitor reference or a named parameter routed to §20.

<!-- DIAGRAM: pricing-gtm-channel-map -->

| Channel | What the evidence shows (read in research round three, 2026; programmes not joined or executed) | Our role in it | Economics known? | What must exist before it can carry a deal | Gate before revenue |
| --- | --- | --- | --- | --- | --- |
| **Direct — published card, self-serve** | Among vendors checked, only Zoho Payroll completes a purchase online; greytHR, Keka and Kredily route pricing-page calls to action to trial, free plan or sales, so freemium here is lead generation, not a self-serve revenue channel (r3/03, medium) | Primary motion for 20–49; the destination of every marketplace lead | Our own funnel only | Checkout with GSTIN capture and a compliant invoice (§18.13); in-product upgrade from Free without sales contact; funnel events live (§19) | V-01 and V-03, as for every PEPM figure (§18.16) |
| **CAs and tax consultants** | Kredily runs a CA Program on a multi-company dashboard; factoHR lists "CA/Tax Consultant" among six partner classes; Zimyo recruits tax consultants and financial advisors (r3/03) | Referral, or agency/reseller (§18.7) | Unpublished for HRMS CA programmes | CA console (§18.7; §15.3.6), Mode D sessions (§22), co-branding to the practice, the offline-referral claim path below | V-05 (H-P5) |
| **Payroll service providers / bureaus** | Kredily separates a white-label Partner Program for PSPs from its CA Program; greytHR's PSP page is a demo-capture page, not a programme (r3/03) | White-label operator running payroll on our platform for its clients | Unpublished | Tenant-level white-label — logo, domain, sender identity, payslip and ESS branding (r3/03) | V-05 extension. **[Hypothesis]** white-labelling hides our brand at the Free→File moment, so it is offered only on agency economics; the decision is routed to §20 |
| **Tally partners** | Four grades (3-Star and 5-Star Certified, Associate, GVLA) plus a CA Community; the public locator listed 1,257 partners on two fetches — a directory count, not an audited network size; no margins published (r3/03) | The payroll-and-filing layer attached to the partner's accounting sale (§18.8) | Unpublished | TallyPrime-importable payroll journal with per-client ledger mapping; the Tally importer (§18.9) | V-02 (H-P6) |
| **Bank alliances** | greytHR's Alliance Partner track is overwhelmingly banks and payment networks — ICICI Bank, HSBC, IDFC First Bank, AU Small Finance Bank, Bank of Baroda, Kotak Mahindra Bank, Visa, Mastercard — re-fetched from its page-data payload; whether these are distribution relationships or payout integrations is not knowable from the public site. Freemium competitors bind payouts to one bank: Kredily's paid tier to ICICI Bank and NEFT, Zoho Payroll's free tier to HSBC (r3/03) | Placement inside a bank's SME channel, with our payout files bank-neutral | Unknown | Bank-agnostic payout-file abstraction with per-bank adapters as versioned artefacts (§16), co-brandable embedded onboarding, per-bank tenant provisioning (r3/03) | H-P16 |
| **Review marketplaces** | G2 acquired Capterra, GetApp and Software Advice from Gartner; the deal closed 5 February 2026, so the global review channel is **one counterparty**, and G2 has signalled a pay-per-lead product off the combined dataset; none publishes vendor pricing and vendor pages block automated access (r3/03) | Lead source into Direct | Unknown; terms in flux | Lead ingestion by email parse and webhook, de-duplication, an immutable source stamp, cost attribution (below) | H-P17 — commit in short increments until G2's pricing surfaces |
| **Indian marketplaces** | SoftwareSuggest publishes an INR vendor rate card — Basic ₹3,00,000 for 6 months, Gold ₹6,50,000 for 6 months, Platinum ₹10,00,000 for 12 months — with PPC and lead credits drawn down inside a prepaid term and CPC/CPL set only at signup; its paid tiers carry influence over ranking artefacts (Leader Matrix consultation is Platinum-only). Techjockey runs free listing, paid inventory and its own checkout — part marketplace, part reseller — and publishes no rate card (r3/03) | Lead source; Techjockey also a transaction channel | Package cost known; unit cost knowable only after the term | Same ingestion and attribution | H-P17 |
| **Device dealers** | factoHR recruits "IT Hardware/Biometric Reseller" partners (r3/03); eSSL markets six named HRMS integrations (§09) | Referral from inside the customer's premises | Unpublished | Self-service device registration and a certified-device list (§09, §16); we never resell hardware (§18.17) | None modelled |

Three consequences for collateral and contracts. A ranking artefact a vendor can buy influence over is not independent evidence, so no marketplace "leader" badge is cited as proof of anything in our material or against a competitor (§21). Because the review channel is now one counterparty, a plan that assumes four independent review sites is obsolete (r3/03). And a bank as a distribution partner is not a bank as a customer: if a bank or its group company becomes a tenant, RBI's outsourcing obligations are materiality-gated, entity by entity (EV-087, mirror-sourced — pull from the primary source before customer use), and whether the arrangement is material is a counsel question (Part D-14, §23). Whether a distribution agreement with a bank engages any of those obligations is the same kind of question, so every bank distribution agreement is reviewed by counsel before signature.

#### Worked arithmetic — what a marketplace package must return [Hypothesis]

The revenue figures are this section's placeholders (§18.14); the package prices are SoftwareSuggest's published card (r3/03).

| Package | Cost | Term | Accounts whose first-year revenue equals the cost, at the illustrative File account (50 × ₹110 × 12 = ₹66,000) | The same, at the lower half's ₹24,000–60,000 ACV (§05.1) |
| --- | --- | --- | --- | --- |
| Basic | ₹3,00,000 | 6 months | 3,00,000 ÷ 66,000 ≈ **4.5** | 5 to 12.5 |
| Gold | ₹6,50,000 | 6 months | 6,50,000 ÷ 66,000 ≈ **9.8** | 10.8 to 27.1 |
| Platinum | ₹10,00,000 | 12 months | 10,00,000 ÷ 66,000 ≈ **15.2** | 16.7 to 41.7 |

That is revenue, not contribution: it is before the four-line COGS stack (§18.14), before the assisted sale's own cost (§18.6) and ex-GST. The table does not say marketplaces fail; it says a package is bought only against a CAC ceiling set per band in §20 and is judged on cost per closed-won deal at the end of its term (H-P17). No marketplace spend is committed before the attribution in the acceptance criteria below is live.

#### Partner economics — parameters, with the only published market references

Referral shares and reseller discounts are CAC, never COGS (§18.7), and are capped so blended payback holds (§18.14). Only two vendors in this market publish commission figures; everything else is negotiated at enrolment (r3/03). None of the references below is a default: each parameter is set in §20 after V-05 reports.

| Parameter | What it controls | Market reference (r3/03) |
| --- | --- | --- |
| `partner_commission_pct` (per tier) | Share of collected subscription revenue paid to the partner | Zoho affiliate 15% / 18% / 20%, graduated by trailing revenue or count of new paid customers; Zimyo up to 20% (1–3 referrals a month) and up to 30% (3+), recurring |
| `partner_commission_term_months` | How long the share is paid | Zoho: first 12 months; Zimyo: recurring; Keka resellers: first 12 months of billing and on renewal, rate unpublished |
| `partner_commission_cap_per_transaction` | Ceiling on any single deal's commission | Zoho: $25,000 per transaction |
| `partner_deal_size_bonus` | One-time kicker at invoice-value thresholds | Zoho: an additional 5% at tiered invoice values |
| `referral_attribution_window_days` | Link-based attribution window | Zoho: 90-day cookie |
| `partner_stickiness_days` | Window after referral inside which a churned client claws the commission back | Zoho: 60-day stickiness period |
| `partner_tier_reevaluation_months` | How often tier status is recomputed | Zoho: 6 months |
| `deal_registration_window_days` | How long a partner's named prospect is protected from our direct team | None published |
| `referred_customer_credit` | Credit funded to the referred customer's account, redeemable against invoices | Zoho: $100 wallet credit at every affiliate tier |
| `partner_setup_fee_assignable` | Whether a partner-led implementation fee is the partner's revenue, not ours | Keka confirms a setup fee exists and what it buys; no vendor publishes the amount (EV-025, r3/03) |

Acceptance criteria (channel instrumentation — all must hold before the first rupee of channel spend or commission):

1. Every tenant carries an immutable acquisition source and, where one exists, a partner ID, set at creation; later touches are appended, never overwritten, so a deal is attributed exactly once.
2. A referral introduced offline — by phone or in person, which is how CAs and Tally partners introduce prospects — can be claimed by the partner and approved by us without a link; a link-only model silently fails the highest-value partner class (r3/03).
3. The commission ledger computes from revenue actually collected, ex-GST, under the parameter set in force on the invoice date; a clawback applies inside `partner_stickiness_days`; every payout statement reconciles to the ledger.
4. Cost per qualified lead and cost per closed-won deal are reported by source, with prepaid package costs amortised across the package term (r3/03).
5. Inbound demand from a registered partner's prospect routes to that partner for `deal_registration_window_days`, so the direct team never competes with the channel for the same deal.

#### Order of investment [Hypothesis]

Direct first, because it is the only channel whose economics we will observe from launch. The CA channel second, because it is the best-evidenced route to exactly our band, gated on V-05. The Tally channel third and importer-only until V-02 reports (§18.8). Bank alliances as a test of H-P16, built on the payout adapters we need anyway (§16). Marketplaces last and in short increments, because their unit cost is unknowable in advance and the largest counterparty's pricing is in flux. Device dealers are a referral courtesy, never a revenue line. The standing rule of §18.17 holds: no revenue is modelled from any channel but Direct until its gate reports.
