## 04. Problem Statement & Market Sizing

The preceding sections established *what* we build (filing-first, 20–200 employees) and *why computation is priced at zero while filing outputs are not* (EV-029). This section does the arithmetic underneath those decisions: it states the problem in the buyer's own terms, sizes the market on a denominator that survives audit, quantifies the money already being spent (from filed accounts, not analyst projections), and maps the competitive field to the one region where **obligation, budget and dissatisfaction overlap**. Every number here is either [Verified] against a primary source or carried as a [Hypothesis] with a named kill criterion. The banned figures from §20 — 6-crore MSMEs, $23.32bn, ₹83.3/USD, ₹37,500 CA fee, "Frappe PT in 15+ states / LWF in 14" — do not appear except as [Killed] or [Reversed] entries, and must not be reintroduced downstream.

A note on method before the argument. This section deliberately refuses two moves that every India-HR-tech deck makes. It does not quote a total-addressable-market number it cannot denominate, and it does not describe the product's advantage as generic "more complete compliance". **[Reversed]** v0.3 said the incumbents "lack no feature, only execution and guarantee"; source-code and product-documentation checks show named gaps — Frappe HR v16 ships no Indian statutory artefact and no state dimension (EV-031), and TallyPrime has no state PT slab table, no LWF engine and no leave module (EV-032) — so the advantage is stated as those specific gaps plus attended filing, never as a blanket claim. Both refusals cost us a bigger headline. Both are the reason the sizing survives a data room. Where a claim is load-bearing for the business case, it carries its provenance in line; where it is a placeholder, it carries the study that would collapse it to a point.

### 04.1 The problem, stated in the buyer's terms

The Indian employer of 20–200 people does not experience "HR software" as a category. They experience a recurring, dated, legally-enforced obligation to *file* — and a monthly scramble to get it right with tools and people that were never designed to file. Three distinct pains stack on top of each other, and the product's entire reason to exist is that it answers all three at once where the incumbents answer at most one.

#### Pain 1 — The statutory burden is a step function that gets worse as you grow

Indian labour and tax compliance is not a flat cost; it turns on at headcount thresholds, and each threshold adds a new *filing* with its own portal, format, cadence and penalty regime. The beachhead employer sits squarely inside the zone where the burden compounds.

| Headcount | Obligation that turns on | Filing artefact | Cadence | Penalty exposure for getting it wrong |
| --- | --- | --- | --- | --- |
| 1 | TDS on salary — s.392 of the Income-tax Act 2025 (ex-s.192, EV-050); Shops & Establishments; minimum wages; **POSH Internal Committee — every employer, s.4(1)** (the ten-worker line is s.6(1)'s Local Committee, not an exemption — EV-056) | Form 138 (ex-24Q); Form 130 (ex-Form 16) | Quarterly + annual | Interest at 1% per month from due-to-deduct to deduction and 1.5% per month from deduction to deposit — Income-tax Act 2025 s.398(3)(a), ex-s.201(1A) (r5/04) [Verified]; a ₹200/day late-filing fee under the 1961 Act's s.234E per a secondary source (r1/06) [Hypothesis — not primary-verified; 2025-Act equivalent unmapped, §06.5] |
| 10 | ESI — at 10+ persons, but 20+ for some Central-sphere extended classes, and only in ESIC-notified districts, so applicability is decided on the work location (r1/06, §06.3); gratuity accrual; maternity benefit ("on any day of preceding 12 months" — latches once crossed); **prescribed-format appointment letter** — attaches to an "establishment" of 10+ workers, form prescribed by the state (K-18, EV-057) | ESI contribution challan; half-yearly return-of-contributions view | Monthly by the 15th (r3/02) + half-yearly | Simple interest at 12% p.a. from the due date (S.O. 2698(E), 29 May 2026 — r1/06) [Verified]; damages graded by delay up to 25% p.a. under legacy ESI (General) Regulation 31-C (r3/02), which is saved only to ~21 Nov 2026 (EV-002, EV-004) — the scale is parameter `esi.damages_scale`, no shipped default (§06.3) [Hypothesis for the Code-era scale] |
| 20 | **EPF**; Grievance Redressal Committee (20+ workers, IR Code s.4 — EV-057) | ECR; PF Forms 3A/5/6A/10/12A | Monthly by the 15th | Simple interest at 12% p.a. (S.O. 2698(E) — r1/06), which EPFO's portal still labels s.7Q, auto-calculates and makes **mandatory with the contribution** (EV-039) [Verified]; damages (legacy s.14B, CoSS s.128 — r2/10) may be deposited later at the employer's option (EV-039) — the scale is parameter `epf.damages_scale`, no shipped default (§06.2) [Hypothesis] |
| 50 | Crèche facility (EV-057) | — | — | Not sized here (§06.1) |
| 100 | Canteen (EV-057); a Works Committee only where the appropriate Government orders one — conditional, not automatic (r3/04) | — | — | Not sized here (§06.1) |
| 300 | Standing orders; retrenchment/closure permission (raised from 100 by the new Codes — EV-057), for industrial establishments such as factories, mines and plantations (r3/04) | Prior Government permission | Event-driven | Permission-gated (r3/04) [Verified]; the consequence of proceeding without permission is not in the evidence base — counsel (§23) |

(Source: the four Labour Codes and Central Rules notified 8 May 2026 — central sphere only, EV-056/EV-057; the counting unit (worker vs employee) and sphere (central vs state) differ by obligation and are schema fields, not constants (§06.1); Income-tax Act 2025 section and form mapping per EV-050 and r5/04; EPF and ESI penalty treatment aligned with §06.2 and §06.3.)

Behind each threshold sits an actual contribution or benefit computation, and the *numbers* are where a spreadsheet or an inattentive bureau quietly goes wrong. The mechanics that the payroll engine must get right, deterministically, every period:

| Levy | Rate / formula | Wage base & ceiling | Edge cases the engine must handle | Source cue |
| --- | --- | --- | --- | --- |
| **EPF** | 12% employee + 12% employer | Statutory ceiling ₹15,000/mo; of the employer 12%, **8.33% routes to EPS capped at ₹15,000 (= ₹1,250)**, remainder to EPF | International workers: EPFO's FAQ says IWs who joined after September 2014 with wages above ₹15,000 are **not EPS members** (r5/02) [Verified]; the uncapped full-wage basis for IWs is a contested rule (§06.2) [Hypothesis]; employer may voluntarily contribute on actuals above ₹15,000; PF wages redefined by the 50% add-back (below) | EPF Scheme 1952 / Scheme 2026; EPS 1995; 8.33%/3.67% split per EPFO pages (r1/06) [Verified — framework; migrate to Scheme 2026 per §06.2] |
| **EDLI** | 0.5% employer | On EPF wages, ceiling ₹15,000 | Exempted (own-trust) establishments pay an inspection charge instead — EDLI 0.005% of wages, minimum ₹1,250 (S.O. 2701(E), 29 May 2026 — r2/10) | EDLI 1976 (r1/06) [Verified — rate]; exemption-route form references are carried, not re-captured [Hypothesis] |
| **EPF admin** | 0.5% employer | On EPF wages | Exempted (own-trust) establishments pay an inspection charge instead — 0.35% of wages, minimum ₹8,750 (S.O. 2701(E) — r2/10) [Verified] | Admin-charge minimum is parameter `epf.admin_charge.minimum` (§06.2) [Hypothesis — minimum not re-captured] |
| **ESI** | 0.75% employee + 3.25% employer | Gross wages, ceiling **₹21,000/mo** (₹25,000 for persons with disability) | Wage crossing the ceiling **mid-contribution-period** does not stop ESI until the period (Apr–Sep / Oct–Mar) ends (r1/06) [Verified]; employees on a daily average wage up to ₹176 are exempt from the employee share while the employer still pays 3.25% (r1/06) [Verified]; ₹0-wage days | esic.gov.in contribution and coverage pages, rates w.e.f. 1 Jul 2019 (r1/06) [Verified]; saved regime to ~21 Nov 2026 (EV-004) |
| **Gratuity** | (last-drawn wages × 15 × completed years) ÷ 26 | "Wages" per CoSS s.2(88); ceiling on gratuity payable is "such amount as may be notified by the Central Government" (CoSS s.53(3)) — **no Code-era notification located**; the familiar ₹20 lakh is the repealed 1972 Act's figure (r1/06). Parameter `gratuity.ceiling`, no shipped default, notification watch per §20 and §22 | Five-year continuous-service requirement does not apply on death, disablement or fixed-term expiry; fixed-term employees are paid pro rata, eligible at one year (r1/06, r3/04); gratuity base rises under the add-back | CoSS s.53 (r1/06) [Verified]; ceiling amount [Hypothesis] |
| **Bonus** | Minimum 8.33% of wages earned or ₹100, whichever is higher, for at least 30 days' work; maximum 20% (Code on Wages s.26 — r1/06) [Verified] | Eligibility and calculation ceilings are delegated to the appropriate Government and may differ by state; the engine's legacy values — eligibility ≤ ₹21,000/mo, calculation ceiling ₹7,000 or minimum wage, whichever higher — are the 2015 amendment's figures, with no Code-era notification located (r1/06) [Hypothesis] | Set-on/set-off of allocable surplus (parameter `bonus.set_on_off_years`); infancy exemption (`bonus.infancy_years`) — both carried, not re-captured (§06) | Code on Wages s.26 (r1/06) |
| **Maternity** | Up to 26 weeks' benefit at 80 days' qualifying service; medical bonus ₹3,500 or as notified (r3/04, r1/06) [Verified] | Average daily wage | Applies at 10+ employees on any day of the preceding twelve months (r1/06); crèche at 50 (EV-057); the reduced entitlement beyond two children and post-leave work-from-home terms are carried, not re-captured [Hypothesis] | CoSS Chapter VI (r1/06) |

Three consequences follow, each of which the product must answer:

- **The problem is not "run payroll" — it is "produce and lodge a correct return, on time, on a government portal, every month, forever."** ICAI's own recommended fee schedule confirms the buyer's mental model: it prices TDS return filing, PT registration and PT returns — and has **no line item for "payroll processing" at all** [Verified — EV-017; the schedule is pre-GST and at least nine years old, and a February 2020 revision was not retrieved (r2/05)]. The unit of value the market already pays for is the filing.
- **The burden is dated and unforgiving.** EPF ECR is due monthly by the 15th; PT returns are state-specific and range monthly to annual; TDS is quarterly with a shifting file format (Form 138 replaced 24Q; the Q4 regular *and* Q4 correction formats were still unreleased on the September 2026 re-check — EV-046, §06.5). A missed deadline is not a soft failure; it is interest, damages and, for TDS, a disallowance risk (§06.5) — and the window to deem the deductor in default runs six years from the end of the tax year, or two years from the end of the tax year in which a correction statement is delivered, whichever is later (Income-tax Act 2025 s.398(5), r5/04).
- **The burden is multiplying under transition.** Four Labour Codes in force 21 Nov 2025; Central Rules 8 May 2026; a one-year saving of EPF/ESI schemes expiring ~21 Nov 2026; the "50% wages add-back" creating **two concurrent wage bases on one payslip** (EV-010, §06.10). The employer who was compliant last year is not automatically compliant this year — and cannot know it without a maintained system.

##### Worked example — the 50% add-back, in rupees

The hardest single calculation in the build (§06.10) is abstract until you run one payslip through it. Take a ₹50,000/month sales employee at a beachhead firm with a commission-heavy structure:

| Component | Monthly ₹ | Counts as "wages"? (Code on Wages s.2(y)) |
| --- | --- | --- |
| Basic | 15,000 | Yes |
| HRA | 9,400 | Excluded |
| Conveyance | 1,600 | Excluded |
| Commission | 22,000 | Excluded |
| LTA | 2,000 | Excluded (travelling concession) |
| Wages (pre add-back) | **15,000 (30%)** | — |
| Excluded total | **35,000 (70%)** | — |

**[Reversed]** v0.3 reached 70% by treating ₹22,000 of *special allowance* as excluded, and its components summed to ₹48,100, not ₹50,000. Special allowance is not an excluded head, and relabelling universal pay does not move it out of wages (§06.10; the *Vivekananda Vidyamandir* principle, §06.2) — so a special allowance counts as wages and the engine carries each component's wage-base membership as an effective-dated flag, never a label-driven default. The example now uses commission and a corrected HRA so the arithmetic closes.

The proviso: where the excluded components exceed **one-half of total remuneration**, the excess over one-half is *deemed wages and added back*. Half of ₹50,000 is ₹25,000; excluded is ₹35,000; the excess is **₹35,000 − ₹25,000 = ₹10,000**. Post add-back, wages = ₹15,000 + ₹10,000 = **₹25,000** (exactly 50% of remuneration).

Downstream effect on the same payslip:

- **Gratuity base** (uncapped by any ₹15,000 ceiling) jumps from ₹15,000 to ₹25,000 — a **≈67% rise in accrued gratuity liability** per employee, applied retrospectively once the rule bites.
- **PF base**: if the employer contributes only to the ₹15,000 ceiling, PF is unchanged; but if the employer already contributes on actual basic (common above the ceiling), the base rises from ₹15,000 to ₹25,000 and monthly PF cost rises with it. The engine must know *which policy each tenant runs*.
- **Two wage bases now coexist on one payslip**: the add-back base (₹25,000, excludes HRA/conveyance/commission/OT/bonus) drives PF and gratuity; the payment-of-wages / equal-remuneration base (₹50,000, includes them) drives minimum-wage and overtime tests. A single "salary" field cannot represent both.
- The statute says "or such other per cent as may be notified" — 50% is a **standing variable, not a constant** (EV-010, §06.10). The rule must be effective-dated and retrospectively recomputable.

##### Worked examples — the four other levies where the number quietly goes wrong

The add-back is the hardest single calculation, but it is not the only one where a spreadsheet accrues silent liability. Four more, each run in rupees on the same 60-person beachhead firm, because "the rule is subtle" only lands when you watch it break a real payslip.

**(a) ESI contribution-period continuity — the mid-period crossing (AC-4).** ESI contribution periods are fixed: April–September and October–March. Eligibility is tested at the *start* of the period; once a member is in, a mid-period pay rise does not drop them. Take an employee at ₹20,500 gross in April (below the ₹21,000 ceiling, so ESI applies). They get a raise to ₹24,000 effective 1 July.

| Month | Gross | Naive tool ("stop at ceiling") | Correct (ESIC rule) |
| --- | --- | --- | --- |
| Apr–Jun | 20,500 | ESI on 20,500 | ESI on 20,500 |
| Jul–Sep | 24,000 | **ESI dropped** (over ₹21k) | **ESI continues on 24,000** until 30 Sep |
| Oct onward | 24,000 | — | Now genuinely out; drops from new period |

A tool that drops the member on the July crossing under-remits three months of ESI (employee 0.75% + employer 3.25% on ₹24,000 = **₹960/month × 3 = ₹2,880** short), and — worse — the *employee* is wrongly shown as uncovered mid-treatment, leaving the employer to answer the resulting benefit dispute. The engine must contribute on the *actual* (raised) wage for the rest of the period, not freeze at ₹21,000. (Source: esic.gov.in contribution page, per r1/06 — an employee crossing the ceiling mid-period keeps contributing to the end of that contribution period [Verified — period rule]; contribution on the raised *actual* wage rather than the ceiling is to be reconfirmed against current ESIC instructions [Hypothesis]; the whole ESI regime is saved only to ~21 Nov 2026 (EV-004, §20 V-08).)

**(b) Gratuity accrued liability — the add-back applied across tenure.** The add-back's ₹15,000→₹25,000 base jump (above) is a per-employee balance-sheet event, not a payslip line. Gratuity = (last-drawn wages × 15 × completed years) ÷ 26, subject to a payable ceiling the Central Government has not yet notified under CoSS s.53(3) (`gratuity.ceiling`; both figures below sit far beneath the repealed Act's ₹20 lakh, so the example does not depend on it). For a 7-year employee:

| Wage base | Per-year accrual (base × 15 ÷ 26) | Accrued at 7 years |
| --- | --- | --- |
| ₹15,000 (pre add-back) | ₹8,654 | ₹60,577 |
| ₹25,000 (post add-back) | ₹14,423 | ₹1,00,962 |

The add-back lifts this one employee's accrued gratuity liability by **₹40,385 (≈67%)**, and it applies to *every* employee whose structure trips the 50% test — a step-change in the firm's Ind AS 19 / actuarial provision the month the rule bites, recognised retrospectively. A payroll tool that treats gratuity as a payslip afterthought misses a liability the auditor will not. (Source: CoSS s.53 formula and s.53(3) ceiling-by-notification (r1/06) [Verified]; no Code-era ceiling notification located [Hypothesis — amount], §06.)

**(c) Professional Tax — the February top-up.** Maharashtra's schedule from 1 April 2023 collects the constitutional ₹2,500/year (Art. 276(2)) as **₹200 × 11 months + ₹300 in February** for men above ₹10,000/month and women above ₹25,000/month (men ₹7,500–10,000 pay ₹175/month; below that, nil). An engine that hard-codes a flat ₹200/month remits ₹2,400/year — **₹100 short of the ₹2,500 cap**, every year, per employee. Across 40 above-slab employees that is ₹4,000/year of quiet under-remittance plus interest, and it recurs precisely because the February value is an exception, not a slab. Karnataka has run the same 11 × ₹200 + ₹300-in-February structure at ₹25,000/month and above since 1 April 2025, and Odisha reaches the same ₹2,500 on an *annual*-income base with ₹300 in "the last month" (which month is undefined on the state page). The two-part logic must be a rule with a per-state slab base and true-up month, not a constant. (Source: Maharashtra and Odisha schedules read at the state primary source, Karnataka notification DPAL 08 SHASANA 2025 of 15.04.2025 corroborated on the state PT portal (r2/10) [Verified — MH, OD; Karnataka effect verified, instrument text not retrieved]; Odisha's true-up month [Hypothesis] — parameter `pt.OD.true_up_month`, §06.4.)

**(d) Statutory bonus — the calculation ceiling and set-on/set-off.** Code on Wages s.26 computes bonus on the lower of actual wage and a ceiling equal to *the notified amount or the minimum wage, whichever is higher* — not on actual salary — and delegates both the eligibility and the calculation ceilings to the appropriate Government, so they may differ by state (r1/06). No Code-era notification has been located, so the worked example runs on the legacy 2015-amendment values — eligibility ≤ ₹21,000/month, notified amount **₹7,000/month** — held as parameters, never constants (§06). For an eligible employee at ₹18,000/month in a state where the scheduled minimum wage for their category is ₹10,500 (an illustrative input):

- Calc base = max(₹7,000, ₹10,500) = **₹10,500**, not ₹18,000.
- At the statutory floor of 8.33%: annual bonus = ₹10,500 × 12 × 8.33% = **₹10,496**; at the 20% ceiling (when allocable surplus permits): **₹25,200**.

A tool that pays 8.33% of *actual* ₹18,000 over-remits by ~71%; one that uses a bare ₹7,000 floor and ignores a higher minimum wage under-remits. The rate between 8.33% and 20% is not a constant either — it is driven by *set-on / set-off of allocable surplus* carried forward for a limited number of years (parameter `bonus.set_on_off_years`, no shipped default), so a loss-making beachhead unit in its formative years and a profitable one owe different percentages on the same salary. (Source: Code on Wages s.26(1)–(3) — minimum 8.33% or ₹100, maximum 20%, ceiling = notified amount or minimum wage (r1/06) [Verified]; ₹21,000 and ₹7,000 are legacy 2015-amendment figures (r1/06, medium) [Hypothesis — Code-era values]; set-on/set-off years carried from the legacy Act, not re-captured (§06) [Hypothesis]; per-state minimum-wage schedules [Hypothesis].)

The through-line across all four: none of these is a "salary × rate" one-liner. Each has a ceiling, an exception, or a cross-period carry that a flat spreadsheet formula gets wrong in the direction of silent under- or over-remittance — and each is invisible until an inspection, an actuarial valuation, or an employee grievance surfaces it. This is the concrete content of "the filing, not the payslip, is the unit of delivery."

##### The edge cases that manufacture retro-liability

Beyond the headline levies, a cluster of threshold-and-eligibility edge cases is where a spreadsheet or an inattentive bureau accrues silent liability. These are not exotic — they occur in ordinary beachhead firms every year.

| Edge case | Rule | Why it bites in the beachhead | Source cue |
| --- | --- | --- | --- |
| PoSH Internal Committee | **Every employer** must constitute one (s.4(1)); the ten-worker line is s.6(1) — the *Local* Committee where no IC exists — and is not an exemption | Applies from employee one; routinely missed as a "non-payroll" obligation, and the ten-worker myth makes sub-10 firms believe they are exempt | Sexual Harassment of Women at Workplace Act 2013 [Verified — EV-056] |
| Fixed-term employee gratuity | The five-year continuous-service requirement does not apply on fixed-term expiry; payable **pro rata**, eligible at one year | Common in the beachhead's project/contract staffing; accrual starts from year one | CoSS s.53 (r1/06, r3/04) [Verified] |
| Apprentices | Excluded from EPF/ESI while engaged under the Apprentices Act 1961 | Mis-classifying an apprentice as an employee over-remits; the reverse under-remits | Carried, not re-captured (§06.1) [Hypothesis] |
| International workers | Contribution on **full wages with no ₹15,000 ceiling**, unless exempt under a Social Security Agreement; post-September-2014 joiners above ₹15,000 are not EPS members (r5/02) | A single expat/returning-NRI hire breaks the ₹15,000-ceiling assumption | EPS exclusion [Verified — EPFO FAQ, r5/02]; the uncapped basis is a live, contested rule (§06.2) [Hypothesis] |
| Contract labour | The principal employer pays EPF and recovers from the contractor (CoSS s.17); for ESI the employer pays both contributions for every employee "whether directly employed by him or by or through a contractor" (s.31(1)); OSH Code s.55 makes the principal employer liable for contract workers' wages on contractor default; the contract-labour licensing threshold is 50 (EV-057) | The beachhead firm inherits the contractor's non-compliance | CoSS ss.17, 31 (r2/10) [Verified]; OSH s.55 (r3/04) [Verified] |
| Arrears / retro wage revision | Recompute PF/ESI/PT/TDS against the **period's** rule version | Add-back and slab changes make retro runs non-trivial (AC-2) | Code on Wages; EPF Scheme [Verified — principle] |
| LWF employer/employee split | Differs by state, remitted monthly/half-yearly/annually | Tiny rupees, many distinct rules — a maintenance load, not a calculation one | State LWF Acts [Hypothesis — per-state amounts] |

The through-line: each of these is a place where "run payroll" and "file correctly, provably, forever" diverge — and each is invisible until an inspection or an employee grievance surfaces it. The audit trail (AC-9) and effective-dated recompute (AC-2) exist precisely to make these defensible rather than discovered.

Two of these edge cases are worth a rupee illustration, because their *shape* — not their magnitude — is what defeats a spreadsheet:

- **International worker, PF uncapped — if the rule is enforceable.** A hire at ₹2,00,000/month who qualifies as an "international worker" contributes on **full wages with no ₹15,000 ceiling**, as the rule is carried. Employee 12% + employer 12% on ₹2,00,000 = **₹48,000/month** of PF, against the ₹3,600 a ceiling-capped domestic employee at the same salary would show — a **13.3× difference on one payslip**; and because a post-September-2014 IW above ₹15,000 is not an EPS member (r5/02), none of the employer's 12% routes to EPS. A tool that applies the ₹15,000 ceiling universally would under-remit ₹44,400/month for this one worker and mislabel the contribution class on the ECR. The engine needs a per-employee IW flag that overrides the tenant-level ceiling policy (AC-5), not a global constant — and, because the current enforceability of the IW provisions is contested (§06.2 carries the litigation history; it has not been re-captured), the uncapped basis ships behind an effective-dated rule switch, never as a hard-coded default. (Source: EPFO revamped-ECR FAQ on IW EPS membership (r5/02) [Verified]; the uncapped basis, its paragraph references and the litigation history are carried, not re-captured [Hypothesis] — kill criterion per §06.2.)
- **LWF, the many-tiny-rules problem.** LWF amounts are small, but the *rules* are the cost. The shape, with no amounts asserted: State A deducts an employee and an employer amount *half-yearly*; State B deducts different amounts *once a year in a fixed month*; State C deducts *monthly*. Each has its own amount, split, month and portal — so a three-state firm carries three independent LWF cadences that a "flat monthly ₹X" formula cannot represent, and a missed annual remittance is a compliance flag for a trivial sum. This is the canonical "maintenance load, not calculation load" (§06.8): trivial rupees, non-trivial *rule count*. (Source: respective State LWF Acts — LWF sits entirely outside the four Labour Codes and no LWF rate or split is verifiable from a government source in any state (r2/10); the single verified periodicity is Karnataka's calendar-year cadence with a 15 January due date (r2/10); every other per-state amount, split and cadence is unknown until the gazette dataset lands (EV-015, §20 V-09), held as parameters `lwf.<state>.employee`, `lwf.<state>.employer`, `lwf.<state>.periodicity` (§06.8); neither Frappe HR nor TallyPrime ships an LWF engine (EV-031, EV-032).)

##### Worked example — TDS's breaking file-format change

The TDS filing is not a stable target the buyer can "set and forget" — it is actively breaking underneath them this year, which is why a *maintained* system beats a spreadsheet macro that encoded last year's layout. Form 138 replaces 24Q and the record layout is a breaking change, not a rename (EV-011, EV-051, §06.5):

| What changed | Old (24Q) | New (Form 138) | Consequence for the filer |
| --- | --- | --- | --- |
| Challan sub-headings | 301–312 | Remap to A–K, **303 deleted** | Any tool hard-coding challan codes emits an invalid file |
| Annexure I fields | 313–327 | Remap to C–N, with **313, 321, 322, 325 removed** | Field-position parsers break silently |
| Surcharge / Education Cess / Penalty-Others | Present | **Deleted** | Amounts that used to have a home now have none |
| Interest Allocation / Others Allocation | Absent | **Added** | New mandatory fields a stale template does not populate |
| Deductor identification | Token No.; TAN Registration No. | Token No. becomes **"Return Receipt Number"**; TAN Registration No. **deleted**; the form auto-populates from the deductor's TRACES profile (EV-051) | A template that still carries last year's identification fields is structurally wrong |
| Period vocabulary | "Financial Year" | **"Tax Year"**, a six-digit field (202627 for Tax Year 2026-27) (EV-050) | Search, labels and imports must accept both vocabularies — historical periods keep the old forms |
| Rollout | — | Q1–Q3 v1.2 shipped 22 Jul 2026; correction-statement structures 4 Aug 2026 | Mid-year format churn |
| **Q4 regular and Q4 correction formats** | — | **Not released** on the September 2026 re-check (EV-046) | Form 130 (ex-Form 16) is TRACES-generated from Annexures I and II (EV-048), so the annual certificate is blocked until Q4 lands — both generators are fenced |

(Source: Protean RPU/FVU 1.2 release note and CBDT FN-138, 2026 — EV-011, EV-046, EV-051; the 1.2 stack applies from Tax Year 2026-27 and mixing versions causes rejection (EV-052); §06.5. [Verified].)

The buyer-facing point: an employer running a spreadsheet or an un-maintained tool cannot even *know* its Q1 (Tax Year 2026-27) statement is on a stale layout until the FVU rejects it — and the Q4/Form 130 dependency means the annual certificate is blocked on a format that has not shipped. Neither incumbent removes this: TallyPrime ships 24Q-era annexures, but whether its forms are current with the latest Finance Act is an unresolved parity cell (EV-032); Frappe HR ships no 24Q/138 generator at all (EV-031). It is also a concrete instance of the standing rule: a watcher keyed only to *new instruments* would miss a corrigendum to the *format*, exactly the failure mode that inverted the November 2026 analysis (§02.4).

##### Worked example — the mid-year joiner and previous-employer income

The other recurring TDS defect is not about the file format at all — it is the mid-year joiner whose previous-employer income and TDS are not picked up. Take an employee who joins the 60-person firm on 1 October at ₹1,50,000/month (₹9,00,000 for Oct–Mar), having earned ₹9,00,000 at the prior employer in Apr–Sep, which deducted ₹80,000 of TDS (illustrative inputs, as the employee declares them on Form 122).

The arithmetic below runs on the new-regime slabs for AY 2026-27 — the latest verified in the evidence base (r1/06; the worked base in §06.5): nil to ₹4 lakh, 5% to ₹8 lakh, 10% to ₹12 lakh, 15% to ₹16 lakh, 20% to ₹20 lakh; an s.87A rebate of up to ₹60,000 where taxable income does not exceed ₹12 lakh; 4% health and education cess. The standard deduction (parameter `tds.standard_deduction.<regime>`) is left out to keep the arithmetic visible, and the Tax Year 2026-27 slabs, rebate ceiling and standard deduction must be re-verified before the year's TDS runs (§06.5 kill criterion) — the example demonstrates a *shape*, not this year's tax.

- **If the new employer ignores the prior income** (the spreadsheet default): it projects ₹9,00,000 for the year. Tax before rebate is ₹30,000 (5% of ₹4 lakh = ₹20,000, plus 10% of ₹1 lakh = ₹10,000), which the rebate wipes out — so it deducts **nothing** for six months.
- **The correct treatment (1961-Act s.192(2) with Form 12B; now s.392 and Form 122 — EV-050):** the employee furnishes prior salary and TDS on Form 122 (ex-12B); the new employer aggregates ₹9,00,000 + ₹9,00,000 = **₹18,00,000**, which is above the rebate ceiling. Tax = ₹20,000 (₹4–8 lakh) + ₹40,000 (₹8–12 lakh) + ₹60,000 (₹12–16 lakh) + ₹40,000 (₹16–18 lakh at 20%) = ₹1,60,000; with 4% cess, **₹1,66,400**. Credit the ₹80,000 already deducted and ₹86,400 remains — **₹14,400/month** over Oct–Mar.

The naive run under-deducts the full ₹86,400. The rebate ceiling is what turns "ignore prior income" from a small slab error into a zero-deduction error: each half-year looks rebate-eligible on its own, the aggregate is not. The gap surfaces only in the employee's own Form 130 (ex-Form 16) reconciliation or a processing intimation — by which point it is tax the *employee* must pay on filing and short-deduction exposure for the *employer*: interest at 1% per month from the date tax was deductible (Income-tax Act 2025 s.398(3)(a), ex-s.201(1A), r5/04), inside a default window of at least six years (s.398(5)). The engine must (i) accept Form 122 (ex-12B) prior-income input at onboarding — income after exemptions, tax already deducted, professional tax and EPF from prior employers (r3/02), (ii) annualise on aggregate, and (iii) reconcile prior-employer TDS credit — none of which a single-employer salary column can represent. This is exactly one of the "judgement calls the bureau carries" (Pain 3) made visible and deterministic. (Source: Income-tax Act 1961 s.192(2) and Form 12B, carried into the Income-tax Act 2025 as s.392 and Form 122 (EV-050); Form 122's previous-employment fields (r3/02) [Verified]; AY 2026-27 slabs, rebate and cess (r1/06) [Verified]; their continuation into Tax Year 2026-27 [Hypothesis] (§06.5); the product accepts both vocabularies (EV-050).)

##### The November 2026 cliff as a market-timing wedge

One statutory fact does double duty as a *sizing* argument, not just an engineering one. The EPF Act 1952 is repealed with effect from 21 Nov 2025; Code on Social Security s.164(2)(b) saves the EPF/EDLI/EPS schemes and all ESI rules for *one year*, expiring ~**21 Nov 2026** (EV-002, §06.9, [Verified]). The EPF side has a named successor (Employees' Provident Funds Scheme, 2026, 12% re-notified retrospectively by S.O. 3582(E) — EV-003); **the ESI side is unresolved** (EV-004).

Why this matters to the market, not just the codebase:

- It creates a **forced re-evaluation moment** across the entire contributing base simultaneously. Every 20–200 employer must confirm their payroll runs against Scheme 2026 and whatever replaces the ESI saving — a rare synchronous trigger in a market where switching inertia is otherwise the dominant force (§04.2).
- It is a **wedge against the status quo specifically**. A Tally-plus-CA arrangement survives on the CA quietly absorbing changes; a cliff of this size, with an *unresolved ESI leg*, is exactly the kind of event where the black-box relationship (Pain 3) fails visibly and the employer starts shopping.
- It is **time-boxed**, which is unusual and valuable for GTM. The window in which "are you ready for 22 November 2026?" is a live buyer anxiety is measured in months, and it maps to the §20 (V-08) primary-source watch.

> [Hypothesis] The cliff is a launch-timing tailwind, not just a compliance risk.
> **Kill criterion:** if ESIC re-notifies its schemes cleanly and early (well before 21 Nov 2026) with no disruption, the "forced re-evaluation" tailwind weakens to the ordinary annual-Budget change cadence, and acquisition timing loses this specific hook.

##### Why now — three timing forces converge on the launch window

The cliff is one of three near-simultaneous forces that make the 12–18 months from the research date an unusually good entry window. None is individually decisive; together they compress the market's ordinary switching inertia.

| Force | Nature | Timing | Direction on entry |
| --- | --- | --- | --- |
| Nov 2026 EPF/ESI cliff | Regulatory (forced re-check) | ~21 Nov 2026, ESI leg unresolved | Tailwind — synchronous re-evaluation (above) |
| Four Codes + Central Rules bedding in | Regulatory (new spec) | In force 21 Nov 2025; Rules 8 May 2026; state rules rolling unevenly | Tailwind — "build against a settled spec" (§06), and every employer's prior config is now suspect |
| Zoho free-gate widening | Competitive (price floor moves) | Unknown date; treated as *when*, not *if* (§18; §20 R-1) | Headwind — compresses the paid floor from below |

The read: the two regulatory forces open a window in which "is your payroll correct under the new regime?" is a live, dated anxiety the Tally-plus-CA arrangement answers opaquely — and the competitive force sets a clock on how long the 20–50 sub-band stays monetisable before Zoho zero-prices it. A filing-first entrant wants to land *while both regulatory triggers are fresh and before the free floor widens*, which is the concrete GTM meaning of the beachhead being "over-served by cheap product, under-served by product that carries the filing through to portal acceptance" (§01).

> [Hypothesis] The regulatory tailwind outweighs the Zoho-gate headwind for a launch inside this window.
> **Kill criterion:** if Zoho (or a fintech, §20 R-6) widens the free gate to 50 *before* the regulatory re-check anxiety converts pipeline, the entry window closes on the lower beachhead and the launch must re-center on 50–200 at higher PEPM — the §04.3 grid re-run on the upper sub-band (see §04.4 structural risks).

##### Acceptance criteria — Pain 1 (statutory engine)

These are the pass/fail tests the engine must meet for this section's thesis to hold. They are written so a §20 prototype can be graded against them.

- **AC-1 (dual wage base).** For any CTC structure, the engine computes and stores at least two concurrent wage bases per employee per period; a change to the add-back percentage re-derives both without manual re-entry.
- **AC-2 (effective-dated rules).** A retro/arrears run for period *P* recomputes against the rule version in force *for P*, not the version in force today, and emits an audit trail showing which version applied. (Mirrors §06.10.)
- **AC-3 (deterministic statutory numbers).** No PF/ESI/PT/TDS/gratuity figure is ever model-generated; the LLM may explain a number but never produce one (§13.4, "rules-first, LLM-last").
- **AC-4 (contribution-period continuity).** An ESI member whose wage crosses ₹21,000 mid-period continues to contribute until the contribution period closes; the engine does not drop them at the crossing.
- **AC-5 (ceiling policy per tenant).** PF is computed on either the ₹15,000 ceiling or actual wages per a tenant-level policy flag, and the two never silently diverge across employees.
- **AC-6 (Scheme 2026 migration).** All EPF computation references the Employees' Provident Funds Scheme, 2026, not the repealed 1952 Scheme, and carries a corrigendum-check flag per the standing rule (§02.4).

The worked examples above add five more pass/fail tests, sub-lettered so they do not renumber AC-7 onward, plus one new test numbered after the section's maximum:

- **AC-4a (ESI raised-wage continuity).** When an in-period ESI member's wage rises above ₹21,000, the engine contributes on the *raised actual* wage for the remainder of the contribution period, not on the frozen ₹21,000 ceiling and not zero.
- **AC-6a (gratuity as a liability, not a payslip line).** Every add-back or wage revision re-derives per-employee accrued gratuity on the correct base and surfaces the aggregate liability delta for actuarial/provisioning use — retrospectively for the affected period.
- **AC-6b (bonus calc ceiling + minimum-wage floor).** Statutory bonus is computed on min(actual wage, max(notified amount, applicable minimum wage)), with the eligibility ceiling, the notified amount and `bonus.set_on_off_years` held as per-appropriate-Government parameters (the legacy ₹21,000 / ₹7,000 apply only on recorded operator confirmation, per AC-16, until a Code-era notification is captured), and the 8.33%–20% rate driven by set-on/set-off — never a hard-coded 8.33%, never a bare ₹7,000.
- **AC-6c (PT exception months).** State PT is a rule table with a per-state slab base (monthly salary for Maharashtra and Karnataka, annual income for Odisha), gender variants and a true-up month (Maharashtra's and Karnataka's ₹300 February; Odisha's ₹300 "last month", `pt.OD.true_up_month`), never a flat monthly constant; annual PT reconciles to the state cap per employee.
- **AC-6d (mid-year joiner aggregation).** The engine accepts Form 122 (ex-12B, EV-050) prior-employer income and TDS at onboarding, annualises tax on the aggregate, and credits prior TDS — no single-employer-only TDS run for a mid-year joiner. Test case: the ₹9 lakh + ₹9 lakh example above must deduct ₹14,400/month on the worked base, not ₹0.
- **AC-16 (unnotified ceilings stay open).** *(Numbered after AC-15 so existing IDs stay stable; it belongs with the Pain-1 engine tests.)* Where a Code delegates a figure to notification and none has been captured — the gratuity payable ceiling (`gratuity.ceiling`), the bonus ceilings, the EPF and ESI damages scales (`epf.damages_scale`, `esi.damages_scale`) — the parameter ships with no silent default; any computation that needs it is held for operator confirmation, and a legacy figure is applied only with that confirmation recorded against the run.

<!-- DIAGRAM: problem-market-obligation-thresholds -->

#### Pain 2 — The tooling is fragmented, and the seams are where errors live

The 20–200 employer does not run one system. They run a *stack of partial systems joined by spreadsheets and manual re-keying*, and every join is a place a statutory number goes wrong.

| Function | What the beachhead employer typically uses today | The seam / failure mode |
| --- | --- | --- |
| Payroll calculation | Tally payroll module, or Excel, or a CA's in-house tool | Wage-base definitions not versioned; add-back rule applied inconsistently |
| Attendance | eSSL/ZKTeco biometric terminal + its own time-office software | Punch data manually exported and re-keyed into payroll; OT hours untracked against any quarterly limit |
| Statutory filing | CA/bureau logs into EPFO/ESIC/TRACES/state PT portals | No single source of truth; the employer cannot see filing status until something breaks |
| Employee queries | Email, WhatsApp, HR person's memory | Payslip disputes, investment declarations, Form 130 (ex-Form 16) requests all manual |
| Records | Paper registers or per-portal downloads | The six central-sphere employer registers plus the wage slip (EV-053) — including Form IX's per-day IN/OUT grid (EV-055) — not maintained as a system; retention periods per EV-054 |

The cost of fragmentation is not licence fees — it is **re-keying error, reconciliation labour, and the absence of a defensible audit trail**. This is the specific gap the PRD's positioning attacks: not feature parity with Zoho (that is table stakes, §21), but *portal-accepted artefacts plus attended, assisted submission under the employer's written authority, over a single record* (K-13). TallyPrime generates the artefacts (EV-032) but submission and status stay with the employer or its CA; a spreadsheet-plus-CA arrangement does both badly. The statutory liability stays with the employer either way — it is non-delegable.

Two seams are worth naming concretely because every pay cycle crosses them (their relative error frequency is unmeasured — a §20 V-16 baseline question):

- **The attendance→payroll seam.** A biometric terminal records punches; those punches must become paid days, overtime hours, leave deductions and loss-of-pay. When this crosses a manual export, OT is mis-stated, any quarterly OT limit is invisible, and the wage base for PF/ESI is wrong before any filing runs. (The "144 OT hours per quarter" cap is reported only by secondary summaries and has not been confirmed against gazette text — [Hypothesis], K-04: the product may *warn*, never *block*; §09.6, §20 V-17.) The device push receiver (ADMS/WDMS, EV-013, §09.3) exists to close exactly this seam without middleware.
- **The wage-master→filing seam.** The ECR, ESI challan and PT return each need the *same* employee master with *different* wage definitions (add-back base for PF, gross for ESI, salary slab for PT). A spreadsheet keeps one column called "salary" and derives the rest by hand. Every derivation is a defect opportunity.

##### Acceptance criteria — Pain 2 (single record, closed seams)

- **AC-7 (one master, many views).** ECR, ESI challan, PT return and TDS annexure all draw from one employee/wage master; no filing is produced by re-keying from another artefact.
- **AC-8 (attendance closes into payroll).** Punch data from a supported device (eSSL/ZKTeco via ADMS push) resolves to paid days, OT (checked against a configurable quarterly OT limit that *warns and never blocks* — K-04) and LOP with no manual export step.
- **AC-9 (audit trail).** Every statutory figure is traceable to the source record and rule version that produced it, and feeds the six central-sphere registers and wage slip (EV-053) with state form numbers configurable; retention follows EV-054's central-sphere periods, with state-sphere periods held as configuration pending counsel (§14.7, §23).

#### Pain 3 — The bureau relationship is a real, recurring budget line — and a black box

The dominant "solution" in the beachhead today is not software. It is a **CA or payroll bureau** charging a monthly retainer to run the filings and carry the judgement calls. This is simultaneously the status quo to displace-or-partner-with and the price anchor for everything.

- Published anchor: one provider's indicative bands run **₹3,000–8,000/month for 11–50 employees and ₹8,000–15,000/month for 51–100** (IndiaFilings, r2/05) — [Verified as a published indicative range]; what bureaus actually charge across the market is [Hypothesis] (§20 V-01). At the low end that is ~₹36k/year; at the high end ~₹1.8L/year — a meaningful budget line that already exists and does not need to be created.
- The black-box problem: the employer pays the retainer but has **no visibility into filing status, no self-serve record, and single-person key risk** (the relationship lives in the CA's head and login). When the CA is slow, sick, or wrong, the *employer* carries the statutory liability — the notice from EPFO or the AO lands on the *employer*, not the bureau.
- The judgement calls the bureau carries — the add-back interpretation, which allowances count as PT-liable, whether a mid-year joiner's previous-employer TDS is picked up — are precisely the calls that a maintained rules engine can standardise and make visible. Today they are opaque even to the employer paying for them.

> [Hypothesis] The realised bureau price is the single most important unvalidated number in the entire market model.
> If a CA in a Class-B city actually charges under ₹2,000/month for 20–50 people, the ₹80–150 PEPM modelling band collapses toward the ~₹50 value floor and the beachhead economics must be rebuilt. (K-09: price is a two-anchor structure — a value floor near ₹50 PEPM (Qandle, greytHR at 50 employees) and a mid-market clearing band of ₹80–200 (Zimyo, HROne, Keka), EV-027; the ₹80–150 band sits inside the clearing band and is not a ceiling; §18.)
> **Kill criterion:** mystery-shop 6–8 CAs/bureaus across two city tiers for 20/50/100-person quotes (§20 V-01). If the median monthly quote is < ₹2,000, re-anchor pricing before any funding decision.

**Where the three pains converge is the beachhead thesis:** the 20–200 employer has a *legally-enforced, dated obligation* (Pain 1), *fragmented tooling that manufactures errors* (Pain 2), and *an existing budget line paid to a black box* (Pain 3). That is obligation + dissatisfaction + budget in one segment — the definition of a market.

#### Who actually buys — the decision anatomy of a beachhead firm

Market sizing is meaningless without knowing who inside a 60-person firm signs, who uses, and who the product must *not* alienate. The beachhead buying unit is small and unusual — the same person often occupies three of these roles, and the external CA is inside the loop.

| Role | Who it is in a 20–200 firm | What they care about | Implication for the product |
| --- | --- | --- | --- |
| Economic buyer | Founder / owner / CFO | The penalty notice lands on *them*; wants the retainer line controlled | Sell on risk reduction and visibility, not features — the statutory liability stays with the employer and cannot be sold away (K-13) |
| Admin user | One HR/admin person (often <1 FTE on HR) | Not being blamed when a filing is late; not re-keying | Filing-status dashboard; single record (AC-7) |
| The CA / bureau | External, part-time, holds the portal logins | Their retainer, their judgement calls, their client relationship | Channel, not enemy — CA console (§18.7), or they block the sale |
| Employees | 20–200 people | Payslip, Form 130 (ex-Form 16), investment declaration, leave balance | Employee/mobile surface — parity with Frappe's PWA; whether TallyPrime ships employee self-service is an unresolved parity cell and must not be asserted either way (EV-032) |

Two consequences for GTM and therefore for CAC:

- **The CA is a gatekeeper, not a bystander.** In many beachhead firms the CA *is* the person who would evaluate and recommend the software, because the founder delegates compliance entirely. A product that reads as "disintermediate your CA" gets vetoed by the one person the founder trusts on this. This is why "design for the CA as a user" is the most consequential GTM call in the PRD — and why it is also entirely unvalidated (§18.7, §20 V-05). If CAs see us as a threat, the channel inverts into an opponent and CAC rises.
- **The admin user has almost no time budget.** HR is a fractional job in a 60-person firm. The buyer will not sit through an enterprise demo cycle, which is the concrete reason self-serve INR pricing and a published price card are table stakes (AC-14, §18), not polish.

> [Hypothesis] The CA is a channel, not a competitor, in the beachhead buying unit.
> **Kill criterion:** 20–30 practising-CA interviews across two city tiers (§20 V-05). If CAs predominantly see filing-first software as disintermediation of their retainer, the primary GTM motion is wrong and must flip to direct-to-founder with the CA as an integration, not a channel.

#### The status-quo alternatives the buyer weighs

The competitor at the point of sale is rarely another SaaS — it is the arrangement the firm already runs. Naming the real alternatives is what keeps the wedge honest (it is *quality-of-delivery*, not *availability* — §01).

| Status-quo option | What it costs the buyer today | Where it fails the buyer | Why we win / why we do not |
| --- | --- | --- | --- |
| Excel + in-house | ~₹0 licence; heavy hidden labour + error risk | No audit trail; add-back and TDS-format changes silently break it | Win on correctness + maintained updates |
| TallyPrime + CA | Payroll inside the existing TallyPrime licence (Silver is single-PC; multi-user needs Gold at 3× the price — EV-032) + CA retainer (indicative ₹3k–15k/mo, V-01) | No state PT slab table, no LWF engine, no leave module, leave encashment not calculable (EV-032); submission and status visibility sit with the CA | Win on multi-state PT/LWF, leave-to-payroll and attended submission with visibility (§21) |
| Pure bureau (no software) | Indicative ₹3k–15k/mo (V-01), all judgement outsourced | Black box; single-person key risk; liability stays with employer | Win on visibility; risk is the CA blocking (above) |
| Kredily / Zoho free tier | Kredily ₹0 unlimited; Zoho Payroll ₹0 to 10 employees | Computation free, outputs charged — bank payout files, PF/ESI challans, the annual tax certificate, Form 124 (ex-12BB) (EV-029) | Win on the output and submission layer; **parity on computation** |
| A priced HRMS (greytHR, Qandle, Pocket HRMS, Zimyo, HROne, Keka) | At 20 employees ₹2,450–6,999/month, because all six bill a 50-employee minimum block (Keka's historical block: 100) — ₹122.50–349.95 effective PEPM (EV-026, EV-027) | Generate artefacts; none claims to submit (EV-030); Keka suppresses its live price card (EV-021, EV-024) | Win on no seat floor (§18) and attended submission (K-13) |

The distribution across these options is unknown and it is the *volume* variable behind the bureau pool (§04.3) and the incumbent question. **Two incumbents, two jobs** (K-23): TallyPrime owns accounting and the statutory artefacts; greytHR owns the HRMS job (EV-091). Tally payroll *adoption*, as distinct from capability, is unknown (EV-032; §20 V-01–V-02). If most of the beachhead is on Tally-plus-CA, the wedge is displacement-with-migration; if most is on a rival SaaS, it is competitive win/loss. These are different GTM motions and the §20 studies decide which one we are running.

#### Worked example — one month in the life of a 60-person employer

To make the burden concrete rather than abstract, here is the recurring filing load for a single beachhead employer: a 60-person firm registered in Maharashtra and Karnataka (a common two-state footprint — HQ plus a satellite office). This is *one month*, and it repeats every month, forever.

| Date (typical) | Filing / action | Portal | Consequence of a miss |
| --- | --- | --- | --- |
| 7th (March deductions: 30 April — r3/02) | TDS deposit for prior month (s.392, ex-s.192 — EV-050) via Challan ITNS 281 (r3/02) | Bank challan | Interest 1.5% per month from deduction to deposit — Income-tax Act 2025 s.398(3)(a), ex-s.201(1A) (r5/04); disallowance risk (§06.5) |
| Per registration (periodicity ingested each financial year — §06.4) | Professional Tax return — Maharashtra (PTRC); filing frequency is assigned **per registration each financial year** by the state department, so it is ingested, never derived (r1/06) | mahagst.gov.in | Interest and late fee per `pt.<state>.interest_rate` / `pt.<state>.late_fee`, no shipped default (§06.4) |
| 15th | **EPF ECR** upload → approve → challan → pay, for 60 employees; an approved return can never be cancelled (EV-036) | unifiedportal (EPFO) | Interest at 12% p.a., auto-calculated and mandatory with the contribution (EV-039); damages per `epf.damages_scale` (§06.2) |
| 15th (national date, ESI (General) Regulation 31 — r3/02) | ESI contribution for eligible employees (at or under the wage ceiling, in notified districts) | esic.gov.in | Interest at 12% p.a. (S.O. 2698(E)); damages per `esi.damages_scale` (legacy Reg 31-C graded up to 25% p.a. — r3/02) |
| 20th (within 20 days of month-end — r3/02) | Professional Tax — Karnataka, Form 5A (monthly) | e-PRERANA, Commercial Taxes Department (r3/02) | Per `pt.KA.*` parameters (§06.4) |
| State-set (not captured) | Shops & Establishments renewals and other state touchpoints | state labour portals | Per state — due days not captured (§06.11). Vendor calendars are not a source: one listed Karnataka PT on the "21st" with the wrong authority (r3/02) |
| Month-end | Attendance close: OT reconciliation against the configured quarterly OT limit (warn only — K-04); leave accrual; wage-base recompute (two bases per the 50% add-back) | internal → payroll | Wrong PF/gratuity base → retro liability |
| 31 Jul / 31 Oct / 31 Jan / 31 May (EV-049) | **Form 138** (ex-24Q) quarterly statement — FVU-validated file uploaded by the deductor (K-13) | TRACES/Protean | ₹200/day late fee under the 1961 Act's s.234E per a secondary source [Hypothesis]; statement-default penalty per `tds.penalty.statement_default`, 2025-Act section unmapped (§06.5) |
| 30 Sep / 31 Mar | ESI contribution-period close — ceiling-crossers exit from the next period; half-yearly return-of-contributions view (§06.3, §06.11) | esic.gov.in | Coverage re-evaluation errors carry into the next period |
| Annual | Form 130 (ex-Form 16 — TRACES-generated only, EV-048; issued to each employee by 15 June following the tax year per CBDT's Form 138 guidance note, r5/02; blocked on the Q4 format, EV-046); PF Form 3A/6A; PT annual (state); LWF (state — Karnataka's calendar-year remittance due 15 January is the one verified cadence, r2/10) | multiple | Certificate delay penalty per `tds.penalty.certificate_delay`; return defaults per state parameters (§06.5, §06.8) |

That is **six-plus distinct portals, three-plus statutory authorities, and at least four different filing cadences** for one 60-person firm in two states. Add a third state and the PT/LWF matrix multiplies again. This is the burden the product converts from a monthly scramble into a dated, tracked pipeline that ends in a portal-accepted artefact and an attended submission under the employer's authority (K-13) — and it is why the *filing*, not the payslip, is the unit of delivery.

##### The cost of one missed month, in rupees

To size the *downside the product removes*, run the penalty math on a single missed EPF month for this 60-person firm. Assume total monthly PF remittance (employee + employer) of ₹1.2 lakh (60 employees, an assumed blended ₹2,000/head — an illustrative input, not a measured figure).

- **Interest (the portal's "7Q" line):** simple interest at 12% p.a. from the due date (S.O. 2698(E), 29 May 2026 — r1/06; EV-039). For, say, a 3-month delay: ₹1.2L × 12% × 3/12 = **₹3,600**. It is auto-calculated and mandatory with the contribution, so it is a cash-flow item on the day of payment (EV-039).
- **Damages (legacy s.14B; CoSS s.128 — r2/10):** the Code-era scale is not in the evidence base — it is parameter `epf.damages_scale`, no shipped default (§06.2), and EPFO's own EDLI page still shows a legacy per-month figure (r1/06), so two official texts disagree. The illustration therefore carries damages as an unknown annual rate *d*: ₹1.2L × *d* × 3/12 = **₹300 per percentage point of *d***. Damages may be deposited later at the employer's option (EV-039), which defers the cash but not the liability.
- **The unquantified part:** the employer, not the bureau, receives the interest and damages demand; the Code-era offence provisions behind repeated default are unmapped (§06.2, §06.13) and are not sized here. The reputational and audit cost is not in the arithmetic at all.

The point is not the exact rupee figure — it is that a *single portal missed by one person on leave* costs, in mandatory interest alone, ₹3,600 — 40–75% of a month of the product at the ₹80–150 modelling band (60 × ₹80–150 = ₹4,800–9,000) — before damages (₹300 per point of an unverified rate) and the unquantified layers, and the buyer has no forewarning today. Filing-status visibility is not a nicety; it is the insurance the retainer was supposed to buy and does not.

<!-- DIAGRAM: penalty-waterfall -->

#### The state-fragmentation multiplier

Professional Tax and Labour Welfare Fund are **state subjects** — there is no single national schema. Every state an employer operates in adds an independent levy with its own slab table, gender variants, periodicity, registration and filing cadence.

- **PT is a levy under roughly 20 separate State Acts** run by separate departments; no national government source of truth or consolidated table was found (r2/10); aggregator compilations count roughly 19–20 levying states/UTs (r1/06). In Tamil Nadu and Kerala it is a **local-body** levy rather than a state tax-department levy (r2/10), so even the levying authority varies. States commonly reported as *not* levying PT (Delhi, Uttar Pradesh, Rajasthan, Haryana, Punjab, Uttarakhand and others) are **unconfirmed** — no negative has been verified at source (r1/06, r2/10). A multi-state employer must therefore track "levy yes/no" and "levied by whom" per state before even reaching slabs. [Verified as structural — per-state Acts, no national table, local-body levies in TN and Kerala; the non-levying list and the levying count [Hypothesis]]
- **LWF is levied by a subset of states** (the exact list is part of the V-09 dataset) with contribution amounts, employer/employee split and periodicity that differ by state and are revised on their own schedules.
- **[Reversed] "Frappe HR ships PT across 15+ states and LWF across 14, free — so multi-state PT/LWF is table stakes."** False from source code: Frappe HR v16's India payroll is 3 files / 549 lines overriding 3 functions (HRA and marginal relief); no Indian state name appears anywhere in the repository; no PT slabs, no LWF (EV-031). TallyPrime has no state PT slab table (slabs are hand-entered) and no LWF engine, and a five-catalogue TDL search found no add-on closing the gap (EV-032). **Multi-state PT and LWF is a genuine differentiator — greenfield in both incumbents.**
- The maintenance consequence (§06.4, §06.8, §22): a verified, gazette-sourced PT+LWF dataset for every state — levy, slabs, gender variants, periodicity, effective dates — is a **build dependency**. Three state PT schedules have been read at the state's own primary source — Maharashtra and Odisha, with Karnataka's February top-up corroborated on its state portal (r2/10; §06.4 carries them) — while Telangana's verification reached its employer-registration wording, not its slab (r2/05; §06.4) and every other state is uncaptured. Aggregator PT tables are "materially disputed" and at least one widely-cited 2026 table reproduces a superseded structure (§20 V-09). Building on unverified aggregator PT data is a correctness risk, not a shortcut.

To make the fragmentation concrete — and to show exactly why we must treat aggregator tables as suspect — here is the *shape* of the divergence across five states. Rows marked [Verified] were read at the state's primary source (r2/10); every other rupee value is [Hypothesis] pending the gazette re-check (§06.4, §20 V-09).

| State | Slab base and top slab | Periodicity | Notable divergence | Status |
| --- | --- | --- | --- | --- |
| Maharashtra | Monthly salary, from 1 Apr 2023. Men: nil to ₹7,500; ₹175/mo to ₹10,000; above ₹10,000, ₹200/mo with **₹300 in February** (₹2,500/yr). Women: nil to ₹25,000, then the same split | Assigned per registration each financial year by the department — ingest, never derive (r1/06) | A gender-differentiated threshold and a February true-up; an aggregator's 2026 table omits the women's threshold (r1/06) | Slab [Verified — primary, r2/10]; periodicity mechanism [Verified — MAHAGST, r1/06] |
| Karnataka | Monthly salary: ₹200/mo at ₹25,000 or above, **₹300 in February** (₹2,500/yr); nil below — notification DPAL 08 SHASANA 2025, effective 1 Apr 2025 | Monthly Form 5A within 20 days of month-end, via e-PRERANA (r3/02) | At least one widely cited 2026 aggregator table still shows the pre-2023 three-band structure (r1/06) | Effect verified on the state PT portal, instrument text not retrieved (r2/10) [Verified]; return frequency parameter `pt.KA.return_frequency` |
| Odisha | **Annual** income: nil below ₹1.6 lakh; ₹125/mo to ₹3 lakh; above ₹3 lakh, ₹200/mo for 11 months and ₹300 in "the last month" | Annual, online only (r2/10) | The slab base differs *in kind* — annual income, not monthly salary; the true-up month is undefined | Slab [Verified — primary, r2/10]; true-up month [Hypothesis], `pt.OD.true_up_month` |
| Tamil Nadu (and Kerala) | Local-body schedules, not captured | Not captured | Levied by local bodies, not the state tax department | Levy structure [Verified, r2/10]; values [Hypothesis], `pt.TN.<local_body>.slabs` |
| Telangana, West Bengal and every other levying state | Not captured — `pt.<state>.slabs` | Not captured | Earlier drafts' slab figures for these states are carried, not re-captured, and not shipped (§06.4) | [Hypothesis] — Telangana verified to employer-registration wording only (r2/05) |

- LWF divergence is worse because it is smaller and less documented: LWF sits outside the four Labour Codes, no state's LWF rate or employer/employee split is verifiable from a government source (r2/10), and the only verified cadence is Karnataka's calendar-year remittance due 15 January (r2/10). Amounts, splits and periodicity (monthly, half-yearly or annual) differ by state and are parameters until V-09 lands. The absolute rupees are trivial; the *count of distinct rules to keep current* is the cost.

> [Hypothesis] The state-fragmentation load is a *moat if maintained, a liability if not*. Neither incumbent does this work today — Frappe HR's payroll model has no state dimension and TallyPrime makes the user hand-enter PT slabs and build LWF as a manual pay head (EV-031, EV-032) — which is where a maintained, remedy-capped compliance SLA (§19) earns its price.
> **Kill criterion:** if a rival ships a *contractually backed*, all-state PT/LWF update SLA before we do, the maintenance moat narrows to attended submission alone.

<!-- DIAGRAM: market-funnel -->

### 04.2 The denominator problem, and the one number that survives audit

Almost every published figure for "India HR tech market size" is unusable, and the PRD already killed the worst offenders. This section states the rule, then builds up from a government denominator.

#### Numbers that are banned as denominators

| Banned denominator | Size implied | Why it is wrong | Status |
| --- | --- | --- | --- |
| "$23.32bn → $38.36bn India HR tech" | ~₹2,20,000 Cr → ₹3,60,000 Cr | Almost certainly a *global* figure mislabelled as India; no attribution | [Killed] (§02, EV-K04) |
| "63 million MSMEs" / 5.31 crore Udyam registrations | ~5–6 crore "employers" | Udyam registrations are classified by investment and turnover, not headcount, are cumulative with no de-registration, and are not employers with payroll obligations (r2/09); 5.31 crore is ~69× the contributing base | [Killed] (§02 EV-K01, §20) |
| 24,18,266 EPFO *registered* establishments | ~24 lakh | Registered ≠ contributing; two-thirds of PF codes are dormant | [Killed as denominator] (§02) |

The pattern is consistent: every inflated number counts *entities that could theoretically owe payroll* rather than *entities that demonstrably run payroll now*. The correction is to use the one figure that reflects revealed obligation. This is not pedantry — a plan denominated on 5.31 crore and one denominated on 7.66 lakh differ by ~69×, and every downstream metric (share, penetration, CAC payback against TAM) inherits that error.

#### The audit-proof denominator: EPFO contributing establishments

| Metric | Value | Source | Status |
| --- | --- | --- | --- |
| EPFO **contributing** establishments (FY2023-24) | **7,66,254** | EPFO Annual Report 2023-24, as on 31.03.2024 (EV-001) | [Verified] |
| EPFO registered establishments (same date) | 24,18,266 | EPFO | [Verified] |
| Ratio registered : contributing | **3.16×** | Derived | [Verified] |
| Contributing members (active UANs) | 7.37 Cr (7,37,39,204) | EPFO AR 2023-24 | [Verified] |
| Mean contributing employees per contributing establishment | 96.2 | Derived (7.37 Cr ÷ 7.66 lakh) | [Verified, but see caution] |
| *Registered* establishments by cumulative accounts | 0–50: 19,43,910 · 51–100: 1,80,736 · 101–150: 76,944 · 151–200: 43,426 · **>200: 1,73,250** | EPFO AR 2023-24 Appendix-2(v) — registered universe, bands by cumulative accounts, not current employees (r2/09) | [Verified] |
| Contributing establishments with **>200** employees | 41,881 *modelled*; plausibly anywhere in 41,881–1,73,250 | Output of a one-moment Pareto fit to the two anchors above (r2/09) — **not** an EPFO table; we are not aware of any EPFO contributing-by-headcount crosstab as of September 2026 (r2/09 asks EPFO for one) | [Hypothesis — modelled] |

> **[Reversed]** v0.3 cited 41,881 as an EPFO Appendix-2(v) count and marked it [Verified]. It is a model output (r2/09); the only measured band table is the registered-by-accounts table above. Every figure below that uses 41,881 inherits the model's uncertainty.
>
> Caution on the mean. 96.2 is a **right-skewed average**, not a typical establishment. A small number of very large contributing establishments (those above 200 employees — 41,881 to 1,73,250 of them — and the tail above 2,000) pull the mean far above the median. The *typical* contributing establishment is much smaller than 96 people. Any per-establishment revenue model built on 96.2 as a "typical" seat count will overstate ARPU. Use the mean only for aggregate ceilings, never for per-account modelling.

**Standing denominator rule for this PRD:** every market size, share claim and funnel stage is denominated on **7,66,254 contributing establishments**, or a sub-band of it. Any figure denominated on registered establishments (24.18 lakh) or Udyam (5.31 crore) is retracted on sight.

One caveat the denominator itself carries, stated so it is not discovered later: EPFO contributing establishments **exclude** tiny employers below the EPF threshold that have not opted in yet still owe TDS/ESI/PT, and — we assume, because the evidence base does not say how the count treats them — establishments exempted from EPF that run their own trusts [Hypothesis]. Opting in is not rare: 2,29,403 establishments took voluntary EPF coverage under s.1(4) in FY2023-24, 77.8% of all new EPFO registrations that year, at only 0.85 accounts each (r2/05) — so some sub-20 establishments sit inside the EPFO universe, which is exactly why `beachhead_sub20_share` (§04.3) cannot be assumed to be zero. The denominator therefore slightly *understates* the count of entities with *some* statutory payroll obligation while being the honest ceiling for entities with the *full* obligation stack the product serves. We accept the understatement because it errs conservative — the opposite direction from every banned number.

##### Stress-test — what if the denominator itself moves?

The whole model rests on one [Verified] number (7,66,254). Discipline requires asking what happens if it is stale or mis-stated, because a data room will.

- **It is a point-in-time count (31.03.2024).** EPFO's 2024-25 Annual Report was not published when last checked (r2/09), so this is still the latest count. The contributing base grows with formalisation and net EPFO additions; by launch it is likely higher (the r2 model assumed a 6% annual roll-forward — an assumption, not a measurement). That moves SAM *up*, not down — so anchoring on the FY2023-24 figure is again the conservative choice. The kill risk is the reverse: a recession or mass EPF-exemption shift shrinking the contributing base, which would show up in the next EPFO Annual Report.
- **The exclusions are directional, not random.** Sub-20 TDS/ESI/PT-only employers (excluded) are precisely the <20 funnel band we serve free anyway (§01, §05.1); their absence from the denominator does not distort the *paid* beachhead. Exempted-trust establishments (if excluded) are assumed to skew large and enterprise — outside the beachhead [Hypothesis]. Both exclusions therefore fall mostly *outside* the 20–200 band, so the denominator is *more* accurate for the beachhead than for the whole market.
- **The refresh discipline:** re-pull the contributing count from each new EPFO Annual Report and restate every downstream figure; never let a 31.03.2024 number age silently into a 2027 deck. (Source: EPFO Annual Report series [Verified — cadence].)

> [Hypothesis] 7,66,254 is a stable-to-growing floor for the addressable base over the plan horizon.
> **Kill criterion:** if the next EPFO Annual Report shows the contributing base *falling* year-on-year, treat the market as contracting and re-test the entry thesis, not just the SAM arithmetic.

#### The share-ceiling calibration

greytHR — the HRMS-job incumbent (K-23) — currently claims **"30,000+ companies"** (captured September 2026, EV-091; earlier captures read 34,000, and its own About page says "around 20,000+ paying businesses in India and GCC countries" — r2/09). 30,000 is **≈3.9%** of the 7.66 lakh contributing establishments (derived; a marketing claim over a government count, not a measured share — and not all of greytHR's customers are EPF-contributing Indian establishments). **[Reversed]** v0.3's "34,000 customers = 4.4%" was a moved vendor number carried as [Verified] without a date. This is still the single most useful number for sanity-checking any SOM: *that is roughly the footprint of the vendor with the largest claimed customer count in the set (r2/09), on the honest denominator.* Any three-year plan that implies more than low-single-digit percentage penetration of contributing establishments is claiming to out-penetrate the HRMS-job incumbent from a standing start, and should be rejected.

A second calibration sits alongside it: greytHR's realised **~₹52 PEPM** (filed revenue ÷ claimed platform scale — EV-006 inputs, §18), which sits at its own published entry price of ₹49.90 PEPM at 50 employees (EV-027). Read together, the two numbers say the HRMS-job incumbent reaches roughly 4% of establishments at ~₹52/employee/month; its profitability is not public (r2/09), and its filed revenue includes GCC business, so its India-only revenue is lower by an undisclosed amount (r2/09). Any model that assumes both higher penetration *and* higher realised PEPM than greytHR is asserting we out-execute the HRMS-job incumbent on both axes simultaneously, from zero. That is the specific claim the sensitivity grid in §04.3 is built to discipline.

#### The market funnel, stage by stage

The market-funnel diagram narrows from the inflated denominators the industry quotes to the number a founder can actually act on. Each step is a deliberate exclusion with a reason, not a haircut.

| Stage | Count | What it is | Why we narrow here |
| --- | --- | --- | --- |
| Quoted "market" | 5.31 crore | Udyam MSME registrations | [Killed] — not employers with payroll obligations (§02) |
| Registered universe | 24,18,266 | EPFO-registered establishments | [Killed as denominator] — 3.16× the contributing base; two-thirds dormant |
| **Addressable universe (TAM)** | **7,66,254** | EPFO *contributing* establishments | [Verified] — revealed payroll obligation; the honest ceiling (EV-001) |
| Serviceable (SAM) | Up to ~7.24 lakh on the r2/09 fit; 1.8–2.6 lakh in the high-<20-share scenarios (§04.3) — plus a slice of the modelled 41,881–1,73,250 above 200 | 20–200 beachhead + near-in expansion | Obligation + budget + dissatisfaction overlap; product shape fits |
| Winnable in 3 yrs (SOM) | ~1,100–3,300 establishments at a 2.2-lakh scenario; ~3,600–10,900 at the fit's 7.24 lakh | 0.5–1.5% of the beachhead | Bounded by greytHR's ≈3.9% calibration (EV-091) and cold-start reality |

The funnel discipline is the section's core contribution: the difference between the top row (5.31 crore) and the SOM row (~2,200 establishments at the 1% midpoint of the 2.2-lakh scenario) is **more than four orders of magnitude** (~24,000×), and almost every published India-HR-tech number lives in the top two rows. Building a plan on 7,66,254 and narrowing transparently is what makes the SAM defensible in a data room.

#### Demand-side evidence of dissatisfaction

"Dissatisfaction" is the softest leg of the obligation-budget-dissatisfaction stool, so it needs its own evidence rather than assertion.

- **Support responsiveness and implementation friction recur as the leading churn themes in sampled negative reviews** — ahead of missing features (r1/01, r1/07; a qualitative reading of the negative tail, not a measured frequency — aggregate ratings for every vendor are good, r1/07; §20 R-28). Switching friction concentrates at **mid-year cutover** (r1/00) — opening balances, YTD earnings, TDS already deducted, previous-employer income, investment declarations mid-cycle, certificate continuity across two systems, EPF UAN and ESI IP continuity, leave balances, gratuity accrual. The pain of *switching* is itself evidence that the installed base is unhappy but stuck. It also cuts the other way for us: the same friction is a moat *once we hold the record*, which is why migration is a product surface, not a services task (§16.7).
- **The incumbents' own limits create dissatisfaction.** TallyPrime generates the statutory artefacts but has no state PT slab table, no LWF engine and no leave module, and cannot calculate leave encashment; attendance is manual vouchers (EV-032); its cloud option is a hosted virtual desktop (r3/01). Kredily and Zoho give away computation and charge for outputs — bank payout files, PF/ESI challans, the annual tax certificate, Form 124 (ex-12BB) (EV-029). The employer who "has software" still hits a wall at the exact moment of filing.
- **The bureau black box (Pain 3) is dissatisfaction by another name** — no filing-status visibility, single-person key risk, and the employer carrying liability for the CA's errors.

> [Hypothesis] Dissatisfaction is real but its *magnitude and willingness-to-switch* are unmeasured — no NPS, churn-rate or win/loss data exists in the corpus.
> **Kill criterion:** buyer interviews (§20 V-01–V-03, V-05). If beachhead employers report high satisfaction with the Tally-plus-CA status quo and low switching intent, the wedge is weaker than the burden analysis implies, and acquisition CAC assumptions must rise.

##### Acceptance criteria — the denominator discipline

- **AC-10 (single denominator).** Every share, penetration and SAM figure in any downstream deck resolves to 7,66,254 (or a named sub-band); a reviewer can trace it in one step. Any figure that cannot is retracted.
- **AC-11 (no skew laundering).** No per-account revenue figure multiplies by 96.2; the mean is used only for aggregate ceilings, flagged as such.
- **AC-12 (band resolution gate).** Before any funding model hardens, the 20–200 contributing-establishment count — and with it `beachhead_sub20_share` (§04.3) — is resolved from a measured source, replacing the scenario range. EPFO's published Appendix-2(v) cannot do this alone (registered universe, cumulative-accounts bands — r2/09); the method is a §20 desk-validation item.

### 04.3 TAM / SAM / SOM on the honest denominator

We size the market two ways and reconcile them: **top-down by establishment count × realised ARPU** (a full-penetration potential), and **bottom-up from filed vendor revenue** (what is paid today). They answer different questions, so they need not match — but the gap between them must be explained, and the explanation named as a validation item.

#### Establishment counts by band

The beachhead is 20–200. Only one end is measured: EPF turns on at 20 (EV-057). The above-200 count is modelled, and we are not aware of any EPFO contributing-by-current-headcount band table as of September 2026 — Appendix-2(v) counts *registered* establishments by *cumulative accounts* (§04.2) — so the interior split is one model plus one unmeasured parameter.

| Band (contributing employees) | Contributing establishments | Basis | Status |
| --- | --- | --- | --- |
| Total contributing (all sizes) | 7,66,254 | EPFO 31.03.2024 (EV-001) | [Verified] |
| > 200 (expansion + enterprise) | 41,881 modelled (41,881–1,73,250 plausible) | Pareto fit (r2/09); upper end is the registered >200-accounts count | [Hypothesis — modelled] |
| 20–49 on the fit | 5,25,246 (1.58 Cr members) | One-moment Pareto fit, x_min = 20, α = 1.2624 (r2/09) | [Hypothesis — low confidence] |
| 50–199 on the fit | 1,99,127 (1.77 Cr members) | Same fit | [Hypothesis — low confidence] |
| **20–200 (beachhead)** | **7,24,373 × (1 − `beachhead_sub20_share`)**, less any above-200 excess over 41,881 | Fit residual (7,66,254 − 41,881), adjusted by the unmeasured parameter | **[Hypothesis]** |
| < 20 (funnel/acquisition only) | 7,24,373 × `beachhead_sub20_share` | Not published anywhere in the evidence base | Unknown — §20 |

> Note on the beachhead count. The fit is pinned by one moment (the 96.2 mean) and its family was chosen by assertion; a lognormal alternative fits the same anchors and disagrees ~2× on the 200–999 band (r2/09). By construction it puts **no** contributing establishment below 20, so it overstates the beachhead to whatever extent sub-20 establishments contribute. That share is the named parameter `beachhead_sub20_share` — value unknown, routed to §20 (AC-12). §05 uses the fit's 7.24 lakh residual; this section carries it as the upper case.
> **[Reversed]** v0.3 modelled the beachhead at **1.8–2.6 lakh** from an assumed ~65% sub-20 share (with 22/8/5% for 20–50/50–100/100–200) that no source supported, and argued that right skew implied a large sub-20 share. Right skew lowers the median; it does not by itself put establishments below 20 — the fitted distribution is right-skewed with none below 20. The 1.8–2.6 lakh figures survive only as scenarios, corresponding to a `beachhead_sub20_share` of ~64–75% (derived: 1 − 2.6/7.24 and 1 − 1.8/7.24).
> **Kill criterion:** if a measured source (AC-12) puts the 20–200 band below ~1.5 lakh contributing establishments, SAM falls below every grid row and the "expansion into 200–2,000" phase must be pulled forward; if it lands near the fit, the beachhead is ~3× the 2.2-lakh scenario and the §04.3 SOM grid scales with it.

**Sensitivity, stated so the parameter can be attacked.** Each 10 points of `beachhead_sub20_share` moves the beachhead by ~72,400 establishments (10% of 7,24,373). The fit's own mean in 20–199 is ~46 employees (3.34 Cr members ÷ 7.24 lakh), below the 55 billable seats this section assumes (V-03). No funding model hardens on either figure — only on a measured count.

#### Top-down market model

We use **realised** PEPM where it exists and list price only as a bound. List prices give **two anchors** (K-09, EV-027): a **value floor near ₹50 PEPM** (Qandle ₹49.00 on annual billing, greytHR ₹49.90, at 50 employees) and a **mid-market clearing band of ₹80–200 PEPM** (Zimyo ₹80.00, HROne ₹99.00, Keka ₹139.98 at its ₹6,999 floor or ₹199.98 on the archived card). The two realised points that survived audit — **₹52** (greytHR, SMB-weighted) and **₹126** (PeopleStrong, enterprise-weighted) — derive from filed revenue over claimed platform scale and are biased *downward* because platform users exceed billed seats (EV-006, §18); they sit on the floor and inside the band respectively. For the beachhead we model **₹80–150 PEPM** as a [Hypothesis] band inside the clearing band — above the floor because our thesis is that portal-accepted artefacts plus attended submission command more than commodity SMB HR — and it is a modelling band, not a price ceiling (§18).

Per-account revenue requires a *billable* seat count, not the skewed mean. We model the beachhead average billable headcount at **~55 employees** (the segment centre of mass — 50–200 "carry revenue" per §05.1, blended with the 20–50 tail) [Hypothesis, V-03]; the r2/09 fit's own mean in 20–199 is ~46. Because we bill actual headcount with no seat floor (§18), billable seats equal employees — unlike the six priced competitors, every one of which bills a 50-employee minimum block (EV-026).

| Layer | Definition | Establishments | Avg billable seats | PEPM | Annual value | Status |
| --- | --- | --- | --- | --- | --- | --- |
| **TAM** | All contributing establishments as a software-addressable universe | 7,66,254 | 96.2 (mean, aggregate only) | ₹80–150 | see reconciliation below | [Hypothesis] |
| **SAM** | Beachhead 20–200 (the 200–2,000 expansion slice is excluded from the value) | 1.8–7.24 lakh across the `beachhead_sub20_share` scenarios | ~55 (fit row: ~46) | ₹80–150 | **₹950 Cr – ₹6,018 Cr** | [Hypothesis] |
| **SOM (3-yr)** | Realistic capture at sub-leadership share | 0.5–1.5% of beachhead | ~55 | ₹80–150 | **₹5.8 Cr – ₹32.7 Cr ARR** at the 2.2-lakh scenario; scales with the count | [Hypothesis] |

SAM worked example (2.2-lakh scenario, midpoints): 2.2 lakh establishments × 55 seats × ₹115 PEPM × 12 = **₹1,670 Cr/yr** addressable in the 20–200 band alone. On the r2/09 fit (3.34 Cr members in 20–199) the same ₹115 gives **₹4,614 Cr/yr**. The 200+ slice is excluded from both.

SOM worked example (3-yr): at **1.0%** of a 2.2-lakh beachhead = 2,200 paying establishments × 55 seats × ₹115 × 12 = **₹16.7 Cr ARR**. greytHR's ≈3.9% calibration (EV-091) implies an upper bound near **₹65 Cr ARR** on that beachhead (≈8,600 establishments) — reachable only at multi-year leadership, not in three years from zero; on the fit the bound scales with the count.

#### Bottom-up reconciliation (the reality check)

The top-down SAM is a full-penetration potential; observed spend is what the market pays today. They need not match — they must be *explained* together.

- **Filed revenue across 11 Indian HRMS entities: ₹1,374 Cr** [Verified] (the scoreboard in §04.4). Grossed up on the assumption that those eleven are 35–65% of India HRMS software spend (r2/09) → **₹2,100–3,900 Cr** real annual India HRMS software spend (USD 0.22–0.41bn at ₹94.43/USD, EV-089) — [Verified inputs + modelled gross-up] (EV-005). The share band is the weak link: the filed base itself contains non-India revenue (Darwinbox's standalone figure, greytHR's GCC business), which pulls one way, while unfiled and foreign vendors (SAP SuccessFactors, Oracle, Workday, Zoho People, MYND after Qandle) are unmeasured and pull the other (r2/09).
- **Implied spend per contributing member:** ₹2,100–3,900 Cr ÷ 7.37 Cr members ÷ 12 = **₹23.7–44.1 per member-month** — below every entry-tier list price at 50 employees (₹49.00–199.98, EV-027). (r5's synthesis and CFO review quote ₹2.4–4.4; that is a tenfold arithmetic slip.)
- **Two readings, both stated.** *Penetration:* at list, observed spend pays for software for roughly 12–55% of contributing members at the ₹80–200 clearing band (up to ~90% only if every member paid the ~₹49 floor) — the rest are on Tally, spreadsheets or a bureau. *Discounting:* if most members were already on paid software, realised price would be ₹24–44 PEPM, below every list card. greytHR's realised ~₹52 sits at its own ₹49.90 list (EV-006, EV-027), which argues against deep discounting at the SMB end and leans toward penetration — but one vendor is not the market. **Validation:** §20 V-02 (status-quo distribution) settles penetration; §20 V-03 (realised ARPU vs list) settles discounting.
- **Corrected CAGR ceiling: ₹10,905 Cr at 10% CAGR** (not ₹12,250 Cr — overstated 12.3%, [Killed], EV-K11). This is the upper sensitivity of a *modelled* whole-market ceiling, not a target: the same Pareto model gives ₹9,013 Cr at 0% and ₹10,126 Cr in its 6% central case, and a lognormal alternative gives ₹8,861 Cr (r2/09). The two-year roll-forward exists only because EPFO's 2024-25 Annual Report is unpublished (r2/09).

**[Reversed]** v0.3 argued that a SAM above observed spend would be "self-refuting" and that the SAM midpoint landing at ~43–80% of spend proved the model internally consistent. A full-penetration SAM can legitimately exceed current spend; the integrity check is the penetration × realised-price identity above, not a ratio of potential to actual.

#### SAM/SOM sensitivity — the model is a range, so show the range

Because the beachhead establishment count (`beachhead_sub20_share`) and realised PEPM are both unvalidated, the responsible presentation is a grid, not a headline. SOM ARR = (beachhead establishments) × (share) × (avg billable seats, held at 55) × (PEPM) × 12.

**Beachhead SAM (₹ Cr/yr) at full penetration — establishment count × PEPM (55 seats; the last row uses the fit's own member count):**

| Establishments ↓ / PEPM → | ₹80 | ₹115 | ₹150 |
| --- | --- | --- | --- |
| 1.8 lakh (sub-20 share ~75%) | ₹950 Cr | ₹1,366 Cr | ₹1,782 Cr |
| 2.2 lakh (~70%) | ₹1,162 Cr | ₹1,670 Cr | ₹2,178 Cr |
| 2.6 lakh (~64%) | ₹1,373 Cr | ₹1,973 Cr | ₹2,574 Cr |
| 7.24 lakh — r2/09 fit (0%; 3.34 Cr members) | ₹3,210 Cr | ₹4,614 Cr | ₹6,018 Cr |

**3-year SOM (₹ Cr ARR) at the 2.2-lakh scenario — share × PEPM (55 seats); on the fit, multiply by ~3.3 at 55 seats or ~2.8 on its own member count:**

| Share ↓ / PEPM → | ₹80 | ₹115 | ₹150 |
| --- | --- | --- | --- |
| 0.5% | ₹5.8 Cr | ₹8.3 Cr | ₹10.9 Cr |
| 1.0% | ₹11.6 Cr | ₹16.7 Cr | ₹21.8 Cr |
| 1.5% | ₹17.4 Cr | ₹25.0 Cr | ₹32.7 Cr |

Reading the grids: even the optimistic corner of a 3-yr SOM at the 2.2-lakh scenario (1.5% share, ₹150 PEPM) is **₹32.7 Cr ARR** — about half the ~₹65 Cr greytHR-calibrated bound and inside "credible for a well-executed new entrant." The pessimistic corner (0.5% share, ₹80 PEPM) is **₹5.8 Cr ARR** — survivable but thin. The spread between corners is ~5.6×, driven by the two unvalidated inputs the SOM grid varies (share and PEPM); the beachhead count is a third (AC-12), held at 2.2 lakh in that grid for legibility and worth up to ~3.3× on its own. That is the quantified reason the §20 validation programme gates funding: the model's uncertainty is not noise, it is a short list of specific studies wide.

A further variable — average billable seats, held at 55 throughout — is worth a sensitivity note even though we do not grid it. If the realised beachhead average is 40 (heavier 20–50 weighting) rather than 55, every ARR figure above scales by 40/55 ≈ 0.73×; the 1.0%/₹115 midpoint drops from ₹16.7 Cr to ~₹12.1 Cr. If it is 70 (heavier 100–200 weighting), the midpoint rises to ~₹21.2 Cr. Seat count is its own study (won-deal seat sizes, §20 V-03; the fit's mean is ~46) that the grid holds constant only for legibility.

> Why TAM is expressed as a range, not a point. Multiplying 7.66 lakh × 96.2 × ₹115 × 12 yields ~₹10,170 Cr. The product 7.66 lakh × 96.2 is simply the 7.37 crore contributing members — a legitimate aggregate — but the figure assumes every one of them is on paid software at a mid-band price, while observed spend implies ₹23.7–44.1 per member-month (above). It is arithmetically adjacent to the ₹10,126 Cr central and ₹10,905 Cr upper *modelled ceilings* and would be easy to launder into a deck. **Do not.** The honest TAM statement is: *current revealed spend ₹2,100–3,900 Cr (EV-005), modelled whole-market ceiling ₹9,013–10,905 Cr (0–10% roll-forward, ₹10,126 Cr central — r2/09), beachhead SAM ₹950–6,018 Cr across the `beachhead_sub20_share` scenarios.*

<!-- DIAGRAM: tam-sam-som -->

#### The bureau/CA spend pool (the displaceable adjacency)

Separate from software spend is the money paid to bureaus and CAs — the budget line the product actually displaces at the point of sale.

- Published anchor: indicative **₹3,000–15,000/month** per employer across the 11–100-employee bands (IndiaFilings, r2/05); the realised price is unvalidated (§20 V-01).
- Illustrative pool: 2.2 lakh beachhead establishments × an assumed ₹6,000/month × 12 = **~₹1,580 Cr/yr** [Hypothesis]. ₹6,000 is a point inside the published range, not a measured median (the median is unknown — V-01), and the figure assumes *every* beachhead employer uses a bureau; scale it by the bureau-usage share (V-02) and by the beachhead count (AC-12).
- This pool is *not additive* to the software SAM in a naive way — winning a customer often means **converting bureau spend into software spend** (the CA becomes a channel or a displaced incumbent, §18.7). It is best read as evidence that the willingness-to-pay exists and is already being spent monthly.

The strategic read: the bureau pool (~₹1,580 Cr [Hypothesis]) and the beachhead software SAM (~₹1,670 Cr), both at the 2.2-lakh scenario, are the *same order of magnitude*, which is the point. The buyer is already spending PEPM-equivalent money — just to a person, not a platform. The product does not need to create budget; it needs to redirect an existing monthly line item and give the buyer visibility the retainer never did. That is a fundamentally easier sale than "adopt a new cost category," and it is why the bureau is a price anchor rather than a competitor (§18.1).

> [Hypothesis] The bureau pool is anchored on one provider's published indicative price *range* but an unverified *volume* (how many beachhead employers use a bureau vs. Tally-plus-in-house vs. a rival SaaS).
> **Kill criterion:** the same mystery-shop + Tally-payroll-adoption study (§20 V-01, V-02). If bureau usage in the beachhead is below ~30%, the "displace the bureau" wedge weakens relative to "displace Tally/spreadsheet."

### 04.4 Competitive landscape

The competitive question is not "who is biggest" — it is **where does a filing-first entrant have room**. That requires separating the field by *what they actually do at the price the beachhead pays*, and by *which segment they defend*. §21 holds the full parity tables and capture log; this section keeps only what the sizing and the wedge depend on. Unless stated otherwise, competitor facts below were captured from vendor pages, product documentation, source code or filed accounts in September 2026 (Keka's withdrawn card is a dated archive, EV-022); **no competitor product was executed** — every capability statement is read, not tested.

#### The field, grouped by threat type

| Group | Players | What they are | Threat to the beachhead |
| --- | --- | --- | --- |
| **Two incumbents, two jobs (K-23)** | TallyPrime; greytHR | Tally ships the statutory artefacts — PF Forms 3A/5/6A/10/12A + ECR, ESI 3/5/6, PT statement, Form 16, 24Q annexures, 12BA, 27A — but no state PT slab table, no LWF engine and no leave module; payroll comes inside the licence (Silver single-PC; multi-user at Gold, 3× the price) (EV-032). greytHR claims 30,000+ companies (EV-091), publishes a full card (Essential ₹2,495/month including 50 employees + ₹45 per additional — EV-027, r5/03) and uses generation-only statutory language (EV-030). | **Highest.** Tally holds the accounting relationship and the artefacts, but its payroll *adoption* is unknown (V-02); greytHR holds the HRMS job at the value floor. Beaten on multi-state PT/LWF (Tally), no seat floor (greytHR, EV-026) and attended submission (both) — not on computation. |
| **Zero-priced computation** | Kredily; Zoho Payroll (₹0 to 10 emp), Zoho People (₹0 to 5 users, Zia AI at ₹48); Frappe HR (OSS) | Kredily and Zoho give away computation and charge for outputs — bank payout files, PF/ESI challans, the annual tax certificate, Form 124 (ex-12BB) (EV-029). Frappe HR v16 has strong gross-to-net, arrears, leave and a PWA, but no Indian statutory artefact and no state dimension (EV-031). | **High and structural.** Sets the price of computation at zero. Assume Zoho widens its free gates from 10 toward 25/50 (§18; §20 R-1). Investment-declaration + bank payouts, once our "P0 differentiator," are table stakes here [Killed as differentiator]. Against Frappe the bake-off will not be won on gross-to-net (EV-031). |
| **The priced mid-market set** | Qandle (MYND since April 2025 — EV-034), Pocket HRMS, Zimyo, HROne, Keka; also factoHR, RazorpayX Payroll | Entry-tier PEPM at 50 employees from ₹49.00 (Qandle, annual) to ₹139.98–199.98 (Keka); all six priced vendors, greytHR included, bill a 50-employee minimum block (Keka's historical block: 100) (EV-026, EV-027). Payroll sits in every entry tier (EV-028). | **High.** The 50–200 sub-band is served cheaply; the 20–50 sub-band pays for 50 seats — ₹122.50–349.95 effective PEPM at 20 employees (EV-027). Keka suppresses its live card (EV-021, EV-024). None claims to submit a filing (EV-030). |
| **Enterprise suites and adjacency** | Darwinbox, PeopleStrong; ZingHR and Ramco as enterprise adjacency (EV-033) | Full-suite, sales-led, enterprise procurement. ZingHR and Ramco publish no price and are kept out of the competitive set (EV-033). | **Low at launch, rising on expansion.** PeopleStrong ₹301.99 Cr FY25, valued ₹1,200 Cr (4.0× revenue — the only recoverable India HRMS multiple, r2/09). Enterprise is arithmetically closed for ~3 years (§01, §05.2). |
| **Not competitors (channel / anchor / adjacency)** | CAs & payroll bureaus; eSSL/ZKTeco device vendors; Aparajitha/Simpliance | Bureaus = channel + price anchor. Device vendors = partners (eSSL markets integration with 6 HRMS vendors). Aparajitha = a large statutory dataset, consolidated with Simpliance (76% acquired at an enterprise value of ₹120 crore — r2/07); no AI/ML claim found on its own surfaces (r2/00). | Not to be displaced; to be integrated or partnered with (§09.3, §16.4, §18.7). |

#### Filed-revenue scoreboard (the only honest scale metric)

Analyst rankings are unusable; filed accounts are not. These are the eleven filed HRMS entities behind the ₹1,374 Cr aggregate (EV-005), ordered by revenue, plus Ramco as a calibration row outside the sum. Revenue is operating revenue as filed; growth is year-on-year; "not published" means no figure is available from a source the research accepted — free ratio panels were excluded as unreliable for this set (r2/09).

| Vendor (entity) | Latest filed revenue | Profitability | Position vs. our beachhead |
| --- | --- | --- | --- |
| Darwinbox (Darwinbox Digital Solutions Pvt Ltd) | ₹533.87 Cr FY25, standalone; growth reported as +36% or +50% by two sources reading the same filing — an FY24 base-year discrepancy (r2/09) | Statutory net result not disclosed; only adjusted figures published (r2/09) | Enterprise, sales-led; share of revenue from India not disclosed |
| PeopleStrong | ₹301.99 Cr FY25 (+10%) | Not published — a free ratio panel indicates a loss, direction only (r2/09); majority stake acquired at ~₹1,200 Cr, 4.0× revenue (r2/09) | Above us — enterprise/mid-market |
| ZingHR | ₹150 Cr FY25 (+21%) | +₹1 Cr (0.80% EBITDA) — the only fully published FY25 P&L in the set (r2/09) | Enterprise adjacency, outside the competitive set (EV-033) |
| Keka | ₹133.86 Cr FY25 (+55%) | −₹80 Cr on ₹78 Cr FY24 revenue; staff cost 137% of FY24 revenue; FY25 result not published (r2/09) | In our beachhead at the top of the price range (EV-027) |
| greytHR (Greytip Software Pvt Ltd) | ₹125.22 Cr FY25 (+29%); includes GCC revenue (r2/09) | Not published (r2/09) | The HRMS-job incumbent (K-23) at the value floor (EV-027) |
| HROne (Uneecops Workplace Solutions Pvt Ltd) | ₹46.67 Cr FY25 (+50%) | Not published (r2/09) | Priced mid-market set (EV-027) |
| Akrivia | ₹30.67 Cr FY24 (+20%); FY25 not yet filed (r2/09) | Not published | Mid-market |
| factoHR (Version Systems Pvt Ltd) | ₹25.76 Cr FY25 (+12%) | Not published | Beachhead-adjacent |
| Pocket HRMS (Sage Software Solutions Pvt Ltd) | ₹12.84 Cr FY25 (−25%); the entity also distributes Sage ERP, so the figure is not Pocket HRMS alone (r2/09) | Not published | Priced mid-market set (EV-027) |
| Zimyo | ₹9.42 Cr FY25 (+52%) | Not published | Priced mid-market set (EV-027) |
| Kredily (PeopleProsper Technologies Pvt Ltd) | ₹3.82 Cr FY25 (+38%) | Not published | Zero-priced computation (EV-029) |
| **Sum of the eleven** | **₹1,374.12 Cr** | — | The verified floor of EV-005's ₹2,100–3,900 Cr gross-up |
| Ramco (calibration row, not in the sum) | HR & Payroll BU ₹297.6 Cr FY2025-26 (+30.8%), consolidated across geographies; India revenue across *all* BUs ₹133.0 Cr; standalone Indian entity's India geography ₹112.8 Cr (EV-033, EV-092) | Single Ind AS 108 segment — India HR revenue is not separable; it is bounded above by ₹133.0 Cr (tighter: ₹112.8 Cr) | Enterprise adjacency, outside the competitive set (EV-033) |

(Source: MCA/ROC filings — the EV-005 inputs (§02), entity-level detail per r2/09; Ramco from its audited FY2025-26 annual report (r5/03, EV-092). All revenue figures [Verified]; Ramco's rupee-crore figures are conversions of its reported ₹ Mn. The ordering is by filed revenue, which is not India-only revenue for Darwinbox, greytHR or Ramco.)

Two reads: (1) **profitability is mostly not public** — only ZingHR has a fully published FY25 P&L (₹1 Cr profit on ₹150 Cr); Keka reported an ₹80 Cr loss in FY24 and 55% revenue growth in FY25, with its FY25 result unpublished; Darwinbox publishes only adjusted figures; for most of the set no profit figure exists (r2/09). (2) **Keka's pricing is no longer a gap**: its live card is suppressed but the rates were recovered by raw-HTML fetch (EV-021–025) — the v0.3 "TLS-blocked, unverified" status is [Reversed]. The HRMS-job incumbent is greytHR, not Keka (K-23), even though Keka's filed revenue is slightly higher: the incumbency is about customer count and the value-floor price, not revenue rank.

A third read that changes strategy: the cost that decides margin here is not feature velocity but keeping state PT/LWF, the ECR and Form 138 current — work neither incumbent does (EV-031, EV-032) and which the compliance data pipeline (§22) and the supervised-filing cost line (EV-088, §13) must size. Keka's FY24 staff cost (137% of revenue) is one company's figure, not a market norm. The scoreboard supports competing on **maintained rules and attended submission**, not on out-spending anyone on features.

#### Beachhead rival profiles — the direct dogfight

The priced vendors built for 20–500 are where deals are won and lost. What is known, and what is not (captures September 2026 unless dated otherwise; pages read, products not executed):

- **greytHR** — the HRMS-job incumbent (K-23). Claims 30,000+ companies (EV-091; ≈3.9% of contributing establishments), realised PEPM anchor ~₹52 (biased low), publishes a full card — Essential ₹2,495/month including 50 employees + ₹45 per additional (EV-027) — and prices Recruit at ₹2,500 per recruiter and GPS live-tracking at ₹140/user/month vs. the ₹45 marginal seat rate (3.1× — a signal that location and recruiting are monetisable separately; add-on prices per r2/05, r5/03). Its statutory language is generation-only — ECR generation, challans, 24Q generation with FVU validation, Form 16 generation; no submission claim (EV-030). NAVOS assistant launched 3 Jun 2026 and is "included in every plan" — claim posture, not tested (EV-090) — a data point in the "HR AI price is zero" set (§13.1). The one to benchmark artefact breadth and price-card transparency against.
- **Keka** — ₹133.86 Cr FY25 (+55%); ₹80 Cr loss on ₹78 Cr FY24 revenue (r2/09). Pricing captured 5 Sep 2026 by raw-HTML fetch: no live prices on its pricing page; three commented-out spans of ₹90 / ₹120 / ₹150 per additional employee (EV-021); the withdrawn card of ₹9,999 / ₹12,999 / ₹15,999 per month up to 100 employees (EV-022); a live small-companies floor "from ₹6,999 per month" / "starts at ₹90 per employee/month" (EV-023). The suppression is global — US and UAE pages use the same mechanism (EV-024). Two live pages contradict each other on setup fees, and ToS clause 15 says renewal fees are "subject to an increase" (EV-025). Keka AI is waitlisted; its published AI governance commitments (citation on every answer, no silent writes, RBAC on every AI call, no training of external models on customer data) and "Keka MCP Server" are table stakes to match (EV-090). **[Reversed]** v0.3's "INR tiers TLS-blocked and unverified — treat every Keka pricing claim as provisional".
- **factoHR (Version Systems Pvt Ltd)** — ₹25.76 Cr FY25 (+12%), payroll-led, with a retirement-benefit administration heritage (PF, gratuity, superannuation trusts) and self-described AI positioning, unverified (r2/09). Publishes an INR ladder — free for up to 20 employees; Core ₹4,999, Premium ₹5,999 and Ultimate ₹6,999 per month each including 50 employees, plus ₹69 / ₹89 / ₹119 per additional employee (captured September 2026, r1/01) — so it sits outside the EV-026 six-vendor set but shows the same 50-employee block shape above its free tier. A feature-and-price comparator.
- **Qandle (MYND) / Pocket HRMS / Zimyo / HROne** — published cards, all on 50-employee minimum blocks: at 20 employees ₹2,450/month (Qandle, annual billing) to ₹4,950/month (HROne) (EV-026, EV-027). Qandle has sat inside the MYND payroll-outsourcing group since April 2025 (EV-034). **[Reversed]** v0.3's "unswept, TLS-blocked tier".
- **RazorpayX Payroll / HivePayroll** — RazorpayX: ₹2,499/month for up to 20 employees (captured September 2026, r1/01); it carries a fintech parent (bank-payout distribution motive) — watch for the Jupiter/sumHR-style zero-pricing move (§20 R-6). RazorpayX's next tier is ₹5,499/month for 50 employees with a 100-employee ceiling and ₹150 per additional employee (r1/01). HivePayroll: Standard ₹1,499, Premium ₹2,499 and Ultimate ₹3,999 per month, each up to 25 employees, plus ₹35 / ₹55 / ₹95 per additional; no permanent free tier (verified against the vendor's page, r2/05). **[Reversed]** an earlier draft's withdrawal of the ₹1,499 figure — it is primary-verified in r2/05.

##### What each rival cannot do (the wedge, per competitor)

Positioning is only real if it names, per competitor, the thing they structurally do not do. This is the per-rival version of the whitespace claim:

| Rival | Does well | Structurally does not do | Our wedge against them |
| --- | --- | --- | --- |
| TallyPrime | Ships the statutory artefacts (PF/ECR, ESI, PT statement, Form 16, 24Q annexures, 12BA, 27A) inside the licence; granular multi-user permissions (EV-032, r3/01) | No state PT slab table, no LWF engine, no leave module, no leave-encashment calculation; attendance by manual vouchers (EV-032); submission stays with the employer or CA. ESS status unresolved — assert nothing | Multi-state PT/LWF, leave-to-payroll, attended submission (§21) |
| Kredily | Free computation, unlimited headcount | Outputs are charged — challans, payout files, the annual tax certificate, Form 124 (ex-12BB) (EV-029) | The output and submission layer |
| Frappe HR | OSS; strong gross-to-net, arrears, leave, PWA (EV-031, r3/01) | Any Indian statutory artefact: no state dimension, no ECR/ESI, no PT slabs, no LWF, no 24Q/138, Form 16/130, 12BA or 27A (EV-031) | The statutory layer — **not** gross-to-net, where the bake-off will not be won (EV-031) |
| Zoho | Self-serve, size-gated free tiers | Outputs charged (EV-029); otherwise nothing structural on computation — **parity, not advantage** | Honest answer: none on computation; compete on outputs, attended submission and the CA channel |
| Keka | Broad suite; published AI governance commitments (EV-090) | Live price card suppressed (EV-021, EV-024); AI waitlisted (EV-090); bills a block, historically 100 employees (EV-026) | Published per-head card with no seat floor (§18); attended submission |
| Enterprise suites | Full-suite, enterprise procurement | Beachhead price/shape; self-serve | Segment fit — but deferred, not fought (§01, §05.2) |

The honest line the PRD requires us to hold: the wedge is specific per incumbent — multi-state PT/LWF, leave and attended submission against Tally (EV-032); the whole Indian statutory layer against Frappe (EV-031); the output and submission layer against Kredily and Zoho (EV-029); on computation it is **parity, not advantage**. Any collateral claiming feature advantage against Zoho, or gross-to-net advantage against Frappe, is falsifiable in a bake-off and must not ship.

#### Where obligation + budget + dissatisfaction overlap

The beachhead thesis is a claim about an intersection, not a segment size. Mapping it:

| Segment | Obligation? | Budget? | Dissatisfaction / whitespace? | Verdict |
| --- | --- | --- | --- | --- |
| < 10 employees | Light (TDS, S&E, and a POSH Internal Committee from employee one — EV-056) | ~₹0 marginal | Served free (Kredily; Zoho to 10) or inside an existing Tally licence | No overlap — decline commercially |
| 10–20 | Real (ESI, gratuity, appointment letter at 10 — EV-057) | ₹0 for computation (Kredily free at any headcount; Zoho Payroll free to 10; factoHR free to 20 — r2/05, r1/01); outputs cost ₹12,000/yr at Zoho Standard (₹1,000/month on annual billing, 25 included) or ~₹15,000/yr at Kredily Payroll OS (₹1,249/month, up to 25) — r2/05; ₹29,400+ at every priced vendor's 50-seat floor (EV-026, EV-027) | Free tiers cover computation; outputs charged (EV-029) | Partial — acquisition funnel only |
| **20–200** | **Strong (EPF at 20; step function stacks)** | **Indicative ₹3k–15k/mo bureau line (V-01)** | **20–50 structurally overcharged by seat floors (EV-026); 50–200 over-served by cheap product; nobody in the priced set claims to submit (EV-030)** | **Full overlap — beachhead** |
| 200–2,000 | Strong (canteen 100; standing orders and retrenchment approval 300 — EV-057) | Larger, but sales-led | Suites present; migration friction real | Overlap exists — expansion, not launch |
| 2,000+ | Strong | Large | Incumbency-locked (SBI/Indian Bank RFP arithmetic) | Overlap blocked by procurement — defer |

The honest version of the wedge (§01): the 20–200 band is **not a competitive vacuum** — Zoho Payroll serves 25 employees for ₹1,000/month on annual billing (r2/05), HivePayroll 25 for ₹1,499 (r2/05), RazorpayX up to 20 for ₹2,499 (r1/01), factoHR is free up to 20 (r1/01), Kredily computes free, and six priced vendors sell 50-seat blocks (EV-026). The 20–50 sub-band is **structurally overcharged** by those floors (₹122.50–349.95 effective PEPM at 20 employees — EV-027), and the whole band is **under-served by product that carries the filing through to portal acceptance**: portal-accepted artefacts plus attended, assisted submission under the employer's written authority (K-13; legality of acting on portals under employer credentials is under counsel review — §23), a maintained compliance SLA with a remedy cap (§19) and a CA-facing console. The employer's statutory liability stays non-delegable throughout. That moves the wedge from *availability* (false) to *quality-of-delivery* (true and harder); the per-incumbent differentiation is in the table above.

#### The whitespace, stated as a position not a vacuum

The competitive-map diagram places the field on two axes that the beachhead buyer actually feels: **how far the product carries the filing** (computes only → generates portal-ready artefacts → attended submission under written authority, with a remedy-capped SLA) against **evaluability by a 30-person buyer** (sales-led/opaque → self-serve with a published INR price card). Reading the field on those axes rather than on "features" is what makes the whitespace legible:

| Position | Who sits here | Why it is not where we win / lose |
| --- | --- | --- |
| Computes + self-serve, outputs charged | Kredily, Zoho (EV-029); Frappe HR, OSS with no Indian statutory artefact (EV-031) | The crowded floor. Statutory *computation* is table stakes here and priced at zero. Not a moat. |
| Generates artefacts + published price | greytHR, Qandle, Pocket HRMS, Zimyo, HROne (EV-027); TallyPrime (artefacts in the licence, EV-032) | Generation only — none claims to submit (EV-030) — and every priced SaaS card carries a 50-seat floor (EV-026). |
| Generates artefacts + sales-qualified | Keka — live card suppressed (EV-021, EV-024); enterprise suites, whose filing scope is not in the evidence base | Opaque to a buyer who will not sit through a demo (AC-14); enterprise is arithmetically closed to the beachhead (§01, §05.2). |
| Outsourced filing + demo-sold | MYND/Qandle — the only bundle pairing self-serve HRMS with an outsourced filing operation, unpriced (EV-030, EV-034) | The nearest occupant of the target corner, but unpriced and sales-led. |
| **Attended submission + self-serve, no seat floor** | **Target position — currently thin** | Portal-accepted artefacts + attended, assisted submission under written authority + CA console + employee surface, on a *published* per-head INR card. No vendor in the priced set claims to submit anything (EV-030) — which is what makes attended submission a real differentiator (K-13). |

Two disciplines keep this honest and prevent it collapsing back into the "vacuum" error the PRD explicitly killed (§01):

- **The corner is thin, not empty.** The r5 sweep read pricing, payroll and feature pages, not product documentation or a live tenant, so the absence of a submission claim is strong evidence of positioning, not proof of absent capability (EV-030). MYND/Qandle's outsourced filing operation already sits next to the corner.
- **The axes are chosen because they are the buyer's, not ours.** "How far the product carries the filing" is the Pain-1/Pain-3 axis (the obligation and the black box); "self-serve/price-card" is the decision-anatomy axis (the admin user has no time budget, AC-14). A whitespace on axes the buyer does not feel is a marketing artefact; this one is grounded in §04.1's pains.

The single falsifiable risk to the position: MYND prices and self-serves its filing operation for 20–200, or a priced vendor adds submission — either occupies the target corner and narrows the wedge to execution quality, no seat floor and CA-channel depth. AC-15 keeps every such claim dated and re-captured.

<!-- DIAGRAM: problem-market-competitive-map -->

#### The two structural risks to the market position

Both are already in the PRD's risk register; they belong here because they threaten the *sizing*, not just execution:

- **Zoho widens its free gates.** If Zoho Payroll's ₹0 ceiling moves from 10 to 25 or 50 employees, the bottom of the beachhead is zero-priced and SAM re-anchors upward to 50–200 (§20 R-1). Observable trigger: the Zoho pricing page's headcount ceiling changes. This is a *when*, not an *if* (§18). Quantified impact: if the beachhead floor moves from 20 to 50, the establishment count in the paid band falls (20–49 is the most populous sub-band — 5,25,246 of the fit's 7,24,373, r2/09) and SAM re-centres on fewer, larger accounts at higher PEPM — the model does not collapse, but it *shifts shape*, and the §04.3 grid must be re-run on the 50–200 sub-band.
- **Fintech-subsidised HRMS.** A neobank/card issuer acquires an HRMS and zero-prices it to win the payroll-to-bank-account flow (Jupiter/sumHR precedent, in which the software asset was valued at ~₹7.5 Cr — r2/00). Defence is attended submission, maintained rules and switching cost, never price (§20 R-6). Observable trigger: a fintech acquires or launches a zero-priced payroll product with bank-payout as the funnel. RazorpayX is the one to watch inside the existing field — it already carries the fintech parent and the distribution motive.

##### Acceptance criteria — competitive posture

- **AC-13 (no falsifiable advantage claim).** No collateral claims feature advantage against Zoho, gross-to-net advantage against Frappe (EV-031), or a generic "more complete India compliance" (§20 R-7). Competitive claims are confined to what dated evidence supports — Frappe's and Tally's named statutory gaps (EV-031, EV-032), seat floors (EV-026), the absence of any published submission claim (EV-030) — plus our attended submission, maintained SLA, CA console and employee surface. No collateral says a competitor's published data is wrong (§21).
- **AC-14 (price-card transparency).** A self-serve, per-head INR price card with no seat floor is published — Keka suppresses its live card (EV-021, EV-024) and every priced competitor sells a 50-employee block (EV-026) — and it is the only way to be evaluable by a 30-person buyer who will not sit through a demo (§18).
- **AC-15 (dated competitor claims).** Every competitor fact in this section carries a capture date and says whether the product was executed or only its pages, documentation or code were read; each is re-captured before external use. **[Reversed]** the v0.3 Keka gate ("no claim is final until the rendering-browser sweep") — the rates were obtained by raw-HTML fetch (EV-021–025).

### 04.5 What this section commits, and what it gates

**Committed (build the plan on these):**

- The denominator is **7,66,254 contributing establishments** (EV-001). Never registered (24.18 lakh), never Udyam (5.31 crore).
- Revealed current spend is **₹2,100–3,900 Cr/yr** software — verified inputs, modelled gross-up (EV-005) — plus a bureau pool anchored on one provider's published indicative range (₹3k–15k/mo; realised price unvalidated, V-01). The modelled whole-market ceiling is **₹9,013–10,905 Cr** (0–10% roll-forward; ₹10,126 Cr central — r2/09); the 10% figure is ₹10,905 Cr, not ₹12,250 Cr.
- Price is a **two-anchor structure** (K-09, EV-027): a value floor near ₹50 PEPM and a mid-market clearing band of ₹80–200; the ₹80–150 modelling band sits inside it.
- The share calibration for sanity-checking any SOM is **greytHR's ≈3.9%** (30,000+ companies claimed, September 2026 — EV-091). A 3-yr SOM above low-single-digit penetration of the beachhead is rejected on sight.
- The competitive advantage is **no seat floor + portal-accepted artefacts with attended, assisted submission under written authority + multi-state PT/LWF (greenfield in both incumbents — EV-031, EV-032) + maintained SLA, CA console and employee surface**. The employer's statutory liability stays non-delegable; attended-filing legality is under counsel review (§23). Parity on computation vs Zoho and Kredily; deferred vs enterprise suites.
- The statutory engine must satisfy AC-1 through AC-9, including the AC-4a and AC-6a–AC-6d sub-tests, plus AC-16 (dual wage base, effective-dated rules, deterministic numbers, unnotified ceilings held open, single record, closed seams, audit trail) — these are the product's reason to exist, not enhancements.

**Gated (no financial model may harden these until §20 reports):**

| Open question | Current placeholder | Kill / validation criterion | §20 ref |
| --- | --- | --- | --- |
| Beachhead establishment count (20–200) — `beachhead_sub20_share` | Unmeasured; ≤7.24 lakh on the r2/09 fit; 1.8–2.6 lakh scenarios ([Reversed] as an estimate) | A measured contributing-by-headcount count; EPFO's Appendix-2(v) is registered-by-accounts and cannot settle it alone (AC-12) | Desk validation (method to be set) |
| Realised bureau/CA price | ₹3k–15k/mo one provider's published indicative range; median unknown | Mystery-shop 6–8 CAs, 2 city tiers | V-01 |
| Bureau usage rate in beachhead | assumed material | Tally-payroll-adoption + buyer survey | V-02 |
| Penetration vs discounting behind the ₹23.7–44.1 per member-month implied spend | Penetration reading leans ahead on greytHR evidence only | Status-quo distribution (V-02); realised vs list (V-03) | V-02, V-03 |
| Realised ARPU vs list | List anchors verified (EV-027); ₹80–150 modelling band [Hypothesis] | Buyer/reseller interviews, won-deal figures | V-03 |
| Avg billable seats per beachhead account | held at 55 for the grid (fit mean ~46) | Won-deal seat sizes | V-03 |
| State PT/LWF slab dataset | PT read at primary for Maharashtra and Odisha, Karnataka's February structure corroborated (r2/10); Telangana to registration wording only (r2/05); every other state and every LWF rate [Hypothesis] | Gazette-sourced per-state dataset | V-09 |
| Unnotified Code-era figures — gratuity payable ceiling, bonus eligibility and calculation ceilings, EPF and ESI damages scales, the 2025-Act TDS late-fee section | Parameters with no silent default (AC-16); legacy figures only on recorded operator confirmation | Notification capture with a corrigendum check (§02.4) | §20 statutory desk validation, with the §06.13 register |
| Keka pricing residuals | Card obtained (EV-021–025) — [Reversed] the v0.3 "TLS-blocked" status; open: the block size behind the ₹6,999 floor, the unquantified setup fee (EV-025), AI as tested rather than claimed (EV-090) | Sales quote; product trial | Desk / commercial validation |

#### Claim ledger for this section

Every load-bearing claim in §04, with its status and the source or study that governs it. This is the section-level mirror of the PRD's evidence ledger — a reviewer should be able to challenge any number by its row.

| Claim | Value | Status | Source / kill criterion |
| --- | --- | --- | --- |
| Contributing-establishment denominator | 7,66,254 | [Verified] | EPFO AR, 31.03.2024 (EV-001) |
| Registered : contributing ratio | 3.16× | [Verified] | EPFO |
| Registered establishments >200 accounts | 1,73,250 | [Verified] | EPFO AR Appendix-2(v) — registered, cumulative accounts |
| >200-employee contributing establishments | 41,881 modelled; 41,881–1,73,250 plausible | [Hypothesis — modelled] | Pareto fit, r2/09 ([Reversed] v0.3's "[Verified], Appendix-2(v)") |
| greytHR share calibration | ≈3.9% (30,000+ companies, captured September 2026) | [Verified claim; derived ratio] | EV-091, EV-016 ([Reversed] v0.3's 34,000 / 4.4% — K-16, EV-K27) |
| Filed HRMS revenue (11 entities) | ₹1,374 Cr | [Verified] | MCA/ROC filings (EV-005 inputs) |
| Grossed-up real software spend | ₹2,100–3,900 Cr (USD 0.22–0.41bn at ₹94.43) | [Verified inputs + modelled gross-up] | EV-005 |
| Implied spend per contributing member-month | ₹23.7–44.1 | [Verified arithmetic] | EV-005 ÷ 7.37 Cr members ÷ 12; readings V-02/V-03 |
| Whole-market modelled ceiling | ₹9,013 Cr (0%) · ₹10,126 Cr (6%, central) · ₹10,905 Cr (10%) | [Verified arithmetic on a modelled ceiling] | r2/09 (₹12,250 Cr [Killed], EV-K11) |
| Bureau/CA retainer range | ₹3,000–15,000/mo | [Verified as one provider's published indicative bands] | IndiaFilings (r2/05); realised price §20 V-01 |
| Realised PEPM anchors | ₹52 / ₹126 | [Verified derivation] | filed revenue ÷ claimed platform scale (r2/09); §18, EV-006 inputs (both biased low) |
| Price anchors | ~₹50 value floor; ₹80–200 clearing band (at 50 employees) | [Verified] | EV-027 (K-09; any single-figure ceiling [Killed], EV-K20) |
| Seat floors | 50-employee minimum block at six of six priced vendors (Keka historically 100) | [Verified] | EV-026 |
| Labour Codes in force / Central Rules | 21 Nov 2025 / 8 May 2026 | [Verified] | §06 |
| 50% wages add-back | s.2(y) / s.2(88) | [Verified] | EV-010, §06.10 ([Reversed] v0.3's example treating special allowance as excluded) |
| Form 138 breaking format change; Q4 formats unreleased | as tabled | [Verified] | EV-011, EV-046, EV-051 |
| Nov 2026 EPF/ESI cliff | ~21 Nov 2026 | [Verified] | EV-002 (ESI leg unresolved, EV-004) |
| POSH IC for every employer; ten-worker line is the Local Committee | s.4(1) / s.6(1) | [Verified] | EV-056 |
| 144 OT hours per quarter | — | [Hypothesis] | secondary summaries only; warn, never block (K-04, EV-012, §20 V-17) |
| Beachhead PEPM modelling band | ₹80–150 (inside the clearing band) | [Hypothesis] | EV-006; §20 V-01, V-03 |
| Beachhead establishment count | ≤7.24 lakh on the fit; 1.8–2.6 lakh scenarios | [Hypothesis] | `beachhead_sub20_share`, AC-12 ([Reversed] v0.3's 1.8–2.6 lakh estimate) |
| Beachhead SAM | ₹950–6,018 Cr across scenarios | [Hypothesis] | derived from the two above |
| 3-yr SOM | ₹5.8–32.7 Cr ARR at the 2.2-lakh scenario | [Hypothesis] | derived; bounded by the ≈3.9% calibration; scales with the count |
| Bureau spend pool | ~₹1,580 Cr at the 2.2-lakh scenario, 100% bureau usage | [Hypothesis] | assumed ₹6,000/mo × unverified volume; §20 V-01, V-02 |
| Avg billable seats | 55 (fit mean ~46) | [Hypothesis] | §20 V-03 |
| State PT slabs — Maharashtra, Odisha, Karnataka | per §04.1 table | [Verified] | state primary sources (r2/10); Odisha true-up month [Hypothesis] |
| State PT slabs — every other state; all LWF rates | not captured | [Hypothesis] | gazette dataset, §20 V-09; parameters `pt.<state>.*`, `lwf.<state>.*` |
| Keka pricing | withdrawn card, live floor, suppressed card | [Verified] | EV-021–025 ([Reversed] v0.3's "TLS-blocked, unknown") |
| Keka / greytHR AI posture | waitlisted / "included in every plan" | [Verified as claim posture; not tested] | EV-090 |
| Sub-20 share of the fit residual (`beachhead_sub20_share`) | unmeasured; 64–75% implied by the scenarios, 0% in the fit | [Hypothesis] | §20 desk validation; drives the beachhead count |
| ESI raised-wage in-period treatment | contribute on actual | [Hypothesis] | reconfirm ESIC instructions; period rule [Verified] (r1/06) |
| EPF and ESI late-payment interest | 12% p.a. simple from the due date | [Verified] | S.O. 2698(E), 29 May 2026 (r1/06); EPF portal auto-calculates it (EV-039) |
| EPF and ESI damages scales | not captured — `epf.damages_scale`, `esi.damages_scale` | [Hypothesis] | legacy s.14B / Reg 31-C; Code-era scale unverified (§06.2, §06.3) |
| TDS interest | 1% / 1.5% per month | [Verified] | Income-tax Act 2025 s.398(3)(a) (r5/04) |
| TDS late-filing fee | ₹200/day | [Hypothesis] | 1961-Act s.234E per a secondary source (r1/06); 2025-Act equivalent unmapped |
| Gratuity payable ceiling | not notified under CoSS s.53(3) — `gratuity.ceiling` | [Hypothesis — amount] | r1/06; ₹20 lakh is the repealed Act's figure |
| Bonus eligibility / calculation ceilings | legacy ₹21,000 / ₹7,000 | [Hypothesis] | Code on Wages s.26 delegates both to the appropriate Government; no Code-era notification located (r1/06) |
| International-worker uncapped EPF basis | full wages, no ₹15,000 ceiling | [Hypothesis] | contested rule, carried in §06.2; EPS exclusion for post-2014 IWs [Verified] (r5/02) |
| MH PT ₹200×11 + ₹300 Feb split | as stated, with the women's ₹25,000 threshold | [Verified] | Maharashtra schedule from 1 Apr 2023, read at primary (r2/10) |
| Per-state minimum-wage (bonus floor) | varies | [Hypothesis] | state minimum-wage schedules; bonus framework [Verified] |
| Regulatory tailwind > Zoho-gate headwind | net positive | [Hypothesis] | window closes if free gate widens to 50 first |
| Contributing base stable-to-growing | ≥7,66,254 floor | [Hypothesis] | next EPFO AR; contracting base kills entry thesis |
| $23.32bn India HR tech | — | [Killed] | mislabelled global figure, §02 (EV-K04) |
| 5.31 crore Udyam as TAM | — | [Killed] | not payroll-obligated employers (EV-K01) |
| 24.18 lakh registered as denominator | — | [Killed] | two-thirds dormant |
| Zoho invest-declaration/payouts as differentiator | — | [Killed] | table stakes vs Zoho (§21) |
| "Multi-state PT/LWF is not a differentiator — Frappe ships PT in 15+ states and LWF in 14" | — | [Reversed] | Frappe ships no state PT or LWF (EV-031); Tally has no PT slab table or LWF engine (EV-032) — greenfield in both (K-01, EV-K12) |
| "Tally is the incumbent" (singular) | — | [Reversed] | two incumbents, two jobs — Tally and greytHR (K-23, EV-K34) |
| Prescribed appointment letter "from employee one" | — | [Reversed] | attaches at 10+ workers, state-prescribed form (K-18, EV-057, EV-K29) |
| HivePayroll ₹1,499/month for up to 25 | ₹1,499 / ₹2,499 / ₹3,999 per month, 25 included | [Verified] | vendor page, r2/05 — an earlier withdrawal of this figure is [Reversed] |

Until those report, this section's SAM is a **defensible order of magnitude (₹950–6,018 Cr for the beachhead, depending on the unmeasured sub-20 share)**, not a business case. That distinction is the entire point of the confidence ledger: the numbers are honest about being ranges, and every range names the study that would collapse it to a point. The section commits a *method* and a *denominator* the reader can trust; it withholds a *point estimate* it has not earned. That is the trade the PRD's evidence discipline demands, and it is the version that survives the room.
