## 09. Functional Requirements — Attendance, Leave & Deskless

Attendance was in the original brief and received **zero research in round one**
(r1 critic). Round two researched devices and the deskless worker (r2), round four
the biometric-data regime (r4), and round five the notified registers (r5). This
section closes that gap and turns the one strong, hostile-checked finding in the corpus — build
the **ADMS/WDMS push receiver in v1** — into a full functional spec, alongside
the leave, shift, overtime and regularization surfaces that the beachhead
(manufacturing, retail, logistics, hospitality, clinics at 20–200 heads) will not
buy without.

The framing is the same one that runs through the whole document: **the statutory
filing, not the payslip, is the unit of delivery.** Attendance is not a
convenience feature here — it is a *filing input* and a *filing itself*. Worked
hours drive the **Form IX** attendance register-cum-muster roll, which must carry
**per-day IN and OUT timestamps** (EV-055) and, in the central sphere, is kept five
years from the date of last entry (EV-054, §09.10); overtime drives the wages base that feeds ECR, ESI and PT
(§06, §08); leave-without-pay and loss-of-pay drive the paid-days count that every
downstream challan reconciles against. A wrong punch is not a UX problem, it is a
wrong PF contribution and a wrong 24Q/Form 138 line. Attendance therefore inherits
the engine's cardinal rule (§12, Verified): **rules-first, LLM-last — no worked-hour,
overtime or leave-balance figure is ever model-generated.** The assistant explains,
nudges, translates and drafts regularizations; the deterministic engine computes.

A second framing, specific to this section: **the beachhead is more deskless than
it looks.** A 120-person auto-components firm in Pune, a 60-store QSR chain, a
3PL warehouse cluster — these are the 50–200 accounts that carry revenue (§05),
and their workforce is largely frontline, on shared or no devices, in low
connectivity, reading Hindi/Marathi/Tamil, not English. Draft 1's verified
constraints — **worker-initiated not employer-push, shared-device reality, and
terminal integration as non-optional for frontline** — are load-bearing design
inputs, not accessibility niceties. They appear throughout as `FR-DSK-###`.

<!-- DIAGRAM: attendance-engine -->

**How to read the FRs.** Each requirement carries an ID (`FR-<area>-###`), a
priority (**P0** = required for v1 beachhead launch; **P1** = fast-follow within
v1.x; **P2** = expansion/v2), the requirement statement, a short rationale tied to
statute or evidence, and **acceptance criteria** as testable bullets. Confidence
markers apply to the *claim a requirement rests on*, not to the requirement itself.
The standing rule from §02 holds: **no statutory number ships without a
gazette/notified-rule citation and a "check for a corrigendum" pass** — several
figures below are marked **[Hypothesis]** precisely because leave-accrual,
spread-over and rest-interval values have not been read from the OSH&WC Code or
its Central Rules (notified 8 May 2026; the Wages Rules defer spread-over and rest
intervals to them, r3), and *state* rules — which may differ — are rolling out
unevenly (§20 risk: uneven state-rule notification). Where research does not give
a value, this section names a configurable parameter and ships **no default**; the
value arrives through the §22 compliance data pipeline. A [Hypothesis] figure may
raise a **warning** but may never stop a punch, a roster, a pay run or a filing
(§06.12 R17).

---

### 09.1 Scope, dependencies and the attendance data contract

**In scope for this section:** capture (biometric/ADMS, geo-mobile, kiosk, web,
WhatsApp-assisted), device integration, shifts and rosters, the attendance
processing engine (punch pairing → worked hours → exceptions), overtime per the
notified Rules, leave policy configuration and accrual, regularization and
approval workflows, deskless/frontline constraints, and the statutory attendance
register as an output.

**Out of scope here (owned by other sections):** the wage-base and add-back
computation (§06), PF/ESI/PT/TDS challan generation (§06, §08), the assistant
architecture and cost model (§12, §13), migration of opening leave balances (§14.4.10, §16.7),
and the pricing of location tracking as an add-on (§18 — noted in §09.11 for the
requirement it generates).

**Upstream dependencies (this module consumes):**

| Dependency | From | Why attendance needs it |
| --- | --- | --- |
| Employee master, DOJ, employment type | Core HR (§07) | Eligibility for leave accrual, OT, shift assignment |
| Work location → state, sphere (central/state), Code-regime commencement date | Core HR (§07.2) | State S&E vs OSH rule selection; PT/holiday calendar (jurisdiction sits on the work location, not the employee) |
| Effective-dated statutory rule set | §06 statutory engine | OT multiplier, wage-period normal hours, the [Hypothesis] quarterly OT ceiling (warn-only), leave accrual formula, national/festival holidays |
| Headcount time-series | §06 | Latching obligations (register format, crèche, works committee) |
| Holiday calendar (national + state + optional) | §06 / tenant config | Present/absent/holiday classification, comp-off eligibility |

**Downstream consumers (this module produces):**

| Output | To | Contract |
| --- | --- | --- |
| Paid-days, LOP-days per employee per period | Payroll engine (§08) | Immutable once payroll is locked; recompute only via retro run with audit trail |
| Overtime hours (at each applicable multiplier) | Payroll engine (§08) | Split by multiplier band; an excluded head under s.2(y) — outside "wages" but counted in the 50% add-back test (§06.10) |
| Form IX rows — per-day IN/OUT timestamps (EV-055) | Statutory register store (§09.10, §06.9) | Electronic, tamper-evident; retention per EV-054 (central sphere: five years from last entry; state periods to counsel, §23) |
| Leave ledger transactions | Payroll + employee surface | Double-entry, effective-dated, recomputable |
| Location/geo-fence events (opt-in) | Location add-on (§09.11) | Metered separately (§18) |

**FR-ATT-001 — Attendance is an effective-dated, recomputable ledger, not a state flag. (P0)**
Every attendance-affecting fact (raw punch, regularization, leave application,
shift assignment, holiday) is stored as an append-only (never edited in place),
timestamped, source-tagged event. The day's status (`Present / Absent / Half-day /
Weekly-off / Holiday / On-leave / OD / LOP`) is a *derived* projection over the event
log for that date, recomputable against the rule version in force **for that date**
for as long as the underlying events are held. **[Reversed]** Earlier drafts implied
a never-forget log; bitemporality is scoped by entity class (§14). Rule-sets and shift
definitions are bitemporal. Punches, biometric templates, consent artefacts and
rendered documents are **erasable classes**, tombstoned when their retention class
expires. After an erasure, replay of that period returns the Form IX rows and the
attendance summary frozen at payroll lock, flagged `source-erased`. It never
returns a recomputation from punches that no longer exist.

- **AC1:** Re-running the engine over an unchanged event log for a past period
  yields byte-identical worked-hours and status output (deterministic replay); where
  any of the period's punches has been erased, the replay returns the lock-time
  snapshot and says so.
- **AC2:** Inserting a back-dated regularization for 15 days ago recomputes that
  day and *only* affected downstream days (e.g., comp-off eligibility), and emits
  an audit entry naming actor, timestamp, before/after values, and the rule
  version applied.
- **AC3:** Once a payroll period is locked, attendance for that period is
  read-only; a correction opens an explicit **retro/arrears run** that recomputes
  against the period's rule version, never today's (mirrors §06 wage-rule
  versioning). Rationale: **[Verified]** the wage-definition rule is versioned,
  effective-dated and retrospectively recomputable (Source: §06.10; Code on Wages
  s.2(y) / CoSS s.2(88)).

### 09.1-A Core attendance & leave data model (the entity contract)

§09.1 asserts a *contract*; this is its shape. The model is aligned to the
§14 data-model section and exists to make the invariants above enforceable, not to
prescribe storage. Every mutable-looking figure (day status, leave balance,
paid-days) is a **derived projection**, never a stored counter — the same rule as
the wage engine (§06).

<!-- DIAGRAM: attendance-entity-model -->

| Entity | Key fields | Mutability | Owner / source |
| --- | --- | --- | --- |
| **Punch** (raw event) | `punch_id, tenant_id, employee_id?, device_sn?/device_user_id?, ts_device, ts_utc, tz, direction, verify_mode?, source_channel, source_ref, adapter_version?, geo?, face_match_outcome?, skew_offset?, payload_hash` — no image, no template reference | Append-only; **erasable class** (not bitemporal) — tombstoned when its retention class expires (§14) | FR-ATT-010 |
| **BiometricTemplate** | `template_id, employee_id, modality, consent_id, key_ref (biometric keyspace), enrolled_at, erased_at?` — no image column | Separate keyspace; erasable (key destruction); never referenced by a Punch | FR-ATT-017 |
| **DeviceEnrolment** | `(employee_id, device_sn), enrolled_at, erase_cmd_id?, ack_at?, exception_state?, attested_by?` | Per-device erasure ledger | FR-DEV-007 |
| **AttendanceMethodElection** | `employee_id, method (card / PIN / geo-mobile / web / supervisor / biometric), elected_by, effective_from` | Effective-dated; set by the employee | FR-ATT-017 |
| **Device** | `device_sn, tenant_id, make, model, firmware, endpoint_secret, last_seen, clock_offset, health` | Config + telemetry | FR-DEV-001/003 |
| **DeviceUserMap** | `(device_sn, device_user_id) → employee_id, effective_from, effective_to` | Effective-dated | FR-DEV-002 |
| **ShiftDefinition** | `shift_id, start, end, breaks[], grace_in, grace_out, spread_over_cap, night_flag, version, effective_from` | Effective-dated, versioned | FR-SHF-001 |
| **RosterAssignment** | `employee_id, date, shift_id, site_id, published_at` | Effective-dated | FR-SHF-002 |
| **HolidayCalendar** | `establishment_id, date, type(national/festival/optional), source_gazette_ref` | Effective-dated | FR-SHF-004 |
| **DayStatus** (projection) | `employee_id, date, status, in_ts, out_ts, worked_min, ot_min_by_band, paid_flag, rule_version` | **Derived** — recomputable, never authored | FR-ATT-021 |
| **FormIXRow** (statutory record) | `establishment_id, employee_id, month, day[1..31]{in_ts, out_ts}, shift, place_of_work, days_worked, ot_hours, tour_details, register_version` | Materialised at period lock; corrections are new versions; retained per EV-054 | FR-STAT-001 |
| **LeaveType** | `type_code, accrual_rule, cap, encashment_rule, unit, eligibility, doc_req, paid_flag, statutory_floor_ref` | Config, effective-dated | FR-LV-001 |
| **LeaveLedgerTxn** | `txn_id, employee_id, type_code, delta, reason, source_ref, effective_date, reverses_txn?` | Immutable, double-entry | FR-LV-004 |
| **Regularization** | `reg_id, employee_id, date(s), before, after, reason, evidence_ref, approver_chain, decision, decided_at` | Append + decision | FR-REG-001 |
| **ConsentArtefact** | `consent_id, version, employee_id, purpose(biometric-enrolment/night-shift/location), regime(SPDI-r5-written / DPDP / OSH-s43), given_to_entity, notice_text_version, capture_form, granted_at, effective_from, withdrawn_at?, withdrawal_ref?` | Versioned, append-only, revocable-forward; erasable class (§14) | FR-SHF-005, FR-ATT-017, FR-LOC-001 |
| **ContractorLink** | `employee_id, contractor_entity_id, license_ref, pf_code, esi_code, effective_from` | Effective-dated | FR-CL-001 |
| **AuditEntry** | `actor, ts, action, before, after, rule_version, tenant_id` | Immutable | CC-5 |

- **AC1:** No field on `DayStatus` or any leave balance is directly writable; both
  are computed from the event entities and the rule version in force for the date
  (CC-1, CC-3).
- **AC2:** Every raw-capture entity (`Punch`, imported rows, supervisor-attested)
  is source-tagged and append-only; corrections are new dated events, never
  overwrites (CC-5, FR-STAT-001 AC2). Erasure at the end of a retention class is a
  tombstone, never an edit (FR-ATT-001).
- **AC3:** No entity carries an image column and no image object store exists for
  biometric data. A `Punch` never references a `BiometricTemplate`, so destroying a
  template leaves every attendance record and `FormIXRow` valid (FR-ATT-017).

---

### 09.2 Attendance capture — the multi-modal ingestion layer

The beachhead is a **mixed fleet by definition**: a factory floor on biometric
terminals, field sales on a mobile app, a back office on web/desktop, and
frontline stores on a shared kiosk tablet. The capture layer must accept all of
these into one normalized punch stream and let policy — not the capture channel —
decide what is valid.

**FR-ATT-010 — Unified punch model across all channels. (P0)**
Every capture channel emits a punch to a single normalized schema:
`{employee_id (or device_user_id → resolved), tenant_id, timestamp (device-local + UTC + tz),
direction (IN/OUT/AUTO), verify_mode (card / PIN / fingerprint / face / geo / web / supervisor),
source_channel, source_ref (device SN / kiosk id / app session), adapter_version (device channels),
geo (lat/lng/accuracy, optional), face_match_outcome (optional — never an image), payload_hash}`.
Direction may be `AUTO` where the device does not distinguish in/out; the engine
infers direction at pairing time (§09.5).

- **AC1:** A punch from any channel validates against one schema; unknown extra
  fields are preserved verbatim (forward-compat with new firmware).
- **AC2:** Device-local time and server time are both stored; clock skew per
  device is measured and surfaced (§09.3). No punch is silently rewritten to
  server time.
- **AC3:** `payload_hash` makes each raw punch tamper-evident and is the dedup key
  (§09.3, AC on idempotency).

**FR-ATT-011 — Biometric / access-control terminals via push (ADMS/WDMS). (P0)**
See §09.3 — this is the primary capture path for the frontline beachhead and is
the best-evidenced call in the corpus. **[Verified]** (Source: r2 — four independent
sources: an HRMS vendor's device documentation, a commercial Odoo ADMS module
listing, CAMS, and the pyzk library; bench test §20 V-11). A terminal can
authenticate by card, PIN or biometric; the channel is not the biometric (FR-ATT-017).

**FR-ATT-012 — Mobile app punch with geo-fence and optional selfie. (P0 for field/deskless, P1 for others)**
Employees punch from a mobile app; the punch is stamped with GPS coordinates and
accuracy, evaluated against one or more configured geo-fences (site, client site,
route zone), and optionally a liveness/face-match selfie for identity assurance on
shared or personal devices. The selfie option is biometric capture and is governed
by FR-ATT-017; a geo punch without a selfie is a complete, non-biometric punch.

- **AC1:** A punch inside an active geo-fence (radius = tenant-set parameter
  `geofence_radius_m` per fence; the product ships no sourced default) is accepted;
  outside it is either **blocked** or **flagged-for-approval** per policy — never
  silently accepted or silently dropped.
- **AC2:** GPS accuracy worse than tenant parameter `gps_min_accuracy_m` marks the
  punch `low-confidence` and routes it to regularization rather than rejecting it
  outright (frontline GPS is noisy indoors).
- **AC3:** A selfie frame, if enabled, is used for liveness and face-match and then
  discarded — no image is persisted (FR-ATT-017 AC4); only the outcome is kept on the
  punch. Face-matching processes biometric information, which SPDI r.3 classifies as
  sensitive (EV-060) — DPDP itself creates no sensitive category (EV-059), and both
  halves apply — so it runs only for an employee who has given written consent and
  elected a biometric method. It is advisory and
  human-overridable — **it never deterministically blocks pay** (rules-first: an
  identity model error must not become a wage error). **[Hypothesis]** face-match
  as a hard gate creates a wage-denial failure mode; kill if pilots show >1%
  false-reject on frontline cameras.
- **AC4:** Punches captured offline are queued locally and reconciled on
  reconnect (§09.9, FR-DSK).

**FR-ATT-013 — Kiosk / shared-device mode. (P0 for frontline)**
A tablet or phone mounted at a site entrance runs a kiosk app where any worker at
that site authenticates per-punch (PIN, employee code + selfie, or a bring-up
biometric) without a personal login session. This is the **shared-device**
answer, and it is not optional for frontline: **[Verified]** nine in ten people
who do not use a phone live in a household that owns one, so worker identity cannot
be assumed to equal device identity (Source: Comprehensive Annual Modular Survey
2023, re-verified r2).

- **AC1:** No persistent per-user session; the kiosk returns to a neutral
  "who's punching?" state within tenant parameter `kiosk_idle_reset_s` after each
  punch. A worker cannot see or edit another worker's data.
- **AC2:** Kiosk works with a **shared roster subset** cached locally (only the
  site's assigned workers) so authentication is fast and offline-tolerant.
- **AC3:** Anti-buddy-punch controls are configurable per tenant: selfie
  face-match, a device-bound biometric, a rotating site PIN, or supervisor
  attestation. The biometric options apply only to employees who have elected a
  biometric method with written consent (FR-ATT-017). **No configuration may make a
  biometric method the only way to punch** (a "biometric only" setting is not
  shipped — §23).

**FR-ATT-014 — Web / desktop punch and bulk import. (P0)**
Back-office staff punch from web; managers and admins can bulk-import attendance
(CSV/Excel, or a Tally export of attendance vouchers — TallyPrime records attendance
through manual vouchers only and has no leave module, EV-032) for migration and for
sites still on legacy systems mid-cutover (§14.4.10, §16.7 — migration is a
first-class surface).

- **AC1:** Bulk import validates against employee master, reports per-row errors
  without aborting the whole file, and stages for review before commit.
- **AC2:** Imported rows are source-tagged `import` and are distinguishable from
  device/app punches in the audit trail forever.

**FR-ATT-015 — WhatsApp-assisted punch and status. (P1, frontline)**
Given the deskless reality, a worker may check-in/out or query balance via a
WhatsApp flow — but **worker-initiated only**. **[Verified]** a new WhatsApp
Business portfolio can reach only **250 unique users per rolling 24 hours**, so
employer-push onboarding of a 5,000-worker site on day one is impossible
(Source: Draft 1, verified; Meta WhatsApp Business Platform tier limits).

- **AC1:** The system never assumes it can push to arrive; onboarding to WhatsApp
  is pull/worker-initiated and rate-aware (respects the 250/24 h cold-start tier
  and ramps).
- **AC2:** A WhatsApp punch is subject to the *same* geo/site validation as the
  app where location can be obtained; where it cannot, it is `flagged-for-approval`.
- **AC3:** **[Killed]** Do not price or plan on the claim that Meta begins
  charging for service messages in India on 1 Oct 2026 — that change applies to
  nine *other* markets (Source: Draft 1, Killed). And **[Hypothesis]** the Meta
  India rate card is unresolved (marketing ₹0.8631 vs ₹0.95; utility ₹0.1150 vs
  ₹0.15 — a 6.3–7.5× spread); no per-worker messaging price may be committed
  until the rate card is downloaded and captured (§20 V-12). Separately, the
  WhatsApp Business account must migrate to INR billing by 31 Dec 2026 or delivery
  stops on 1 Jan 2027 (EV-088) — a dated dependency for this flow.

**FR-ATT-016 — Manual/exception capture by supervisor. (P0)**
A shift supervisor can mark attendance for a worker on the supervisor's own device
(worker forgot phone, terminal down, new joiner not yet enrolled), tagged as a
supervisor-attested punch requiring the same downstream approval as a
regularization (§09.8).

- **AC1:** Supervisor-attested punches carry the supervisor's identity and are
  never indistinguishable from a first-party device punch.

**FR-ATT-017 — Biometric capture under the SPDI Rules today, DPDP from ~May 2027, and Aadhaar Act limits. (P0)**
The beachhead runs on fingerprint/face terminals and selfie punches, so the
capture layer collects biometric data on day one. Two halves, always stated
together: DPDP creates **no** sensitive category of personal data (s.2(t), EV-059)
— **and** the SPDI Rules 2011, live today, classify biometric information as
sensitive (r.3) and **require consent in writing before collection** (r.5(1))
(EV-060, **[Verified — provenance caveat]**: the text was read from a third-party
host; re-pull from the e-Gazette before quoting it to a customer). **[Reversed]**
Earlier drafts stated as current law that DPDP s.7(i) removes the consent requirement for employee data. s.7(i) is **not in force** until
on or about 13 May 2027 (EV-058); when it commences it disapplies consent and notice
for employment purposes only and leaves the s.8 duties in place. Whether it will
reach *biometric* capture — the most intrusive way to take attendance — is
unresolved, and this PRD does not say it does (statutory basis under counsel review,
§23). **We are not aware of any Indian law that requires biometric attendance, as
of September 2026** (EV-072): OSH Code s.33(a) requires an attendance *record*,
maintained "electronically or otherwise", and is device-neutral (r5).

Two citations are banned as authority. The Supreme Court order of 29 October 2025
(*Union of India v. Dillip Kumar Rout*) turned on the employees not opposing the
system and decided nothing about privacy (K-14, r4). The 2026 decision holding
biometric attendance unlawful even with consent is **Turkish** (KVKK Principle
Decision 2026/921) and has no force in India (K-15, r4). A foreign decision is
cited only with its jurisdiction named in the same sentence.

Aadhaar is a separate regime and never part of this flow. **[Verified]** A private
employer cannot simply perform Aadhaar authentication for attendance: s.57 was
omitted in 2019, and s.4(4) permits authentication only with UIDAI's satisfaction
plus a Parliamentary-law permission or a purpose prescribed by the Central
Government (Aadhaar Act 2016 ss.4(4), 8; r4). The prescribed route is the Good
Governance (SWIK) Rules 2020 as amended by G.S.R. 88(E) of 31.1.2025: r.3 lists
four purposes, none of which names attendance, and approval is **per entity and per
use case**, through a sponsoring Ministry, ending in a Gazette notification.
MeitY's SOP lists "staff attendance" as a candidate use case for some named sectors;
r4 reads the approval as attaching to the employer or sector participant, not to a
horizontal HR SaaS (r4's inference, not the instrument's words). The product
therefore builds no Aadhaar-authentication punch path; a customer asking for one is
routed to counsel (§23). A face template captured by the employer's own terminal is
not "core biometric information" and was not collected under the Aadhaar Act — but a
photograph *is* "biometric information" under s.2(g) (EV-071). An Aadhaar
identifier and a device template never share a record or a flow.

- **AC1 — Written consent before enrolment.** Enrolment is refused until a written
  `ConsentArtefact` exists for that employee (§09.1-A), separate from the employment
  contract and any bundled notice, recording purpose, notice-text version, the legal
  entity it was given to, capture form, timestamp and enrolling device. r.5(1) names
  letter, fax or email; whether in-app capture suffices, and whether the employer or
  the SaaS owes the duty, are counsel questions (§23) — the capture machinery ships
  either way. Consent cannot be backfilled for migrated employees.
- **AC2 — Two consent regimes, one switch.** Parameter `consent_regime_switch_date`
  (default on or about 13 May 2027, EV-058; can be pulled forward) moves new
  enrolments from the SPDI regime to the DPDP regime; SPDI-regime artefacts stay on
  record. Whether written consent is still captured after the switch is a
  counsel-set configuration, defaulting to *yes*, because s.7(i)'s reach to
  biometrics and the SPDI Rules' survival are both unresolved (§23).
- **AC3 — A genuine non-biometric path, per employee.** Every employee can elect
  card, PIN, geo-mobile, web or supervisor-attested attendance
  (`AttendanceMethodElection`) at any time, without manager override or penalty
  flag. Withdrawing biometric consent moves the employee to the elected alternative
  and starts template erasure (FR-DEV-007). No tenant setting makes biometrics the
  only path. This is a risk-mitigation choice, not something r.5(7) compels — r.5(7)
  lets the body corporate withhold the service (r4).
- **AC4 — Template, not image; template, not event.** Enrolment and selfie images
  are deleted once a template or match outcome is extracted — no image column, no
  image bucket. A `BiometricTemplate` sits in a separate keyspace, independently
  access-controlled and logged, and is never referenced by a `Punch`. Templates are
  personal data throughout: they are not reliably irreversible (r4), so no vendor
  "it is only a hash" claim is accepted.
- **AC5 — Review, withdrawal, erasure.** A worker sees enrolment metadata (whether
  enrolled, when, on which devices — never the template), can withdraw consent and
  request deletion; the SPDI Rules give review and withdrawal rights today
  (r.5(6), r.5(7); r4). Whether DPDP access and erasure rights attach against an
  employer relying on s.7(i) is a counsel question (§23). Erasure timing is
  configuration, hard-coded neither as immediate nor as a one-year hold (§23).
  Form IX rows are not biometric data and keep their own retention (FR-STAT-001).

### 09.2-A The attendance-method election — a genuine non-biometric path, per employee

FR-ATT-017 AC3 commits every employee to a non-biometric path. This subsection specifies
that path as data, a decision table and invariants a build team can test. The path is an
attribute of the **employee**, not of the device or the site: one terminal authenticates by
card, PIN or biometric (FR-ATT-011), so it is the employee's election, not the hardware,
that decides which of those the system treats as a biometric act. It is the least
intrusive means under every counsel answer (§23.8.2, commitment 1). It is offered because
the proportionality question is open (Part D-2), not because a rule requires it — SPDI
r.5(7) lets the body corporate withhold the service (r4).

**FR-ATT-023 — The election is an effective-dated attribute the employee owns. (P0)**
Biometric is opt-in and never the default. A joiner, and every migrated employee, starts
on the non-biometric methods their sites support, and moves to a biometric modality only
by their own election with written consent (FR-ATT-017 AC1; non-responders at migration,
§07 FR-CHR-102). The `AttendanceMethodElection` entity (§09.1-A) is specified as follows.

| Field | Type | Rule |
| --- | --- | --- |
| `election_id` | Identifier | Immutable; a change is a new row that closes the previous one |
| `employment_id` | Reference | §14's employment key, to which this section's `employee_id` resolves; one open election per employment |
| `biometric_modalities` | Set of {fingerprint, face} | Empty unless the employee elected; each member needs a live written `ConsentRecord` naming that modality in its data classes (§07 FR-CHR-100) |
| `non_biometric_methods` | Set of {card, PIN, kiosk PIN, geo-mobile, web, supervisor-attested} | Never empty (EL-1); drives provisioning of cards and PINs, never limits which non-biometric punches count |
| `elected_by` | employee · hr_on_written_request · joiner_default · migration_default | `hr_on_written_request` needs `evidence_ref`; no manager or supervisor value exists |
| `evidence_ref` | Document reference | The worker's written request, for a worker who cannot use a self-service surface |
| `effective_from`, `effective_to` | Timestamps | Forward-only; a change never re-derives a past day (EL-4) |

`SiteMethodCapability` records, per site, which methods its hardware and policy support.
It is effective-dated tenant configuration, and it is where invariant EL-1 is enforced.

- **AC1:** An employee can change their election from any worker surface — app, kiosk,
  WhatsApp flow (FR-ATT-015) — in their language (FR-DSK-003), at any time, with no
  approval step. A worker without a surface asks HR in writing; HR records the change as
  `hr_on_written_request` with the request attached.
- **AC2:** No role other than the employee can add a biometric modality. An attempt by
  HR, a manager or an API client is refused and audited as `election-change-refused`.
- **AC3:** A joiner's election is created with `elected_by = joiner_default` and empty
  `biometric_modalities` before the first roster naming them is published.

**FR-ATT-024 — One decision table for punch acceptance by verify mode, election and consent. (P0)**
A punch records how the worker was verified (`verify_mode`, FR-DEV-008 AC3). The table
below is the only place the election and consent state touch capture. No row rejects a
punch for the way the worker was verified: a worker who attended is recorded as
attending, and a consent failure is a data-handling fault for the tenant to fix, never a
wage loss.

<!-- DIAGRAM: fr-attendance-punch-method-decision -->

| # | Verify mode on the punch | Modality in the election? | Live written consent for it? | Outcome | Exception |
| --- | --- | --- | --- | --- | --- |
| M1 | Card, PIN, kiosk PIN, geo-mobile, web | n/a | n/a | Accepted and counted, whatever the election lists | None — a non-biometric method is never "wrong" |
| M2 | Supervisor-attested | n/a | n/a | Accepted, routed to approval (FR-ATT-016) | As FR-ATT-016 |
| M3 | Fingerprint or face at a terminal | Yes | Yes | Accepted and counted | None |
| M4 | Fingerprint or face at a terminal | Yes | No — withdrawn, or never captured for that modality | Accepted and counted | `biometric-without-consent`; erasure item opened for that device (FR-DEV-008 AC3) |
| M5 | Fingerprint or face at a terminal | No | Any | Accepted and counted | `biometric-without-consent`; unticketed enrolment recorded against the device (FR-ATT-028) |
| M6 | Selfie face-match, app or kiosk | Yes | Yes, and the match succeeds | Accepted and counted | None |
| M7 | Selfie face-match, app or kiosk | Yes | Yes, and the match fails or is low-confidence | Accepted as `flagged-for-approval` | `face-match-review` — advisory, never blocks pay (FR-ATT-012 AC3) |
| M8 | Selfie face-match requested | No, or consent not live | — | The camera is never opened for matching; the worker punches by a non-biometric method | None — no biometric data is captured |
| M9 | Missing, or a vendor code the adapter cannot map | n/a | n/a | Accepted; `verify_mode` null with a reason code (FR-DEV-008 AC1) | `verify-mode-unknown`, a device-class exception for the site admin |

- **AC1:** In every row, day status, worked minutes, OT and pay equal what the same times
  punched by card would produce. Tested by replaying one punch sequence under each verify
  mode and comparing the outputs byte for byte.
- **AC2:** A `biometric-without-consent` exception names the device and the employee to
  the tenant admin only, closes when the erasure item closes, and never appears on a
  supervisor's or manager's view of the worker (EL-5).
- **AC3:** M8 is enforced in the client. The app and the kiosk hold, per worker, a flag
  saying whether face-match may be offered, synced with the roster subset (FR-ATT-013
  AC2). The flag carries no reason, so a kiosk never shows who declined.

**FR-ATT-025 — Changing the election: transitions and side effects. (P0)**
An election change is a state change with device commands attached. §09.2-B covers the
enrolment half.

| From | Event | Guard | To | Side effect | Who may trigger |
| --- | --- | --- | --- | --- | --- |
| Non-biometric | Employee adds a modality | A live written `ConsentRecord` for it (FR-ATT-017 AC1) | Biometric pending enrolment | Enrolment ticket issued (FR-ATT-028) | Employee |
| Biometric pending enrolment | Ticket consumed | Enrolment evidence inside the ticket window | Biometric active | `DeviceEnrolment` rows written | Device evidence, through the receiver |
| Biometric pending enrolment | Ticket expires, or consent withdrawn | — | Non-biometric | Ticket closed; later evidence is unticketed (FR-ATT-028) | System or employee |
| Biometric active | Employee removes the modality, or withdraws consent in writing | — | Non-biometric | Erasure request, trigger `method_switch` or `consent_withdrawal`, command type delete-template (FR-DEV-014); card or PIN provisioned if not already held | Employee |
| Biometric active | Permanent transfer away from a site | The new site's roster is published | Unchanged election | Erasure request for the old site's devices, trigger `site_transfer`; enrolment at the new site only through a ticket the employee confirms | System |
| Any | Date of leaving reached | Exit recorded in §07 | Closed | Erasure request, trigger `exit`, command type delete-user | System |
| Any | HR, a manager or an API client sets a modality | — | Unchanged | `election-change-refused` audited | — |

- **AC1:** Provisioning a card or PIN is a user-sync command on the terminal's command
  channel (FR-DEV-008), queued in the same transaction as the election change, so the
  worker is never left without a working method at the terminal.
- **AC2:** Where a model supports only delete-user, not delete-template (recorded in the
  FR-DEV-004 matrix after V-11), a switch to card runs as delete-user followed by a user
  re-add without biometrics. The re-add is sent only after the delete result arrives;
  sending both at once risks the delete removing the new card (FR-DEV-014 AC1).
- **AC3:** A PIN reaches only the worker's own surface or a sealed printed slip handed
  over by the supervisor. It is never displayed on a shared kiosk (FR-DSK-002).

**FR-ATT-026 — The election is invisible to pay, performance and discipline. (P0)**
These invariants make "no penalty flag" testable. They sit alongside FR-LEG-016, under
which the product records method elections and never penalties for them.

| # | Invariant | How it is tested |
| --- | --- | --- |
| EL-1 | Every employment has at least one usable non-biometric method at every site it is rostered to, and every site offers at least one that does not depend on the worker's own phone — card, PIN, kiosk PIN, web on a shared workstation, or supervisor-attested | Save-time validation on `SiteMethodCapability` and elections; a configuration that would breach it is refused |
| EL-2 | No payroll rule, report filter, approval-routing condition, performance input or AI feature may read `biometric_modalities` or the election history | Read grant limited to the capture layer and the enrolment service; a static scan of rule definitions and report queries fails the build on any other reader |
| EL-3 | No tenant setting removes every non-biometric method from a site or makes a biometric method the only one (FR-ATT-013 AC3) | Configuration test across every site-capability combination |
| EL-4 | An election change never alters a past `DayStatus`, OT line or register cell | The prior period replays byte-identical before and after the change (CC-1) |
| EL-5 | The election is visible to the worker and to the HR admin who administers enrolment; a supervisor sees only which methods the worker can use at the supervisor's site, never whether the worker declined a biometric method | Role-based view test (§07 permissions matrix) |
| EL-6 | An extra anti-buddy-punch control — card plus PIN, rotating site PIN, supervisor attestation — applies to everyone using that method at that site, never only to workers without a biometric election | A control scoped by election is refused at configuration |

EL-1's phone-free clause rests on two findings. Worker identity cannot be assumed to be
device identity — nine in ten people who do not use a phone live in a household that
owns one (FR-ATT-013, **[Verified]**). And roughly two-thirds of men against half of women
had used the internet (Comprehensive Annual Modular Survey 2023, via r2), so a
geo-mobile-only non-biometric path would leave many women frontline workers with the
biometric terminal as the only practical option — defeating the point of the path.

> **Worked example — one kitchen, three methods, one payroll.** A QSR kitchen of 35
> workers has one face terminal that also reads cards, and a kiosk tablet. 28 workers
> elect face and give written consent in their language; 5 elect card; 2 who carry no
> phone use the kiosk PIN. In month three one face user removes face from her election at
> the kiosk. In the same transaction the election closes, an erasure request
> (`method_switch`, delete-template) is created for the terminal, and a user-sync command
> adds a card number to her device user record. The terminal's next command poll serves
> both commands in order, and she punches by card the next morning. Her day status,
> worked hours and pay for the month are exactly what face punches at the same times would
> have produced (FR-ATT-024 AC1). Her supervisor's view shows "card" as her method at this
> site and nothing about the change (EL-5). The kiosk's face-match flag for her clears on
> the next roster sync (FR-ATT-024 AC3).

> **Test scenarios — election.**
>
> | # | Given | When | Then |
> | --- | --- | --- | --- |
> | T-EL-1 | A site configured with face as its only method | The admin saves it | Refused (EL-1, EL-3) |
> | T-EL-2 | A payroll rule that reads `biometric_modalities` | The rule is published | The publish fails the static scan (EL-2) |
> | T-EL-3 | A manager sets an employee's election to fingerprint through the API | The call is made | Refused; `election-change-refused` audited |
> | T-EL-4 | An employee removes face on the 14th | The month is replayed | Days 1–13 unchanged; from the 14th, face punches raise M4 and still count |
> | T-EL-5 | A model that supports only delete-user | An employee switches from fingerprint to card | Delete-user, then re-add with card only, in that order |
> | T-EL-6 | A tenant rule "card plus PIN for workers without biometrics" | It is saved | Refused (EL-6); "card plus PIN for all card users at site S" is accepted |
> | T-EL-7 | A site whose capability lists geo-mobile and face only | The admin saves it | Refused: no phone-free non-biometric method (EL-1) |
> | T-EL-8 | A supervisor opens a worker's profile | — | Usable methods at the site shown; election history and consent state not shown |

### 09.2-B Biometric enrolment under written consent, and the ~May 2027 regime switch

FR-ATT-017 AC1 and AC2 state the rule: written consent before enrolment, and two consent
regimes running concurrently across on or about 13 May 2027 (EV-058, EV-060). §07 owns the
consent record (FR-CHR-100) and the migration consent flow (FR-CHR-102). §23.8 owns the
legal posture, including the tenant acknowledgement at enablement (FR-LEG-015) and the
consent evidence export (FR-LEG-011). This subsection specifies the enrolment machinery
the consent gate sits in, and one problem the rule alone does not solve. Terminals hold
templates in their own flash — the eSSL X990 specification lists 10,000 fingerprint
templates (r4) — so on any model that lets a site admin enrol a user at the device itself,
a gate that lives only in the HRMS screen can be walked around. The product therefore
enforces the gate at three points: it enrols only against a ticket, it detects enrolment
evidence no ticket covers, and it remediates what it detects through the erasure protocol
(FR-DEV-007). Whether a model permits enrolment at the device is recorded per model after
the V-11 bench test (`matrix.local_enrolment_possible`, FR-DEV-004).

<!-- DIAGRAM: fr-attendance-biometric-enrolment-states -->

**FR-ATT-027 — Biometric capture is enabled per tenant, per site and per modality, and is off by default. (P0)**

- **AC1:** A tenant has no biometric capture until its admin records the FR-LEG-015
  acknowledgement. Enablement is then per site and per modality — fingerprint and face are
  separate switches — and each needs the site to satisfy EL-1.
- **AC2:** Fingerprint and face are separate data classes on the consent record, so
  consent to one never covers the other.
- **AC3:** Disabling a modality at a site first shows the admin the affected workers and
  devices, then creates one erasure request per affected worker (trigger
  `modality_disabled_at_site`, FR-DEV-013) and moves their elections for that site to
  non-biometric. Their other sites are untouched.
- **AC4:** The enablement screen shows, for each device model at the site, whether the
  model permits enrolment at the device, accepts a remote delete command and retains
  enrolment images — read from the FR-DEV-004 matrix, and "unknown" until V-11 or the
  vendor contract has answered for that model.

**FR-ATT-028 — The enrolment ticket: no enrolment the product controls happens without one, and none it cannot control goes undetected. (P0)**

| Field | Type | Rule |
| --- | --- | --- |
| `ticket_id` | Identifier | Immutable |
| `employment_id`, `modality` | Reference, enum | One open ticket per employment per modality |
| `consent_id`, `consent_version` | Reference | Live and regime-resolved (FR-ATT-029) at issue |
| `device_scope` | Device serials, or a kiosk or app installation id | The only devices on which the ticket can be consumed |
| `issued_at`, `expires_at` | Timestamps | Validity is `enrolment_ticket_ttl_h`, a product parameter with no statutory basis (owner: Product) |
| `state` | ISSUED · CONSUMED · EXPIRED · REVOKED | REVOKED when consent is withdrawn before consumption |
| `consumed_evidence` | Reference | The command result, template upload or first biometric-verify punch that consumed it |

Enrolment runs in this order, in the worker's language (FR-DSK-003), on the worker's own
phone, at the kiosk, or with HR for a worker who uses neither.

1. **Choice.** The worker sees the notice for the purpose and regime — the counsel-cleared
   template version (FR-LEG-002) — and the biometric and non-biometric methods as equal
   options with nothing pre-selected: a visible choice, not a hidden fallback (r4).
   Declining ends the flow with the non-biometric election recorded (FR-ATT-023).
2. **Written consent.** A `ConsentRecord` is created per modality (FR-CHR-100) with its
   capture form: in-app, letter, email or fax. SPDI r.5(1) names letter, fax or email;
   whether in-app capture suffices is CR-27, so every in-app artefact is labelled and
   FR-LEG-011 AC2 can find it later. A signed paper letter is scanned and attached by HR;
   the scan is a consent artefact (an erasable class), not biometric data.
3. **Regime.** The resolver (FR-ATT-029) stamps the record with its regime.
4. **Ticket.** A ticket is issued for the devices at the worker's rostered sites that
   support the modality.
5. **Enrolment.** Where the model accepts a remote enrolment command, the product queues
   a user-sync command for the worker's device user id. Where enrolment happens at the
   device, the product first sends the user record, so the site admin enrols an identity
   the product already knows.
6. **Consumption.** The ticket is consumed by the first enrolment evidence for that
   (device serial, device user id) inside its validity: a command result for a remote
   enrolment, a template upload where server sync is enabled (FR-ATT-031), or the first
   punch with a biometric verify mode. Consumption writes the `DeviceEnrolment` rows and
   the `BiometricTemplate` entity (§09.2-C).
7. **Images.** Where the product's own kiosk or app captured the enrolment image, the image
   is deleted as soon as the template or match reference is extracted. No image column and
   no image bucket exist to receive it (FR-ATT-017 AC4).

- **AC1:** A biometric-verify punch or a template upload for a (device, device user id)
  pair that no ISSUED ticket covers is an **unticketed enrolment**. It raises
  `biometric-without-consent` (FR-ATT-024 M5), opens an erasure item for that device
  (trigger `unticketed_enrolment`) and alerts the tenant admin with the device and time.
  The punch counts.
- **AC2:** Unticketed enrolments are counted per device and per site. A device with repeat
  occurrences is listed on the compliance view, so the tenant can address how enrolment
  is being done there.
- **AC3:** Evidence that arrives after `expires_at`, or after REVOKED, is unticketed.
- **AC4:** A storage scan after any enrolment through the product's own kiosk or app finds
  no image object and no image-typed value (an automated test on every release).
- **AC5:** No ticket is issued while an erasure request for the same employment and
  modality is open, because a re-enrolment could race a queued delete command that would
  then remove the new template.

**FR-ATT-029 — The consent-regime resolver. (P0)**
The resolver decides which regime a new consent record belongs to and whether written
capture is required before enrolment. It reads three rule-store values, each with an owner
(§22): `consent_regime_switch_date` — on or about 13 May 2027 (EV-058), which can be pulled
forward if MeitY compresses the timeline, with 13 versus 14 May unresolved;
`post_switch_written_capture` — counsel-set, default *yes*, because whether s.7(i) reaches
biometric capture and whether the SPDI Rules survive the omission of IT Act s.43A are both
open (CR-02, CR-12); and the CR-27 answer on capture form, unset until counsel answers.

| # | Capture time vs switch date | `post_switch_written_capture` | Record created | Written capture before enrolment | Notice |
| --- | --- | --- | --- | --- | --- |
| R1 | Before | n/a | SPDI-regime record | Yes — r.5(1) (EV-060) | The SPDI-era biometric notice version |
| R2 | On or after | Yes (default) | DPDP-regime record, with the written artefact attached | Yes — counsel-set configuration | The DPDP-era notice version, counsel-cleared |
| R3 | On or after | No — only after counsel has answered CR-02 and CR-12 | DPDP-regime record on the basis counsel records | No | As counsel sets |
| R4 | The switch date is moved earlier after some captures | — | Earlier records keep their regime; the new date applies to later captures only | Unchanged for existing records | — |
| R5 | The switch date is moved later after some captures were labelled DPDP | — | No record is rewritten; a review task lists the affected records and a corrected version is appended to each, carrying the regime in force at capture under the new date (§14.4.15 invariant 3) | Already done — R2 captured it | — |

- **AC1:** Every consent record carries the resolver inputs as they stood at capture —
  switch-date value, configuration version, capture form — so an auditor can see why it
  got its regime without reconstructing configuration history.
- **AC2:** Nothing happens to existing enrolments at the switch: no automatic re-consent
  campaign, no re-dating, and SPDI-regime records stay as evidence of what was captured
  under them. Whether existing SPDI-regime enrolments need a DPDP-era notice after the
  switch is routed to §23 under CR-02; the notice engine (FR-LEG-002) can send one if
  counsel says so.
- **AC3:** Screens render the switch date as "on or about", never as a bare date, until
  the e-Gazette date question is closed (EV-058).

**FR-ATT-030 — Withdrawal and re-enrolment. (P0)**
SPDI r.5(7) gives the worker an option to withdraw consent at any time, in writing (r4).
The product never refuses a withdrawal and never attaches a consequence to one
(FR-LEG-016). Whether an employer may act against a worker who refuses or withdraws is
CR-28; the product supports no such action under any answer.

- **AC1:** Withdrawal is accepted from any worker surface, and on paper through HR, and is
  recorded on the consent record with its capture form, like the consent it withdraws.
- **AC2:** At receipt the election moves to non-biometric for that modality, forward only,
  and an erasure request opens with trigger `consent_withdrawal` (FR-DEV-013). Its due time
  comes from `template_erasure_delay_days.consent_withdrawal`, tenant configuration within
  counsel's bound (CR-09), never hard-coded as immediate or as a one-year hold (Part D-9).
  The configuration screen says what a delay means in practice: until the delete command
  reaches the terminal, the terminal still holds the template and can still match it, and
  every such match raises M4.
- **AC3:** Re-enrolment after a withdrawal needs a new consent version and a new ticket,
  and FR-ATT-028 AC5 holds it until the earlier erasure request is complete.
- **AC4:** A grievance about biometric processing goes to the tenant's grievance contact
  under the SPDI one-month clock while that regime is armed (FR-LEG-010; r.5(9)). The
  worker's enrolment metadata view (FR-ATT-017 AC5) — enrolled or not, when, on which
  devices, and per-device erasure status — is the shared evidence.

> **Worked example — two workers either side of the switch.** Dates are scenario dates.
> On 20 November 2026 worker A consents in-app to fingerprint enrolment. R1 applies: an
> SPDI-regime record, labelled in-app. A ticket covers the plant's two terminals and is
> consumed by A's first fingerprint punch that shift. The rule store carries the switch
> date as on or about 13 May 2027. On 2 June 2027 worker B consents to face enrolment. R2
> applies: a DPDP-regime record with the written artefact attached, because
> `post_switch_written_capture` is still *yes* while CR-02 and CR-12 are open. On
> 16 August 2027 A withdraws in writing through HR. A's record gains `withdrawn_at` and is
> kept as evidence under its own retention class (§14.7); A's election moves to card; an
> erasure request queues delete-template on both terminals. If counsel later answers CR-27
> that in-app capture does not satisfy r.5(1), FR-LEG-011 AC2 lists A's 20 November record
> for follow-up. Nothing is re-dated, and the withdrawal stands.

> **Test scenarios — enrolment and regime.**
>
> | # | Given | When | Then |
> | --- | --- | --- | --- |
> | T-EN-1 | Biometric capture not enabled for the tenant | A worker opens enrolment | Only non-biometric methods are offered |
> | T-EN-2 | A live fingerprint consent and no face consent | A face-verify punch arrives | M5: counted, `biometric-without-consent`, unticketed enrolment recorded, erasure item queued |
> | T-EN-3 | A ticket scoped to terminal T1 | A fingerprint punch arrives from T2 | Unticketed on T2; T1's ticket stays ISSUED |
> | T-EN-4 | A ticket that expired an hour ago | The first fingerprint punch arrives | Unticketed (FR-ATT-028 AC3) |
> | T-EN-5 | Consent withdrawn while the ticket is ISSUED | A fingerprint punch arrives later | Ticket REVOKED; the punch is unticketed |
> | T-EN-6 | Switch date set to 13 May 2027 | Consent captured on 12 May and on 14 May | R1 and R2 respectively, each with its inputs stamped (FR-ATT-029 AC1) |
> | T-EN-7 | Switch date moved from 13 May to 1 August after captures on 2 June | The change is published | R5: a review task lists the 2 June records; corrected versions appended; originals untouched |
> | T-EN-8 | An open fingerprint erasure request | The worker asks to re-enrol | Ticket refused until the request completes (FR-ATT-028 AC5) |
> | T-EN-9 | Face enrolment through the product's kiosk | The release storage scan runs | No image object anywhere (FR-ATT-028 AC4) |
> | T-EN-10 | A supervisor looks for a deduction rule for workers who withdrew | They search configuration | No such rule type exists (FR-LEG-016, EL-2) |

### 09.2-C The biometric template entity — storage modes, access events and invariants

§14.4.15 fixes the entity's shape and §17.4 its encryption; this subsection specifies what
the attendance module does with it. The template is a separate entity from the attendance
event (Part E-6): a `Punch` carries an employee and a time, never a template reference, so
every attendance record survives template destruction (§09.1-A AC3).

**FR-ATT-031 — Three storage modes, and holding no copy is the default. (P0)**

| Mode | What the product holds | When used | Erasure reaches |
| --- | --- | --- | --- |
| `DEVICE_HELD` (default) | A `BiometricTemplate` row with metadata only — no payload, no `key_ref` | Terminals that enrol and match locally | Each device's flash, through the command channel (FR-DEV-007) |
| `SERVER_SYNCED` | The metadata row plus an encrypted payload in the biometric keyspace, under its own key | Only where the tenant enables `template_server_sync`, for example to copy an enrolment to a second terminal without re-enrolling | The server key (phase 1) and each device's flash (phase 2) |
| `KIOSK_CACHED` | An encrypted reference in the kiosk's local store, limited to consented workers in the site's roster subset (FR-ATT-013 AC2) | Offline face-match on a kiosk (FR-DSK-001) | The kiosk installation, treated as a device in the `DeviceEnrolment` ledger |

`DEVICE_HELD` is the default because a server-side breach then exposes no template. Its
cost is re-enrolment when a worker moves to another terminal, which the tenant weighs when
deciding whether to enable sync.

- **AC1:** Enabling `template_server_sync` is an audited tenant-admin action. Disabling it
  destroys the server-side key of every synced template (phase 1 only); device copies stay
  until each worker's own erasure trigger fires.
- **AC2:** A template upload from a device is accepted only under `SERVER_SYNCED`, and
  only for a worker with a live written consent and an election for that modality
  (FR-DEV-008, template-upload row). Otherwise the blob is discarded, written nowhere, and
  the discard is logged.
- **AC3:** The kiosk cache holds only workers whose election and consent are live. Each
  roster sync removes a worker whose consent was withdrawn, and the kiosk's
  acknowledgement confirms that worker's erasure item for the kiosk.
- **AC4:** A mobile selfie face-match compares against a reference held in the biometric
  keyspace, whatever the tenant's sync setting, because a personal phone is not a device
  the tenant controls. The match outcome, never the frame, is written to the punch
  (FR-ATT-012 AC3).

**FR-ATT-032 — Every template access is an event, and some operations do not exist. (P0)**

| Field of `TemplateAccessEvent` | Rule |
| --- | --- |
| `event_id`, `template_id` | Immutable |
| `actor` | A service identity — enrolment, sync-to-device, match, erasure — or a named human; no human role reads payloads (AC3) |
| `operation` | create · read-for-match · sync-to-device · key-destroy · discard |
| `purpose_code` | enrolment · attendance-match · erasure; no other value is accepted |
| `ts`, `outcome` | Time, and success or refusal |

- **AC1:** Access events are ICT logs, kept in India for at least 180 days (CERT-In,
  EV-062). Any longer period is `template_access_log_retention_days`, counsel-set. DPDP's
  detection-capable logging duty is not in force (EV-064); the events are built to support
  it.
- **AC2:** No export, download, report or API returns a template payload: exporting one
  would create a portable, invertible credential (r4). The worker sees enrolment metadata
  only (FR-ATT-017 AC5).
- **AC3:** No human role can read a template payload. Support tooling, analytics, backups
  outside the keyspace and every outbound model call exclude the keyspace; templates are
  default-deny at the redaction chokepoint (Part E-7, §12.8).
- **AC4:** The keyspace and every copy of it, backups included, stay in India. SPDI r.7
  restricts cross-border transfer of sensitive personal data (EV-060); any change goes to
  counsel (§23.6).
- **AC5:** Access outside the service identities' normal pattern — a read-for-match from a
  service that does not match, or a burst of reads — raises a security event that enters
  the six-hour CERT-In triage (EV-062, §17).

**What survives the destruction of a template.**

| Record | After the template key is destroyed and the devices acknowledge |
| --- | --- |
| `Punch`, `DayStatus`, OT lines, `FormIXRow` | Unchanged — they never referenced the template |
| `DeviceEnrolment` rows | Kept as erasure evidence, with the per-device outcome |
| `ConsentRecord` | Kept under its own retention class (§14.7, `retention.consent_evidence`) |
| `TemplateAccessEvent` | Kept for the log retention period (FR-ATT-032 AC1) |
| `BiometricTemplate` row | Tombstoned — identifier, modality, dates, erasure basis, actor; payload and key gone |
| Device copies | Gone where the device acknowledged; `closed-by-attestation` where it could not (FR-DEV-007 AC2) |

**Per-model facts the vendor contract must supply.** Indian terminal vendors' public
documentation is silent on template format, image retention, storage location, encryption
and deletion (r4). FR-LEG-017 makes these contract terms; the FR-DEV-004 matrix records the
answer per model so that product behaviour can depend on it. Each field reads "unknown"
until the vendor contract or the V-11 bench test answers it, and a vendor statement is
recorded as a claim, not a verified capability.

| Matrix field | What the product does with it |
| --- | --- |
| `matrix.template_format` | Records whether the template is in a portable format, which raises linkability risk (r4) |
| `matrix.images_retained` | A model that keeps enrolment images defeats "no image anywhere"; the enablement screen warns (FR-ATT-027 AC4) |
| `matrix.remote_delete`, `matrix.delete_granularity` | Selects the erasure path (FR-DEV-007 AC3) and the command type (FR-DEV-014) |
| `matrix.local_enrolment_possible` | Whether unticketed enrolment can happen at all (FR-ATT-028) |
| `matrix.template_upload_behaviour` | Whether the device pushes templates unasked, which the receiver discards (FR-ATT-031 AC2) |
| `matrix.user_store_backup_restore` | Whether a restore could bring back an erased template (FR-DEV-015 AC3) |
| `matrix.encrypted_transport` | Shown on the device page (FR-DEV-008 AC6) |
| `matrix.template_protection_claim` | Whether the vendor claims ISO/IEC 24745 template protection, which r4 recommends preferring where procurement allows — a claim, not a test result |

> **Test scenarios — template store.**
>
> | # | Given | When | Then |
> | --- | --- | --- | --- |
> | T-BT-1 | Any release | The schema scan runs | No foreign key from any business table to `BiometricTemplate`; no image-typed column anywhere |
> | T-BT-2 | A `DEVICE_HELD` tenant | A device uploads a template | Discarded and logged; no payload stored (FR-ATT-031 AC2) |
> | T-BT-3 | A `SERVER_SYNCED` tenant; the worker withdrew consent yesterday | A device uploads that worker's template | Discarded; an erasure item opened for the device |
> | T-BT-4 | A support engineer with the highest support role | Opens the worker record | Enrolment metadata only; the keyspace is unreachable |
> | T-BT-5 | A template key destroyed | The worker's last three months are replayed | Byte-identical to the replay before destruction (CC-1) |
> | T-BT-6 | An assistant request that includes the worker's attendance history | It leaves for a model provider | No template and no template identifier crosses the chokepoint |
> | T-BT-7 | A backup restored in a test environment after key destruction | The template row is read | Tombstone and ciphertext only; no restore path recovers the key (§14 AC-DM-35) |

---

### 09.3 The ADMS/WDMS push receiver — device integration

<!-- DIAGRAM: adms-push-sequence -->

**FR-DEV-001 — Build the ADMS/WDMS push receiver in v1. (P0 — the single
best-evidenced requirement in the document.)**
The dominant device-to-cloud path in India is **outbound**: the terminal
HTTP-POSTs punch packets to a tenant-scoped URL. **No on-premise middleware, no
static IP, no port forwarding.** **[Verified]** eSSL and ZKTeco both support it;
corroborated across four independent sources and unshaken by hostile re-checking
(Source: r2 — see FR-ATT-011; the vendor protocol specification itself has not been
captured, §20 V-11).

- **AC1:** A tenant can register a device by serial number and receive a unique,
  tenant-scoped, secret-bearing push endpoint URL to enter into the terminal's
  cloud/ADMS settings — a self-serve flow with a vernacular step-by-step (§09.9).
- **AC2:** The receiver accepts eSSL/ZKTeco push semantics (device handshake,
  heartbeat, attendance-log upload, command poll) and ACKs correctly so the device
  marks records as delivered and does not re-flood. Exact endpoint paths and packet
  field names are taken from the vendor protocol documentation during the §20 V-11
  bench test; this PRD does not assert them.
- **AC3:** Endpoint is authenticated per device (serial + secret/token); a punch
  packet whose serial is unknown or unauthorized to the tenant is rejected and
  logged, never accepted into another tenant's stream (multi-tenant isolation).
- **AC4:** Ingestion is **idempotent**: re-delivery of the same record
  (device retries, overlapping polls, firmware re-sends) is de-duplicated on
  `(device_sn, device_user_id, device_timestamp, direction)` + `payload_hash` and
  counted once.
- **AC5:** Records arrive **out of order and late** (a terminal that was offline
  for two days dumps its buffer on reconnect); the engine ingests them and
  triggers recompute of the affected past dates (FR-ATT-001) rather than dropping
  them.

> **Worked example — the two-day buffer dump.** A Pune plant's eSSL terminal
> (SN `CJXH2340xxxxx`) loses uplink Fri 18:00–Mon 09:00 over a long weekend. During
> the outage 42 workers punch normally against the terminal's local store. On
> reconnect Monday the device replays ~168 buffered attendance-log records, interleaved
> with fresh Monday punches, some duplicated because the device retried a partial
> POST Friday evening. The receiver must: (a) ACK each batch so the terminal marks
> it delivered and stops re-flooding (AC2); (b) de-dup the Friday retries on
> `(device_sn, device_user_id, device_timestamp, direction)` + `payload_hash` so a
> worker is not credited two Friday shifts (AC4); (c) attribute buffered punches to
> **Fri/Sat/Sun pay dates**, not to Monday's ingest date (AC1, capture-time not
> sync-time); (d) recompute Fri–Sun day-status and any weekend OT and
> substituted-rest-day lines those punches now create (AC5, FR-ATT-001, FR-SHF-002
> AC3). If payroll for the
> prior period has already locked, the recompute opens a retro run (FR-ATT-001 AC3)
> rather than mutating locked days.

**FR-DEV-002 — Device-user-to-employee resolution. (P0)**
Terminals key on a device-local enrollment number, not the HRMS employee ID. A
mapping layer resolves `(device_sn, device_user_id) → employee_id`, effective-dated
(a badge number gets reassigned after an exit).

- **AC1:** An unmapped device user surfaces as an **enrollment exception** (punch
  is retained, not lost) so a new joiner's punches are backfilled once mapped.
- **AC2:** Reassignment of a device user number is effective-dated so historical
  punches stay attributed to the correct person.

**FR-DEV-003 — Clock-skew and health monitoring per device. (P0)**
Frontline terminals drift; a device an hour fast silently corrupts shift pairing.
The system measures each device's clock offset (from heartbeat vs server time,
where server time is synced to NIC/NPL NTP as the CERT-In Directions require,
EV-062), last-seen, and delivery gaps. A suspected terminal compromise is treated
as falling within the CERT-In Annexure I incident types (IoT devices, item xiii)
and enters the six-hour pipeline (EV-062, §17).

- **AC1:** A device unseen for longer than tenant parameter
  `device_unseen_alert_h` raises an alert to the site admin **before** payroll
  lock, not after.
- **AC2:** Detected clock skew beyond a threshold is surfaced and can be corrected
  by applying a per-device offset to historical punches (audited), rather than
  requiring manual editing of thousands of rows.

**FR-DEV-004 — Model-level device compatibility matrix + self-serve verification
tool, published. (P0 — cheapest high-leverage artefact in the corpus.)**
**[Verified]** Draft 1 identifies a public, model-level compatibility matrix and a
self-serve verification tool, shipped *before the first enterprise sales call*, as
the highest-leverage cheap artefact — it neutralises deal-gating risk, and we are
not aware of any incumbent publishing one as of September 2026 (Source: Draft 1,
verified). The matrix also records, per model, whether the device accepts a remote
delete-template command — the precondition for FR-DEV-007.

- **AC1:** A prospect can enter a device brand/model and see supported/partial/
  unsupported + the integration path (push, pull-connector, or manual) before
  talking to sales.
- **AC2:** A running device, once pointed at a trial endpoint, self-reports its
  make/model/firmware and confirms end-to-end punch delivery within minutes.

**FR-DEV-005 — Long-tail via partner/paid connector, not in-house build. (P1)**
For SDK-bound brands, pre-ADMS firmware, and air-gapped plant networks, integrate
a third-party connector rather than building. **[Verified]** a paid connector
market exists at roughly **$345 one-time to $588/year** — cheap enough that
in-house build cannot be justified for the tail; the legacy port-4370 protocol is
**reverse-engineered, not documented, and behaves inconsistently across firmware**
(Source: Draft 1, verified).

- **AC1:** A connector-sourced punch enters the same normalized stream
  (FR-ATT-010) and is source-tagged with the connector identity.
- **AC2:** The port-4370 pull path, where used at all, is isolated behind the
  connector and never a v1 core dependency.

> **Sizing caveat, carried forward. [Killed]** The "85–98% success, ~1 in 7
> devices won't integrate" figure is banned — it was marketing from the vendor
> selling the integration fix, and round one applied a range floor as a mixed-fleet
> average (Source: r2; banned-numbers table, §20.4). **Device integration
> effort is currently unsized and needs a hardware spike** (§20 V-10) before any
> implementation estimate. This is an explicit build dependency, not a resolved cost.

**FR-DEV-006 — Device vendors are partners, not rivals. (P0 posture, informs
integrations)**
**[Verified]** eSSL's own software is time-office and access-control, not an
HRMS, and eSSL markets integration with six named HRMS vendors on its own site
(Source: Draft 1, verified). The product treats the terminal fleet as an asset to
read from, and the dealer network as a distribution channel — **not** as something
to displace with own hardware (see §09.12 non-goals; hardware is a [No] in Draft 1).

**FR-DEV-007 — Two-phase device-side template erasure, with a documented exception state. (P0)**
Terminals hold biometric templates in their own flash, so a server-side delete
leaves the template live on every terminal the employee was enrolled on (r4:
eSSL's X990 specification lists 10,000 fingerprint templates in on-device flash).
Erasure — on exit, on consent withdrawal (FR-ATT-017 AC3) or at the end of the
configured retention — therefore runs in two phases over the `DeviceEnrolment`
ledger (§09.1-A). Phase 1 destroys the server-side template key in the biometric
keyspace and queues a delete command for every enrolled device. Phase 2 collects a
per-device acknowledgement through the command channel, retrying offline devices.

- **AC1:** An erasure is `complete` only when every enrolled device has
  acknowledged, or each device that has not is closed through the exception state;
  per-device status is visible to the HR admin.
- **AC2:** **Exception state.** A device that cannot acknowledge (decommissioned,
  lost, wiped, replaced) is closed by an admin attestation recording device, reason,
  actor and date. It shows as `closed-by-attestation`, never as `erased-confirmed`,
  so the compliance view does not stay permanently red and does not overstate
  what happened.
- **AC3:** A device model that does not support a remote delete command is flagged
  at enrolment (FR-DEV-004); its erasures route straight to an on-site deletion task
  plus attestation. Vendor contracts must cover deletion-on-command, because vendor
  documentation is silent on it (r4).
- **AC4:** Erasure never touches `Punch` or `FormIXRow` records — they never
  referenced the template (§09.1-A AC3).
- **AC5:** Each `DeviceEnrolment` erasure item follows the transition table below;
  the diagram illustrates it. Retry cadence and ceiling are tenant parameters
  (`erase_retry_interval_h`, `erase_retry_max`); no sourced default exists.

<!-- DIAGRAM: fr-attendance-device-erasure-states -->

| From | Event | Guard | To | Side effect | Who may trigger |
| --- | --- | --- | --- | --- | --- |
| — | Erasure requested (exit, consent withdrawal, retention end) | Enrolment exists on this device | `QUEUED` | Server-side template key destroyed once, for the employee, on the first item (phase 1); delete command queued | System, on the triggering event |
| — | Erasure requested | Device model flagged "no remote delete" (FR-DEV-004) | `ONSITE_TASK` | On-site deletion task raised to the site admin | System |
| `QUEUED` | Device command poll | Device authenticated (FR-DEV-008) | `SENT` | Command id recorded | Device |
| `SENT` | Command result: success | Result matches command id | `ERASED_CONFIRMED` | `ack_at` set; audit entry | Device |
| `SENT` | Command result: failure, or no result within one retry interval | Retries below `erase_retry_max` | `RETRYING` | Retry scheduled | System |
| `RETRYING` | Retry interval elapses | — | `QUEUED` | Command re-queued | System |
| `RETRYING` | Retry ceiling reached | — | `EXHAUSTED` | Alert to HR admin; compliance view shows the item open | System |
| `QUEUED` | Item age exceeds `erase_queued_alert_h` with no command poll from the device | — | `QUEUED` | Alert to HR admin; the compliance view marks the device silent. A device that never polls never reaches `SENT`, so it can never reach `EXHAUSTED` — without this row it would sit unnoticed (FR-DEV-015 AC4) | System |
| `EXHAUSTED` or `ONSITE_TASK` or `QUEUED` | Admin attestation | Reason in {decommissioned, lost, wiped, replaced, deleted on site}; actor and date recorded | `CLOSED_BY_ATTESTATION` | Item closed; never shown as confirmed (AC2) | HR admin (maker); a second admin confirms where the tenant enables maker-checker |
| `CLOSED_BY_ATTESTATION` | The same device serial authenticates again | Serial matches a closed item | `QUEUED` | Item re-opened as `REOPENED`, delete command re-queued, security event logged — a "lost" device that returns may still hold the template | System |

- **AC6:** The erasure request is `complete` (AC1) when every item is
  `ERASED_CONFIRMED` or `CLOSED_BY_ATTESTATION`; a re-opened item makes it
  incomplete again, and the compliance view says why.

**FR-DEV-008 — The device packet contract: the logical interface every push adapter implements. (P0)**
The ADMS/WDMS wire format — endpoint paths, parameter and field names, encodings,
batch sizes — is **not** captured in research; it is taken from vendor documentation
at the §20 V-11 bench test (FR-DEV-001 AC2, §09.14-A16). What this PRD fixes is the
*logical* contract each vendor adapter maps onto, so nothing downstream of the
adapter ever sees a vendor format. §16.4 owns the integration posture; this is the
attendance-side specification of the same contract. The only published description
of cadence is a competitor blog saying the device posts "every few seconds" (r2) —
a description, not a specification; poll and batch intervals are adapter parameters
set from the bench test.

| Message class | Direction | Logical fields (adapter maps vendor names onto these) | Receiver obligation | On failure |
| --- | --- | --- | --- | --- |
| **Handshake** | Device → receiver | Device serial; per-device secret or token; self-reported make, model, firmware (FR-DEV-004 AC2); device clock | Authenticate serial + secret against the tenant's `Device` registry; record firmware; return the receiver's configuration where the protocol allows | Unknown serial or wrong tenant: reject, log a security event (§16.12), ingest nothing (FR-DEV-001 AC3) |
| **Heartbeat** | Device → receiver | Serial; device clock; buffered-record count where exposed | Update `last_seen`; compute `clock_offset` against NTP-synced server time (FR-DEV-003, EV-062) | Missed heartbeats beyond `device_unseen_alert_h`: alert before lock |
| **Attendance-log upload** | Device → receiver | Per record: device user id; device-local timestamp; direction (IN / OUT, or none → `AUTO`); **verify mode** (card, PIN, fingerprint, face, other); device record sequence where exposed | Durably write each raw record with `payload_hash` **before** acknowledging; dedup (FR-DEV-001 AC4); resolve user (FR-DEV-002); attribute to capture date | Malformed record: kept in a quarantine store with the raw bytes and surfaced as an exception, never silently dropped |
| **Command poll** | Device → receiver | Serial | Return queued commands: user sync (add, update or remove a device user), delete-template (FR-DEV-007), clock set where supported | No commands: empty response |
| **Command result** | Device → receiver | Command id; outcome; device-reported detail | Advance the matching FR-DEV-007 item or user-sync item | Unmatched command id: logged, ignored |
| **Template upload** (only if the model sends one) | Device → receiver | Employee's device user id; template blob | Accept only if the tenant has enabled server-side template sync **and** the employee has a live written `ConsentArtefact` and a biometric `AttendanceMethodElection`; write only to the biometric keyspace, never to business tables (Part E-6) | No consent or no election: discard the blob, log `template-without-consent`, open an FR-DEV-007 erasure for that device |

- **AC1 — Map, never synthesise.** Every adapter maps into these classes. A logical
  field the vendor format does not carry is stored as null with a reason code; the
  adapter never invents a value (a missing direction becomes `AUTO`, resolved at
  pairing, FR-ATT-020).
- **AC2 — Acknowledge only what is durable.** An acknowledgement never covers a
  record that is not durably written. Where the vendor protocol acknowledges only
  whole batches, the batch is written atomically before the acknowledgement. With
  device retries this gives at-least-once delivery and, through the dedup key,
  exactly-once attendance rows (FR-DEV-001 AC4).
- **AC3 — Verify mode is evidence, and a consent check.** Verify mode is kept on the
  `Punch` (`verify_mode`), so a card or PIN punch is distinguishable from a biometric
  one in the audit trail and in any inspection. A punch whose verify mode is
  fingerprint or face, for an employee with no live written consent or no biometric
  election, raises a **`biometric-without-consent`** exception: the punch is kept
  and counts for attendance (the punch holds no template or image, and dropping it
  would turn a consent failure into a wage loss), and an FR-DEV-007
  erasure is opened for that device, because the terminal holds a template it
  should not.
- **AC4 — No images, no templates in attendance records.** If an attendance record
  arrives carrying an image or template payload, the adapter strips it before
  persistence and logs the strip. No image column, no image bucket (Part E-6,
  FR-ATT-017 AC4).
- **AC5 — Versioned adapters.** Each `Punch` records the adapter version that
  parsed it, so a firmware change that alters the format is traceable to the
  records it affected, and a re-parse of quarantined records uses a named version.
- **AC6 — Transport.** Per-device secrets are rotatable from the admin console
  without re-enrolling users. Whether each model supports an encrypted transport is
  recorded in the compatibility matrix after V-11 (FR-DEV-004); a tenant using a
  model without it sees that on the device's page.

> **Contract test corpus (runs against every adapter version).**
>
> | # | Input | Expected |
> | --- | --- | --- |
> | T1 | The same attendance-log batch posted twice | One set of `Punch` rows; second post acknowledged, zero new rows |
> | T2 | Upload from an unregistered serial | Rejected; security event; zero rows in any tenant |
> | T3 | Record with no direction field | Stored with direction `AUTO`; paired by FR-ATT-020 |
> | T4 | Fingerprint verify-mode punch for an employee who withdrew consent last week | Punch counted; `biometric-without-consent` exception; erasure item `QUEUED` for that device |
> | T5 | Command result "success" for a delete-template command | Item `ERASED_CONFIRMED`; request complete if it was the last open item |
> | T6 | Attendance record carrying an image payload | Image stripped before write; strip logged; punch stored |
> | T7 | Batch in which one record is malformed | Valid records written and acknowledged per AC2; malformed record quarantined as an exception |
> | T8 | Device clock 47 minutes fast at handshake | `clock_offset` recorded; punches skew-corrected at pairing, raw retained (FR-DEV-003, pathological case 10) |

### 09.3-A The device contract, field by field — device lifecycle, receiver outcomes and clock skew

FR-DEV-008 fixes the six message classes. This subsection fixes each logical field, the
device's own lifecycle, what the receiver answers and how it behaves under load, and how
clock skew is handled — enough for an adapter author to build against and a tester to
write fixtures for, without the vendor wire format, which stays with V-11 (§09.14-A16).
§16.4 carries the integration posture and points here for the contract.

**FR-DEV-009 — The logical field dictionary. (P0)**
Adapters map vendor fields onto these names. A field the vendor does not carry is null
with one of the listed reason codes; the adapter never infers a value (FR-DEV-008 AC1).

| Logical field | Message classes | Type | Required | Validation | Null reason codes |
| --- | --- | --- | --- | --- | --- |
| `tenant_route_token` | All | Opaque string in the tenant-scoped URL | Yes | Resolves to exactly one tenant | — (absent: REJECTED_AUTH) |
| `device_serial` | All | String | Yes | Registered to the route's tenant in PENDING, ACTIVE, STALE or ROTATING (FR-DEV-010) | — |
| `device_credential` | All, by the vendor's mechanism | Secret or token | Yes | Matches the current secret, or the previous one inside a rotation overlap | — |
| `device_clock` | Handshake, heartbeat | Device-local timestamp | No | Parseable; compared with NTP-synced server time (EV-062) | `NOT_EXPOSED` |
| `make`, `model`, `firmware` | Handshake | Strings | No | Looked up in the FR-DEV-004 matrix | `NOT_REPORTED` |
| `buffered_count` | Heartbeat | Integer | No | Non-negative | `NOT_EXPOSED` |
| `device_user_id` | Attendance-log upload, template upload | String | Yes | Resolved through `DeviceUserMap` (FR-DEV-002); an unmapped id is an enrolment exception, never a rejection | — (absent: quarantine) |
| `device_timestamp` | Attendance-log upload | Device-local timestamp | Yes | Parseable; skew-corrected under FR-DEV-012 | — (absent: quarantine) |
| `direction` | Attendance-log upload | IN · OUT | No | Vendor code mapped | `NOT_SENT` (stored as `AUTO`), `UNMAPPED_CODE` |
| `verify_mode` | Attendance-log upload | card · PIN · fingerprint · face · other | No | Vendor code mapped | `NOT_SENT`, `UNMAPPED_CODE` |
| `record_sequence` | Attendance-log upload | Integer | No | Monotonic per device where exposed (FR-DEV-011 AC4) | `NOT_EXPOSED` |
| `command_id`, `command_outcome`, `command_detail` | Command result | Strings | Id and outcome | The id matches a command queued for this serial | — (unmatched: logged and ignored) |
| `template_blob` | Template upload | Opaque bytes | Conditional | FR-ATT-031 AC2 | `STRIPPED` when removed from an attendance record (FR-DEV-008 AC4) |
| `raw_payload_hash` | All | Hash of the raw bytes as received | Computed by the receiver | — | — |

- **AC1:** The raw bytes of every attendance-log upload are kept with the `Punch` rows they
  produced, under the punch retention class, because a disputed punch is settled against
  what the device sent (§14.4.7).
- **AC2:** Adapter families are registered with their evidence status. ADMS/WDMS push for
  eSSL and ZKTeco is corroborated by four independent sources (r2). The REST-webhook
  mapping for Matrix COSEC and Realtime and the on-premise SDK mapping for Anviz and
  Secureye rest on one competitor's blog, and Matrix publishes no API documentation (r2).
  Those families get an adapter only after a per-brand spike (V-10); until then the
  compatibility matrix shows them as unverified.
- **AC3:** Pushing a blocked-worker list to a gate or turnstile is not part of this
  contract. One vendor ecosystem's contract-labour specification includes such a push (r3 —
  that ecosystem's requirement, not a standard). Physical write-back that stops a worker
  entering is adverse action and needs its own review (FR-LEG-016) before it is specified.

**FR-DEV-010 — The device lifecycle. (P0)**
A device is itself a state machine, and its state decides what the receiver accepts.

<!-- DIAGRAM: fr-attendance-device-lifecycle-states -->

| From | Event | Guard | To | Side effect | Who may trigger |
| --- | --- | --- | --- | --- | --- |
| — | Admin registers a serial | The serial is not live in any tenant | PENDING | Secret generated and shown once; endpoint URL issued; site recorded | Site or HR admin |
| PENDING | First authenticated handshake | Serial and secret match | ACTIVE | Firmware recorded; matrix looked up; first clock offset measured | Device |
| PENDING | `device_pending_expiry_h` passes with no handshake | — | EXPIRED | Secret revoked | System |
| ACTIVE | Unseen beyond `device_unseen_alert_h` | — | STALE | Alert to the site admin before lock (FR-DEV-003 AC1) | System |
| STALE | Authenticated heartbeat | — | ACTIVE | Gap recorded; a buffered upload is expected (FR-DEV-001 AC5) | Device |
| ACTIVE | Admin starts secret rotation | — | ROTATING | New secret shown once; old and new accepted for `device_secret_overlap_h` | Admin |
| ROTATING | The device authenticates with the new secret, or the overlap ends | — | ACTIVE | Old secret revoked | Device or system |
| ACTIVE, STALE or ROTATING | The serial appears on another tenant's route, or authentication failures exceed `device_auth_fail_threshold` | — | SUSPENDED | Ingest refused; security event; CERT-In IoT triage (EV-062) | System |
| SUSPENDED | Admin re-verifies the device and rotates the secret | Maker-checker where the tenant enables it | ACTIVE | Audit entry | Admin |
| ACTIVE, STALE or SUSPENDED | Admin decommissions | Every open erasure item for the device is listed and routed to attestation (FR-DEV-007 AC2) | DECOMMISSIONED | `DeviceUserMap` rows closed; secret revoked | Admin |
| DECOMMISSIONED | The same serial authenticates again | — | SUSPENDED | Security event; closed erasure items for the serial reopened (FR-DEV-007 table) | System |

- **AC1:** A SUSPENDED or DECOMMISSIONED device's uploads are refused, but its command
  polls are answered with delete-template and delete-user commands only, so erasure can
  finish on a device that comes back.
- **AC2:** A serial is live in one tenant at a time. Moving a terminal between tenants — a
  dealer re-selling it, say — needs decommissioning in the first tenant. The second
  registration shows, as a warning, that the serial has open erasure items elsewhere,
  without identities.
- **AC3:** Decommissioning never deletes the device's `Punch` rows or raw payloads; they
  keep their own retention class.

**FR-DEV-011 — Receiver outcomes, acknowledgement and backpressure. (P0)**

| Logical outcome | Meaning | Acknowledged to the device? | Consequence |
| --- | --- | --- | --- |
| ACCEPTED | Durably written | Yes | Punches enter pairing |
| DUPLICATE | Already held under the dedup key (FR-DEV-001 AC4) | Yes | No new row |
| QUARANTINED | Raw bytes durably held, record not parseable | Yes — the bytes are safe and the device must not re-flood | Exception to the site admin; re-parse under a named adapter version (FR-DEV-008 AC5) |
| DEFERRED | Load or a dependency outage prevented a durable write | No | The device retries; at-least-once delivery holds; nothing is dropped |
| REJECTED_AUTH | Unknown serial, wrong tenant route or bad credential | No | Security event (§16.12) |
| REJECTED_SUSPENDED | Device SUSPENDED or DECOMMISSIONED | No, for uploads | Command polls still served (FR-DEV-010 AC1) |

- **AC1:** Per-device and per-tenant ingest limits (`ingest_rate_limit.device`,
  `ingest_rate_limit.tenant`) are set from the V-11 bench results and the §17.9 scale
  targets. Exceeding one returns DEFERRED — never a silent drop — and is metered.
- **AC2:** Attribution uses the skew-corrected device timestamp; arrival order is kept for
  audit only. Records for a locked period open a retro run (FR-ATT-001 AC3).
- **AC3:** The ingest endpoint's logs are ICT logs, kept in India for at least 180 days
  (EV-062).
- **AC4:** Where a device exposes `record_sequence`, a gap raises `device-sequence-gap` with
  the missing range, as a warning on the pre-lock dashboard. The adapter asks for a
  re-send only where the vendor protocol allows one (V-11).
- **AC5:** A quarantined record moves QUARANTINED → REPARSED (under a newer adapter
  version) → ACCEPTED, or QUARANTINED → DISCARDED with an admin reason. A discarded
  record's raw bytes stay under the punch retention class, so the decision can be revisited.

**FR-DEV-012 — Clock skew: one decision table. (P0)**
Server time is NTP-synced to NIC/NPL, as the CERT-In Directions require (EV-062); a
terminal's clock is not. The offset measured at each heartbeat (FR-DEV-003) drives the
action. The thresholds are tenant parameters with no sourced default.

| Measured offset | Punch handling | Device action | Exception |
| --- | --- | --- | --- |
| Within `clock_skew_tolerance_s` | Raw and corrected times equal | None | None |
| Beyond tolerance, within `clock_skew_autocorrect_max_s` | Corrected time = device time minus the offset at the nearest earlier heartbeat; raw kept | Clock-set command where the model supports one | `clock-skew-corrected` (information) |
| Beyond `clock_skew_autocorrect_max_s` | Raw kept; the correction is proposed and applied only when an admin confirms the bulk offset (FR-DEV-003 AC2) | Clock-set command where supported | `clock-skew-review` on each affected day — lock-gating until confirmed or waived (FR-ATT-022) |
| The offset jumps between two heartbeats (a clock reset or battery failure) | Punches between the two heartbeats flagged | — | `clock-discontinuity` on the affected days |

> **Worked example — 47 minutes fast.** The heartbeat received at server time 08:50:00
> carries device time 09:37:00, an offset of +47 minutes. A punch the device stamps 09:47 is
> corrected to 09:00, and the raw 09:47 stays on the `Punch`. If the tenant's
> `clock_skew_autocorrect_max_s` is above 2,820 seconds (47 minutes), the correction
> applies and pairing uses 09:00 (pathological case 10). If it is below, the day carries
> `clock-skew-review` until the admin confirms the offset. Either way the terminal gets a
> clock-set command if its model supports one — a fact the FR-DEV-004 matrix records.

> **Contract test corpus, continued (T9–T20).**
>
> | # | Input | Expected |
> | --- | --- | --- |
> | T9 | Upload with the previous secret, inside the rotation overlap | ACCEPTED; after the overlap, REJECTED_AUTH |
> | T10 | Upload from a SUSPENDED device | REJECTED_SUSPENDED; the same device's command poll returns only queued delete commands |
> | T11 | A serial live in tenant A, registered by tenant B | Registration refused (FR-DEV-010 guard) |
> | T12 | Sequence numbers 1001–1010, then 1014 | Records written; `device-sequence-gap` for 1011–1013 |
> | T13 | The punch store is unavailable during an upload | DEFERRED, no acknowledgement; the device's retry is ACCEPTED once; no duplicates |
> | T14 | A buffered upload with punches in a period already locked | Punches written; retro run opened (FR-ATT-001 AC3); the locked period untouched |
> | T15 | The adapter version changes between two batches | Each `Punch` carries the version that parsed it (FR-DEV-008 AC5) |
> | T16 | A template upload while `template_server_sync` is off | Blob discarded and logged; nothing stored |
> | T17 | Offset +2 minutes, then −58 minutes at the next heartbeat | `clock-discontinuity` on the punches between the two heartbeats |
> | T18 | A user-sync command result reporting failure | Election change marked "provisioning pending"; site admin alerted; the worker's other methods keep working |
> | T19 | A command poll from a DECOMMISSIONED serial | Device moves to SUSPENDED; closed erasure items reopen; delete commands served |
> | T20 | A handshake reporting a firmware version the matrix has never seen | ACCEPTED; the matrix gains an "untested firmware" row for the model, shown on the device page |

### 09.3-B Two-phase erasure, end to end — the request, its timing, its commands and its evidence

FR-DEV-007 defines the per-device item machine. This subsection defines the request that
owns the items, when each trigger fires, which command each device receives, the ways a
device can bring a template back, and the evidence a tenant can produce afterwards.

<!-- DIAGRAM: fr-attendance-erasure-sequence -->

**FR-DEV-013 — The erasure request. (P0)**

| Field | Type | Rule |
| --- | --- | --- |
| `request_id` | Identifier | Immutable |
| `employment_id` | Reference | One open request per employment per modality |
| `modalities`, `template_ids` | Sets | The templates in scope |
| `trigger` | exit · consent_withdrawal · method_switch · site_transfer · modality_disabled_at_site · retention_end · unticketed_enrolment · template_without_consent | Fixes the delay parameter and the command type (FR-DEV-014) |
| `requested_at`, `due_at` | Timestamps | `due_at` = `requested_at` + `template_erasure_delay_days.<trigger>` |
| `phase1_done_at` | Timestamp | Server-side key destroyed (`SERVER_SYNCED`), or marked not applicable (`DEVICE_HELD`) |
| `items[]` | FR-DEV-007 items | One per `DeviceEnrolment` in scope, kiosk installations included (FR-ATT-031) |
| `status` | OPEN · COMPLETE · REOPENED | COMPLETE per FR-DEV-007 AC6 |
| `evidence_pack_ref` | Reference | FR-DEV-016 |

- **AC1:** Before `due_at` a server-held template is SUSPENDED: unreadable to every service
  except the erasure job and excluded from sync-to-device. It is not destroyed early.
- **AC2:** A request cannot be cancelled once created. A worker who changes their mind
  re-enrols through a new consent and ticket after it completes (FR-ATT-028 AC5).

**FR-DEV-014 — Trigger timing and command type. (P0)**
Every trigger's delay is a named parameter, set by the tenant within counsel's bound
(CR-09) and never hard-coded as immediate or as a one-year hold (Part D-9). The product
fixes the event that starts each clock and the command each device receives.

| Trigger | Clock starts at | Delay parameter | Command type | Election effect |
| --- | --- | --- | --- | --- |
| `exit` | The date of leaving recorded in §07 | `template_erasure_delay_days.exit` | delete-user — device user record, card, PIN and templates | Election closed |
| `consent_withdrawal` | Receipt of the written withdrawal (FR-ATT-030) | `.consent_withdrawal` | delete-template; user record and card kept | Modality removed |
| `method_switch` | The election change (FR-ATT-025) | `.method_switch` | delete-template | Modality removed |
| `site_transfer` | Publication of the roster at the new site | `.site_transfer` | delete-template on the old site's devices only | Other sites unaffected |
| `modality_disabled_at_site` | The tenant's disable action (FR-ATT-027 AC3) | `.site_disable` | delete-template for that modality on that site's devices | That site's modality removed |
| `unticketed_enrolment`, `template_without_consent` | Detection (FR-ATT-028 AC1; FR-DEV-008 AC3) | `.no_consent` | delete-template | None — the template should not exist |
| `retention_end` | End of the tenant's configured template retention | — | delete-template, or delete-user if the worker has left | As configured |

- **AC1:** The command type is chosen per device from `matrix.delete_granularity`. Where a
  model supports only delete-user, a delete-template trigger becomes delete-user followed by
  a re-add of the user without biometrics, queued only after the delete result
  (FR-ATT-025 AC2).
- **AC2:** For `.no_consent`, the configuration screen states that the consent failure
  lasts as long as the template stays on the terminal. Legal owns the bound (CR-09), and
  the tenant cannot set a value above it.
- **AC3:** A trigger that fires while a request is OPEN for the same modality adds its
  devices to that request; it never opens a second one.

**FR-DEV-015 — Devices that come back, get replaced or get restored. (P0)**

- **AC1 — A returning device.** A decommissioned or attested device that authenticates again
  goes to SUSPENDED (FR-DEV-010), and every item closed by attestation for its serial is
  reopened and re-queued. The request shows REOPENED until the device acknowledges.
- **AC2 — Replacement.** A replacement terminal registers as a new serial and the old serial
  is decommissioned. The new device receives templates only through tickets
  (`DEVICE_HELD`), or through sync-to-device for workers whose written consent and election
  are live (`SERVER_SYNCED`). Each sync writes `DeviceEnrolment` rows and access events
  (FR-ATT-032).
- **AC3 — The restore hazard.** Where a model can back up and restore its user store
  (`matrix.user_store_backup_restore`, V-11), restoring a backup taken before an erasure
  could bring an erased template back. The product cannot see the restore, but it sees the
  consequence: a biometric-verify punch from a worker whose request is COMPLETE raises M4
  or M5 and reopens that device's item. Backups held outside the product, by the tenant or
  a dealer, are beyond its reach; the vendor terms (FR-LEG-017) and the tenant
  acknowledgement (FR-LEG-015) cover them.
- **AC4 — Offline for good.** A device that never polls leaves its item QUEUED, which never
  becomes EXHAUSTED. The `erase_queued_alert_h` row of the FR-DEV-007 table makes it
  visible, and only an attestation closes it (FR-DEV-007 AC2).

**FR-DEV-016 — The erasure evidence pack and the compliance view. (P0)**

- **AC1:** For each request the tenant admin can export: the worker (surrogate identifier,
  and name while it is held), the trigger and its time, the consent record reference,
  `due_at`, `phase1_done_at`, and per device the serial, model, command id, time sent,
  result, acknowledgement time or attestation (actor, reason, date), and every reopening.
  The export is rendered from the records, never typed.
- **AC2:** The worker's enrolment metadata view shows the same per-device status in their
  language (FR-ATT-017 AC5), never the template.
- **AC3:** The compliance view lists open requests by age, items QUEUED beyond
  `erase_queued_alert_h`, items EXHAUSTED, attestations in the period and reopenings. It
  reports request-to-complete time at the 50th and 90th percentile per tenant, and the
  share of items closed by attestation; a high attestation share points to fleet hygiene
  rather than a protocol fault, and the view says so.
- **AC4:** No erasure request touches `Punch`, `DayStatus`, OT lines or `FormIXRow`
  (FR-DEV-007 AC4); T-ER-10 asserts it on every release.

> **Worked example — an exit, three terminals, one lost in a storeroom.** The tenant has
> set `template_erasure_delay_days.exit` to zero and `erase_queued_alert_h` to 72 — tenant
> choices for the example, not recommendations. A worker enrolled by fingerprint on
> terminals T1, T2 and T3 (`DEVICE_HELD`) leaves on 30 September 2026. At 18:00 the request
> opens with trigger `exit`. Phase 1 is marked not applicable, because there is no server
> copy, and three items are QUEUED with command type delete-user. T1 polls at 18:01 and
> confirms at 18:02; T2 confirms at 18:07. T3 is unpowered in a storeroom and never polls,
> so its item stays QUEUED. At 18:00 on 3 October the queued-age alert reaches the HR admin.
> On 14 October the admin attests "decommissioned", with the date. The item becomes
> CLOSED_BY_ATTESTATION and the request COMPLETE — shown as two confirmed and one attested,
> never as three confirmed. On 3 February 2027 someone powers T3 on. It authenticates,
> moves to SUSPENDED and raises a security event; the item reopens; the delete-user command
> is served on its first poll even though its uploads are refused; T3 confirms. The
> evidence pack shows both the attestation and the later confirmation. At no point did the
> worker's punches, Form IX rows or pay records change.

> **Test scenarios — erasure.**
>
> | # | Given | When | Then |
> | --- | --- | --- | --- |
> | T-ER-1 | A request with three items: two confirmed, one attested | The compliance view renders | COMPLETE; 2 confirmed, 1 attested; never 3 confirmed |
> | T-ER-2 | `.consent_withdrawal` set to 5 days; template `SERVER_SYNCED` | Withdrawal received on day 0 | Template SUSPENDED from day 0; key destroyed on day 5; device commands queued on the same due time |
> | T-ER-3 | A delete-user-only model | A method switch to card | Delete-user, then re-add with card, in order (FR-DEV-014 AC1) |
> | T-ER-4 | A request OPEN for fingerprint | A second fingerprint trigger fires | Devices added to the open request; no second request |
> | T-ER-5 | A COMPLETE request | A fingerprint punch from the same worker arrives from T2 | M4 or M5 exception; T2's item reopened; request REOPENED |
> | T-ER-6 | A device QUEUED longer than `erase_queued_alert_h` | The alert job runs | Alert to the HR admin; the item stays QUEUED |
> | T-ER-7 | An OPEN request | The worker asks to cancel it | Refused; re-enrolment offered once it completes (FR-DEV-013 AC2) |
> | T-ER-8 | A kiosk holding a cached face reference | Consent is withdrawn | The next roster sync removes the reference; the kiosk's acknowledgement confirms its item |
> | T-ER-9 | A permanent site transfer | The new site's roster is published | Old-site devices get delete-template; new-site devices get nothing until the worker confirms a ticket |
> | T-ER-10 | Any request | The erasure job completes | The worker's Punch, DayStatus, OT and Form IX counts unchanged |

---

### 09.4 Shifts, rosters & scheduling

Frontline pay correctness is impossible without knowing *which shift* a worker was
on: night differentials, weekly-off placement, and — critically — the daily/weekly
boundary that defines overtime all depend on it.

<!-- DIAGRAM: roster-to-exception-flow -->

**FR-SHF-001 — Shift definition with tolerances and breaks. (P0)**
A shift is defined by start/end, break windows (paid/unpaid), grace periods
(late-in / early-out tolerance), a **spread-over** limit, half-day and short-leave
rules, and a night flag. Shifts are effective-dated and versioned.

- **AC1:** A worker punching within grace is on-time; beyond grace is late by
  policy (deduction / half-day / flagged), configurable, never hard-coded.
- **AC2:** Unpaid break duration is subtracted from worked hours; paid break is
  not. Break handling is auditable in the day's worked-hour computation.
- **AC3:** **[Verified]** Normal hours depend on the wage period: **8 hours a day**
  where the wage period is daily, **48 hours a week** otherwise — not a universal
  8-and-48 pair (Code on Wages (Central) Rules 2026 r.5, per the PRS review, r3;
  re-read r.5 in G.S.R. 343(E) before customer use). **[Reversed]** Earlier drafts
  marked spread-over as statutorily capped and [Verified]; the Wages Rules defer
  spread-over and rest intervals to the OSH Code and its rules, which have not been
  read for these limits (r3). **[Hypothesis]** the spread-over ceiling is parameter
  `spread_over_cap_min`, effective-dated per (state, sphere). **[Reversed]** Earlier
  drafts seeded it with legacy Factories Act figures; those were never captured in
  research, so no value ships — the parameter stays empty (and the spread-over test
  inactive) for a jurisdiction until the OSH Code/Rules text or the state rule is
  read and published through the §22 pipeline (§20 V-09 extended, §09.14-A1).
- **AC4:** **[Hypothesis]** A maximum unbroken work stretch and a minimum rest
  interval exist in the OSH regime but have not been read (r3). Parameters
  `max_continuous_work_min` and `min_rest_interval_min` are effective-dated per
  (state, sphere) and ship empty, like `spread_over_cap_min`. Once populated, a
  roster or punch sequence that breaches them raises a **warning-class** exception —
  shown on the pre-lock dashboard, never lock-gating (§06.12 R17).

> **Worked example — spread-over vs worked hours.** A retail worker on a
> split-shift roster punches IN 10:00, OUT 14:00 (store lull), IN 17:00, OUT 21:30.
> **Worked hours = 8.5 h** (4.0 + 4.5). **Spread-over = 11.5 h** (10:00→21:30). If
> the state's published `spread_over_cap_min` is below 690 minutes (an illustrative
> condition, not a sourced value), this roster *exceeds spread-over even
> though worked hours are within normal hours* — the engine must flag the
> spread-over breach independently of the OT computation, because they are
> different tests against different limits. While the ceiling is [Hypothesis], the
> flag is a warning, not a block (AC3). The 3-hour unpaid gap is subtracted from
> worked hours (FR-SHF-001 AC2) but still counts toward spread-over.

**FR-SHF-002 — Rostering / shift scheduling. (P0 for frontline, P1 general)**
Managers build rosters assigning workers to shifts across days/weeks, per site,
with pattern support (rotating 6-day, 3-shift rotation, 4-on/2-off), copy-forward,
and bulk edit.

- **AC1:** A roster flags any worker without a **weekly rest day** in a week or
  rostered for more than **ten consecutive days** without a full rest day.
  **[Verified]** At least one weekly rest day (normally Sunday in a six-day week, the
  employer free to fix another day); no more than ten consecutive days without a
  full rest day; and work on a rest day requires **both** a substituted rest day
  **and** overtime wages (Code on Wages (Central) Rules 2026 r.6, per the PRS
  review, r3; re-read r.6 in G.S.R. 343(E) before customer use). State-sphere
  variations are **[Hypothesis]**; validate through the §09.14-A1 state-rules dataset.
- **AC2:** Publishing a roster notifies affected workers (in-app / WhatsApp,
  worker-initiated-aware per FR-ATT-015) in their language (§09.9).
- **AC3:** Roster + actual punches feed the exception engine: a worker who punches
  on a rostered weekly rest day generates **both** a substituted-rest-day obligation
  **and** an OT-wage line (AC1) — not an either/or (§09.5, §09.6, FR-OT-003).

**FR-SHF-003 — Auto shift detection. (P1)**
Where a worker is eligible for multiple shifts, the engine can infer the actual
shift from the first punch of the day against candidate shift windows.

- **AC1:** Auto-detection is deterministic (nearest-window rule), logged, and
  overridable by the supervisor; it is **not** an LLM decision.

**FR-SHF-004 — Holiday and weekly-off calendars, national/festival/state. (P0)**
Per-establishment calendars combine national holidays, state festival holidays
(National & Festival Holidays Acts, state-specific), and optional/floating
holidays. **[Hypothesis]** — downgraded from the [Verified] earlier drafts gave it:
the claim that three national holidays (Republic Day, Independence Day, Gandhi
Jayanti) are near-universally mandatory under the state N&F Holidays Acts was not
re-captured in research, so it is carried, not verified. The count and list of
national and festival holidays per state per year, and any substitution rule, are
effective-dated, gazette-sourced data — kill/validate via the annual
gazette-sourced calendar refresh (§09.14-A6, the §22 compliance data pipeline);
do not ship a static national holiday list.

- **AC1:** A punch on a holiday classifies the day as holiday-worked → comp-off/OT
  candidate per policy.
- **AC2:** Floating/optional holidays are worker-selectable up to a configured
  count per year, with balance tracking.

**FR-SHF-005 — Night-shift rostering with the women-at-night consent gate. (P0
for frontline, where women work night shifts)**
The OSH&WC Code **permits women to be employed in all establishments including at
night** (before 06:00 or after 19:00), a change from the prior blanket bar — but only with
the woman's **consent** and subject to notified safety, transport and dignity
conditions. **[Verified]** the Code lifts the blanket prohibition and makes
night-work conditional on consent and safeguards (Source: OSH Code s.43, read via
the MoLE Compliance Handbook, r3). **[Hypothesis]** the exact safeguard checklist
(minimum group size, employer-provided transport, on-site facilities) is set by
*state* rules and must be effective-dated per state; kill/validate via the
§09.14-A1 state dataset.

- **AC1:** Rostering a worker flagged female into a night window requires a
  recorded, revocable consent artefact effective for the period; a night roster
  without valid consent is blocked, not merely warned.
- **AC2:** Night-shift assignment carries the safeguard-checklist state (transport
  arranged, minimum-group met) as roster metadata so an inspection query can be
  answered from the register, not reconstructed.
- **AC3:** Consent is time-bounded and withdrawable; withdrawal takes effect
  forward from its effective date and is audited (never retro-alters past rostered
  nights already worked).

---

### 09.5 The attendance processing engine — punch → worked hours → status

<!-- DIAGRAM: punch-pairing-state-machine -->

**FR-ATT-020 — Deterministic punch pairing. (P0)**
The engine pairs raw punches into work sessions, infers `AUTO` direction, handles
odd punch counts (missing in/out), overnight shifts crossing midnight, and
multiple in/out pairs (break punching), producing total worked hours per shift-day.

- **AC1:** An overnight shift (e.g. 22:00–06:00) attributes worked hours to the
  correct pay date per the shift's anchoring rule, not split arbitrarily at
  midnight.
- **AC2:** An odd/missing punch produces a **defined exception** (`missing-out`,
  `missing-in`) routed to regularization (§09.8) — never a silent zero and never a
  silent full day.
- **AC3:** Multiple break punches sum correctly against paid/unpaid break rules
  (FR-SHF-001).
- **AC4:** The pairing algorithm is deterministic and unit-tested against a fixed
  corpus of pathological punch sequences; identical input → identical output.

> **The pathological-sequence corpus (AC4).** These are the cases every Indian
> attendance engine gets wrong at least once; each must have a *defined,
> deterministic* outcome, and none may silently produce a full or zero day. Shift
> = general 09:00–18:00, 1 h unpaid lunch, grace 10 min, unless noted.
>
> | # | Raw punches (device-local) | Correct outcome |
> | --- | --- | --- |
> | 1 | IN 09:05 · OUT 18:02 | Present, 8.0 h (grace absorbs 09:05; 1 h lunch deducted) |
> | 2 | IN 09:05 (no OUT) | `missing-out` exception → regularization; **never** auto-full-day, **never** zero |
> | 3 | OUT 18:00 (no IN) | `missing-in` exception → regularization |
> | 4 | IN 09:00 · IN 09:01 · OUT 18:00 | Dup IN de-duped on `payload_hash`; paired 09:00–18:00 |
> | 5 | IN 13:30 · OUT 22:15, night shift 13:30–22:00 anchored to *start* date | 8.0 h to the 13:30 date; 15 min post-shift → OT candidate |
> | 6 | IN 22:00 · OUT 06:15 (crosses midnight) | Worked hours anchored to shift-start pay date (AC1); not split at 00:00 |
> | 7 | IN 09:00 · OUT 12:00 · IN 12:20 · OUT 18:00 | Two sessions; break 12:00–12:20 (20 min) < 60 min lunch rule → break handling per FR-SHF-001 AC2 |
> | 8 | AUTO 09:03 · AUTO 13:00 · AUTO 13:40 · AUTO 18:05 (device gives no direction) | Ordered by time, alternated IN/OUT/IN/OUT; direction inferred at pairing |
> | 9 | IN 08:40 (before shift) · OUT 18:50 | Early-in not counted unless pre-approved OT; late-out → OT candidate per policy |
> | 10 | IN 09:00 device clock +47 min fast (FR-DEV-003) | Skew-corrected before pairing; corrected time used, raw retained |

**FR-ATT-021 — Day-status derivation and LOP. (P0)**
From worked hours, shift, leave ledger, roster and calendar, the engine derives
the day status and computes **loss-of-pay (LOP) days** and **paid days** for the
period — the figures payroll reconciles every challan against.

- **AC1:** Half-day, full-day-present, absent, on-leave (paid), on-leave (LOP),
  weekly-off, holiday, and on-duty (OD) are each derivable and mutually consistent
  for every calendar day of the period.
- **AC2:** Paid-days + LOP-days + weekly-offs + holidays reconcile exactly to the
  calendar days of the period for every employee (no gaps, no double counts) — a
  hard invariant checked before payroll lock.
- **AC3:** Sandwich-leave / prefix-suffix rules (whether a weekly-off/holiday
  bracketed by absence counts as LOP) are policy-configurable per tenant and
  clearly labelled where applied. **[Hypothesis]** sandwich rules have no single
  statutory basis and are contract/policy driven; default to *not* sandwiching
  unless the tenant opts in.

> **Worked example — the paid-days invariant (AC2) and why sandwich policy moves
> money.** September 2026 has 30 calendar days. A worker's month: 22 present, 4
> weekly-offs (Sundays), 1 festival holiday (from the state calendar), 1 EL (paid), and
> is **absent without leave** on Sat 12th and Mon 14th, with Sun 13th being a
> weekly-off in between.
>
> | Bucket | Sandwich OFF (default) | Sandwich ON (tenant opt-in) |
> | --- | --- | --- |
> | Present | 22 | 22 |
> | Paid leave (EL) | 1 | 1 |
> | Weekly-off | 4 | 3 |
> | Holiday | 1 | 1 |
> | LOP (unpaid) | 2 (12th, 14th) | 3 (12th, **13th**, 14th) |
> | **Total** | **30** ✓ | **30** ✓ |
>
> Both configurations satisfy the hard invariant (`paid + LOP + off + holiday =
> 30`), but the sandwiched Sunday moves the paid-days count from 28 to 27 — a full
> day's pay, and a different EPF/ESI/PT wage base for the month. This is exactly
> why sandwich behaviour is (a) explicit config, (b) labelled where applied, and
> (c) defaulted OFF absent a statutory mandate: it is a pay decision dressed as a
> calendar rule, and it must reconcile identically either way.

**FR-ATT-022 — Exception dashboard and pre-lock reconciliation. (P0)**
Before a period locks, admins see every unresolved exception (missing punches,
unmapped device users, low-confidence geo, offline devices, un-actioned
regularizations) and cannot lock until each is resolved or explicitly waived with
a reason.

- **AC1:** Locking with open exceptions is blocked; a forced lock requires a
  logged reason and lists exactly which employees/days were affected.
- **AC2:** The dashboard is filterable by site, supervisor, exception type, and
  age.
- **AC3:** Exceptions raised by a **[Hypothesis]** rule — the quarterly OT ceiling,
  spread-over, rest interval — are **warning-class**: listed, never lock-gating
  (§06.12 R17).

---

### 09.6 Overtime, per the notified Rules

Overtime is where attendance meets the wage engine most sharply. The multiplier and
the normal hours are verified; the quarterly ceiling is not.

**FR-OT-001 — Overtime computed at the statutory multiplier; quarterly ceiling warn-only. (P0)**
**[Verified]** Overtime is paid at **not less than twice the normal rate of
wages** — s.14's own words, "for every hour or for part of an hour so worked in
excess" (Code on Wages s.14, read verbatim, r1; MoLE Compliance Handbook, r3) — against normal hours of
**8 a day where the wage period is daily and 48 a week otherwise** (Wages (Central)
Rules 2026 r.5, per the PRS review, r3). **[Reversed]** Earlier drafts marked a
ceiling of 144 overtime hours per quarter as Verified and built blocking acceptance
criteria on it. It is reported only by secondary summaries of the Central Rules
(r2), has never been confirmed against gazette text, and may sit in the OSH rules
rather than the Wages rules (r3 critic). It is now **[Hypothesis]** (K-04): the
product may warn on it and must never block (§06.12 R17); the figure is routed to
§20 V-17 (§09.14-A13).

- **AC1:** Hours beyond normal hours accrue as OT at 2×. The statutory test follows
  the employee's wage period (daily → per day; otherwise → per week); a tenant basis
  (daily, weekly, or the greater-of) may be more generous, never less, and never
  double-counts the same hour.
- **AC2:** The quarterly ceiling is parameter `ot_quarterly_ceiling_hours`
  (hypothesised value 144, K-04), effective-dated per jurisdiction. The engine
  tracks OT per worker per quarter and raises an **advisory** warning at
  configurable thresholds. It never blocks a punch, a roster publication, an OT
  approval, a pay run or a filing, and it never suppresses OT wages for hours
  actually worked.
- **AC3:** OT hours are exported to payroll **split by multiplier band** as a
  distinct, labelled component, never folded into another head. OT is an excluded
  head under s.2(y) — outside "wages", but counted in the 50% test, so a heavy-OT
  month can trigger or raise the add-back (§06.10 counter-case; Code on Wages
  s.2(y) / CoSS s.2(88)).
- **AC4:** The "normal rate of wages" used for the 2× is the statutory OT base,
  which may differ from the add-back base and the equal-pay base — the engine
  requests the correct base from the multi-base wage service (§06.10, §08) and does
  not compute its own. **[Verified]** at least four concurrent wage bases per
  employee per period exist (§06.10; Code on Wages s.2(y) / CoSS s.2(88)).
- **AC5:** The **daily vs weekly OT tests do not double-count the same hour.** The
  engine computes OT once under the tenant's configured basis and, where "greater-of"
  is set, takes the larger of the two aggregations for the period — never their sum.

> **Worked example — OT in rupees, and the no-double-count rule.** A press-shop
> operator on a monthly wage period (statutory test: weekly, AC1; the tenant has
> configured greater-of): monthly statutory OT base (normal rate of wages, per §06) = ₹26,000
> (illustrative) on the Wages Rules' daily × 26 and daily ÷ 8 conversions (r1, r3)
> → normal hourly rate = ₹125.00 (₹26,000 ÷ 26 ÷ 8). OT
> rate at 2× = **₹250.00/h**.
> - **Week under test:** Mon–Sat, 6 days, punches yield 9 h, 9 h, 10 h, 8 h, 8 h,
>   9 h = **53 worked hours**.
> - **Daily basis:** hours over 8/day = 1 + 1 + 2 + 0 + 0 + 1 = **5 OT hours**.
> - **Weekly basis:** hours over 48/week = 53 − 48 = **5 OT hours**.
> - **Greater-of:** max(5, 5) = **5 OT hours** — *not* 10. Paying both aggregations
>   would double-count the same overtime hours; AC5 forbids it. OT pay = 5 × ₹250 =
>   **₹1,250**, handed to payroll as a distinct labelled component that counts as
>   an excluded head in the s.2(y) 50% test (AC3).
> - **Ceiling check (advisory):** those 5 h are added to the worker's quarterly
>   total and compared with `ot_quarterly_ceiling_hours` (hypothesised 144, K-04).
>   At, say, 120 h already booked, adding 5 crosses a configured warning threshold
>   and warns the site admin before the next roster is published. It is a warning
>   only: nothing is blocked, and every hour worked is paid (AC2, §06.12 R17).

**FR-OT-002 — Overtime requires eligibility and (optionally) pre-approval. (P0)**
Not every worker is within the statutory OT provision (its scope is set by the Code
on Wages, §06), and many tenants require OT to be pre-authorized to control cost.

- **AC1:** OT eligibility is an employee-master attribute; ineligible workers'
  excess hours do not generate OT pay (they may still generate comp-off per policy).
- **AC2:** Where pre-approval is enabled, unapproved excess hours are held as
  `OT-pending` until decided (§09.8 workflow), and every pending item is decided
  before lock (FR-ATT-022). A rejection carries a recorded reason; hours the record
  shows as worked are never dropped from OT pay by default (FR-OT-001 AC2).

**FR-OT-003 — Comp-off credit, never a substitute for statutory OT wages. (P1)**
**[Reversed]** Earlier drafts let comp-off replace cash OT and made the two
mutually exclusive. For an employee within the Code on Wages OT provision, hours
beyond normal hours earn OT wages at not less than twice the rate (s.14), and work
on a weekly rest day earns **both** a substituted rest day **and** OT wages (FR-SHF-002
AC1). Comp-off therefore applies only (a) to employees outside the OT provision
(FR-OT-002 AC1), (b) as a tenant benefit on top of OT pay, or (c) to holiday work
where the state holiday rule allows a substitute day **[Hypothesis — per state]**.

- **AC1:** Comp-off is credited to the leave ledger (§09.7) with an expiry (tenant
  policy parameter `compoff_expiry_days`; a policy term, not a statutory value), and
  its grant is auditable back to the specific worked day.
- **AC2:** For an employee within the OT provision, a comp-off credit never reduces
  the OT-wage line for the same hours; a policy that would do so is rejected at
  configuration time.

**FR-OT-004 — "The variable, not the constant" applies here too. (P0)**
The 2× multiplier, the wage-period normal hours and the [Hypothesis] quarterly
ceiling are **effective-dated configuration**, not hard-coded constants — because the statute permits "such
other per cent/limit as may be notified" and because state OSH rules diverge.
Mirrors §06's standing justification for effective-dating.

- **AC1:** A future notification changing the multiplier, the normal hours or the
  ceiling is applied by effective date; a retro run recomputes prior periods against
  the *then-current* value, not the new one.

**FR-OT-005 — Deterministic worked-hour and OT rounding. (P0)**
Rounding moves rupees and moves challans, so it cannot be an implicit
implementation choice. Worked minutes and OT minutes round by an explicit,
auditable, effective-dated rule.

- **AC1:** Rounding granularity (per punch-pair, per day, or per period) and
  direction are configuration, not hard-coded; the default reckons worked time to
  the minute and never silently rounds OT *down*. Code on Wages s.14 pays overtime
  "for every hour or for part of an hour" worked in excess (r1), so a configuration
  that discards fractional OT is rejected unless a published state rule for that
  jurisdiction supplies the block (AC2).
- **AC2:** **[Hypothesis]** some state OSH/Factories rules may reckon overtime in
  fixed blocks or set a minimum OT spell below which no OT is payable (parameters
  `ot_block_min` and `ot_min_spell_min`, empty until a state rule is read);
  effective-date per state and kill/validate via the §09.14-A1 state
  dataset — do **not** assume minute-level OT nationally, and check for a
  corrigendum (§02 standing rule).
- **AC3:** The rounding rule applied at recompute/retro is the version in force for
  the period; a period reprinted after correction rounds byte-identically (CC-1).

---

### 09.7 Leave policies & the accrual engine

<!-- DIAGRAM: leave-ledger-double-entry -->

**FR-LV-001 — Configurable leave-type catalogue with statutory + policy types. (P0)**
The tenant configures leave types, but the catalogue ships with the Indian
statutory and common-practice set pre-modelled: Earned/Privilege Leave (EL/PL),
Casual Leave (CL), Sick Leave (SL), Maternity Leave (ML), Compensatory Off,
Leave Without Pay (LWP), and policy types (bereavement, marriage, paternity —
non-statutory in the private sector, tenant-optional).

- **AC1:** Each leave type carries: accrual rule, opening balance, carry-forward
  cap, encashment rule, min/max application units (full/half/quarter day, hours),
  eligibility (post-confirmation? tenure gate?), documentation requirement (e.g.
  medical certificate over N days of SL), and paid/unpaid flag.
- **AC2:** Statutory minimums act as **floors**: a tenant policy that grants below
  a state statutory minimum is flagged, not silently accepted (compliance-by-default).

**FR-LV-002 — Earned-leave accrual per statute, effective-dated per state. (P0)**
**[Hypothesis]** The OSH&WC regime provides annual leave with wages, recorded in
the OSH **FORM-XX** register of leave with wages (OSH r.76(1), r5) — but the
accrual ratio (days worked per day of leave, adult and young-worker variants), the
eligibility threshold, the carry-forward cap, the encashment rule and the
calendar-vs-worked-day basis have **not** been read from the Code or its rules in
research, and state rules may differ. **[Reversed]** Earlier drafts stated a ratio
and a carry-forward cap as OSH figures with a section citation; neither was captured
in research, so none ships. They are parameters `el_worked_days_per_day_adult`,
`el_worked_days_per_day_young`, `el_eligibility_min_days`,
`el_carry_forward_cap_days`, `el_encashment_rule` and `el_worked_day_definition`,
effective-dated per (state, sphere, establishment type), **empty until populated**
through the §22 pipeline from the Code/Rules text or a state gazette, with a
corrigendum check (§09.14-A1). State S&E Acts continue alongside the Codes and may
impose their own leave grants (r1: S&E laws are not superseded by the Codes), so an
establishment may carry an S&E-Act rule and an OSH rule at once. Where they differ
the engine computes both and shows the difference; which prevails is a counsel
question (§23), and until it is answered the default grants the more generous so
that no worker is under-granted (FR-LV-001 AC2).

- **AC1:** Accrual runs on a defined cadence (monthly proportional, or on
  crossing the worked-day threshold) and is effective-dated by state and
  establishment type. A jurisdiction whose parameters are empty accrues nothing
  automatically and shows `accrual-rule-missing` on the pre-lock dashboard as a
  warning — the tenant may run a policy accrual meanwhile, labelled as policy.
- **AC2:** Carry-forward at year-end caps at the configured limit; excess is
  encashed or lapses per policy, with a ledger entry either way.
- **AC3:** Changing a state's accrual rule (new notification) recomputes accruals
  from the effective date forward, with an audit trail; it does **not** silently
  restate past balances.
- **AC4:** The ledger renders the FORM-XX leave-with-wages register per
  establishment, and an employee can obtain their own leave record on demand — OSH
  r.76(1) requires the employer to share it "once in a Calendar year, on demand"
  (r5). The self-service surface serves it at any time; the audit trail records
  each request so the statutory minimum is evidenced.

> **Worked example — EL accrual, with illustrative parameter values.** Suppose a
> state's published rule sets `el_worked_days_per_day_adult` = 20 and
> `el_worked_days_per_day_young` = 15 (**illustrative values only** — earlier
> drafts carried them, research has not captured them, and they must not ship). A
> worker completes **250 days actually worked** in the leave year. Accrual =
> 250 ÷ 20 = **12.5 days**; for a young worker, 250 ÷ 15 = 16.67. Two design traps
> the engine must handle deterministically: (a) **what counts as a "worked day"**
> (`el_worked_day_definition`) — paid holidays, weekly-offs and paid leave may be
> *excluded* from the numerator under a worked-day method and *included* under a
> calendar-day method, so the numerator definition is state/establishment config,
> not a constant; (b) **rounding** — the fractional entitlement (12.5, 16.67) is
> rounded by the rule's own rounding term, or by tenant policy where the rule is
> silent, and the rounding rule applied is on the ledger entry. Carry-forward then
> caps the closing balance at `el_carry_forward_cap_days`, encashing or lapsing the
> excess with a ledger entry either way (AC2).

**FR-LV-003 — Maternity, and other protected leaves. (P0)**
**[Verified]** Maternity benefit is Chapter VI of the Code on Social Security 2020,
applying to factories, mines and plantations and to every shop or establishment
with ten or more employees on any day of the preceding twelve months — it latches
(CoSS First Schedule, §06.1; r1). Read verbatim from the Code (r1): **six weeks'**
leave for miscarriage or medical termination of pregnancy and **two weeks** after a
tubectomy (s.65); **two nursing breaks** a day until the child is fifteen months old
(s.66); and a medical bonus of ₹3,500 or a notified amount, payable only where the
employer provides no free pre-natal confinement and post-natal care (s.64 — a
payroll component, §08/§11, signalled from here). The headline entitlement of
**26 weeks** at **80 days'** qualifying service is carried from r3's summary and is
consistent with CoSS s.54's 26-week ceiling on maternity leave counted toward
gratuity (r1) — re-read Ch. VI before customer use. **Not captured in research:**
the pre-natal share of the 26 weeks, the reduced entitlement for a third or later
child, the adopting and commissioning-mother variants, the look-back window for the
80 days, and the Ch. VI section numbers for each. **[Reversed]** Earlier drafts gave
all of these as figures with a legacy Maternity Benefit Act section number; they
are now parameters — `ml_weeks_standard`, `ml_prenatal_max_weeks`,
`ml_weeks_by_parity`, `ml_weeks_adoption`, `ml_weeks_commissioning`,
`ml_adoption_child_max_age`, `ml_qualifying_days`, `ml_qualifying_window` — each
populated from the Ch. VI text with its citation through the §22 pipeline
(§09.14-A15). The leave engine models ML as a special paid type with its own
eligibility and its ESI interaction (an ESI-covered woman draws maternity benefit
from ESIC, not from the employer, §06.3 — the engine must not double-pay).

- **AC1:** ML application blocks LOP/absence logic for the covered weeks and
  correctly signals payroll whether the employer pays or ESIC pays, per coverage.
- **AC2:** The entitlement variant (standard, by parity, adoption, commissioning) is
  derived from the employee's dependant/child records (§07 core HR, §11 benefits
  data model), not typed free-hand, so the entitlement is defensible. Until the
  variant parameters are published, a non-standard case raises a
  `maternity-variant-unconfigured` exception for HR to decide and record — the
  engine never guesses a shorter entitlement.
- **AC3:** **[Hypothesis]** The ESI-side treatment post-22 Nov 2026 is unresolved
  (the ESI regime after the one-year saving is the open statutory question, §06.13;
  gated in §20 V-08) — the ML↔ESI rule is effective-dated so it
  can be re-pointed when ESIC notifies. Kill/validate via the §09.14-A2 primary-
  source watch on ESIC/MoLE; until it resolves, the employer-vs-ESIC pay split is a
  configurable effective-dated rule, never a hard-coded assumption.
- **AC4:** Miscarriage/MTP leave (six weeks), post-tubectomy leave (two weeks) and
  nursing breaks (two, until the child is fifteen months old) are distinct leave or
  time-off types with their own ledger entries (s.65, s.66; r1). A nursing break is
  never treated as an unpaid break, a late-in or LOP by the pairing engine
  (FR-ATT-020); its duration and pay treatment are parameters
  (`nursing_break_min`, `nursing_break_paid`) populated from the Ch. VI text and
  rules, empty until then (§09.14-A15).

**FR-LV-004 — Leave balance is a double-entry, recomputable ledger. (P0)**
Every accrual, application, cancellation, encashment, lapse, comp-off credit and
adjustment is a ledger transaction; the balance is the sum, never a stored mutable
counter.

- **AC1:** Balance at any past date is reconstructable by replaying the ledger to
  that date.
- **AC2:** A cancelled/rejected leave reverses cleanly (compensating entry), and
  the net effect is auditable.
- **AC3:** Opening balances imported at migration (§14; migration is P0) are tagged
  `opening` and reconcile to the prior system's closing balance; discrepancies are
  surfaced, not absorbed.

**FR-LV-005 — Leave application, approval and holiday-aware validation. (P0)**
Workers apply for leave (app/web/kiosk/WhatsApp); the system validates against
balance, notice period, blackout dates, overlap, and team-availability limits,
then routes for approval (§09.8).

- **AC1:** An application exceeding balance is either blocked or allowed as
  LWP/negative-balance per policy — the outcome is explicit and shown to the
  worker in their language.
- **AC2:** Weekly-offs and holidays inside a leave span are handled per the
  sandwich policy (FR-ATT-021 AC3) consistently.
- **AC3:** A worker on the frontline with no smartphone can have leave applied on
  their behalf at the kiosk or by the supervisor (FR-ATT-016), preserving the
  approval trail.

**FR-LV-006 — Leave encashment and Full-and-Final interaction. (P1)**
Unused encashable leave is valued and passed to payroll for periodic encashment
and for Full-and-Final settlement on exit.

- **AC1:** Encashment value uses the correct wage base from §06 (not a local
  computation) and appears as a labelled payroll component.
- **AC2:** On exit, the leave ledger closes to zero via encashment/lapse entries;
  the F&F statement reconciles to the ledger.

**FR-LV-007 — Casual and Sick leave to state S&E floors, ESI-aware. (P0)**
Unlike earned leave (leave with wages under the OSH&WC regime, FR-LV-002), **Casual
Leave (CL) and Sick Leave (SL) are largely Shops & Establishments Act creatures and
vary by state** — state S&E laws are not superseded by the Labour Codes and overlap
them on leave (r1). **[Hypothesis]** the count, whether CL and SL are separate or a
combined pool, carry-forward and documentation thresholds diverge by state.
**[Reversed]** Earlier drafts gave a typical annual CL/SL figure and attributed
variants to named states; research captured no state S&E leave grant, so no figure
ships. Parameters `cl_days_per_year`, `sl_days_per_year`, `cl_sl_pooled`,
`cl_carry_forward_cap`, `sl_carry_forward_cap` and `sl_certificate_after_days` are
effective-dated per (state, establishment type), empty until gazette-sourced per
state through the §22 pipeline; kill/validate via the §09.14-A1/A12 state dataset
(carries a per-state kill criterion).

- **AC1:** CL/SL entitlements are configured per state S&E-Act floor and act as
  **floors** (FR-LV-001 AC2): a tenant policy below the state minimum is flagged,
  not silently accepted.
- **AC2:** SL documentation (medical certificate over N continuous days) is a
  per-type config with the threshold auditable; a short-leave / half-day SL unit is
  supported (FR-LV-001 unit field).
- **AC3:** **ESI interaction — no double pay.** For an ESI-covered worker, a
  certified sickness spell draws **sickness benefit from ESIC** (subject to any
  waiting period — parameter `esi_sickness_waiting_days`, not captured in research,
  populated from the ESI regulations through the §22 pipeline), so the employer's SL
  policy must not also pay for the same ESI-compensated days beyond what policy tops
  up. **[Verified]** sickness benefit is among the ESI benefits administered by ESIC
  (§06.3; Code on Social Security 2020, which repealed the ESI Act 1948; the ESI
  (General) Regulations 1950 continue under the CoSS saving provisions, and their
  position after 22 Nov 2026 is the open question below — §06.13).
  **[Hypothesis]** the exact ESI sickness treatment
  after 22 Nov 2026 is unresolved (same open question as FR-LV-003 AC3) — the
  employer-vs-ESIC split is effective-dated, killed/validated via §09.14-A2.

> **Worked example — CL half-day and the SL/ESI overlap.** A worker takes a
> **half-day CL** (0.5 unit) on the 10th and is **certified sick 20th–24th** (5
> days). CL ledger debits 0.5; SL ledger debits 5. If the worker is ESI-covered and
> the 20th–24th spell clears `esi_sickness_waiting_days`, ESIC pays sickness benefit for
> the qualifying days — so the *paid-days for payroll* on those days are marked
> **ESI-borne, not employer-borne**, and the engine must not credit employer SL pay
> on top unless the tenant runs an explicit top-up policy (AC3). The 0.5 CL day, by
> contrast, is fully employer-paid and does **not** reduce paid-days. Both ledgers
> reconcile independently, and the paid-days invariant (FR-ATT-021 AC2) still holds
> for the month.

---

### 09.8 Regularization & approval workflows

Regularization is the release valve that keeps attendance correct without turning
every missing punch into an LOP dispute. It is also, done well, a major deflection
and satisfaction lever for the frontline.

**FR-REG-001 — Employee-initiated regularization for exceptions. (P0)**
A worker (or supervisor on their behalf) can raise a regularization for a missing
punch, wrong shift, geo-flag, or on-duty/field day, attaching a reason and
optional evidence, routed to the configured approver.

- **AC1:** Every regularization names the specific date(s) and the exact before/
  after status/hours it proposes; approval applies exactly that, recomputes the
  day (FR-ATT-001), and writes the audit entry.
- **AC2:** A regularization cannot alter a locked period except via the retro run
  (FR-ATT-001 AC3).
- **AC3:** SLA/aging: un-actioned regularizations are visible to the next-level
  approver and block period-lock if unresolved (FR-ATT-022).

**FR-REG-002 — Configurable multi-level approval chains. (P0)**
Approval routing supports role-, hierarchy-, and site-based chains, delegation
(approver on leave), and auto-approval/auto-escalation on timeout, all
effective-dated.

- **AC1:** A change to the approval chain does not retro-alter the approver
  recorded on already-decided requests.
- **AC2:** Delegation is time-bounded and audited (who delegated to whom, when).

**FR-REG-003 — On-duty / field-work regularization. (P0 for field/deskless)**
Field staff who never touch a terminal mark on-duty (client visit, delivery route)
which counts as present without a site punch, subject to approval and optional
geo-trail.

- **AC1:** OD days are distinct from present-by-punch in the register and can be
  reported on separately (auditors and clients ask); they populate Form IX column
  (10), "brief details of tour or assignment outside the work place" (EV-055).

**FR-REG-004 — Bulk regularization for site-level events. (P0)**
When a terminal was down for a day or a whole shift was misrostered, a supervisor
regularizes many workers at once with one reason, individually auditable.

- **AC1:** A bulk action expands to per-employee ledger entries each carrying the
  shared reason plus the individual before/after — no aggregate-only records.

**FR-REG-005 — AI-assisted, human-decided. (P1)**
The assistant may draft a regularization from context (device-down window + the
worker's usual pattern), pre-fill the reason in the worker's language, and rank an
approver's queue — but the **decision and the resulting hours are human/rules
outputs**, never model-generated (§12). This is a deflection lever consistent with
"AI is cost-of-goods, not the revenue line" (§13).

- **AC1:** Any AI-drafted regularization is clearly labelled as a draft and
  requires explicit human submission and approval; the model never writes to the
  ledger directly.

---

### 09.9 Frontline / deskless constraints

These are not accessibility footnotes — they are the difference between winning
and losing the 50–200 revenue-core deals, which are disproportionately
manufacturing, retail, logistics and hospitality.

<!-- DIAGRAM: offline-capture-sync -->

**FR-DSK-001 — Offline-first capture. (P0)**
The mobile and kiosk apps capture punches and leave applications **offline**,
queue them durably on-device, and sync on reconnect with conflict-safe
reconciliation. Low-connectivity plant floors, basements, and rural sites are the
norm, not the exception.

- **AC1:** A punch made with no network is not lost; it syncs and is timestamped
  with the *capture* time (device-local + skew-corrected), not the sync time.
- **AC2:** The worker gets local confirmation of a successful offline punch (they
  will not trust an app that shows nothing).
- **AC3:** Sync is bandwidth-frugal (deltas, compressed) for 2G/3G and metered
  connections.

**FR-DSK-002 — Shared-device identity separation. (P0)**
On any shared device (kiosk, supervisor phone), no worker can view or modify
another worker's attendance, balance, payslip or personal data. Reinforces
FR-ATT-013. **[Verified]** worker identity ≠ device identity is the structural
reason (Source: Draft 1, verified).

- **AC1:** Each interaction on a shared device is scoped to the single authenticated
  worker and clears on completion/timeout.

**FR-DSK-003 — Vernacular UI, worker-facing surfaces. (P0)**
All worker-facing screens, prompts, notifications and the WhatsApp flow render in
the worker's chosen language (at minimum Hindi + the major state languages —
Marathi, Tamil, Telugu, Kannada, Bengali, Gujarati; expandable). Admin/CA
surfaces may remain English.

- **AC1:** Language is a per-worker setting, defaulting from establishment state,
  changeable by the worker at the kiosk without an admin.
- **AC2:** Static UI strings are professionally localized (not machine-translated);
  **[Hypothesis]** dynamic assistant text may be model-translated but statutory/
  monetary values in it are rendered by the deterministic engine, not the model
  (§12). Kill if worker comprehension testing shows model-translated statutory
  terms cause errors — then move those to reviewed static strings.
- **AC3:** Numerals, dates and currency render in Indian conventions
  (DD-MM-YYYY, lakh/crore where appropriate).

**FR-DSK-004 — Low-literacy and low-friction interaction. (P1)**
Frontline flows minimize typing: icon-driven punch, employee-code + selfie,
voice-note reasons for regularization, and confirmation by clear visual/haptic
signal rather than text.

- **AC1:** The core punch is completable in ≤ 2 taps by a first-time user without
  training.

**FR-DSK-005 — Worker-initiated engagement, rate-aware. (P0)**
No frontline onboarding flow assumes employer-push reach. **[Verified]** WhatsApp
cold-start is 250 unique users / 24 h (FR-ATT-015); onboarding sequences a large
site over days and prefers worker-initiated pull (poster QR at the gate, kiosk
enrolment) over broadcast (Source: Draft 1, verified).

- **AC1:** A 500-worker site can be fully onboarded without ever requiring a
  same-day broadcast to all 500.

**FR-DSK-006 — Terminal-first for frontline, by design. (P0 posture)**
For frontline segments, terminal (ADMS push) capture is treated as the primary,
most-reliable path precisely because device ≠ worker identity and connectivity is
weak — the mobile app is complementary, not a replacement. This is why FR-DEV-001
is P0 and non-negotiable for these accounts. Terminal-first is not biometric-first:
card and PIN at the terminal are first-class, and each worker's method is their own
election (FR-ATT-017 AC3).

---

### 09.9-A Contract labour & principal-employer attendance

The revenue-core beachhead is precisely the segments that run heavily on
**contract labour** — auto-components lines, 3PL warehouses, QSR kitchens,
hospitality housekeeping. Ignoring it loses the deal, because the principal
employer's *own* statutory exposure depends on the contractor's attendance and
wage discharge. **[Verified]** the Contract Labour (Regulation & Abolition) Act
1970 is subsumed into the OSH&WC Code, which continues the principal-employer /
contractor / contract-workman construct; the CLRA Central Rules 1971 are superseded
by the OSH (Central) Rules 2026 (r5). **[Reversed]** Earlier drafts said the register
duties continue. The central rules prescribe **no** Register of Contractors or
Register of Workmen; the principal employer's surviving duties are an **annual
return in FORM-XVII Part III** (r.98(9)) and a **wage guarantee**: if the contractor
has not paid within seven days of the end of the wage period, the principal pays
within fifteen days and recovers from the contractor (r.98(8)) (r5, central
sphere). **[Verified]** the applicability threshold is **50 or more** contract
labour on any day of the preceding twelve months, raised from 20, and it latches
(OSH Code s.45, central-sphere text, EV-057, §06.1); the Code itself makes the
principal liable to pay if the contractor short-pays or delays (s.55, per the MoLE
handbook, r3), which r.98(8) operationalises. State-sphere values, forms and the counting
unit are per-state configuration **[Hypothesis]** — validate per state gazette
(§09.14-A9) and check for a corrigendum.

<!-- DIAGRAM: contract-labour-attendance -->

**FR-CL-001 — Model contractor, contract-workman and principal-employer links. (P0
for manufacturing/logistics/hospitality beachhead)**
A worker record carries an **employment type** (`direct` / `contract`) and, when
contract, the contractor entity and its licence/registration reference
(`ContractorLink`, §09.1-A).

- **AC1:** The muster/attendance register distinguishes **direct vs contract**
  labour and can roll up **contractor-wise**, because inspection queries and the
  FORM-XVII Part III contractor-wise table ask exactly that. This is a view over
  Form IX, not a separate contractor register (the central rules prescribe none, r5).
- **AC2:** Contract-workman records are effective-dated so a workman moving between
  contractors, or converting to direct, keeps a clean attributed history.

**FR-CL-002 — Contractor capture with principal-employer read-visibility. (P1)**
Contractors punch their workmen through the *same* capture layer (ADMS/kiosk/app,
§09.2), but the principal employer receives **read visibility** to discharge its
wage guarantee under OSH r.98(8) (the principal pays if the contractor has not paid
within seven days of the end of the wage period).

- **AC1:** A per-contractor, per-period **attendance-vs-wage verification report**
  shows whether contract workmen present on the muster were paid at least the
  applicable minimum wage for those days, and flags the r.98(8) trigger when payment
  is not evidenced within seven days of the end of the wage period.
- **AC2:** The module supplies the attendance-derived input to the principal's
  FORM-XVII Part III annual return — the maximum number of contract labour employed,
  per contractor per month (r.98(9), r5). The return covers the calendar year ending
  31 December and is due, electronically, on or before the last day of the
  following February (r.98(9), central sphere, r5); the other columns of the
  contractor-wise monthly table — contractor name and address, contractor LIN, name
  of the work, amount paid against the wage bill — come from Core HR and payroll,
  not from this module. r.98(9) excepts a contract that undertakes to produce a given
  result; that exception is a per-contract flag on `ContractorLink`, set by the
  principal, never inferred. State-sphere forms are **[Hypothesis]**; validate per
  state (§09.14-A9).

**FR-CL-003 — Contract paid-days route to the correct EPF/ESI code. (P0)**
Contract workmen may sit under the **contractor's own EPF/ESI code** or under the
principal's, per the engagement; attendance-derived paid-days and NCP days
(§09.10-A) must route to the correct code and never merge into the principal's
returns by default.

- **AC1:** Paid-days and NCP days for contract workmen are attributable to the
  correct establishment/PF-and-ESI code for *that* entity's ECR/ESI filing (§06,
  §09.10-A), with the routing driven by `ContractorLink.pf_code / esi_code`.
- **AC2:** A misrouted contract-labour paid-day is a **hard reconciliation
  exception** before lock (FR-ATT-022), because it corrupts two establishments'
  challans at once.

---

### 09.10 The attendance register as a statutory filing output

**FR-STAT-001 — The registers this module feeds, electronic, retained per EV-054. (P0)**
**[Reversed]** Earlier drafts said the regime requires "four registers in electronic
form with five-year retention". **[Verified — central sphere]** The notified rules
prescribe **six employer registers plus a wage slip** across three rule-sets,
reduced to one canonical set by non-duplication provisions (EV-053, §06.9). This
module is the source for **Form IX** Attendance Register-cum-Muster Roll (Wages
r.51(1); OSH FORM-XIV is its equivalent), the overtime columns of **Form IV**, and
the OSH **FORM-XX** register of leave with wages (§09.7). Form numbers are per-state
configuration (EV-053). Retention (EV-054): "five years after the date of last entry"
(Wages r.51(4)) or "five calendar years from the date of last entry" (OSH
r.72(1)(vii), SS r.53(1)(e)); OSH r.76(2) bars destroying the leave register even
after five years unless it has been transferred to a new register; OSH r.72(4) and
SS r.53(3) add a three-kilometre location constraint. State-sphere periods are
unknown and go to counsel (§23).

- **AC1:** **Form IX** renders per establishment per month with **per-day IN and
  OUT timestamps** for days 1–31, shift, place of work, total days worked, total OT
  hours, and tour or outside-assignment details (EV-055). A present/absent or
  day-total rendering fails this AC; the time model therefore keeps per-day IN/OUT
  as retained fields (`FormIXRow`, §09.1-A), not values re-derived from erasable
  punches.
- **AC2:** Registers are **tamper-evident** (append-only source events; any
  correction is a new dated entry, never an overwrite) and retained under a
  retention rule keyed to (rule-set, sphere, state), counted from the date of last
  entry — central values from EV-054, state values populated by counsel, never
  below either.
- **AC3:** The OT columns carry OT hours actually worked. The quarterly ceiling is
  advisory and **[Hypothesis]** (FR-OT-001 AC2); the register is a record, never a
  cap enforcer.
- **AC4:** Register format is **effective-dated**: it follows the notified format
  for the period, and the format-selection rule latches per establishment as
  headcount thresholds are crossed (§06 obligation step function).
- **AC5:** **[Hypothesis]** State forms and layouts differ from the central forms;
  validate the notified form for each state/establishment before claiming
  inspection-parity, and check for a corrigendum (§02.4). Two Form IX points are
  unresolved and go to §20: how an electronic register satisfies the per-day
  signature row (the register-keeper signature is footnoted as needed only for a
  physical register), and how a day with several paired sessions fills the single
  IN/OUT cell (parameter `form_ix_multi_session_render`). The SS maternity schedule's
  "in ink" requirement for Form XXII contradicts its electronic permission (EV-054)
  — counsel (§23).

**FR-STAT-002 — Register content survives migration and retro. (P0)**
A register regenerated after a retro/arrears run reflects the corrected figures
*for that period* while preserving the audit trail of what changed.

- **AC1:** A period's register can be reprinted post-correction and the diff
  against the originally-filed version is retrievable.

---

### 09.10-A Attendance as a statutory-filing input — the downstream reconciliations

The section's thesis, made concrete: **attendance is not merely a filing itself
(the register, §09.10) — it is the input that decides five other filings.** A wrong
paid-days count is a wrong ECR, a wrong ESI eligibility flag, a wrong gratuity
year, a wrong maternity eligibility, and a wrong bonus eligibility. This is why
§12's rules-first invariant is absolute for these figures.

<!-- DIAGRAM: attendance-to-filing-map -->

| Attendance-derived quantity | Feeds this filing/right | Rule | Confidence |
| --- | --- | --- | --- |
| **Paid days + NCP (non-contributory) days** | EPF **ECR** (§06.2) | NCP days reduce the wage on which PF is due; "NCP Days" is field 10 of the 11-field ECR record | **[Verified]** (EV-035; EPF Scheme 2026) |
| **Days worked / wages in contribution period** | **ESI** half-yearly contribution & benefit eligibility (§06.3) | Contribution periods 1 Apr–30 Sep and 1 Oct–31 Mar, with benefit periods 1 Jan–30 Jun and 1 Jul–31 Dec; an employee crossing the wage ceiling mid-period keeps contributing to the end of that period; benefit eligibility is day-count driven | **[Verified]** (Source: esic.gov.in contribution-period table, captured Sep 2026, r1; the qualifying day-counts are parameters from §06.3) |
| **Continuous service (days worked / year)** | **Gratuity** accrual & payment (§06.6, §11.7) | "240 days in a twelve-month period" test (190 for underground mines or establishments working under six days a week; or 120 / 95 days in six months); counted days include lay-off, paid earned leave, temporary disablement from employment injury and maternity leave up to 26 weeks; seasonal establishments use a 75%-of-operating-days test | **[Verified]** (Source: CoSS s.54, read verbatim, r1; §06.6) |
| **4 years + 240 days → rounds to 5** | **Gratuity** *eligibility* | 4y240d treated as 5 completed years | **[Hypothesis]** case-law under the legacy Act, not on the bare Code; followed by some High Courts, not uniformly settled; the case citations earlier drafts gave are carried, not re-captured (§06.6); validate (§09.14-A10) |
| **80 days' qualifying service** within the look-back window `ml_qualifying_window` | **Maternity benefit** eligibility (FR-LV-003) | CoSS Ch. VI (section number not captured) | 80-day figure carried from r3's summary; window and section **[Hypothesis]** — §09.14-A15 |
| **30 days worked in the accounting year** | Statutory **bonus** eligibility (§06.7) | Code on Wages s.26 | **[Verified]** (Source: Code on Wages s.26, read verbatim, r1; §06.7) |
| **LOP / absent days** | Proportionate **payment of wages / minimum wages** (§06) | Paid-days is the pay base | **[Verified]** (Source: Code on Wages 2019) |

**FR-FIL-001 — Attendance publishes paid-days, NCP days and continuous-service
counters to every statutory consumer. (P0)**
There is a **single source of truth** for each derived quantity above; no consumer
re-derives its own paid-days from raw punches.

- **AC1:** NCP days are computed from `DayStatus` (LOP + unauthorised absence per
  EPFO's NCP definition, *not* every non-working day — weekly-offs and paid holidays
  are generally not NCP) and exported to the ECR service (§06.2) as field 10 of the
  ECR record (EV-035). **[Hypothesis]** the precise NCP inclusion list is
  EPFO-defined and occasionally re-clarified — EV-035 fixes the field, not its
  contents; validate against the current ECR help-file and check for a corrigendum
  (§09.14).
- **AC2:** A gratuity **continuous-service counter** is maintained per employee —
  the days CoSS s.54 treats as worked in each twelve-month period, including
  lay-off, paid earned leave, temporary disablement from employment injury and
  maternity leave up to 26 weeks (§06.6) — recomputable and audited, and handed to
  the benefits engine; the attendance module does not itself decide gratuity
  *quantum*.
- **AC3:** ESI **days-worked-in-contribution-period** and the maternity/bonus
  day-count flags are exported as labelled, recomputable figures; each is
  effective-dated against the rule version for the period (CC-3).

**FR-FIL-002 — Zero-attendance still files. (P0)**
A member with **zero paid days** in a period is a filing fact, not a skip: PF may
require a full-month NCP line, ESI a zero-wage treatment, and the register still
carries the worker. The absence of attendance must never become the absence of a
filing line.

- **AC1:** A zero-paid-days month produces the correct nil/NCP line for each
  statutory consumer (ECR, ESI) — the member is **never silently dropped** from a
  return, which is a common failure that triggers inspection queries. (This is the
  member case. An establishment with no active members uses no ECR file at all;
  its charges go through Direct Challan Entry — EV-042, §08.)
- **AC2:** A member on continuous long leave (e.g. maternity, extended sick) is
  carried with the correct paid/ESI-borne split (FR-LV-003, FR-LV-007) rather than
  disappearing from the period's filings.

---

### 09.11 Location & geo — a monetizable surface, flagged not built into base

**FR-LOC-001 — Geo-fence and route/location events as an opt-in, metered layer. (P1)**
Geo-fenced punching (FR-ATT-012) is base; **continuous live location tracking** is
a separate, opt-in, separately-metered capability. **[Verified]** greytHR *lists*
GPS Live Tracking as an add-on at **₹140/user/month**, available on Growth or
above, where the marginal seat rate is ₹85 (Essential's is ₹45) (Source: greytHR
pricing page, captured 4 Sep 2026 — documentation read, product not executed; r1).
**[Reversed]** Earlier drafts called this a 3.1× uplift by comparing it with
Essential's ₹45, a tier on which the add-on cannot be bought; against Growth it is
about 1.6×. **[Hypothesis]** that the add-on represents realisable margin for us —
no realised ARPU or willingness-to-pay is validated; route to §20 commercial
validation (§09.14-A5), and commit no location ARPU to any model until it reports.

- **AC1:** Live tracking is off by default, requires explicit tenant enablement and
  worker notice, and its usage is metered per user for billing (§13.9). DPDP s.7(i)
  is not in force until on or about 13 May 2027 (EV-058); continuous tracking raises
  the same least-intrusive-means question as biometrics, so its statutory basis is
  under counsel review (§23).
- **AC2:** Base geo-fence punching does **not** require the paid tracking layer —
  the free capability is not held hostage to the paid one.

---

### 09.12 Non-goals and anti-requirements for this module

Consistent with Draft 1's discipline of recording what was deliberately declined.

| Non-goal | Why | Source |
| --- | --- | --- |
| **Selling attendance hardware** | Devices are roughly ₹4,000–25,000 one-time (review-site guide, not a vendor price list), already installed, no margin/moat, direct channel conflict with dealers who could distribute for us | Draft 1 [No] "Hardware"; r2 |
| **In-house build for the device long tail** | Paid connectors at ~$345 one-time / $588-yr are cheaper than building for SDK-bound/pre-ADMS/air-gapped brands | FR-DEV-005 [Verified] |
| **Face-match as a hard pay gate** | An identity-model error must never become a wage-denial error (rules-first, LLM-last) | §12, FR-ATT-012 AC3 |
| **Model-generated worked hours / OT / leave balances** | Wrong numbers are legal, not UX, problems | §12 Verified |
| **Employer-push mass onboarding on WhatsApp** | 250 unique users / 24 h cold-start; broadcast-first onboarding is architecturally impossible day one | FR-DSK-005 [Verified] |
| **Sizing implementation from the 85–98% device-success figure** | Banned marketing number; integration effort is unsized pending a hardware spike (§20 V-10) | §20.4 [Killed] |
| **Full workforce-management / labour-optimization suite (demand forecasting, auto-scheduling optimization) in v1** | Beachhead needs correct capture + rosters, not WFM optimization; defer to expansion | Scope discipline, §05 |
| **Requiring — or building — Aadhaar biometric authentication for attendance** | Aadhaar auth needs a Parliamentary law or a prescribed purpose (s.4(4)); s.57 omitted 2019; the Good Governance (SWIK) route is per entity and per use case through a sponsoring Ministry, and attaches to the employer, not a horizontal SaaS — device templates ≠ Aadhaar auth | FR-ATT-017 [Verified], Aadhaar Act ss.4(4), 8; SWIK Rules r.3, as amended 31.1.2025 (r4) |
| **A "biometric only" configuration** | We are not aware of any Indian law requiring biometric attendance as of September 2026 (EV-072); shipping a hard-block setting would manufacture every customer's exposure (Part D-10) | FR-ATT-013 AC3, FR-ATT-017 AC3, §23 |
| **Marketing face-match — or any biometric method — as legally required or as settled-lawful** | Whether s.7(i) will reach biometric means is unresolved (§23); face-match stays advisory-only, never a pay gate | FR-ATT-017, §09.14-A8 |

---

### 09.13 Cross-cutting acceptance criteria (module-level)

These apply across every FR above and are the gates for the module's v1
"done."

- **CC-1 — Determinism:** Given a fixed event log and rule version, every derived
  figure (worked hours, OT bands, LOP, leave balance, register content) is
  reproducible byte-for-byte. No non-determinism from ingestion order, retries, or
  time-of-computation. Where an erasable class has been erased, replay returns the
  lock-time snapshot and says so (FR-ATT-001).
- **CC-2 — Rules-first invariant:** No worked-hour, overtime, leave-balance,
  encashment or paid-day value in any output originates from an LLM. Automated
  scan of the compute path confirms model outputs never write to these fields.
- **CC-3 — Effective-dating everywhere:** OT multiplier and the [Hypothesis] advisory ceiling, leave accrual, shift
  rules, holiday calendars, register formats and geo policies are all effective-
  dated per (state × sphere × establishment type) of the work location and
  retro-recompute against the version in force for the period, not today's.
- **CC-4 — Multi-tenant isolation:** No punch, roster, balance or register crosses
  a tenant boundary; device push endpoints are tenant-scoped and authenticated
  (FR-DEV-001 AC3).
- **CC-5 — Auditability:** Every state-changing action (punch ingest,
  regularization, approval, lock, retro, accrual, adjustment) writes an immutable
  audit entry with actor, timestamp, before/after, and rule version.
- **CC-6 — Frontline-first:** Every worker-facing flow works offline, on a shared
  device, in the worker's language, in ≤ 2 taps for the core action.
- **CC-7 — Filing integrity:** Attendance outputs reconcile exactly to the
  calendar (paid + LOP + off + holiday = period days) before payroll can lock, and
  registers are retained per EV-054 (central sphere: five years from last entry;
  state periods from counsel), tamper-evident.
- **CC-8 — Metering-from-v1:** Per-tenant/per-user usage of paid surfaces
  (location tracking, WhatsApp messaging, connector calls) is attributed from v1,
  while the price is still being discovered (§13.9).
- **CC-9 — Empty, never assumed:** A statutory parameter with no captured source
  (the `el_*`, `ml_*`, `cl_*`/`sl_*`, spread-over, rest-interval and OT-block
  parameters above) ships empty. The engine then raises a `rule-missing`
  warning-class exception for that jurisdiction and computes nothing from an
  assumed value; a tenant policy value may fill the gap only when labelled as
  policy on every output it touches (§06.12 R17, §22).

---

### 09.13-A Module KPIs and instrumentation

These are the observable signals that the module is doing its job — correctness
first (the filing thesis), then frontline adoption, then AI deflection. They feed
the §19 metrics section; targets are **[Hypothesis]** until pilot data sets them, and
each carries the instrumentation that must exist from v1.

| KPI | Definition | v1 target | Gate/type |
| --- | --- | --- | --- |
| **Paid-days invariant pass rate** | % employee-periods where `paid + LOP + off + holiday = period days` before lock | **100%** | Hard gate (CC-7) |
| **Unresolved exceptions at lock** | Open exceptions when a period is locked | **0** (forced-lock logged, FR-ATT-022) | Hard gate |
| **Exception rate** | Exceptions raised per 100 worker-days | **[Hypothesis]** < 5 | Health |
| **Device coverage** | % of active devices seen within the health threshold at lock time | **[Hypothesis]** > 98% | Health (FR-DEV-003) |
| **Punch capture success by channel** | Accepted punches ÷ attempts, per channel | **[Hypothesis]** > 99% terminal, > 95% app | Health |
| **Offline-sync loss rate** | Offline punches lost vs captured | **0** | Hard (FR-DSK-001) |
| **Site onboarding time (frontline)** | Median hours from device/kiosk setup to first clean lock | **[Hypothesis]** < 1 shift-cycle | Adoption |
| **Vernacular coverage** | % worker-facing interactions served in the worker's chosen language | **[Hypothesis]** > 90% | Adoption (CC-6) |
| **Regularization deflection** | % regularizations resolved without a manager typing free-text (AI-drafted, human-approved) | **[Hypothesis]** > 40% | AI COGS lever (§13) |
| **OT-ceiling warning coverage** | Warnings fired ÷ worker-quarters crossing the configured [Hypothesis] ceiling (K-04) | **100%** (no silent crossing) | Advisory — never a block (FR-OT-001 AC2, §06.12 R17) |
| **Statutory-filing input accuracy** | ECR/ESI reconciliation exceptions traced to attendance | **[Hypothesis]** → 0 over pilots | Filing thesis (FR-FIL-001) |

- **AC1:** Every KPI above is computable from the event log and audit trail
  (§09.1-A) without a separate analytics write-path — instrumentation is inherent,
  not bolted on (mirrors §13 attribution-from-v1).
- **AC2:** The two hard gates (paid-days invariant, zero-unresolved-at-lock) are
  enforced in the lock flow, not merely dashboarded.

---

### 09.14 Open questions, validation hooks and statutory watch items

Recorded here so they route into the §20 validation programme, the §22 compliance
data pipeline and the §23 counsel register rather than being silently assumed.

| # | Open question | Why it matters here | Resolution path |
| --- | --- | --- | --- |
| A1 | **Leave-with-wages accrual, eligibility, carry-forward and encashment; spread-over; maximum unbroken work and minimum rest interval** — central (OSH Code and Rules, not yet read) and per state | FR-LV-002 and FR-SHF-001 parameters ship **empty** (no seeded value) until the text is read | Read the OSH Code and OSH (Central) Rules 2026 text first (desk, no field work), then the state dataset of §20 V-09 (PT/LWF) extended to leave/hours; gazette + corrigendum check per state |
| A2 | **ESI regime after 22 Nov 2026** (one-year saving expiry) | Maternity↔ESI payment split (FR-LV-003), sickness/ESI interaction | §20 V-08 primary-source watch on ESIC/MoLE (§06.13); effective-dated so it re-points on notification |
| A3 | **Device integration real effort / failure profile** across a mixed fleet, incl. remote template deletion | FR-DEV-001/005/007 implementation sizing; the 85–98% figure is banned | §20 V-10 / V-11 hardware spike (explicit build dependency, currently unsized) |
| A4 | **Meta WhatsApp India rate card** (marketing/utility/service tiers) | FR-ATT-015/FR-DSK-005 per-worker messaging cost | §20 V-12 — capture the rate card before committing any per-worker price |
| A5 | **Willingness to pay for live location tracking** (greytHR lists ₹140 on Growth+, FR-LOC-001) | FR-LOC-001 monetisation | §20 commercial validation; no ARPU committed until it reports |
| A6 | **National & Festival holiday lists per state per year** | FR-SHF-004 calendar correctness | Annual gazette-sourced calendar refresh through the §22 compliance data pipeline |
| A7 | **Sandwich-leave and prefix/suffix norms** — statutory vs contractual | FR-ATT-021/FR-LV-005 LOP correctness | Policy-configurable default-off; confirm no state mandates it before enabling by default |
| A8 | **Biometric attendance legality** — whether s.7(i) will reach biometric means; who owes the SPDI r.5(1) written-consent duty and whether in-app capture suffices; whether the SPDI Rules survive the omission of IT Act s.43A; DPDP r.8(3) retention scope; DPDP access/erasure rights under s.7(i) | FR-ATT-017 consent regime, erasure timing, face-match posture | §23 counsel register; never cite *Dillip Kumar Rout* (K-14) or KVKK 2026/921 (K-15) as authority |
| A9 | **Contract-labour state-sphere threshold, counting unit and forms** (central: 50+, latching, FORM-XVII Part III — EV-057, r5) | FR-CL-001/002/003 for the manufacturing/3PL/QSR core | State OSH gazette per state (extends the A1 dataset); corrigendum check |
| A10 | **Gratuity 4y240d→5 rounding** (the 240-day test itself is CoSS s.54, verified) | FR-FIL-001 AC2 continuous-service counter | Re-capture the case citations (carried, not re-captured, §06.6) and confirm the controlling jurisdiction's position before wiring gratuity eligibility |
| A11 | **State OT rounding / minimum-OT-spell rules** | FR-OT-005 AC2 rupee correctness | Per-state gazette in the A1 dataset; do not assume minute-level OT nationally |
| A12 | **State-wise CL/SL floors, pooling and carry-forward** under S&E Acts | FR-LV-007 statutory-floor enforcement | Per-state S&E-Act gazette (extends the A1 dataset); corrigendum check |
| A13 | **144 OT hours per quarter** — secondary summaries only; never confirmed against gazette text; may sit in the OSH rules (K-04) | FR-OT-001 AC2 advisory ceiling | §20 V-17: read the Wages and OSH Central Rules text; warn-only until then (§06.12 R17) |
| A14 | **Form IX electronic signature row and multi-session days** | FR-STAT-001 AC1/AC5 inspection-parity | §20 desk validation against G.S.R. 343(E); counsel for the signature question (§23) |
| A15 | **Maternity variants not captured** — pre-natal share, third-child and adoption/commissioning entitlements, the 80-day look-back window, nursing-break duration and pay treatment, and the CoSS Ch. VI section numbers | FR-LV-003 parameters (`ml_*`, `nursing_break_*`) ship empty; non-standard cases raise an exception for HR | Desk read of CoSS Ch. VI and the SS (Central) Rules 2026 (§20, build-blocking desk work); publish through the §22 pipeline with citations |
| A16 | **Device packet wire format** — endpoint paths, field names, encodings, batch-ACK granularity, TLS support, and whether each model uploads templates or photos, per make/model/firmware | FR-DEV-008 adapter mapping; the logical contract is fixed, the wire format is not | §20 V-11 bench test against eSSL and ZKTeco; results recorded per model in the FR-DEV-004 compatibility matrix |

**Statutory-watch discipline (from §02.4 / §22):** the [Hypothesis] OT ceiling, the OT multiplier, leave
accrual and register formats above are all subject to the statutory-change watcher,
which must **catch amendments and corrigenda, not just new instruments** — the same
discipline that inverted the November 2026 EPF analysis twice applies to every
effective-dated attendance rule here.

---

*Section 09 — Functional Requirements: Attendance, Leave & Deskless. Confidence
markers reflect the status of the underlying statutory/evidentiary claim, not the
requirement. Verified anchors: ADMS push; OT at 2× against wage-period-dependent
normal hours (8 a day for a daily wage period, 48 a week otherwise); the notified
register set with Form IX's per-day IN/OUT (EV-053, EV-055) and central-sphere
retention (EV-054); WhatsApp 250/24 h cold-start; shared-device reality;
device-vendor partnership; connector pricing. **[Hypothesis]**, warn-never-block:
the 144-hour quarterly OT ceiling (K-04), spread-over and rest intervals, and the
state-devolved numerics (leave accrual, festival holidays, CL/SL floors, OT
rounding, state contract-labour values), each with a named validation path. The
v1.0 correctness pass reversed the "four registers", "DPDP s.7(i) removes consent
today", "144 hours [Verified]", "comp-off instead of OT" and "contractor registers
continue" claims, and applied the biometric architecture: template separate from
the event, separate keyspace, no image store, two-phase device erasure with an
exception state, versioned consent across the ~May 2027 regime switch, and a
per-employee non-biometric path. The adversarial pass removed every statutory
value research does not carry — seeded spread-over and rest-interval figures, the
earned-leave ratio and cap, typical CL/SL grants, the maternity variants and their
legacy section numbers, the gratuity case name — and replaced each with an empty,
named parameter; corrected "ordinary" to s.14's "normal rate of wages"; stated the
Aadhaar Good Governance route accurately; and added the device packet contract
(FR-DEV-008) and the per-device erasure transition table (FR-DEV-007 AC5). The deepen pass added the entity contract
(§09.1-A), biometric capture limits (FR-ATT-017), OT/worked-hour rounding
(FR-OT-005), state CL/SL floors
(FR-LV-007), contract-labour attendance for the manufacturing/3PL/QSR core
(§09.9-A), the attendance-as-filing-input reconciliations that carry the section's
thesis into EPF/ESI/gratuity (§09.10-A), and the module KPI/instrumentation gates
(§09.13-A).*
