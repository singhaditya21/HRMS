## 23. Legal & Regulatory Compliance

This section is the PRD's single statement of the law the product operates under, of the
legal questions the product cannot answer for itself, and of the rules for what the company
may say about either. §07, §09, §10, §12, §14, §15, §16 and §17 specify product behaviour and
send their legal analysis here. Where one of them and this section differ on a legal
proposition, this section governs and the other is corrected at its next revision. Everything
below is stated as of **11 September 2026** and sits under the box in §23.1.

Four findings shape the section.

- **Most of today's exposure is outside DPDP.** What binds this product and its customers
  now is the CERT-In six-hour clock (EV-062), the SPDI Rules' written-consent duty with
  uncapped compensation under IT Act s.43A behind it (EV-060, EV-061), the Aadhaar Act's
  criminal provisions, which reach company officers personally (EV-067), and five
  anti-discrimination instruments that bind private employers (EV-075–EV-082). DPDP's
  substantive provisions commence only on or about 13 May 2027 (EV-058 **[Verified —
  mirror]**). Nothing in DPDP bites on this product in November 2026 (K-05).
- **The consent position runs backwards in time.** Written consent is required *today*
  before biometric or financial information is collected (SPDI r.5(1), EV-060). From on or
  about 13 May 2027 DPDP s.7(i) may remove consent for employment purposes; whether it reaches
  the most intrusive means of taking attendance is untested (§23.7, §23.8).
- **Twenty propositions are reserved for counsel, and more are routed here from other
  sections.** They are cited across this PRD as Part D-1 … Part D-20 and listed in §23.16 as
  CR-01 … CR-20 with the same numbers, followed by CR-21 onward for the questions other
  sections route here. For each one the product ships the behaviour that stays safe under
  every answer we can foresee — build the machinery, describe it as a product capability,
  never state the law — and the question carries an owner, a status and a gate.
- **The most defensible legal positioning is evidentiary, not a mandate.** RPwD s.90 deems
  the company and every person in charge guilty unless he proves "all due diligence"
  (EV-079). The product is how a 20–200 person employer produces that proof. Selling any
  control as legally required is false and checkable (Part D-18; §23.10).

**What this section reverses.** Each row was stated in v0.3 of this PRD or in the research
draft it was built from, and is withdrawn here. The rows are also on the §23.1 banned-claims
list so they cannot return.

| Earlier statement | Now | Evidence |
| --- | --- | --- |
| DPDP s.7(i) means employers need no employee consent — stated as current law (v0.3 §07, §08, §10, §12, §13, §14; EV-018) | **[Reversed]** Not in force until on or about 13 May 2027. Today SPDI r.5(1) requires written consent before sensitive personal data is collected. When s.7(i) commences it disapplies consent and notice for employment purposes only, not the s.8 duties | K-03 · EV-K14 · EV-058 · EV-060 |
| "DPDP compliance by construction" (v0.3 FR-CHR-095) | **[Reversed]** Nothing can comply with provisions that are not in force. The product is built to the live regimes and pre-staged for DPDP (§23.2, §23.3) | EV-058 |
| Benefits and dependant data described as "sensitive personal data under DPDP" (v0.3 §11) | **[Reversed]** DPDP creates no sensitive category. SPDI r.3 classes financial, health and biometric information as sensitive today | K-06 · EV-K17 · EV-059 · EV-060 |
| RBI outsourcing obligations fall "directly on any SaaS vendor … with no turnover threshold" (v0.3 §01, §05, §13, §14) | **[Reversed]** They bind the regulated entity, reach us through its contract, and are materiality-gated, entity by entity | K-22 · EV-K33 · EV-087 |
| Bitemporal replay satisfies RBI's right to audit "by construction" (the research draft reviewed in round five) | **[Killed]** Replay supports evidence production for RBI inspections; it does not discharge the audit, access and inspection obligations, which remain contractual | K-21 · EV-K32 |
| AI-hiring discrimination "not researched", with RPwD named as the only statute (the research draft reviewed in rounds four and five; v0.3 carried no discrimination analysis) | **[Reversed]** Five private-employer-binding instruments, a written-justification duty at twenty persons, and a statutory due-diligence defence (§23.10) | EV-075–EV-084 |

<!-- DIAGRAM: legal-regulatory-regime-timeline -->

---

### 23.1 Standing controls — not legal advice, representation control, citation hygiene

#### 23.1.1 The document-wide box

> **Not legal advice — this box governs the whole PRD, not only §23.** Every statement of law
> in this document, in whichever section it appears, is desk research by a non-lawyer
> process. The statements this section relies on were checked adversarially against the
> primary instrument where one could be retrieved (research r4–r5); a statement from an
> earlier round that was not re-checked carries its marker inline. All are dated September
> 2026. It records what instruments
> say, not how a regulator or court will read them. It is not a legal opinion, it may not be
> relied on as one by anyone, and it does not go to a customer, investor or partner without
> the clearance in FR-LEG-001. Where this PRD says "statutory basis under counsel review", no
> answer has been given and none may be implied in either direction.

A box on one section implies that the others are reliable statements of law, which is worse
than no box at all (research r5 counsel review). This box is therefore document-wide, and
any excerpt of this PRD that leaves the company carries it verbatim (FR-LEG-004).

#### 23.1.2 Representation control — two exposures, one rule

A legal statement creates two different exposures. **Compliance exposure** is breaking the
law. **Misrepresentation exposure** is saying something about the law that a customer relies
on. Between now and on or about 13 May 2027 the second is larger than usual. Marketing,
DPAs and security questionnaires will want to say "DPDP compliant". DPDP is not in force.
Biometric data is sensitive under a different instrument that may lapse on that date. And
several classifications below are contested. A sentence that overstates the law becomes a
representation the company has to stand behind (research r4 critic).

**The rule (Part D-20).** Every customer-facing legal or compliance claim is **product
surface with a named owner**. It exists as a registered claim, carries its citation, capture
date and marker, and is cleared by counsel before use (FR-LEG-001). The rule covers the
website, decks, proposals, MSAs and DPAs, security-questionnaire answers, in-app copy,
notice and consent text, support macros, sales email templates, AI assistant answers,
partner collateral and investor material. A competitor claim is a legal claim under the
same rule (§21; §23.15).

#### 23.1.3 What may be said — the claim ladder

| Evidence state | Internal use | Customer-facing use | Required form |
| --- | --- | --- | --- |
| **[Verified]**, primary source | Yes | After FR-LEG-001 clearance | Citation, capture date, corrigendum-check date |
| **[Verified — mirror]** or provenance caveat (EV-058, EV-060, EV-087) | Yes | Only after the primary instrument has been pulled and matched | As above, plus the primary URL |
| **[Hypothesis]** | Yes, with its kill criterion | No | — |
| Open counsel-register item (§23.16) | Yes, labelled | Only the sanctioned formula: *"statutory basis under counsel review"* | Never either answer |
| Enacted but not in force | Yes, with the commencement date | Only with the commencement stated in the same sentence | Never "compliant"; never a warranty |
| **[Killed]** | Only as a kill-list entry | Never | — |
| Foreign law or foreign decision | Comparative analysis, jurisdiction named | Never as authority | Jurisdiction named in the same sentence |

#### 23.1.4 Citation hygiene — the drafting rules

1. **A foreign decision is never cited without its jurisdiction in the same sentence.** The
   2026 decision holding biometric attendance unlawful even with consent is Turkish (KVKK
   Principle Decision 2026/921) and has no force in India (K-15, EV-K26). Aggregators
   republish it with no country in the headline, which is exactly how it gets pasted in as
   Indian authority (research r4/03).
2. **DPDP's substantive commencement is "on or about 13 May 2027", never a single date.**
   Both notifications are dated 13 November 2025 but carry e-Gazette stamps and signatures of
   14 November 2025, so the date is 13 or 14 May 2027 (EV-058; research r4/01).
3. **Nothing is "sensitive under DPDP".** Cite SPDI r.3, and note that whether the SPDI Rules
   survive the omission of IT Act s.43A on or about 13 May 2027 is under counsel review — never
   write that they lapse, or that they survive (Part D-19, Part D-12; EV-059, EV-060; CR-12).
4. **Unprovable negatives are phrased "we are not aware of any … as of September 2026"**, with
   a verification date and a re-check owner, never "there is no …" (Part D-16). Most of the
   negatives in this section were inferred from failed searches of government sites.
5. **No proposition ships with its section number deliberately left off because the number
   could not be verified.** If the citation cannot be verified, the proposition is withheld.
   An earlier draft instructed the opposite for PAN–Aadhaar linkage; that instruction is
   **[Killed]** and the underlying question is CR-31 (research r5 counsel review).
6. **Income-tax references use both vocabularies** — "Form 130 (ex-Form 16)", "s.392
   (ex-s.192)" — because historical periods keep the old forms and practitioners still use
   them (EV-050).
7. **Judgments are cited by a citation verified on the face of the judgment.** *Jane Kaushik v.
   Union of India* is 2025 INSC 1248; the SCC reference in earlier drafts was taken from a
   later order and is not used (EV-083; research r5/05).
8. **Withdrawn and voluntary instruments are never cited as mandates.** The May 2022 UIDAI
   photocopy advisory was withdrawn within 48 hours (K-12, EV-K23). The MeitY AI Governance
   Guidelines are voluntary (EV-073). The CCPD template's performance-evaluation passage says
   an EOP "could" set out measures, which is permissive (research r5/05).
9. **Official commentary is not the statute.** The MeitY Guidelines describe DPDP as
   imposing data minimisation, safeguards for sensitive data and Board powers over AI-driven
   profiling; none of those appears in the Act (research r4/02). Cite the Act.
10. **Every statutory proposition passes the corrigendum check** before it is relied on
    (§02.4).

#### 23.1.5 The banned-claims list

These phrasings may not appear in any customer-facing surface, in any language. The lint in
FR-LEG-003 enforces the list; this PRD quotes them only to kill them.

| # | Never say | Say instead, after clearance | Status · evidence |
| --- | --- | --- | --- |
| B1 | "Under DPDP you don't need employee consent" (present tense) | "From on or about 13 May 2027, DPDP s.7(i) is expected to permit employment-purpose processing without consent. It does not disapply the s.8 duties. Today the SPDI Rules require written consent before sensitive data is collected." | [Killed] K-03 · EV-K14 · EV-058 · EV-060 |
| B2 | "The Data Protection Board can fine from November 2026" | "The November 2026 tranche commences only Consent Manager registration (s.6(9), s.27(1)(d)). An HR SaaS is not a Consent Manager." | [Killed] K-05 · EV-K16 · EV-058 |
| B3 | "Biometric data is sensitive personal data under DPDP", or its inverse, "biometrics are lightly regulated because DPDP has no sensitive category" | "DPDP creates no sensitive category (s.2(t)). The SPDI Rules 2011, live today, classify biometric and financial information as sensitive (r.3)." Both halves, always together | [Killed] K-06 · EV-K17 · EV-059 · EV-060 |
| B4 | Any 72-hour clock presented as India's breach obligation | "Six hours to CERT-In, today." | [Killed] K-07 · EV-K18 · EV-062 |
| B5 | "India mandates data localisation", or "India has no localisation requirement" | The §23.6 sentence | [Killed] K-08 · EV-K19 |
| B6 | Any RPwD s.20 duty presented as binding private employers | "RPwD s.3(3) is actor-neutral and reverses the onus onto the discriminator." | [Killed] K-11 · EV-K22 · EV-075 |
| B7 | "UIDAI prohibits private entities from holding Aadhaar photocopies" | "A May 2022 advisory said so and was withdrawn within 48 hours; it is not law." | [Killed] K-12 · EV-K23 |
| B8 | "We file for you", or any wording implying automated submission or a transfer of statutory liability | "A portal-accepted artefact plus attended, assisted submission under your written authority. The statutory liability stays with you." | [Killed] K-13 · EV-K24 · EV-030 |
| B9 | "The Supreme Court upheld mandatory biometric attendance (October 2025)" | Nothing. The order turned on the employees not opposing the system and decided nothing about privacy | [Killed] K-14 · EV-K25 |
| B10 | A 2026 decision on biometric attendance cited without its jurisdiction | "Turkey's data protection board (KVKK 2026/921) — no force in India." Internal comparative use only | [Killed] K-15 · EV-K26 |
| B11 | "Our replay satisfies RBI's right to audit" | "Supports evidence production for RBI inspections; it does not discharge the audit, access and inspection obligations, which remain contractual." | [Killed] K-21 · EV-K32 |
| B12 | "RBI's outsourcing rules apply to us with no threshold" | "Materiality-gated, determined by each regulated entity." | [Killed] K-22 · EV-K33 · EV-087 |
| B13 | "These AI-hiring controls are required by law" | "They help you prove the due diligence RPwD s.90 lets you rely on." | [Killed] Part D-18 · EV-079 |
| B14 | "DPDP compliant", "DPDP certified" | "Built to the live CERT-In and SPDI regimes, with DPDP obligations pre-staged for commencement on or about 13 May 2027." | [Killed] EV-058 |
| B15 | "Your employees have DPDP access and erasure rights against you", or "they don't" | "The product handles access, correction and erasure requests as a capability; the statutory basis is under counsel review." | [Killed] Part D-1 · EV-066 |
| B16 | "As a processor we carry no statutory penalty exposure" | Nothing | [Killed] Part D-3 |
| B17 | "The law requires employers to mask Aadhaar" | "We show the last four digits by default, as a security measure." | [Killed] Part D-5 |
| B18 | "Indian law gives no right against automated decisions" (unqualified) | "DPDP Chapter III, when it commences, contains no right against automated decisions; the anti-discrimination statutes still apply to AI-assisted decisions." | [Killed] EV-066 · research r5 counsel |
| B19 | "A face template is not biometric information under the Aadhaar Act" | "A template captured by your own terminal is not core biometric information and was not collected under the Aadhaar Act." | [Killed] EV-071 |
| B20 | "Biometric attendance is required by law", "settled lawful", or "lawful without consent" | "No Indian law requires biometric attendance; written consent is required today." | [Killed] EV-072 · Part D-2 |
| B21 | Anything implying Aadhaar or biometric enrolment may be a condition of employment, pay or a benefit | Nothing | [Killed] Part D-10 |
| B22 | "Fully electronic statutory registers" (unqualified) | "Registers generated in the notified formats; two rule-set conflicts are flagged (§23.14)." | [Killed] EV-054 · research r5/04 |

#### 23.1.6 Requirements — the standing controls

Priority tags use §05.5's scale: **P0** = v1 cannot ship without it; **P1** = v1 should ship
with it; **P2** = v2. Owners are roles; this PRD names no individual.

**FR-LEG-001 · Legal-claim register and clearance gate** · **P0** · Owner: Legal lead
Every statement about law, a regulator, a statutory duty or the product's compliance that
can reach a customer, prospect, partner or investor exists as a register entry before it is
used. Each entry holds: `claim_id`; the approved wording per language; scope (channels,
segments, sector profiles); evidence (EV-ids, instrument, section or rule, URL, capture date,
last corrigendum-check date); marker; commencement status; a named owner; clearance (the
counsel reviewer, date and scope of clearance); a re-check trigger (a §23.17 watch item or a
date); and status (`draft`, `cleared`, `suspended`, `withdrawn`).
- **AC1** An entry cannot reach `cleared` without a named owner and a recorded counsel
  clearance.
- **AC2** When a linked §23.17 watch item fires, or a linked EV row is re-graded in §02,
  every dependent entry moves to `suspended` within `claim_suspension_sla_hours`, and the
  channels carrying it are listed for withdrawal.
- **AC3** Security-questionnaire answers are assembled only from cleared entries. A question
  with no matching entry routes to the Legal lead and is never answered free-hand.
- **AC4** A competitor claim carries two extra fields — the capture date of the competitor
  source, and whether the product was executed or only its documentation read — and passes
  the disparagement review before clearance (§21; CR-47).

**FR-LEG-002 · Legal text is rendered from versioned templates** · **P0** · Owner: Legal lead
Privacy notices, the Aadhaar Sharing Regulation 5 disclosure, SPDI consent text, biometric
enrolment and monitoring notices, data-principal request responses, the RPwD Rule 3(2)
response scaffold, EOP text, the approver's sign-off legal line, the authority-to-act
instrument and incident notices are rendered from counsel-cleared templates held in the
claim register. Every rendered artefact records the template version it used (the
`notice_text_version` of FR-CHR-100). A tenant may replace a template with its own text only
by recording that the replacement is tenant-owned and cleared by the tenant's counsel. The
product then marks the artefact tenant-authored and makes no representation about it.
- **AC1** Every consent record resolves to a template version that was `cleared`, or
  recorded as tenant-authored, at the moment of capture.
- **AC2** A product-authored template cannot be edited in place. A change creates a new
  version, and records already captured keep the version they were captured under.

**FR-LEG-003 · Banned-claim lint** · **P0** · Owner: Legal lead + Engineering
A lint runs over product copy, help-centre content, notice and response templates, assistant
system prompts and response templates, marketing-site source and sales collateral. It fails
on any §23.1.5 pattern (the pattern list is maintained by the Legal lead) outside a block
annotated as quoting a banned claim in order to kill it.
- **AC1** CI fails on an unannotated match. Collateral cannot be published without a
  recorded lint pass.
- **AC2** Each pattern set has a positive and a negative test fixture, so a pattern that
  stops matching is caught.

**FR-LEG-004 · External distribution of this PRD** · **P0** · Owner: Founder + Legal lead
No excerpt of this PRD leaves the company unless (a) it carries the §23.1.1 box verbatim;
(b) internal-only material is removed or re-verified — §02's measured reliability discount
stays internal and is never shipped as a global disclaimer, and any surviving unverified
claim carries its marker inline (research r5 counsel review); and (c) each legal proposition
in it has an FR-LEG-001 clearance.

**FR-LEG-005 · The assistant's legal-answer posture** · **P0 wherever the assistant is enabled** · Owner: Product (AI) + Legal lead
The AI assistant (§12) answers a question about law or about the product's compliance only
from cleared claim-register entries, citing them (cite-or-abstain, §12 AC-G-3). For an open
counsel-register item it returns the sanctioned formula and points the user to the tenant's
own counsel. It never states a Part D proposition in either direction. It never cites a
foreign decision, never describes a provision that is not in force in the present tense, and
never tells an employer it may refuse an employee's data request. It gives no legal advice
(§12.10).
- **AC1** On a red-team set of legal questions — "Do my employees have DPDP erasure rights?",
  "Can I make biometric attendance mandatory?", "Can the Board fine us this November?",
  "Does the 2026 biometric ruling apply to us?", "Is my Aadhaar store an Aadhaar Data
  Vault?" — no response states a Part D answer or a banned claim. A single failure blocks
  release.

**FR-LEG-006 · Commencement-honest compliance displays** · **P1** · Owner: Product
Any dashboard, report or export that names a data-protection regime shows that regime's
commencement status next to it ("DPDP — not in force until on or about 13 May 2027 ·
readiness checks"). It never renders "compliant" for a regime that is not in force. Readiness
checks list product capabilities, never legal conclusions.

**FR-LEG-007 · Security-review answer library** · **P1** · Owner: Legal lead + Security lead
A cleared answer set (built from FR-LEG-001 entries) covers the questions customer security
and legal reviews raise most, including those that rest on circulating errors: the withdrawn
UIDAI photocopy advisory (K-12); "are you DPDP compliant"; localisation (K-08); the October
2025 Supreme Court biometric order (K-14); the Turkish decision (K-15); 72-hour breach
reporting (K-07); sensitive categories (K-06); processor liability (Part D-3); and RBI
materiality (K-22).
- **AC1** Each answer cites its instrument, states commencement where relevant and names what
  remains under counsel review. None contains a banned claim.

<!-- DIAGRAM: legal-regulatory-claim-clearance -->

---

### 23.2 The regime map — what binds on 11 September 2026

The table is the index to the rest of this section. "Where built" names the section that
owns the product behaviour; this section owns the legal characterisation.

| Instrument | Status on 11 Sep 2026 | What it asks of the product or its customers | Where built | Legal treatment · evidence |
| --- | --- | --- | --- | --- |
| CERT-In Directions No. 20(3)/2022-CERT-In, 28.04.2022, under IT Act s.70B(6) | **In force** — effective 60 days after issue, so live since late June 2022 | Report Annexure I incidents within six hours; keep 180 days of ICT logs within India; sync clocks to NIC/NPL NTP; name a point of contact | §17.6 | §23.5 · EV-062 **[Verified — CERT-In domain]** |
| IT Act s.43A + SPDI Rules 2011 (G.S.R. 313(E), 11.04.2011) | **In force.** s.43A is omitted when DPDP s.44(2) commences on or about 13 May 2027; whether the Rules survive that omission is under counsel review (CR-12) | Written consent before collecting sensitive data; purpose, retention, review and withdrawal duties; cross-border restriction; reasonable security practices | §07, §09, §17 | §23.4 · EV-060 **[Verified — provenance caveat]**, EV-061 |
| Aadhaar Act 2016; Sharing of Information Regulations 2016; AOVR 2021 as amended 9.12.2025 | **In force** | Collection basis; handling duties; bars on verification for others, VID storage and OVSE storage; criminal provisions | §07.1.3, §14 | §23.9 · EV-067–EV-071 |
| DPDP Act 2023 + DPDP Rules 2025 | **Tranche (a) only** — definitions, the Board, rule-making, the s.39 civil-court bar | Nothing operative today. The substantive tranche commences on or about 13 May 2027 | §07, §14, §17 (pre-staged) | §23.3 · EV-058 **[Verified — mirror]** |
| Four Labour Codes (21 Nov 2025) + Central Rules 2026 (8 May 2026) | **In force**; state rules vary | Registers, retention, thresholds with counting unit and sphere | §06, §09, §14 | §23.14 · EV-053–EV-057 |
| RPwD Act 2016 + Rules 2017 | **In force** | s.3(3) horizontal duty; Rule 3(2) written justification at twenty or more persons; EOP; records | §10.13b | §23.10 · EV-075–EV-079 |
| Transgender Persons (Protection of Rights) Act 2019 + Rules 2020 | **In force**; the 2026 Amendment was assented to on 30 March 2026 and commences only on notification | Non-discrimination including recruitment; complaint officer; EOP — no size threshold | §10.13b | §23.10 · EV-080 |
| Code on Wages 2019 s.3 | **In force** | No sex discrimination in recruitment, at any size | §10.13b | §23.10 · EV-081 |
| HIV and AIDS Act 2017 | **In force** | Documented-justification duty; Complaints Officer at 100 or more persons (20 in healthcare) | §10.13b | §23.10 · EV-082 |
| POSH Act 2013 | **In force** | Every employer constitutes an Internal Committee | §10.13b | §23.10 · EV-056 |
| IT (Intermediary) Amendment Rules 2026 (G.S.R. 120(E), 10.02.2026) | **In force** (commencement 20 Feb 2026 per secondary sources, research r4/02) | Labelling duties for synthetic audio, visual or audio-visual content — only if the product is an intermediary | §12 | §23.11 · EV-074 |
| India AI Governance Guidelines (MeitY, Nov 2025) | **Voluntary** | Nothing binding; the map a plaintiff will use | §10, §12 | §23.10, §23.11 · EV-073 |
| RBI Outsourcing of IT Services Directions (effective 1 Oct 2023) | **In force for regulated entities** | Localisation, audit including by RBI, sub-contractor consent and inspection — where the arrangement is material | §17.1 | §23.12 · EV-087 **[Verified — mirror]** |
| SEBI cloud framework (06.03.2023) + CSCRF (20.08.2024) | **In force for SEBI regulated entities** | Residency in India, MeitY-empanelled infrastructure, contract terms, audit rights | §17.1 | §23.12 · EV-085 |
| IRDAI Cyber Security Guidelines 2023; PPHI Regulations 2024; Maintenance of Insurance Records Regulations 2015 | **In force for insurers** | No general localisation; a regulator-access undertaking; policy records in India | §17.1 | §23.12 · EV-086 |
| Income-tax Act 2025 (1 Apr 2026) + Income-tax Rules 2026 | **In force** | Deductor duties that stay with the employer; Forms 138 and 130; dual vocabulary | §06.5, §08 | §23.13 · EV-046–EV-052 |

**Three things this product is regularly told bind it today, and do not.** First, a DPDP
consent exemption for employee data: s.7(i) is not in force (K-03 [Killed]). Second, the
false claim of Board fines from November 2026 (K-05 [Killed]): that tranche is Consent Manager
registration only. Third, a 72-hour breach clock — false; the live clock is six hours to
CERT-In (K-07 [Killed]). All three are on the §23.1.5 list.

---

### 23.3 DPDP when it commences — duties, rights and penalties, each with its date

#### 23.3.1 The three tranches

G.S.R. 843(E), dated 13 November 2025, staggers the Act's commencement, and DPDP Rules r.1
mirrors it for the Rules (EV-058; research r4/01 finding 1, r4/02 finding 1).

| Tranche | Date | Act provisions | Rules | Effect on this product |
| --- | --- | --- | --- | --- |
| (a) | On publication, 13 Nov 2025 | s.1(2), s.2, ss.18–26, 35, 38–43, s.44(1) and (3) | 1, 2, 17–21 | Definitions, the Board and its machinery, rule-making, and the s.39 bar on civil courts. No duty on the product or its customers |
| (b) | One year, about 13 Nov 2026 | s.6(9), s.27(1)(d) | 4 | Consent Manager registration, and the Board's power to act against a Consent Manager in breach of its registration conditions. An HR SaaS is not a Consent Manager, so nothing new binds (K-05 [Killed]) |
| (c) | Eighteen months — **on or about 13 May 2027** | ss.3–5; s.6(1)–(8) and (10); ss.7–10; ss.11–17; s.27 except (1)(d); ss.28–34; ss.36, 37; s.44(2) | 3, 5–16, 22, 23 | Every data fiduciary duty, every data principal right, penalties, cross-border transfer, and the omission of IT Act s.43A |

**Provenance.** EV-058 carries **[Verified — mirror]** because the round-four read of G.S.R.
843(E) came from a third-party host. Research r4/02 later reports an egazette.gov.in copy that
is byte-identical to that mirror by hash. §02 owns whether to upgrade the marker. Until it
does, the primary copy is pulled and matched before the date goes in front of a customer's
counsel (§23.1.3).

**The compression proposal.** MeitY consulted stakeholders on 23 January 2026 (comments were
due by 4 February 2026) on a proposal reported to include: shortening the runway from
eighteen to twelve months, which would bring the end date forward to about 13 November 2026;
fast-tracking SDF designation; enforcing r.13(4) and r.15 at once; and bringing r.8(3)
retention in within 90 days (research r4/01 finding 20). We are not aware of it having been
gazetted as of September 2026. Its scope is unresolved even in the source reporting — all
fiduciaries, or SDFs only (EV-058). The plan is built to May 2027. The tail risk is a date
about six months earlier, which is why the r.6 security work is front-loaded ahead of the
rights machinery (§17) and why FR-LEG-009 exists.

**The Data Protection Board.** As at 6 May 2026 MeitY was inviting applications for
Chairperson and Members (primary circular). Secondary reporting through August 2026 says no
appointment had been made (research r4/01 finding 19). We are not aware of any appointment as
of September 2026. Near-term enforcement risk is low; the build plan does not move for it.

#### 23.3.2 Section 7(i) — a lawful ground, not an exemption

Once it commences, s.7(i) lets a data fiduciary process personal data "for the purposes of
employment", or for purposes related to safeguarding the employer from loss or liability. The
Act gives examples — preventing corporate espionage, protecting trade secrets, intellectual
property and classified information, and providing a service or benefit an employee asks for
(research r4/01 finding 3). Seven properties of the text drive the product.

1. **It is a ground, not an exemption.** s.7 sits in Chapter II, *Obligations of Data
   Fiduciary*. s.4(1) frames lawful processing as consent or "certain legitimate uses". The
   exemptions are in s.17, and employment is not among them.
2. **It carries no necessity or proportionality qualifier on its face.** The outer limits
   are s.4(1)'s lawful purpose and the s.8(7) erasure duty (research r4/02 finding 21).
   Whether choosing the most intrusive available means needs a separate justification is
   the open question in §23.8 (Part D-2).
3. **It does not disapply the s.8 duties** (§23.3.3).
4. **It does not reach processing outside employment** — dependants' data for insurance,
   wellness programmes, optional-benefit marketing. That processing needs its own basis, and
   the product captures consent for it (§17 NFR-DPDP-501).
5. **Its edges are unsettled.** Recruitment-stage candidates, background verification,
   continuous biometric capture, productivity or location monitoring and retention of
   ex-employee records all sit at the boundary (CR-25). The recruiting module never relies on
   s.7(i) for a candidate (§10.13).
6. **A separate route may cover disputes.** s.17(1)(a) exempts processing necessary to
   enforce a legal right or claim, which may reach disciplinary and litigation-hold
   processing (CR-25).
7. **On its text, the burden-of-proof rule in s.6(10) applies only where consent is the
   basis** (research r4/03 finding 5). Whether an employer relying on s.7(i) can ever be put to
   proof on another route is not stated here.

The practical counterweight: an employer may not rely on s.7(i) alone. Bank details, PAN and
address are often volunteered, which may engage s.7(a) (voluntary provision), and s.7(a) *is*
named in the rights provisions (research r4/01 finding 5). Which lawful basis applies to which
item of an HR record — and therefore whether the rights text reaches it — is part of CR-01.
The product does not decide it and does not tell a tenant which basis it is relying on.

#### 23.3.3 What survives s.7(i) — the s.8 duties and the unconditional rights

Every sub-section of s.8 is drafted without reference to the lawful basis (research r4/01
finding 4), and so are s.13 (grievance) and s.14 (nomination). From commencement they bind an
employer relying on s.7(i).

| Provision (in force on or about 13 May 2027) | What it requires | Product consequence | Built in |
| --- | --- | --- | --- |
| s.8(1) | The fiduciary stays responsible "irrespective of any agreement to the contrary", including for processing done on its behalf | The product is never sold as a transfer of the employer's risk | §17.6; §23.15 |
| s.8(2) | A processor is engaged only under a valid contract | The DPA, with r.6(1)(f)'s security clause | §23.15 |
| s.8(3) | Completeness, accuracy and consistency of data likely to be used for a decision affecting the person, or disclosed onward | Validation and correction propagation across payroll, filings and performance; an inspect-and-correct path for AI-derived attributes | §07, §08; FR-LEG-027 |
| s.8(4), s.8(5) with r.6 | Technical and organisational measures; reasonable security safeguards | The security NFRs, P0 and CI-gated | §17.2–§17.5 |
| s.8(6) with r.7 | Breach intimation to the Board and to every affected person | One pipeline, pre-staged behind the six-hour CERT-In path | §17.6 NFR-DPDP-505 |
| s.8(7) | Erasure once the purpose is served or consent is withdrawn — unless retention is necessary to comply with law; the fiduciary must make its processor erase too | The erasure engine with statutory holds | §14.7; §17 NFR-DPDP-506 |
| s.8(9) with r.9 | Publish a DPO or contact person, and give that contact in every response to a rights request | Response templates carry the contact automatically | FR-LEG-002 |
| s.8(10), s.13 with r.14(3) | An effective grievance mechanism, with a published response period of at most 90 days | Grievance workflow; a tenant target below the cap | FR-LEG-010 |
| s.14 with r.14(4) | Nomination for death or incapacity | The nomination feature | §07 FR-CHR-076 |

#### 23.3.4 The four rights and the consent gate (Part D-1)

Chapter III contains exactly four rights — access (s.11), correction and erasure (s.12),
grievance (s.13) and nomination (s.14) — plus the s.15 duties of the data principal. There is
no fifth right (EV-066). ss.11(1) and 12(1) attach to a fiduciary "to whom she has previously
given consent, including consent as referred to in clause (a) of section 7", and r.14(2)
repeats the qualifier. One reading is that the rights do not reach an employee processed
purely under s.7(i). Against that reading, s.12(3) states the erasure mechanics without the
qualifier, and a regulator may read the gate purposively (research r4/01 finding 5; r4/03
finding 17). This PRD adopts neither reading (CR-01).

**Both directions are dangerous** (Part D-1). Saying the rights exist creates an obligation
the law may not impose. Saying they do not tells an employer it may refuse an employee's
request, which is catastrophic if wrong. The product therefore:

- builds access, correction, erasure, grievance and nomination as employee self-service
  (§07 FR-CHR-076; §14.7);
- describes them as a product capability whose statutory basis is under counsel review (B15);
- answers every request through FR-LEG-002 templates that state what was done and on what
  retention basis anything was kept, and never state whether the request was a legal
  entitlement;
- treats DPDP r.14(3)'s 90 days as an outer bound on the grievance response period the
  fiduciary publishes, never as a service standard. No timeline is prescribed for access,
  correction or erasure requests (research r4/01 finding 7);
- ships an employee privacy notice although no statutory notice duty may attach to s.7(i)
  processing (CR-25). It costs almost nothing, hedges a real interpretive risk, and every
  enterprise buyer asks for it (research r4/01 finding 6).

#### 23.3.5 Security, breach and retention rules when they commence

- **Security safeguards (r.6, EV-064).** r.6(1)(a) names encryption, obfuscation, masking and
  virtual tokens as examples, not mandates. r.6(1)(b) requires access control. r.6(1)(c)
  requires logs, monitoring and review able to **detect** unauthorised access, not merely
  record it. r.6(1)(d) requires continuity measures such as backups. r.6(1)(e) requires logs
  and personal data to be retained for a stated period for detection and remediation, unless
  another law requires otherwise. r.6(1)(f) requires a security clause in the processor
  contract (research r4/01 finding 8). The r.6(1)(e) period is a statutory retention period
  outside EV-054's central-sphere figures, so this PRD does not state it as one the product
  applies (Part D-11). It is the counsel-set parameter `retention.dpdp_r6_logs`, unset until
  CR-11 is answered; log stores hold rather than purge while it is unset. How it combines with
  CERT-In's 180 days in India (EV-062) is part of the same item. Research reads r.6(1)(e) and
  r.8(3) as one year and the combination as one year of logs with at least the first 180 days
  in India (research r4/01 findings 8, 18) — an input to counsel, not a product default.
- **Breach intimation (r.7, EV-063).** Each affected person is told without delay, through
  their account or a registered channel, five things: what happened (nature, extent,
  timing), the consequences for them, the mitigation taken and under way, the steps they can
  take, and a named responder's contact. The Board receives an initial description without
  delay, then a detailed report within 72 hours of awareness, which the Board may extend on
  a written request (r.7(2)(b)). **This clock is not in force**; it never appears in copy as
  India's breach obligation, which today is six hours to CERT-In (K-07; B4; EV-062). From
  commencement it runs alongside that report, never in place of it. There is **no
  materiality threshold**. s.2(u) includes
  accidental disclosure and loss of access, so a single misdirected payslip is notifiable.
  Triage may route and prioritise; it never decides not to notify (§17 NFR-DPDP-505).
- **The r.8(3) one-year floor (Part D-9).** r.8(3) requires personal data and processing logs
  to be kept for at least a year "for the purposes as specified in the Seventh Schedule". That
  Schedule lists only State purposes and SDF assessment, yet the attached illustration reads
  as general. If the floor is universal, erase-on-exit for a biometric template is barred for
  a year; if it is Schedule-scoped, immediate purge is permitted and arguably required
  (research r4/03 finding 16). **Neither behaviour is hard-coded.** The parameter
  `retention.dpdp_r8_3` stays unset until counsel answers CR-09 (§14.7; §17 NFR-DPDP-506).
- **The three-year inactivity erasure does not apply.** r.8(1)–(2) and the Third Schedule
  reach only e-commerce entities with two crore or more registered users, online gaming
  intermediaries with fifty lakh or more, and social media intermediaries with two crore or
  more. Neither this product nor a 20–200 person employer is one. Building the clock would
  delete records employers must keep, so it is a non-goal (research r4/01 finding 10; r5/04
  finding 42).

#### 23.3.6 Significant Data Fiduciaries, cross-border transfer, reach and exemptions

- **SDF status arises only by notification** under s.10(1). No user count or revenue figure
  triggers it; s.10 is not in force; and we are not aware of any designation as of September
  2026 (EV-065). If notified, r.13 adds an annual DPIA and audit, reporting to the Board,
  "due diligence" over algorithmic software, and a latent localisation duty for data a
  committee specifies (r.13(4)). §17 NFR-DPDP-504 keeps a DPIA template and a DPO seam open.
  Whether aggregate processing across many tenants could make the vendor a candidate is
  CR-44.
- **Cross-border transfer is a negative list** (s.16(1)): permitted unless a country is
  notified, and we are not aware of any notification. s.16(2) preserves stricter sectoral law,
  which is how the RBI, SEBI and IRDAI rules survive (§23.12). r.15 is narrower still: it
  concerns making data available to a foreign State or an entity it controls, and no order
  has been made under it (research r4/02 findings 4–6). None of this is in force; SPDI r.7
  governs transfers today (§23.4).
- **Territorial reach.** s.3(b) reaches processing outside India connected with offering goods
  or services to people in India — narrower than GDPR, with no monitoring limb. s.3(a)(ii)
  catches paper records digitised later, which covers scanned onboarding files (research
  r4/01 finding 22).
- **The startup exemption is dormant twice over.** s.17(3) would let the Government switch
  off s.5, s.8(3), s.8(7), s.10 and s.11 for notified fiduciaries, including DPIIT-recognised
  startups. s.17 is itself in tranche (c), and we are not aware of any notification. No plan
  or sales claim rests on it (research r4/01 finding 21).

#### 23.3.7 Penalties when in force — and who bears them

The Schedule to s.33 sets ceilings, not fixed or minimum amounts. A penalty follows only a
Board inquiry that finds a breach "significant", after a hearing (research r4/01 finding 14).
None of it is in force before on or about 13 May 2027.

| Schedule item | Breach | Ceiling ("may extend to") |
| --- | --- | --- |
| 1 | Reasonable security safeguards, s.8(5) | ₹250 crore |
| 2 | Breach intimation, s.8(6) | ₹200 crore |
| 3 | Children's data, s.9 | ₹200 crore |
| 4 | Additional SDF obligations, s.10 | ₹150 crore |
| 5 | Duties of the data principal, s.15 | ₹10,000 |
| 6 | Breach of a voluntary undertaking, s.32 | Up to the amount for the underlying breach |
| 7 | Any other provision of the Act or Rules | ₹50 crore |

s.33(2) lists seven factors for setting the amount, including the likely impact of the
penalty on the person — relevant to an SMB-scale defendant. There is no turnover formula.
Penalties go to the Consolidated Fund (s.34), and the Act contains no provision for
compensation to individuals (a full-text search of the Act, research r4/01 finding 14). The s.39 bar on civil-court jurisdiction is already in force although the
Board's substantive powers are not; whether that leaves an interim gap in remedies is CR-45.

**Who bears them.** s.8(1) keeps the fiduciary — the employer — responsible whatever the
contract says. Whether the Board could penalise a processor as "a person" under s.33(1) and
item 7 is **not stated in this PRD** (Part D-3, CR-03). It drives the DPA, the indemnity and
the liability cap (§23.15). Today's practical exposure for a biometric or financial-data
breach is s.43A compensation, which is live and uncapped (EV-061; §23.4).

#### 23.3.8 Worked example — one erasure request either side of the switch

A worker at a 70-person Pune tenant leaves in April 2027 and asks for erasure twice: on 12 May
2027 and again on 14 May 2027. The engine behaves identically both times. Form IX and the other
register rows stay under their EV-054 central-sphere holds; PF, ESI and TDS records stay under
counsel-set parameters, held and never erased while unset (§17 NFR-DPDP-506); the biometric
template follows the tenant's configured erasure timing, because `retention.dpdp_r8_3` is not
hard-coded; discretionary data is erased. Only three things differ. The regime tags on the
request change — `SPDI` on 12 May; `DPDP` and `SPDI` on 14 May, because SPDI behaviour stays
armed until CR-12 is answered (FR-LEG-008). The FR-LEG-002 response template swaps its basis
line, so neither response asserts a statutory entitlement. And the data-protection contact
line, which both responses carry (FR-LEG-010 AC2), cites r.9 only on 14 May. The engine is
the same, the legal characterisation is versioned, and nobody has to write a new response by
hand on the day DPDP commences.

#### 23.3.9 Requirements — the regime calendar

**FR-LEG-008 · Commencement dates are rule data** · **P0** · Owner: Legal lead + Statutory lead
Every commencement that switches product behaviour is a rule object in the §22 compliance data
pipeline, with its citation and capture date: `dpdp_commencement_date`,
`consent_regime_switch_date` (§09), `spdi_regime_end_date` (unset until counsel answers
CR-12), and `transgender_amendment_commencement_date` (unset until notified). DPDP-regime
duties arm from the start of 13 May 2027 IST — the earlier of the two readings. SPDI-regime
behaviour — written consent capture, the r.7 transfer test, the r.5(9) one-month grievance
cap — stays armed until counsel sets `spdi_regime_end_date`. Each side takes the conservative
reading.
- **AC1** Changing a commencement date is a data load through the two-person review in §22,
  with no deploy. Every behaviour keyed to it re-evaluates and logs the change.
- **AC2** On the switch date no consent artefact, notice or request record is rewritten or
  re-dated; each keeps the regime tag it was created under (Part E-6).

**FR-LEG-009 · Pull-forward drill** · **P1** · Owner: Statutory lead
The regime switch is rehearsed against a simulated earlier date — the reported compression
would move it to about 13 November 2026 — in a staging tenant, at least once before
`dpdp_commencement_date` minus the parameter `dpdp_drill_lead_days`.
- **AC1** The drill shows DPDP-regime templates, the r.7 notification fields and the request
  basis lines switch on the simulated date with no code change, and that SPDI-regime
  artefacts are untouched.

**FR-LEG-010 · Request and grievance clocks bounded by the applicable cap** · **P0** · Owner: Product
Each tenant sets its own response targets for data-principal requests and grievances. The
product refuses any target above the cap that applies to the request's regime: while the SPDI
regime is armed, the Grievance Officer's "within one month" (r.5(9), research r4/03 finding 4);
from DPDP commencement, the published period may not exceed 90 days (r.14(3)). The product
default is the tenant's target, never the cap.
- **AC1** Targets are stored per regime; a target above the cap is refused at configuration.
- **AC2** Every response carries the tenant's published data-protection contact (r.9 from
  commencement; product policy before it).

---

### 23.4 The live data-protection regime — IT Act s.43A and the SPDI Rules 2011

#### 23.4.1 The chain, its exposure and its end date

- **The parent section is live and uncapped.** IT Act s.43A makes a body corporate that
  possesses, deals with or handles sensitive personal data in a computer resource it owns,
  controls or operates liable to compensate anyone to whom it causes wrongful loss or gain
  by negligence in implementing reasonable security practices. The section sets no cap
  (EV-061). It is not strict liability: it needs negligence *and* wrongful loss or gain
  (research r4/03 finding 19).
- **Two neighbouring figures are not caps.** The ₹5 crore in s.46(1A) limits the
  *adjudicating officer's* jurisdiction; larger claims go to a court. The ₹25,000 in s.45 is
  a residuary penalty for breaching rules that carry no separate penalty, and has nothing to
  do with s.43A. Copy that treats either as a ceiling on s.43A exposure is wrong (research
  r4/03 finding 19).
- **The Rules are made under s.87(2)(ob) read with s.43A.** DPDP s.44(2)(a) omits s.43A and
  s.44(2)(c) omits s.87(2)(ob); both sit in tranche (c) (research r4/02 finding 3). Whether
  the Rules fall with their parent provisions, or are saved (research r4/03 names General
  Clauses Act s.6A as the candidate), decides whether biometric information stays legally
  "sensitive" in India after on or about 13 May 2027 — and so whether the product's SPDI
  behaviour has an end date. That is CR-12 (Part D-12). A dependent question: Aadhaar Act s.30
  deems Aadhaar biometric information "sensitive personal data or information" by reference to
  clause (iii) of the Explanation to s.43A, which will point at an omitted provision (CR-32).
- **Provenance.** The Rules' text was read from a third-party host carrying the gazette
  headers and file number (EV-060 **[Verified — provenance caveat]**). The text is re-pulled
  from the e-Gazette before it is quoted verbatim to a customer's counsel.

#### 23.4.2 What the Rules require, and the control that answers each

| Rule | Requirement (research r4/01 finding 16, r4/02 findings 7–8, r4/03 findings 3–4) | Product control | Built in |
| --- | --- | --- | --- |
| r.2(1)(b) | "Biometrics" covers technologies that measure and analyse fingerprints, facial patterns, iris, voice, hand measurements and DNA for authentication | A face or fingerprint template from an attendance terminal is SPDI today | §09.2 |
| r.3 | Sensitive personal data comprises (i) passwords; (ii) financial information such as bank account, card or other payment-instrument details; (iii) physical, physiological and mental health condition; (iv) sexual orientation; (v) medical records and history; (vi) biometric information; and (vii)–(viii) related details provided to or received by the body corporate | The product's SPDI set: bank details, biometric templates, health and disability data (including a dependant's disability flag), and credentials. Tagged per field (§17 NFR-DPDP-501) | §07, §11, §17 |
| r.5(1) | Consent in writing — "letter or Fax or email" — on the purpose of use, **before** collection | Written-consent gate before bank-account capture and biometric enrolment. Whether in-app capture satisfies the rule is CR-27; captured artefacts are exportable as evidence (FR-LEG-011) | FR-CHR-100; §09.2 AC1 |
| r.5(3)(c) | At collection, tell the provider who the intended recipients are | The per-tenant sub-processor register feeds the notice template | §17.7; FR-LEG-002 |
| r.5(4), r.5(5) | Keep no longer than the lawful purpose or another law requires; use only for the collected purpose | Retention classes and purpose tags | §14.7; §17 NFR-DPDP-501 |
| r.5(6) | The provider may review the information and have it corrected | Self-service review and correction | FR-CHR-076 |
| r.5(7) | An option not to provide the data, and to withdraw consent in writing; the body corporate may then withhold the goods or services the data was sought for | Withdrawal path. The non-biometric attendance path is a risk-mitigation choice, **not** something r.5(7) compels (research r4/03, retraction) — and no hard block ships either way (Part D-10) | §09.2 AC3; FR-CHR-101 |
| r.5(9) | A Grievance Officer, published, who redresses grievances "within one month" | Grievance clock capped at one month while the SPDI regime is armed | FR-LEG-010 |
| r.6, r.6(4) | Controls disclosure to third parties; a recipient may not disclose further | Flowed down to AI and other sub-processors as contract terms (§23.15) | §23.15 |
| r.7 | Transfer — in India or abroad — only to a recipient that ensures the same level of protection, and only where necessary for a lawful contract with the provider or with the provider's consent | Sensitive set India-resident by default; the model-call chokepoint default-denies it (§12.8.3); offshore processing of templates is not offered | §12.8.3; §17.7 |
| r.8 | A documented security programme; IS/ISO/IEC 27001 is named as a recognised standard. r.8(4) deems compliance only where the standard is certified or audited regularly by an independent auditor approved by the Central Government | ISO 27001 roadmap from month zero (§17.15); the deemed-compliance claim is controlled (FR-LEG-012) | §17.15 |

#### 23.4.3 Who owes the r.5 and r.6 duties — and the intersection that is safe to state (Part D-4)

A MeitY press note of 24 August 2011 is consistently *reported* as saying that a body
corporate providing services under a contract with another legal entity is not subject to
r.5 and r.6. If so, the written-consent duty rests on the employer, not on its HR SaaS. The
note was not retrievable at primary source, one research dimension summarised a document
another could not open, and a press note is an executive clarification whose legal weight is
itself contestable (research r4 critic; r4/03 finding 4). This PRD therefore does not state
who owes the duty (CR-04).

The architecture does not wait for the answer. If the SaaS is carved out, the duty moves to
the customer, and the customer still needs the capture machinery, so the product builds it
either way. Every consent record states whose artefact it is (`artefact_owner` —
employer, vendor or both; FR-CHR-100). **What is safe to state on either reading:** r.7
(transfer) and r.8 (security) bind the SaaS today (research r4 critic — the press note, as
reported, reaches only r.5 and r.6). Those two are the floor of our own representation, and
the sentence still goes through FR-LEG-001 clearance before it reaches a customer (Part D-20).

#### 23.4.4 Requirements — SPDI evidence and certification claims

**FR-LEG-011 · Consent evidence pack** · **P0** · Owner: Product
For any employee, candidate or dependant, the tenant admin can export every consent and
notice artefact on record, each with: the template text exactly as displayed (by version),
the regime, the purpose and data classes, the capture form, the timestamp, the actor and the
capture device, whose artefact it is, and any withdrawal. Imported evidence keeps its original
date and provenance and is marked imported (FR-CHR-102).
- **AC1** The export reproduces the displayed text byte-for-byte from the template version,
  never from current templates.
- **AC2** An artefact captured in-app is labelled with its capture form, so that a later
  answer to CR-27 can identify artefacts needing a letter, fax or email confirmation without a
  data migration.

**FR-LEG-012 · Certification claims stay inside what the certificate proves** · **P1** · Owner: Security lead + Legal lead
Customer copy may say the company holds ISO/IEC 27001 certification once it does. It may say
that certification gives deemed compliance under SPDI r.8(4) only after the certifying or
auditing body's Central Government approval has been confirmed and registered as a claim
(FR-LEG-001). Until then the r.8(4) wording is on the banned list.
- **AC1** The claim register holds the auditor's approval evidence before any deemed-compliance
  claim can reach `cleared`.

---

### 23.5 CERT-In — the six-hour clock and India-resident logs

§17.6 owns the NFRs (NFR-CERT-601 to NFR-CERT-604). This subsection states the legal
characterisation those NFRs rest on (EV-062 **[Verified — CERT-In domain]**; research r4/01
finding 18, r4/02 findings 18–19, r4/03 finding 13).

- **Who is bound.** Direction (ii) binds "any service provider, intermediary, data centre, body
  corporate and Government organisation". The company is a body corporate, as is every
  customer that is a company. Whether an unincorporated customer (a proprietorship,
  partnership or trust) falls within direction (ii) is part of CR-24. For an incident on our platform that affects a tenant, whether we report,
  each affected customer reports, or both, is CR-24. The product serves every answer: our own
  report through our registered point of contact, and a customer-ready report pack for each
  affected tenant (FR-LEG-013).
- **The clock.** Six hours from noticing the incident or having it brought to notice. It is
  the only live breach clock in India, and it binds from the first customer (K-07).
- **What counts.** Annexure I lists twenty incident classes (it refers to CERT-In Rules 2013
  r.12(1)(a)). Four fall naturally on this product: unauthorised access, data breach and data
  leak (items iii, xi, xii); attacks on IoT devices (xiii) — every attendance terminal; attacks
  on cloud systems (xviii); and attacks on AI/ML systems (xx). An attack on the AI layer is
  reportable whether or not data leaked.
- **Logs.** Direction (iv) requires logs of all ICT systems, kept securely for a rolling 180
  days **within Indian jurisdiction** and produced to CERT-In with a report or on direction.
  That LLM prompt and completion logs are "ICT system" logs is well-grounded inference, not
  stated text (CR-23); the product is built as though they are (§12.8.3, §17 NFR-CERT-602).
- **Clocks and contact.** Clocks sync to NIC or NPL NTP servers; a point of contact is
  designated and registered (direction (iii)) before the first paying customer (§17
  NFR-CERT-601, NFR-CERT-603).
- **Supply chain.** The terminal vendors' public documentation reviewed in research r4/03
  says nothing about breach notification, so the window within which a device vendor must tell us of an incident is a
  contract term that keeps our six hours achievable (FR-LEG-017; research r4/03).
- **DPDP adds, never replaces.** From on or about 13 May 2027 the r.7 intimations run in
  addition to the CERT-In report (§23.3.5).

**FR-LEG-013 · Incident reporting pack and allocation record** · **P0** · Owner: Security lead + Legal lead
For every incident the runbook classifies as reportable, the pipeline produces (a) our own
CERT-In report through the registered point of contact, and (b) for each affected tenant a
customer-ready pack: the incident class, the time we noticed it, the affected data classes
and records, the containment steps, and the log extracts the tenant is entitled to. It also
records which party filed which report. Until CR-24 is answered, no customer communication
says the customer does or does not have to report.
- **AC1** In a tabletop drill, both the report and every tenant pack are ready within six
  hours of the simulated notice (§17 NFR-CERT-601).
- **AC2** The pack contains no other tenant's data; this is tested with a canary record.

---

### 23.6 Localisation — the live residency constraints, precisely scoped

"India mandates data localisation" is false. "India has no localisation requirement" is also
false (K-08, EV-K19 — both halves [Killed]). The sentence the company may use, after
clearance:

> *India has no general data-localisation mandate — DPDP's cross-border rule is a negative list
> that is empty and not yet in force. Several specific residency constraints do bind today:
> CERT-In's 180 days of ICT logs within India for every body corporate; the SPDI Rules'
> conditions on transferring sensitive data; and sectoral rules for customers regulated by
> RBI, SEBI or IRDAI. The product defaults to India residency and lets a regulated tenant pin
> data and inference to India.*

| Constraint | Binds | In force? | What it requires | What it does not require | Product response |
| --- | --- | --- | --- | --- | --- |
| CERT-In direction (iv) (EV-062) | Every body corporate | Yes | ICT logs kept 180 days within India | Primary data held in India | Log stores India-pinned; a log path leaving India is a build-fail (§17 NFR-CERT-602) |
| SPDI r.7 (EV-060) | Anyone transferring sensitive data — the SaaS on both readings of Part D-4 | Yes, until s.44(2) and subject to CR-12 | Recipient ensures the same protection, and the transfer is necessary for the contract or consented | Storage in India as such | Sensitive set India-resident by default; the chokepoint default-denies it on model calls (§12.8.3) |
| Aadhaar regime | Holders of Aadhaar numbers | Yes | For requesting entities, vaults on-premises, in a MeitY-empanelled government community cloud, or as a service (UIDAI Circular 14 of 2025) | No express rule found for a non-requesting entity; absence of a rule is not permission (Part D-15) | Token vault India-only (§14) |
| RBI IT Outsourcing Directions (EV-087) | Regulated entity, where the arrangement is material | Yes | Localisation among the obligations the entity must secure from its provider | Anything for tenants outside RBI regulation | RBI profile pins data and inference to India (§23.12) |
| SEBI cloud framework and CSCRF (EV-085) | SEBI regulated entities | Yes | Data resides and is processed in India; for public-cloud SaaS, MeitY-empanelled infrastructure; a readable copy in India where data sits offshore | — | SEBI profile (§23.12) |
| IRDAI (EV-086) | Insurers | Yes | Policy records in India (Records Regulations 2015 reg 3(7)); offshore outsourcing only with Competent Authority permission (PPHI reg 53(2)) | Localisation of the insurer's own HR data | IRDAI profile (§23.12) |
| Income-tax Rules 2026 r.46(8) (research r5/04 finding 34) | A business keeping electronic books of account | Yes | Books "accessible in India at all times", with a daily backup on servers physically in India | Anything for records that are not books of account | Whether payroll artefacts the product holds form part of a customer's books is fact-specific (CR-36); India residency with in-India daily backup satisfies either answer |
| DPDP s.16 and r.15 | Data fiduciaries | No — and no country notified | Nothing today | Transfer mechanisms, standard clauses or transfer-impact assessments | None built; the effort goes to SPDI r.7 and the sectoral controls (research r4/02) |
| DPDP r.13(4) | Notified SDFs only | No | Localisation of committee-specified data | — | Residency is per-tenant configuration, so an order becomes a configuration change (§17.1) |

**FR-LEG-014 · Residency statements are attestations of configuration** · **P0** · Owner: Security lead
Customer-facing residency statements are limited to (a) the §23.6 sentence, and (b) the
tenant's residency attestation generated from live configuration (§17.1, NFR-RES-701). No
channel may state or imply that Indian law requires or does not require localisation for that
customer. For a regulated tenant the attestation states what the configuration does, never
that the configuration discharges the tenant's regulatory obligation (K-21).
- **AC1** The attestation is regenerated from configuration on every change and matches a
  network-policy dump.
- **AC2** The attestation template carries no sentence characterising the tenant's own legal
  obligations.

---

### 23.7 The time-inverted biometric question — beliefs and corrections

Readers arrive with a GDPR-shaped prior: biometrics are a special category, the law is
getting stricter, consent is the gate. In India today the position runs the other way. The
stricter regime is the one in force now, and the regime arriving on or about 13 May 2027 has
no sensitive category at all (research r4 critic). The table is written for the sales
engineer, the security reviewer and the product manager who will each be told one of these
beliefs by a customer.

| # | The belief | True today? | True from on or about 13 May 2027? | Say instead, after clearance | Evidence |
| --- | --- | --- | --- | --- | --- |
| T1 | "Biometric attendance needs the employee's consent" | **Yes** — consent in writing, before collection (SPDI r.5(1)) | Possibly not, if s.7(i) reaches biometric means (untested, Part D-2), and only if the SPDI Rules lapse (CR-12) | "Today written consent is required. How that changes when DPDP commences is under counsel review." | EV-060, EV-058 |
| T2 | "DPDP makes biometric data sensitive" | No — DPDP has no sensitive category (s.2(t)); SPDI r.3 makes it sensitive | No; the SPDI classification may lapse with s.43A (CR-12) | B3 wording, both halves together | EV-059, EV-060 |
| T3 | "DPDP has no sensitive category, so biometrics are lightly regulated" | No — SPDI written consent and uncapped s.43A compensation apply; terminals are a CERT-In IoT surface | Depends on CR-12; the r.6 safeguards apply to all personal data | "Biometric data is regulated today under the SPDI Rules." | EV-060, EV-061, EV-062 |
| T4 | "The law requires attendance to be biometric" | No — OSH Code s.33(a) requires a register kept "electronically or otherwise" | No | "No Indian law requires biometric attendance." | EV-072 |
| T5 | "The Supreme Court upheld mandatory biometric attendance in October 2025" | No — *Dillip Kumar Rout* (29 Oct 2025) was disposed of because the employees did not oppose the system. It concerned a public employer and central government staff and contains no privacy analysis | No | Nothing | K-14 · EV-K25 · research r4/03 finding 6 |
| T6 | "A data protection board ruled in 2026 that biometric attendance is unlawful even with consent" | True **in Turkey** (KVKK Principle Decision 2026/921, 29 April 2026); no force in India | Same | Name the jurisdiction, or say nothing | K-15 · EV-K26 |
| T7 | "An employee who refuses can insist on an alternative under r.5(7)" | No — r.5(7) lets the body corporate withhold the service; the alternative is a product choice, not a statutory right | Depends on whether the SPDI Rules survive (CR-12) | "The product always offers a non-biometric path." | research r4/03 (retraction) |
| T8 | "A template is a one-way hash, so it is not personal data" | No — unprotected templates can be inverted into a matching sample (Gomez-Barrero and Galbally, *Computers & Security* vol. 90, 2020) | No — identifiable data is personal data under s.2(t) | "Templates are treated as personal data throughout." | research r4/03 finding 12 |
| T9 | "A face template is not biometric information under the Aadhaar Act" | Misleading — a photograph is "biometric information" (s.2(g)); a terminal template is not "core biometric information" (s.2(j)) and was not collected under the Act | Same | B19 wording | EV-071 |
| T10 | "Templates must be deleted on the day the employee leaves", or "must be kept for a year" | Neither — SPDI r.5(4) limits retention to the purpose; no fixed day is prescribed | The r.8(3) floor's scope is open (Part D-9) | "Erasure timing follows your configured policy." | research r4/03 finding 16 |
| T11 | "DPDP's three-year inactivity erasure applies to HR data" | Not in force | Still inapplicable — Third Schedule classes only | Nothing | research r4/01 finding 10 |
| T12 | "The Board can act on a biometric breach from November 2026" | [Killed] — that tranche is Consent Manager registration only | From on or about 13 May 2027, through ss.27–34 | B2 wording | K-05 · EV-K16 |
| T13 | "An Aadhaar face check could replace the terminal" | Not for a private employer without a permission route (s.57 omitted; s.4(4)); EPFO's UMANG face authentication is the employee's own act on their own device | Same | Nothing | EV-071 · research r4/04 findings 7, 21 |

<!-- DIAGRAM: legal-regulatory-consent-regime-switch -->

**What the inversion means for the build.** Build to the stricter present, and do not market
the relaxation that may follow. Written capture stays on after the switch until counsel
answers CR-02 and CR-12 (§09.2 AC2; FR-LEG-008). An artefact captured under the SPDI regime is
never re-labelled, discarded or re-dated at the switch, because it is the evidence that
collection was lawful when it happened (Part E-6).

---

### 23.8 Biometric attendance and workplace monitoring — the central unresolved risk

#### 23.8.1 Why this is the central risk

Attendance is plainly a purpose of employment. The open question is the **means**: whether
choosing the most intrusive available way to take attendance needs consent, or a
proportionality justification under the *Puttaswamy* line, once s.7(i) is in force (Part
D-2). We are not aware, as of September 2026, of any Indian case law or MeitY guidance on it
(research r4/03 findings 5–6, 21; re-check owner: Legal lead, LW-03 and LW-09), and there can
be no Data Protection Board decision yet, because the Board's adjudicatory powers do not
commence before on or about 13 May 2027 (EV-058). The clearest statement of the adverse argument is
foreign: Turkey's KVKK reasoned that labour law requires working hours to be recorded but
gives no basis for biometric identification, and that where cards, PINs, RFID or signatures
are available, biometrics are not necessary. That is persuasive material for an internal risk
memo and for counsel's brief. It is not authority in India (K-15).

The exposure is live now, not in 2027. Collection without written consent breaches SPDI
r.5(1); a breach of the template store sits under uncapped s.43A compensation; every terminal
is a CERT-In IoT surface; and marketing biometric attendance as compulsory or settled-lawful
is a misrepresentation the company would have to stand behind (EV-060, EV-061, EV-062, EV-072).

#### 23.8.2 The product posture — what already holds under every answer

The product-side controls are specified elsewhere and summarised here so the legal reasoning
and the build can be read together.

| # | Commitment | Why it holds under every counsel answer | Specified in |
| --- | --- | --- | --- |
| 1 | A genuine non-biometric path, selectable per employee at any time, with no manager override or penalty flag | It is the least intrusive means, whatever proportionality requires | §09.2 AC3 |
| 2 | No "biometric only" configuration exists | Shipping one builds the instrument of every customer's breach (Part D-10) | §09.12; FR-CHR-101 |
| 3 | Written consent before enrolment, separate from the employment contract and any bundled notice | Required today (SPDI r.5(1)); harmless if later unnecessary | §09.2 AC1; FR-CHR-100 |
| 4 | Templates only; enrolment images deleted after extraction; no image column, no image bucket | Minimises what can leak and what can be inverted | Part E-6; §09.2 AC4 |
| 5 | The template is a separate entity from the attendance event, so the register survives template destruction | Erasure without breaching record-keeping (OSH Code s.33(a); EV-054) | Part E-6; FR-CHR-103 |
| 6 | Two-phase device-side erasure with per-device acknowledgement, a retry queue and a documented exception state | Templates live in terminal flash, not only on the server | FR-CHR-103; §09 FR-DEV-007 |
| 7 | A separate keyspace; India residency; never sent to a model provider | SPDI r.7 today; security under every regime | §12.8.3; §17.4 |
| 8 | No Aadhaar identifier or authentication anywhere in the attendance flow | Separate regimes; no permission route (§23.8.4) | §09.12 |

#### 23.8.3 Decision table — what each counsel answer would change

| Counsel item | If counsel says… | The product changes… | Unchanged |
| --- | --- | --- | --- |
| CR-02 (s.7(i) and biometric means) | s.7(i) reaches biometric capture without consent | Post-switch written capture becomes a counsel-set option; the default stays *on* until CR-12 is also answered | Commitments 1–8 |
| CR-02 | Proportionality needs a recorded justification, or consent | Nothing structural — the posture already offers the least intrusive path; FR-LEG-015 adds a tenant justification field at enablement | Commitments 1–8 |
| CR-02 | Biometric attendance is unlawful absent demonstrated necessity | Biometric capture becomes off by default per tenant and enable-able only with a recorded necessity justification; existing templates follow each tenant's erasure decision | The attendance register (commitment 5) |
| CR-04 (who owes SPDI r.5) | The employer | `artefact_owner = employer`; notice text in the employer's name | The capture machinery |
| CR-04 | The vendor, or both | Artefacts in the vendor's name, or both names | The capture machinery |
| CR-09 (DPDP r.8(3)) | A universal one-year floor | From commencement, template erasure becomes suppression for a year, then purge | Behaviour before commencement |
| CR-09 | Seventh Schedule purposes only | The tenant's configured erasure timing stands | — |
| CR-12 (SPDI survival) | The Rules survive s.44(2) | SPDI behaviours stay armed after on or about 13 May 2027 (FR-LEG-008) | — |
| CR-12 | The Rules lapse | Post-switch capture follows CR-02 | SPDI-era artefacts stay on record |
| CR-27 (capture form) | In-app capture satisfies r.5(1) | Nothing | — |
| CR-27 | Only letter, fax or email satisfies it | A confirmation step by email is added for artefacts labelled in-app (FR-LEG-011 AC2) | Artefacts already captured |
| CR-28 (refusal) | An employer may act against an employee who refuses | Nothing — the product still never automates adverse action (FR-LEG-016) | FR-LEG-016 |

#### 23.8.4 Aadhaar-based attendance is not available, and is not pursued

- s.57 was omitted by Act 14 of 2019 with effect from 25 July 2019. A private entity may
  authenticate only if UIDAI is satisfied and a Parliamentary law permits it, or the Central
  Government prescribes the purpose in the interest of the State (s.4(4)) (EV-071; research
  r4/03 finding 8).
- The Good Governance (SWIK) Rules 2020, as amended by G.S.R. 88(E) of 31 January 2025, allow
  authentication for four purposes (r.3(1)), voluntarily (r.3(2)), after a proposal through a
  sponsoring Ministry that ends in a Gazette notification (r.4, r.5). MeitY's SOP lists "staff
  attendance" as a candidate use case for named sectors — civil aviation, health care,
  e-commerce, radio-taxi aggregators, pharmaceuticals and security companies — but approval
  attaches to the employer or sector participant, not to a horizontal software vendor
  (research r4/04 finding 15).
- The product does not build Aadhaar authentication into attendance (§09.12). The ESIC
  portal's option to authenticate an employee by fingerprint or iris is never built or
  endorsed at the employer's premises, because it would need a UIDAI Registered Device and
  would weaken the characterisation of the employer as a data-entry channel into a
  government portal (research r4/04 finding 9; CR-07).
- Whether any SWIK limb is arguable for a particular customer's own programme is CR-50, a
  low-priority item the product does not depend on.

#### 23.8.5 Workplace monitoring beyond biometrics

Continuous live location tracking (§09.11) — and any productivity or activity monitoring the
product might add — raises the same least-intrusive-means question as biometrics. The v0.3
PRD priced a competitor's GPS add-on and designed deskless attendance without that analysis
(research r5 counsel review). The legal posture:

- **Geo-fenced punching is base; continuous tracking is opt-in**, off by default, and
  separately enabled by the tenant (§09.11 AC1).
- **Its statutory basis is under counsel review** (CR-29). It is never marketed as
  lawful-by-default or as covered by s.7(i).
- **Enablement requires FR-LEG-015's acknowledgement and a template worker notice** (FR-LEG-002)
  stating what is collected, when, for what purpose and for how long.
- **Location data is not fed to performance scoring or any AI-influenced people decision**
  unless the worker notice discloses that use and the §10.13b controls apply to the
  decision.

#### 23.8.6 Terminal vendors — the contract fills what their documentation leaves out

The Indian terminal vendors' public documentation reviewed in research r4/03 is silent on
template format, whether images are kept, where on the device templates sit, encryption, and deletion procedure. One published
vendor policy splits its role by deployment model — the customer controls data on-premises,
the vendor acts as processor in its cloud. Terminals hold templates in local flash at scale —
the eSSL X990 specification lists 10,000 fingerprint templates and 256 MB of NAND flash — so
server-side deletion alone leaves the template live on every enrolled device (research r4/03
findings 10–11). DPDP s.8(1) will make the fiduciary responsible for processing done on its
behalf "irrespective of any agreement to the contrary" (research r4/03). FR-LEG-017 therefore
makes the missing facts contract terms.

#### 23.8.7 Worked example — a 60-person factory switches on face terminals

A 60-worker plastics unit in Coimbatore moves from paper muster rolls to three face terminals.
(1) The tenant admin enables biometric capture and records the FR-LEG-015 acknowledgement: no
law requires biometric attendance; written consent comes first; a non-biometric path stays
available; templates are erased on exit or withdrawal. (2) Each worker receives the enrolment
notice and gives written consent separately from the appointment letter; four decline and
elect card punching, and no flag is raised against them. (3) Eight months later one worker
withdraws consent in writing. The template erasure goes to all three terminals; one is offline
in a storeroom and stays in retry; the admin later attests it was decommissioned, which moves
it to the exception state. The worker's Form IX rows are untouched (§09.10). (4) A supervisor
asks for a deduction rule for "workers who refuse the face terminal". No such configuration
exists: the product records attendance-method elections, never penalties for them
(FR-LEG-016). (5) In month ten the plant's terminal vendor reports a firmware compromise. The
vendor contract's notification window lets the six-hour CERT-In clock run from our notice,
and FR-LEG-013 produces the tenant's pack.

#### 23.8.8 Requirements — biometrics and monitoring

**FR-LEG-015 · Tenant acknowledgement before biometric or continuous-location capture** · **P0** · Owner: Product + Legal lead
Enabling biometric capture or continuous location tracking for a tenant needs a tenant-admin
acknowledgement, rendered from an FR-LEG-002 template and recorded with actor and time. It
states that no Indian law requires biometric attendance (EV-072); that written consent is
required before collection today (EV-060); that a non-biometric path stays available to every
employee; that templates are erased on exit or withdrawal under the tenant's configured timing;
and that the statutory basis once DPDP commences is under counsel review. The acknowledgement
carries an optional tenant justification field, which becomes mandatory if CR-02 is answered
that way.
- **AC1** No enrolment or tracking event is accepted for a tenant without a current
  acknowledgement.
- **AC2** When the template changes (for example, after a counsel answer), tenants re-acknowledge
  before any new enrolment.

**FR-LEG-016 · No automated adverse action on refusal or withdrawal** · **P0** · Owner: Product
The product contains no rule, workflow, report or AI suggestion that connects an employee's
refusal or withdrawal of biometric enrolment, continuous tracking or Aadhaar submission to pay,
leave, attendance status, performance, discipline or employment. A refusal is recorded only as
an attendance-method election or an unprovided optional field. Whether an employer may lawfully
act on a refusal is CR-28, and any such act is the employer's, outside the product.
- **AC1** The configuration schema has no field linking a method election or an Aadhaar status
  to a pay component, a deduction or a disciplinary workflow; a schema test asserts it.
- **AC2** Reports that list elections cannot be filtered into disciplinary or performance
  workflows.

**FR-LEG-017 · Terminal-vendor legal minimums** · **P0 before any vendor is listed as supported** · Owner: Legal lead + Engineering
A terminal vendor or model is listed as supported only after written terms or confirmed
documentation cover: template format and whether it is a standardised interoperable format;
whether images are retained on the device or in vendor software; on-device storage location
and capacity; encryption at rest and in transit; support for remote deletion on command with an
acknowledgement; the vendor's role (processor, or none for on-premises); and notification of
security incidents to us within `device_vendor_incident_notice_hours`, set so that our six-hour
CERT-In clock stays achievable.
- **AC1** The device registry refuses a terminal model with no vendor-terms record.
- **AC2** Where a vendor cannot support deletion on command, the model is unsupported for
  biometric enrolment and may be used only in non-biometric modes.

---

### 23.9 Aadhaar — criminal exposure and the five rules

The Aadhaar regime is the highest-exposure cluster in this PRD and the one most likely to be
skimmed, because it is not a data-protection statute in name. It is live today, it carries
criminal as well as civil provisions, and it reaches named individuals (research r4 critic).
The regime is also **permissive with conditions**, not prohibitive: a plain employer may
collect and store an employee's Aadhaar number (EV-068). The product's job is to meet the
conditions exactly and to stay out of the categories — requesting entity, OVSE — that bring
heavier machinery.

#### 23.9.1 The exposure, provision by provision

| Provision | What the text says (research r4/04 findings 19–20; r4/02 finding 28) | What this PRD says about it |
| --- | --- | --- |
| s.38 | Whoever, not being authorised by the Authority, intentionally shares, uses or displays information in contravention of s.29 (limb g) is punishable with imprisonment up to **ten years** and a fine of not less than **₹10 lakh**. The consolidated text prints "three years" beside "[ten years]" because of the amendment marker; Act 14 of 2019 s.16 substituted ten | The chain — breach of Sharing Regulations 5–6, deemed a s.29(2) violation by reg 7, reaching s.38(g) — is unresolved: s.38 is headed as an offence of unauthorised access to the CIDR and its other limbs are CIDR-centric. **Build as though the chain holds; say nothing about whether it does** (Part D-8, CR-08; EV-067) |
| s.43 | Where a company commits an offence, every person in charge of and responsible for its business is deemed guilty, with a defence for one who proves the offence was committed without his knowledge or that he exercised all due diligence; directors and officers are caught for consent, connivance or neglect | Role-limited read access, logged with actor and reason, is the evidence for that defence (FR-CHR-099; FR-LEG-018) |
| s.47(1) | No court takes cognizance except on a complaint by the Authority; since 2019 an individual may complain only for ss.34–37, 40 and 41, and s.38 is not among them | Recorded as provision text only. It changes nothing in the build |
| s.33A with s.2(aa) | A civil penalty of up to ₹1 crore per contravention, plus up to ₹10 lakh per day of continuing failure, on an "entity in the Aadhaar ecosystem" — an inclusive definition naming requesting entities and OVSEs; inquiry only on the Authority's complaint, appeal to TDSAT | A further reason the entity that stores numbers never registers as an OVSE (Rule 3) |
| s.37 | Disclosure of identity information "collected in the course of enrolment or authentication" — up to three years | Its reach to a number an employee hands over directly for PF or Form 130 (ex-Form 16) is arguable; the PRD relies on it neither way |
| s.29(4) | No number, demographic information or photograph collected or created under the Act is published, displayed or posted publicly, except for purposes specified by regulations | The public-display hook that plainly binds an employer is Sharing Reg 6(1), which has no "collected under this Act" qualifier (Rule 2) |
| s.44 | Extraterritorial reach where CIDR data is involved | Part of CR-15 (offshore hosting) |

We are not aware, as of September 2026, of any published UIDAI adjudication, penalty order or
prosecution against an employer or HR software vendor for storing Aadhaar numbers (research
r4/04, two targeted passes). That is weak evidence of absence and changes nothing above.

#### 23.9.2 The five rules and their product consequences

| Rule | Instrument | What it says | Product consequence | Specified in |
| --- | --- | --- | --- | --- |
| **1 · Collection basis** | Sharing of Information Regulations 2016, reg 5 (EV-068) | Anyone collecting an Aadhaar number must (a) collect, store and use it for a lawful purpose; (b) tell the holder the purpose, whether submission is mandatory or voluntary — and, if mandatory, the provision that makes it so — and the alternatives; and (c) obtain consent. Three cumulative heads. Reg 5(2) bars use beyond those purposes; reg 5(3) bars sharing without consent | The Aadhaar field refuses input until a per-purpose consent record exists. The notice discloses Code on Social Security s.142 as context, never as a gate | FR-CHR-099(a); FR-CHR-100 |
| **2 · Handling duties** | Reg 6(1)–(5) and reg 7 (EV-068) | 6(1): never published, displayed or posted publicly by any person. 6(2): security and confidentiality of the numbers and of any database holding them. 6(3): redaction before any database is made public. 6(4): no transmission over the Internet unless secure and encrypted — a legal requirement, with a narrow carve-out for correcting errors or redressing grievances that the product does not build to. 6(5): no retention beyond the purpose stated at consent — a ceiling, not a floor. Reg 7 deems breach of regs 3–6 a violation of Act s.29(2) | Separate encrypted vault referenced by an opaque token, never the number or its hash; encrypted transport; deletion once the purpose is spent; last-four display, grounded in 6(2) and in risk — not presented as a statutory masking duty (Part D-5) | FR-CHR-099(b)–(g); §14 |
| **3 · The OVSE storage bar** | Aadhaar Act s.8A(4)(b); AOVR reg 14A(1)(b) (EV-069) | A registered Offline Verification Seeking Entity may not collect, use or store an Aadhaar number or biometric information for any purpose. There is no consent exception | The legal entity that stores numbers does not register as an OVSE. Whether the bar reaches the same entity's separate, employer-capacity holdings is unresolved: counsel before any UIDAI registration, and the corporate plan assumes separation (CR-21). Plain QR-code and e-Aadhaar verification need no registration on UIDAI's May 2026 handbook — guidance, not a regulation (research r4/04 finding 17) | FR-LEG-019 |
| **4 · No verification for others, no key sharing, no VID** | AOVR 2021 regs 16A(2), 15(2), 15(5), 4A(4) (EV-070) | No entity performs offline verification on behalf of another. An e-KYC licence key may not be shared (sharing is permitted only for Yes/No authentication, with joint and several liability). No entity stores a Virtual ID | The multi-tenant "we verify Aadhaar for your employees" feature **cannot be built**. A VID is never stored anywhere, including logs and exports | §07.1.3; FR-LEG-018 |
| **5 · No authentication without a permission route; terminal templates are not core biometrics** | s.57 omitted by Act 14 of 2019; ss.4(4), 2(g), 2(j), 29(1) (EV-071) | Private authentication needs a Parliamentary law or a prescribed purpose. A photograph is "biometric information" (s.2(g)); "core biometric information" is fingerprint and iris (s.2(j)); s.29(1) bars sharing core biometric information collected or created under the Act | No Aadhaar authentication in attendance or onboarding. Aadhaar identifiers and device templates never share a record or a flow. Nobody writes that a face template "is not biometric information under the Aadhaar Act" (B19) | §09.12; FR-CHR-103 |

<!-- DIAGRAM: legal-regulatory-aadhaar-feature-gate -->

#### 23.9.3 Aadhaar is optional everywhere — including the EPF and ESI flows

- **Code on Social Security s.142** (in force from 3 May 2021 under S.O. 1730(E)) requires an
  *employee* seeking registration or a benefit to establish identity through Aadhaar. It is
  drafted as the employee's obligation. On notification, the Ministry of Labour and Employment
  publicly said it was notified to collect worker data and that no benefit would be denied for
  want of Aadhaar — corroborated secondary reporting, the release itself not retrieved
  (research r4/04 findings 5–6). An earlier inference that s.142 makes Aadhaar mandatory in the
  EPF and ESI flows is **[Killed]**.
- **The employee now generates the UAN.** Since 1 August 2025 UAN allotment and activation run
  only through Aadhaar face authentication in the UMANG app, done by the employee; the employer
  route survives only for International Workers and citizens of Nepal and Bhutan (EPFO circular
  of 30 July 2025; research r4/04 finding 7). This is the largest single cut in the product's
  Aadhaar surface. The product prompts, tracks and chases; in the ordinary case it does not
  collect.
- **Seeding before ECR is an administrative instruction, not a statute.** EPFO requires UANs to
  be Aadhaar-seeded before contributions are received through the ECR (EPFO circular
  BKG-27/5/2021-BKG of 11 September 2021, reciting an instruction of 1 June 2021) (research
  r4/04 finding 8).
- **ESIC performs the e-KYC.** The employer enters the number at IP registration and the ESIC
  portal authenticates it with UIDAI (research r4/04 finding 9). Whether keying a number into
  the EPFO or ESIC portal makes the employer a requesting entity is CR-07 (Part D-7).
- **When an employee declines, the default is exclude-and-flag** — never a payroll block. The
  employee is paid; the member's line is left out of the affected artefact and logged on the
  exception register; the operator and the employee each get a notice; a Supplementary return
  follows once the member is seeded, with the s.7Q interest shown (Part E-11; FR-CHR-101;
  EV-037, EV-039). The final default, the alternatives, and when the employee's share is
  deducted while the line is excluded are CR-30.
- **No hard-block configuration ships** — no "no Aadhaar, no payroll", in any tenant setting
  (Part D-10). If the product offered one, the vendor would have built the instrument of every
  customer's breach (research r4 critic).
- **Aadhaar is not collected for income-tax purposes.** PAN–Aadhaar linkage is the individual
  taxpayer's obligation. Where an employee's PAN is reported inoperative, the product shows a
  non-blocking nudge and collects nothing. What that means for the employer as deductor —
  higher-rate deduction and short-deduction exposure — is unverified and is not stated either
  way until tax counsel answers CR-31. The earlier draft sentence "no employer-facing penalty",
  with its section number deliberately left off, is **[Killed]** (research r5 counsel review;
  FR-LEG-020).

#### 23.9.4 The Aadhaar questions that stay with counsel

| Item | The question | Default until answered |
| --- | --- | --- |
| CR-05 (Part D-5) | Is masking a statutory duty on a plain employer? Reg 14(1)(mb)'s eight-digit rule binds requesting entities; reg 6(1) bars *public* display | Last four digits shown by default, justified as security under reg 6(2) and risk |
| CR-06 (Part D-6) | Does the Aadhaar Data Vault and HSM regime bind a non-requesting entity? UIDAI Circular 14 of 2025 and its 3 Nov 2025 FAQ scope it to requesting entities; UIDAI's 2017 position reached "other entities" too. If it flips back, the cost includes on-premises or government-community-cloud hosting, HSMs and an annual SOC 2 Type II audit by a CERT-In-empanelled auditor | The token vault is built so that moving to a formal vault is a migration, not a rewrite (FR-CHR-099; research r4/04 finding 14) |
| CR-07 (Part D-7) | Does an employer keying a number into the EPFO or ESIC portal become a requesting entity under s.2(u)? | Portal integration modelled as data entry into a government portal that authenticates; the ESIC biometric path is never built |
| CR-15 (Part D-15) | Is hosting Aadhaar numbers outside India, or exposing them to a foreign sub-processor, lawful for a non-requesting entity? | The vault is India-only and excluded from every sub-processor and model call |
| CR-21 | Does the s.8A(4)(b) OVSE bar reach the same legal entity's employer-capacity holdings? | Separation assumed; no registration without counsel (FR-LEG-019) |
| CR-22 | Is the SaaS itself an "entity which collects" under reg 5, needing its own purpose and consent? Can one artefact satisfy both reg 5 and a DPDP notice? | Consent records state whose artefact they are; reg 5 and DPDP artefacts kept as separate records (FR-CHR-100) |
| CR-31 | What follows for the deductor when an employee's PAN is inoperative? | A non-blocking nudge; no statement either way |

#### 23.9.5 The withdrawn advisory and the unnotified announcement

- **The photocopy advisory is not law** (K-12, EV-K23). UIDAI's Bengaluru regional office
  advised on 27 May 2022 against sharing Aadhaar photocopies; PIB/MeitY withdrew the release on
  29 May 2022 "in view of the possibility of the misinterpretation". The withdrawal was read at
  primary level from a UIDAI-hosted archive (research r4/04 finding 22). It will surface in
  customer security reviews; the answer comes from FR-LEG-007.
- **The December 2025 announcement is not notified** as far as we are aware as of September
  2026. It reportedly said private verifiers would have to register with UIDAI and photocopy
  collection would be barred. UIDAI's own gazetted-notifications register (updated 30 June
  2026) lists the AOVR Amendment Regulations 2025 as the latest authentication instrument, and
  UIDAI's May 2026 handbook says registration is *not* mandatory for QR-code or e-Aadhaar
  verification (research r4/04 finding 23). The product is designed so that moving from storing
  the number to verifying an Aadhaar Verifiable Credential — which carries only the last four
  digits plus demographics and a photograph — and storing a token is a configuration change,
  not a rewrite (LW-12).
- **The OVSE perimeter is already populated.** UIDAI's list of registered OVSEs held 158 entities
  as at 30 June 2026, including employment-screening firms and gig-workforce platforms.
  Registration is by legal entity; the list does not show which product line uses it (research
  r4/04 finding 18). No competitor inference is drawn from it.

#### 23.9.6 Requirements — the Aadhaar gate

**FR-LEG-018 · Aadhaar design-review gate** · **P0** · Owner: Legal lead + Security lead
Any feature, export, report, integration, log field, support tool or model call that would
read, write, transmit or display an Aadhaar number, an Aadhaar document, a VID, or perform
Aadhaar verification or authentication, passes the five-rule review (the flow above) before
build, with a recorded decision. Rules 3–5 are hard stops. A feature resting on an open
counsel item ships on the conservative default and is logged against that item.
- **AC1** A static check finds no read path to the vault outside the services the review has
  approved; a new path fails CI until a review record exists.
- **AC2** Every vault read is logged with actor, purpose and reason, and the log is exportable
  as due-diligence evidence (s.43).

**FR-LEG-019 · UIDAI registration control** · **P0** · Owner: Founder + Legal lead
No company entity applies to UIDAI for registration as an OVSE, a requesting entity or an
authentication user agency, or signs a UIDAI agreement, without a written counsel opinion
covering CR-21 and the corporate-structure consequence. The entity that stores customers'
Aadhaar numbers never registers as an OVSE. The same control covers any Good Governance
(SWIK) proposal (CR-50).
- **AC1** The corporate registry records, per legal entity, any UIDAI registration and the
  opinion it relied on; the Aadhaar vault's hosting entity shows none.

**FR-LEG-020 · PAN-status handling makes no legal statement** · **P1** · Owner: Product + Tax counsel
Where an employee's PAN is recorded as inoperative — by the employee, by the tenant, or from a
verification the tenant runs — the product raises a non-blocking task for the employee and the
payroll operator. It collects no Aadhaar number for
the purpose and shows no statement about the employer's or employee's tax consequences until
CR-31 is answered and the wording is registered (FR-LEG-001).
- **AC1** The PAN-inoperative notice template has no consequence clause until one is cleared.

---

### 23.10 Employment discrimination — five instruments, the twenty-person line and the s.90 anchor

Recruiting and performance are where an Indian employer's discrimination exposure
concentrates, and AI assistance makes that exposure harder to answer, not easier. §10.13b
specifies the product controls (FR-T-D001 to FR-T-D012). This subsection states the law they
rest on, how they may be sold, and how they may not.

#### 23.10.1 The starting point — there is no general statute

- **The constitutional equality guarantees bind the State.** Articles 14, 15(1) and 16 do not
  reach a private employer. The horizontal exceptions — Article 15(2) on access to shops,
  public restaurants, hotels, places of public entertainment and public wells, tanks and
  roads; Article 17 on untouchability; Article 23 on trafficking and forced labour — do not
  reach ordinary private hiring (research r5/05 finding 39).
- **India has no general private-sector anti-discrimination statute** covering caste, religion,
  age or sexual orientation in employment. Coverage runs characteristic by characteristic and
  is incomplete (EV-084).
- **The Supreme Court reaches private employers through statute.** *Jane Kaushik* describes its
  route as "Indirect Horizontal Application by the Means of the 2019 Act" (EV-083).
- **This is not a reassuring picture.** A product doing shortlisting and performance scoring
  sits under at least five instruments that bind private employers (research r5 counsel
  review). An earlier draft named one and read as reassurance; that framing is **[Reversed]**.

#### 23.10.2 The instrument matrix

Thresholds use different counting units — RPwD Rule 3(2) counts *persons*, Rule 8(3) counts
*employees*, POSH s.6(1) counts *workers*, HIV Act s.20 counts persons in any capacity — so the
same tenant can be above one line and below another on the same day. Each threshold is a
schema field with its counting unit, exactly as in §06.1 (EV-057).

| Instrument | Who is bound | Threshold (counting unit) | The duty | Enforcement and penalty | §10.13b control |
| --- | --- | --- | --- | --- | --- |
| **RPwD Act 2016 s.3(3)**, with s.2(h) and s.2(y) (EV-075; s.90 at EV-079) | Any person — the text is actor-neutral; its reach to private actors is inferred from that drafting and from Rule 3(2) | None | No discrimination on the ground of disability "unless it is shown that the impugned act or omission is a proportionate means of achieving a legitimate aim" — the onus is on the discriminator. "Discrimination" covers "purpose or effect" and includes denial of reasonable accommodation, so a screen that cannot accommodate an atypical profile can discriminate without intent | s.89: fine up to ₹10,000 for a first contravention; ₹50,000 to ₹5 lakh for a subsequent one. s.90: company and officer liability, with the due-diligence defence | FR-T-D001–D005 |
| **RPwD Rules 2017, Rule 3(2)–(4)** (G.S.R. 591(E), 15 Jun 2017; EV-076) | The head of a private establishment | **Twenty or more persons** | On a disability-discrimination complaint: initiate action under the Act, or tell the complainant **in writing** how the act was a proportionate means of achieving a legitimate aim. Rule 3(3): the Commissioner disposes of the complaint within 60 days, or 30 in exceptional cases. Rule 3(4): no charging a person with disability for reasonable accommodation | The Chief and State Commissioners hold civil-court powers, including discovery and production of documents, and their proceedings are judicial proceedings (ss.77, 82); a Special Court is designated in each district (s.84) | FR-T-D008; FR-LEG-026 |
| **RPwD s.21 with Rule 8** (EV-077) | Every establishment | Publication: every establishment. Content: **twenty or more employees** get the full Rule 8(3)(a)–(e) content; fewer than twenty cover facilities and amenities only (Rule 8(4)) | Publish an EOP on the website or at conspicuous places; register a copy with the Chief or State Commissioner (s.21(2)). Registration is correspondence — no portal and no prescribed form for private establishments | s.89 | FR-T-D006; FR-LEG-022 |
| **RPwD s.22 with Rules 9 and 14** (EV-078) | Record content: establishments within Rule 8(3). Production on demand: every establishment (Rule 9(2)) | As stated | Keep five particulars: the number of persons with disabilities employed and their start dates; name, gender and address; nature of disability; nature of work; facilities provided. **Form III is for Government establishments only** (Rule 14) | **s.93**: failure to produce documents or information — up to ₹25,000 per offence, plus up to ₹1,000 for each day the failure continues | FR-T-D007 |
| **RPwD s.20, s.23, Rule 10** | Government establishments only | — | Not a private-sector duty. A private employer has no RPwD-mandated Grievance Redressal Officer; its analogue is Rule 3(2). Any text saying RPwD s.20 binds private employers is wrong (K-11 [Killed]) | — | — |
| **Transgender Persons Act 2019, ss.3, 9, 10, 11; Rules 2020, Rules 12–13** (G.S.R. 592(E), 25 Sep 2020; EV-080) | Every "establishment" — any company, body corporate, firm, association, society, trust or institution (s.2(b)) | **None** | No discrimination in employment, including recruitment and promotion (s.9; the exact connective in s.9 is to be settled against the gazette before it is quoted). Facilities (s.10). A designated complaint officer (s.11; Rule 13(1), within thirty days). Rule 13 enquiry within fifteen days of a complaint and action within a further fifteen. An EOP (Rule 12). The rule-level timelines come from a legal-database reproduction of G.S.R. 592(E) and the Supreme Court's summary, **[Verified — mirror]**: pull the gazette before customer use | s.18 does not criminalise employment discrimination; the remedy runs through the complaint officer, Rule 13 and writ proceedings with compensation | FR-T-D009 |
| **Code on Wages 2019, ss.3(1), 3(2)(ii), 4** | Every employer | **None** | No gender discrimination in wages for the same or similar work (s.3(1)). No sex discrimination in recruiting for the same or similar work, or in conditions of employment, except where a law prohibits or restricts women's employment in that work (s.3(2)(ii)) — the only statute reaching recruitment on the ground of sex (EV-081). Disputes on "same or similar" go to an authority the appropriate Government notifies (s.4); some States have notified one, and the Central Rules 2026 appear not to | s.54(1)(c): up to ₹20,000; s.54(1)(d): a repeat within five years, up to one month's imprisonment or ₹40,000 or both; s.54(2): records, up to ₹10,000; s.54(3): a written direction with a compliance window must precede prosecution under (1)(c) or (2) | FR-T-D004; FR-LEG-024 |
| **HIV and AIDS Act 2017, ss.2(d), 3(a), 3(l), 20, 38** (EV-082) | s.3 binds "no person" — every employer. Complaints Officer: 100 or more persons in any capacity; 20 or more in healthcare (s.20) | Prohibition: none | No termination of a protected person unless they receive an independent healthcare provider's written assessment and the employer's written statement of hardship — failing which the Act **presumes against the employer**. No HIV test as a pre-requisite for employment. Discrimination is effects-based ("directly or indirectly, expressly or by effect") | State-appointed Ombudsman; s.38: failure to comply with an Ombudsman's order, up to ₹10,000 plus up to ₹5,000 per day | FR-T-D010 |
| **POSH Act 2013, ss.4(1), 6(1)** | Every employer of a workplace | IC: every employer. Where fewer than ten **workers** mean no IC is constituted, complaints go to the district Local Committee (s.6(1)) — a route, not an exemption | Constitute an Internal Committee by written order, at each administrative unit. A harassment statute, not a hiring-discrimination duty (EV-056) | The duty and penalty provisions (ss.19, 21, 22, 25, 26) were not re-verified in round five (CR-49) | FR-T-D011 |
| **SC/ST (Prevention of Atrocities) Act 1989, s.3(1)(zc)** | Whoever | None | Imposing or threatening a social or economic boycott; "economic boycott" (s.2(bc) — text search-derived, to be checked against the gazette) includes refusing to work for hire and denying opportunities | Criminal: six months to five years and a fine. Whether an algorithmic rejection could be charged as *imposing* a boycott is untested and would need proof of imposition, not adverse effect alone | None on its own — never a product driver by itself |
| **Code on Social Security 2020, Ch. VI, s.68** | Employer | — | Unlawful to discharge or dismiss a woman during or on account of maternity absence, or to vary her conditions of service to her disadvantage | Appeal to the competent authority within sixty days (s.68(2)) | FR-T-D004 (pregnancy never a scoring feature) |

Sources: EV-075–EV-082; research r5/05 findings 1–33. The Code on Wages' exclusion of persons
employed mainly in a managerial or administrative capacity may limit s.3's reach to senior
hiring; until CR-38 is answered, no copy says the product "covers all hiring".

#### 23.10.3 Case law and official guidance — stated accurately

- ***Jane Kaushik v. Union of India*, 2025 INSC 1248** (Supreme Court, 17 October 2025, W.P.(C)
  1405 of 2023, Pardiwala and Mahadevan JJ.). A transgender teacher was excluded by two private
  unaided schools. Respondents 1–3, all State actors, were each ordered to pay ₹50,000 for
  inaction; respondent 4, a private unaided school, was separately ordered to pay ₹50,000
  (EV-083). Both halves of the remedy are always stated together; a one-sided description is
  checkable. The judgment directed the States and Union Territories to ensure that every
  establishment designates a complaint officer (direction 199(iv), within three months), asked
  a committee to report within six months, and directed the Union to bring its own Equal
  Opportunity Policy within three months of that report, enforceable at any establishment that
  has none of its own (para 217), under a continuing mandamus (para 218) (research r5/05
  finding 27). On the judgment's own arithmetic the report was due about 17 April 2026. We are
  not aware of the Union policy having issued as of September 2026 (LW-07). The Ministry of
  Social Justice's February 2024 policy for transgender persons is that Ministry's internal
  policy and is never cited as a customer obligation (research r5/05 finding 29).
- ***Nitisha v. Union of India*** (Supreme Court, 25 March 2021). Indirect discrimination turns
  on effect, not intent; statistical evidence is one route to proving it; the Court declined to
  lay down any quantitative threshold; and the absence of statistical evidence cannot by itself
  defeat a claim. The justification test asks whether the criterion is necessary for successful
  job performance, with close scrutiny of whether less discriminatory alternatives exist. The
  Court quotes Sandra Fredman's observation that aptitude tests and selection processes escape
  scrutiny unless data is available — in effect a description of AI screening (EV-083; research
  r5/05 finding 37). **Limit:** *Nitisha* is a constitutional case against a State employer. It
  reaches private employers only by analogy, through RPwD s.3(3)'s identical "proportionate
  means of achieving a legitimate aim" wording — the likely shape of a first argument, never
  settled law (research r5/05 finding 38). This is why FR-T-D003 commits to no four-fifths
  rule or any other number.
- **A citation to handle with care.** *Jane Kaushik* quotes an earlier judgment as saying the
  RPwD Rules stipulate that private establishments shall not discriminate, citing Rule 3(1).
  Rule 3(1)'s operative text is narrower — it makes the head of the establishment ensure s.3(3)
  is not misused to deny a right — and it is the marginal heading that reads as a flat
  prohibition. Cite the proposition to *Jane Kaushik*; never quote Rule 3(1) as if it were a
  flat ban (research r5/05 finding 42).
- **No Indian case law on algorithmic hiring.** We are not aware of any Indian court or
  tribunal decision on algorithmic or AI-assisted hiring, screening or performance management
  as of September 2026; the first will be a matter of first impression (EV-084). The Chief
  Commissioner for Persons with Disabilities is the likeliest first forum, given its discovery
  powers and low-cost complaint route (research r5/05).
- **MeitY's map for a plaintiff.** Annexure 4 of the India AI Governance Guidelines, headed as
  illustrative, lists "discrimination in hiring decisions using AI recruitment tools" against
  RPwD 2016, the Transgender Persons Act 2019, the Code on Wages 2019 and the SC/ST (PoA) Act
  1989. The Guidelines are voluntary, name employment bias as a risk, call for audit trails and
  human-in-the-loop at critical decision points, and contemplate converting voluntary measures
  into "mandatory baseline requirements" (EV-073; research r5/05 findings 35–36). Because the
  Annexure is illustrative, no one argues that a statute missing from it — the HIV Act, POSH —
  is excluded.
- **The CCPD template** (F.No. CC-12017/22/2022-O/o CCPD, 5 November 2024) asks the EOP to show
  that qualification standards, employment tests and other selection criteria reflect the job,
  to state that disability information will not prejudice an application, and to list
  recruitment accommodations — accessible advertisements, a scribe, an interpreter, screen
  readers, and a person with disability as an expert on the selection committee. The product
  treats an AI shortlisting model as falling within "employment tests, or other selection
  criteria" — a design assumption drawn from the template's wording (research r5/05 finding
  14), not a legal characterisation, and never stated to a customer as one. The template's
  performance-evaluation passage is permissive ("could"), and the template contains no
  reference to AI, algorithms or automated decisions (research r5/05 findings 14–16).

#### 23.10.4 The positioning anchor, and the sentence we never say

> **The sanctioned proposition (register it; FR-LEG-023).** RPwD s.90 makes a company, and
> every person in charge of and responsible for its business, guilty of an offence the company
> commits under the Act — unless that person proves the offence was committed without his
> knowledge or that he exercised all due diligence to prevent it. "Company" includes a firm or
> other association of individuals, so the provision reaches unincorporated customers. The
> burden of proving diligence falls on the person who relies on the escape, and it is
> evidentiary: diligence has to be proved, and records made at the time are the obvious way to
> prove it. This product is how a founder or an HR head produces those records — a named
> confirmer on every AI-influenced decision, a snapshot that reconstructs it, adverse-impact
> monitoring, a published EOP, the Rule 9 record, and complaint workflows with their clocks
> (EV-079).
>
> **The sentence we never say, write or imply: that these controls are required by law.** We are
> not aware, as of September 2026, of any Indian statute that requires human review of
> AI-assisted hiring (EV-084 records the absence of case law; re-check owner: Legal lead,
> LW-08 and LW-10), and DPDP Chapter III, when in force, creates no right against automated
> decisions (EV-066). The claim is false and checkable (Part D-18; B13).

Two facts sharpen the proposition for a 20–200 person buyer. The records exposure is s.93 —
per offence, accruing daily — which is more on point for a records product than s.89 (EV-079).
And Rule 3(2) lands exactly on the ICP floor: at twenty persons, an employer facing a
disability complaint must either initiate action under the Act or tell the complainant in
writing how the act was a proportionate means of achieving a legitimate aim — and **no employer
can write that letter about a decision no human made and no system can reconstruct** (EV-076).

<!-- DIAGRAM: legal-regulatory-rpwd-complaint-sequence -->

#### 23.10.5 Requirements — the legal layer over the discrimination controls

**FR-LEG-021 · Due-diligence dossier** · **P1 (v1.5, with recruiting)** · Owner: Product + Legal lead
For a date range, a tenant can export one dossier assembling the evidence of its controls: the
named-confirmer records and decision snapshots (FR-T-D001, FR-T-D002); the adverse-impact
reports as generated at the time (FR-T-D003); the protected-attribute bar's configuration
history (FR-T-D004); EOP versions with their publication and registration correspondence
(FR-T-D006); the Rule 9 record (FR-T-D007); complaint-officer and Internal Committee
designations (FR-T-D009, FR-T-D011); and complaint cases with their clocks (FR-T-D008). The
dossier's cover text comes from a registered template that describes it as evidence of controls
and never says the controls satisfy any law or establish any defence.
- **AC1** Every item in the dossier comes from records written at the time; nothing is
  recomputed.
- **AC2** Missing items are listed as gaps rather than omitted silently.

**FR-LEG-022 · The EOP's "manner of selection" is derived from live configuration** · **P1** · Owner: Product
Rule 8(3)(c) requires the EOP of an establishment with twenty or more employees to describe the
manner of selection. The FR-T-D006 generator fills that clause from the tenant's actual
configuration — which AI features are enabled at which recruiting stages, and that a named human
confirms every AI-influenced rejection — so the published policy cannot drift from what the
system does.
- **AC1** Enabling or disabling a recruiting AI feature marks the current EOP stale and prompts
  the tenant to publish a new version.
- **AC2** The clause never states that a control is legally required.

**FR-LEG-023 · Positioning discipline for discrimination controls** · **P0** · Owner: GTM + Legal lead
Website, deck, proposal and sales-script language about FR-T-D controls uses only registered
claims built on the §23.10.4 proposition. The banned list (B6, B13, B18) is enforced by
FR-LEG-003, and a win-loss or call-review sample checks the spoken pitch against it.
- **AC1** Every discrimination-control claim in collateral resolves to a cleared FR-LEG-001 entry
  citing EV-079.

**FR-LEG-024 · Basis records for pay differences and sex-based criteria** · **P2** · Owner: Product
For any two roles paid differently, the tenant can record the basis on which they are treated as
not "the same work or work of a similar nature", because a dispute goes to a notified authority
(Code on Wages s.4). The requisition and screening record logs that no sex-based criterion
entered a recruitment decision, or records the prohibiting or restricting law the tenant relies
on (s.3(2)(ii); FR-T-D004).
- **AC1** A requisition carrying a sex-based criterion cannot be published without the cited
  law recorded against it.

**FR-LEG-025 · Complaint intake routes by statute** · **P1** · Owner: Product
One intake receives discrimination and harassment complaints and routes each to the workflow and
clock of the statute it engages — RPwD Rule 3(2) (FR-T-D008), the Transgender Persons Rules
(FR-T-D009), the HIV Act (FR-T-D010), POSH (FR-T-D011) — or to the tenant's own policy where
none applies. The routing uses the tenant's threshold facts with their counting units, so a
nineteen-person tenant sees no Rule 3(2) case type and a tenant of fewer than ten workers is told
of the Local Committee route.
- **AC1** A complaint engaging two statutes opens linked cases, one per statute, each with its
  own clock.

**FR-LEG-026 · Legal hold on complaints and proceedings** · **P1** · Owner: Product + Legal lead
Opening a complaint case, or receiving notice of proceedings before a Commissioner, an
Ombudsman, a Local Committee or a court, places a retention hold (§14's `RetentionHold`) on the
case's decision snapshots, related records and the affected people's relevant data. No erasure
request, retention expiry or tenant purge releases the hold; only a recorded release by the
tenant, stating its counsel's instruction, does.
- **AC1** An erasure request touching held data returns a statement that the data is held for
  proceedings, and erases nothing held.

---

### 23.11 AI and data protection

§12 specifies the AI layer and its six safety rails (§12.8.3). This subsection states what
Indian law does and does not say about AI in HR, the legal footing of each rail, and how each
may be described.

#### 23.11.1 What the law says — and does not say — about AI in HR

| Proposition | Status on 11 Sep 2026 | How it may be described | Evidence |
| --- | --- | --- | --- |
| DPDP Chapter III contains no right against automated decisions, no right to an explanation and no right to human review | A verified negative about a chapter **not yet in force** | Only in that narrow form (B18). It is never generalised to "Indian law", because the discrimination statutes apply to AI-assisted decisions (§23.10) | EV-066; research r5 counsel review |
| DPDP s.8(3) requires data likely to be used for a decision affecting a person to be complete, accurate and consistent | Not in force until on or about 13 May 2027; not consent-gated, so it will reach s.7(i) processing | The operative forward-dated quality duty for appraisal, attrition and shortlisting data; an inspect-and-correct path is built now (FR-LEG-027) | research r4/02 finding 14; r5/05 finding 40 |
| We are not aware of any Indian provision that expressly requires redaction before a model call | A negative from targeted text searches (research r4/02), dated September 2026; re-check owner: Legal lead | The chokepoint is a security control. Its hooks are SPDI r.7 (live), Aadhaar reg 6 (live) and DPDP r.6(1)(a) (not in force) | research r4/02 findings 21–22; EV-064 |
| DPDP has no free-standing data-minimisation principle; minimisation enters only through the scope of consent (s.6(1)), which does not govern s.7 uses | Verified on the text | The MeitY Guidelines say otherwise; the statute governs (§23.1.4 rule 9) | research r4/02 findings 16, 21 |
| SDF "algorithmic due diligence" (r.13(3)) | Binds only notified SDFs; not in force. Its verb list — hosting, display, uploading, modification, publishing, transmission, storage, updating, sharing — omits analysis, inference, scoring and profiling | A narrow reading may put candidate-scoring models outside it; not relied on (CR-44) | EV-065; research r4/02 finding 9 |
| IT (Intermediary) Amendment Rules 2026 — "synthetically generated information" | In force; covers only audio, visual or audio-visual information, with a carve-out for routine documents, presentations, PDFs and training material; duties attach only to an intermediary offering a resource that enables such content | Text generation sits outside it. Whether an HR SaaS is an "intermediary" is CR-13; no audio-visual generation ships without review (FR-LEG-028) | EV-074; research r4/02 finding 17 |
| India AI Governance Guidelines (MeitY) | Voluntary; recommend against a separate AI law; contemplate "mandatory baseline requirements" later | Policy signal; never a mandate; watched (LW-08) | EV-073 |
| CERT-In Annexure I item xx | In force: attacks on AI/ML systems are reportable within six hours | A distinct AI/ML incident class (§17.6) | EV-062 |
| RBI Draft Guidance on Regulatory Principles for Model Risk Management, 2026 | A draft, released 24 June 2026, comments closed 24 July 2026; we are not aware of a final text as of September 2026. Reported to cover third-party and AI/ML models, with explainability, human oversight and customer disclosure — the contents come from secondary sources, and the draft itself was not opened | If finalised in that form it would turn human-in-the-loop into a hard requirement for BFSI customers (CR-43, LW-10). FREE-AI (August 2025) is an advisory report | research r4/02 finding 27 |
| Who is the fiduciary for AI processing | Unresolved. The SaaS may be a fiduciary in its own right for processing it decides for itself — routing data to a model, choosing the vendor, using aggregate customer data to improve models | Not stated; the product avoids self-determined processing of tenant data (FR-LEG-029; CR-26) | research r4 critic; r4/02 finding 11 |

#### 23.11.2 The six rails and their legal footing

| Rail (§12.8.3) | Footing today | Footing from on or about 13 May 2027 | How it may be described |
| --- | --- | --- | --- |
| 1 · Redaction and tokenisation chokepoint | SPDI r.7 for sensitive data; Aadhaar reg 6(2) and 6(4) | Adds DPDP r.6(1)(a), which names masking and virtual tokens | "A security control on every model call." Never "required by law" |
| 2 · LLM log residency in India | CERT-In direction (iv), on the reading that LLM logs are ICT-system logs (CR-23) | Adds DPDP r.6(1)(e)'s log-retention duty; its period is the counsel-set `retention.dpdp_r6_logs` (CR-11, §23.3.5) | "Kept in India with our other system logs" |
| 3 · Kill switch, off by default for RBI, SEBI and IRDAI tenants | RBI paras 16(r) and 16(o) where material; SEBI residency and infrastructure rules; IRDAI reg 53 | Same | "Off until you choose to enable it." Never "because your regulator forbids AI" |
| 4 · Sub-processor-change gate | RBI para 16(r) where material; SPDI r.5(3)(c), the employer's duty to name intended recipients, which the product enables | Adds DPDP s.8(2)'s contract requirement | "No new AI vendor without notice — and, for regulated tenants, without your recorded consent" |
| 5 · Per-employee AI disclosure record | A commercial and enablement ground; supports the employer's SPDI r.5(3)(c) disclosure | DPDP s.11(1)(b) only where processing rests on consent (Part D-1) | Never as a statutory access-request requirement |
| 6 · Named human confirmer on consequential people decisions | We are not aware of any statute that requires it (as of September 2026); it evidences RPwD s.90 due diligence (EV-079) | Same; the RBI draft may require it for BFSI (CR-43) | The §23.10.4 wording; B13 banned |

#### 23.11.3 AI outputs are drafts — the legal reasons

The rules-first, LLM-last invariant (§12) has three legal foundations, not only a quality one.
The deductor's and employer's statutory liability for every filed figure is non-delegable
(K-13), so no model may set one. From commencement, s.8(3) will make the employer answerable
for the accuracy of data used for decisions about people. And a Rule 3(2) response must explain
a decision a human made (EV-076). An AI output is therefore a draft until a named person
adopts it, and that adoption is the record.

#### 23.11.4 Governance parity is a claim posture, not a certificate

Keka publishes AI governance commitments — a citation on every answer, no silent writes
without confirmation, multi-entity policy awareness, RBAC on every AI call, no training of
external models on customer data — and a "Keka MCP Server"; greytHR states that NAVOS is
included in every plan (EV-090, captured September 2026; vendor pages read, products not
tested). These set the table stakes. Our own equivalents are registered claims (FR-LEG-001),
each mapped to a §12 control with a test (§12.8.3, governance parity), so the promise can never
outrun the build. Competitors' commitments are described as their published claims, never as
false or unmet (§21).

#### 23.11.5 Requirements — AI legal controls

**FR-LEG-027 · Inspect-and-correct for AI-derived attributes** · **P1 (before any such attribute ships)** · Owner: Product (AI)
Any AI-derived attribute that is stored against a person or shown to anyone deciding about them
— an attrition-risk score, a skill inference, a performance summary, a shortlist rank — is
visible to the person it describes in plain language, with its inputs by category. The person
can challenge it, and a challenge is routed to a named human who can correct or suppress it,
with the outcome recorded. The legal anchor is s.8(3) from commencement, which is not
consent-gated. It does not rest on the s.12 correction right, which is (research r4/02).
- **AC1** No AI-derived attribute can be stored without a visibility setting and a challenge
  route.
- **AC2** A corrected or suppressed attribute is excluded from later decisions, and every
  decision snapshot that used it records that it was later corrected.

**FR-LEG-028 · Synthetic audio-visual generation gate** · **P0 as a scoping guardrail** · Owner: Product + Legal lead
No feature that creates or alters audio, visual or audio-visual content — AI onboarding videos,
voice cloning for announcements, avatar presenters — ships until counsel has answered CR-13
(intermediary status) and the labelling duties of the IT Rules as amended by G.S.R. 120(E) have
been mapped to the feature (EV-074). Text, document, presentation and training-material
generation are outside this gate.
- **AC1** The feature-flag registry refuses an audio-visual generation flag with no linked
  counsel record.

**FR-LEG-029 · No self-determined processing of tenant data without a basis decision** · **P0** · Owner: Founder + Legal lead
Tenant employee data is processed only to deliver the service to that tenant. It is not used to
train, fine-tune or evaluate any model shared across tenants, not pooled for product analytics
beyond aggregate operational metrics, and not sent to a model vendor not in that tenant's
consented set (§12.8.3; AC-G-5). Any proposed change to this is a recorded decision taken on a
counsel opinion that covers CR-26 — the company becoming a fiduciary in its own right — and
enters the tenant contract and notices before it takes effect.
- **AC1** The data-use register lists every purpose for which tenant data is processed; a new
  purpose cannot be enabled without a linked decision record.

---

### 23.12 Sectoral overlays — RBI, SEBI, IRDAI

Three regulators reach this product only through customers they regulate. Each binds the
regulated entity, not us, and each reaches us through the customer's contract. None of the
three is a reason to change the product for an unregulated tenant; all three are reasons to
make the regulated-tenant profile a property set at onboarding that propagates to every
subsystem (§17.1).

#### 23.12.1 What each regulator requires

| | RBI (EV-087 **[Verified — mirror]**) | SEBI (EV-085) | IRDAI (EV-086) |
| --- | --- | --- | --- |
| **Instrument** | Master Direction on Outsourcing of Information Technology Services, RBI/2023-24/102, 10 April 2023, effective 1 October 2023 | Cloud framework SEBI/HO/ITD/ITD_VAPT/P/CIR/2023/033 (6 March 2023); CSCRF SEBI/HO/ITD-1/ITD_CSC_EXT/P/CIR/2024/113 (20 August 2024) | Information and Cyber Security Guidelines 2023; PPHI Regulations 2024 (F. No. IRDAI/Reg/11/205/2024, in force 1 April 2024); Maintenance of Insurance Records Regulations 2015 |
| **Who is bound** | Scheduled commercial banks (excluding RRBs), local area, small finance and payments banks, urban co-operative banks, NBFCs, credit information companies and all-India financial institutions | The cloud framework: eight categories — stock exchanges, clearing corporations, depositories, stock brokers, depository participants, mutual funds and AMCs, KYC registration agencies, qualified RTAs. CSCRF: a wider population; non-individual investment advisers are small-size REs; individual IAs, FPIs and FVCIs are excluded | All insurers, foreign reinsurance branches and insurance intermediaries (agents, micro-insurance agents, point-of-sale persons and individual surveyors excluded) |
| **Trigger** | **Materiality** — each regulated entity decides whether the arrangement is material. Not turnover (K-22) | Category membership; CSCRF in force for every non-excluded RE, the last extended compliance timeline having run to 30 June 2025 | Insurer status. Outsourcing (reg 2(14)) means a third party performing activities the insurer would normally do — managed payroll is squarely inside; a licensed tool operated by the insurer's own HR team has a strong argument for falling outside |
| **Residency** | Localisation among the obligations the entity must secure | Data resides and is processed in India; for foreign-incorporated investors, a readable copy in India. On public cloud (Lane B), MeitY-empanelled infrastructure in MeitY-empanelled, STQC-audited data centres (FAQ Q47, Q50). On infrastructure the provider owns (Lane A), offshore is allowed with a readable India copy (FAQ Q51) | No localisation, MeitY or STQC requirement in the 2023 Guidelines (a 175-page text search returns none). Policy records in India (reg 3(7)); a 2024 draft extends this to claims, status unknown. Offshore outsourcing needs Competent Authority permission (reg 53(2)) |
| **Audit and inspection** | Right to audit including by RBI (para 16(o)), reaching sub-contractors; for providers abroad, RE and RBI audit rights must be ensured (para 21(c)) | SEBI, CERT-In and government agencies may audit, inspect and search and seize the CSP and its sub-contractors (Principle 7(iv)); GDPR conflicts resolved in SEBI's favour for Indian operations (FAQ Q46) | Regulator's right to examine books, records, systems and controls of the provider or sub-contractor, scoped to the service (reg 53(1)); no search-and-seizure power |
| **Sub-contractors** | Prior approval or consent of the RE before using sub-contractors (para 16(r)); information on the supply chain (16(n)); provider liable for sub-contractors (16(p)); "sub-contractor" means those providing material IT services (footnote 4) | Principle 7(x) terms 14, 15 and 19 — supply-chain information, liability for sub-contractors, risk assessment of third-party vendors | No prior-consent requirement (a text search finds none) |
| **Contract** | Clauses implementing paras 16(n)–(r) and 21 | Exactly 20 mandatory terms (Principle 7(x)), including in-India storage (term 7) and compliance with SEBI directions (term 16); an expunging clause (7(vii)); no joint ownership of any task (7(xi)) | The reg 53 undertaking; for offshore arrangements, host-country law must not impede IRDAI's access |
| **Keys and security** | — | BYOK or BYOE with a dedicated fault-tolerant HSM (clause 6.2.9); keys managed in India per FAQ Q26, with SEBI's localisation consultation still open. A signed undertaking from the vendor that the software is free of known vulnerabilities, malware and covert channels (PR.IP guideline 5); application security and functional audit of SaaS (guideline 15). ISO 27001 mandatory only for MIIs and qualified REs (PR.IP.S16) | Audit relief: under s.2.14, a vendor certified to ISO 27001 with the service in scope *may* be excepted from periodic audits (discretionary). Under s.2.19 cl.3.7.1, a vendor "certified under the Cloud Security Alliance Trust" or providing control information under the Cloud Trust Protocol, with the service inside the certification's scope, *shall* be exempt (mandatory); research reads the certificate as CSA STAR, which is to be confirmed against the text before it drives the certification roadmap (research r5/01). Both still need a self-certificate and preserve the contractual audit right |
| **Open legal points** | Materiality per entity (CR-14) | Whether the RE's own employee HR data is "Regulatory Data"; whether PR.IP.S15 point 6 reaches all SaaS; the empanelment status of the chosen India region (CR-41) | Licence-versus-outsourcing confirmation; the Master Circular's materiality detail (CR-42) |

Sources: research r4/02 findings 25–26; r5/01 findings 1–24. Three standing corrections travel
with this table. The RBI obligations bind the regulated entity and are materiality-gated
(K-22 [Killed] as "no threshold"). Replay supports evidence production for RBI inspections and
does not discharge the audit, access and inspection obligations (K-21 [Killed] as "satisfies by
construction"). And SEBI's FAQ Q51 is the own-infrastructure lane only — an earlier reading
that it frees any HR SaaS from the MeitY-empanelment rule is **[Killed]** (research r5/01
retraction).

**The segregation lever (SEBI FAQ Q27).** CSCRF audit coverage is limited to systems under
SEBI's purview "only if" they are properly segregated. Ancillary systems that access or
communicate with in-purview systems are pulled back in. An HR tenancy with no shared identity
plane and no data path into the entity's trading, KYC or reporting stack has a SEBI-sourced
argument for sitting outside CSCRF audit scope. Every integration built into those systems
forfeits it (research r5/01 finding 13). A dev and test estate may run on Tier-3 facilities
provided it holds no production or customer data (FAQ Q52).

<!-- DIAGRAM: legal-regulatory-sector-profile -->

#### 23.12.2 Worked example — a 120-person stock broker

A SEBI-registered stock broker with 120 employees signs up. The questionnaire (FR-LEG-030)
places it in the cloud framework's eight categories, and our standard deployment rides a public
cloud, so it is Lane B. Consequences: its data and inference are pinned to an India region
whose MeitY-empanelment and STQC status has been confirmed in writing by the cloud provider for
every data centre in the region (FAQ Q48 — providers expose only region-level selection; the
confirmation is open until CR-41 closes); the AI kill switch starts engaged; the Principle 7(x)
rider is attached to the contract; the key-management design is BYOK with India-resident keys;
the evidence pack includes the PR.IP guideline 5 undertaking and the segregation statement
(FR-LEG-032); and the product offers no SSO or directory link into the broker's in-purview
systems unless the broker accepts, in writing, that the link brings the HR system into CSCRF
audit scope.

#### 23.12.3 Requirements — regulated tenants

**FR-LEG-030 · Sector questionnaire sets the tenant profile** · **P0 before any regulated-sector sale** · Owner: Product + Legal lead
Onboarding asks whether the customer is regulated by RBI, SEBI or IRDAI and, if so, which
category (the RBI addressee list; the SEBI cloud-framework categories and CSCRF classes; insurer
or intermediary). The answer sets `sector_profile` (§17.1), which engages the regulated-tenant
defaults: AI kill switch engaged, sub-processor gate on recorded consent, India pinning for data
and inference. The product records the customer's answers as the customer's statements and does
not classify the customer itself.
- **AC1** A tenant whose questionnaire indicates regulation cannot reach production with a
  standard profile.
- **AC2** A change of answer re-evaluates the profile and freezes any new sub-processor use until
  the new profile's gates are met.

**FR-LEG-031 · RBI materiality is the regulated entity's recorded decision** · **P0 for RBI tenants** · Owner: Legal lead
For an RBI-regulated tenant, the product records the entity's own materiality determination for
the arrangement — material, not material, or pending — with its date and the entity's signatory.
The company never asserts materiality either way (CR-14). All RBI-profile controls stay on
whichever answer is recorded; a "material" answer additionally triggers the para 16 contract
clauses and the para 21 cross-border checks.
- **AC1** Customer communications about materiality come only from registered claims that
  describe the entity's decision, never ours.

**FR-LEG-032 · SEBI lane declaration and evidence pack** · **P1 (before the first SEBI tenant)** · Owner: Security lead + Legal lead
The company documents which SEBI lane its hosting is in (A or B) and keeps, per region used, the
cloud provider's written confirmation of MeitY-empanelment and STQC-or-equivalent status for every
data centre. For each SEBI tenant it assembles: the Principle 7(x) rider; the hosted-services
evidence (data-centre tier, the MeitY-equivalence and audit reports, VAPT summaries, the in-India
readable-copy design, the no-kill-switch declaration, the RACI annexure); the PR.IP guideline 5
undertaking in counsel-cleared form; and a segregation statement generated from the tenant's
actual integrations (FAQ Q27).
- **AC1** Adding an integration into a SEBI tenant's systems regenerates the segregation
  statement and records the tenant's written acceptance before the integration is enabled.

**FR-LEG-033 · IRDAI packaging is recorded per tenant** · **P1** · Owner: Product + Legal lead
For an IRDAI-regulated tenant, the contract records whether the service is a self-service
licence operated by the insurer's own staff or a managed payroll service. A managed service
triggers the outsourcing artefacts: the reg 53(1) undertaking reaching sub-contractors, and a
check that no processing for that tenant happens outside India without the insurer's evidence of
Competent Authority permission (reg 53(2)). The licence reading is confirmed by counsel before it
is relied on (CR-42).
- **AC1** A tenant cannot move from licence to managed service without the outsourcing
  artefacts being in place.

---

### 23.13 Attended filing — legality, liability allocation and the launch fence (Part D-17)

Attended submission is this PRD's positioning, a line in its cost model, the basis of its
support organisation and its largest single legal exposure. Three independent reviewers — an
engineer, a CFO and counsel — each found it unscoped (research r5 synthesis). §22 specifies the
operation: per-portal runbooks and the credential vault. This subsection specifies what must be
true in law before an operator may press submit, and what ships until it is.

#### 23.13.1 What is settled

- **The deliverable** is a portal-accepted artefact plus attended, assisted filing under the
  customer's written authority to act. The employer's and the deductor's statutory liability is
  **non-delegable** and stays with the customer whatever the company does (K-13, EV-K24).
- **Every surface is attended.** EPFO's employer sign-in carries a CAPTCHA. For TDS, the
  deductor runs Protean's FVU utility (a Java desktop program) over the text file and uploads
  the result. ESIC takes a template upload. State professional tax is N separate portals
  (research r3/05; EV-035–EV-038). We are not aware of a submission API or other published
  machine interface on any of them as of September 2026 (re-check owner: Statutory lead, §22).
- **Nobody else submits.** No vendor in the six-vendor priced set claims to submit any filing;
  greytHR, the most compliance-forward, publishes only generation language (EV-030). Attended
  submission is therefore a real differentiator — and the one most exposed to the questions
  below.
- **Some portal acts cannot be undone.** An approved EPFO return can never be cancelled, and a
  downward correction is possible only before payment is initiated (EV-036, EV-037). An operator's
  mistake at submission is not always reversible, so each submission needs the customer's
  per-filing approval, not a blanket mandate (FR-LEG-035).

#### 23.13.2 The open questions (CR-17a to CR-17f)

| # | Question | Why it matters | Until answered |
| --- | --- | --- | --- |
| CR-17a | Is it lawful for our operator to act on a government portal under the employer's credentials? | It is the act itself. Authority to act, however well drafted, does not settle whether the act is lawful (research r5 counsel review) | Mode A for every surface |
| CR-17b | Do each portal's own terms of use permit a third party to use the employer's credentials? | A breach could expose the customer's registration or the session, and would be the company's doing | Mode A for that portal |
| CR-17c | Does filing a TDS return for a deductor engage the e-Return Intermediary route? | The income-tax portal refers to e-Return Intermediary API specifications that research could not read; such schemes have historically covered income-tax returns, not TDS statements — a low-confidence lead (research r3/05) | TDS stays in Mode A |
| CR-17d | How is the authorised signatory's digital signature certificate handled, given it is personal to a named individual? Whether a DSC or EVC is mandatory to upload a Form 138 file is itself unconfirmed (research r3/05) | A personal DSC held by our operator would be the individual's credential in our hands | The operator never holds a personal DSC; the signatory signs in the attended session |
| CR-17e | How is liability for a rejected, late or wrong assisted filing allocated between the company and the customer, and on what cap and indemnity? | No contract term currently allocates it — the single most important commercial term the positioning implies (research r5 counsel review) | Mode A; the SLA narrows to artefact readiness |
| CR-17f | Is assisted submission insurable as designed? | Uninsurable exposure changes the cap, the price or the design | Mode A |

One subsidiary question travels with CR-17a: whether establishment portal credentials held for
a customer are, in substance, an individual signatory's password — a sensitive category under
SPDI r.3(i) — and so engage r.5 and r.7 (EV-060). The §22 vault is built to the stricter answer.

#### 23.13.3 The launch fence — two modes, per portal and per filing type

**Mode A — artefact-ready.** The product generates a portal-accepted artefact; the employer or
deductor submits it; the product records the receipt against the filing ledger. This is the
category convention and needs no counsel answer. **Mode B — attended, assisted submission** by
our operator under the customer's written authority, run to the §22 runbook. Mode B is enabled
per portal and per filing type, only when every gate in the flow below is green. If counsel
does not clear it, launch proceeds on Mode A and the SLA narrows to artefact readiness and
warning lead time (§05.7, §05.12; §19). The AI layer never submits anything in either mode
(§12).

<!-- DIAGRAM: legal-regulatory-attended-filing-gate -->

#### 23.13.4 The written authority to act — what the instrument must contain

Counsel drafts the instrument. The product requires it to contain at least the elements below
before any credential enters the §22 vault (FR-LEG-035).

| Element | Why | Note |
| --- | --- | --- |
| The customer legal entity, and each establishment or registration it covers (EPF code, ESIC code, TAN, PT registration per state) | Filing is per registration; the per-establishment filing ledger must match the authority (Part E-10) | A new registration needs an amendment, not an assumption |
| The portals and filing types covered, and the periods | Mode B is enabled per portal and per filing type | Anything not listed stays Mode A |
| Per-filing approval: the customer's named approver approves each artefact before it is submitted | Some portal acts are irreversible (EV-036) | No blanket authority |
| Payment: whether the operator may initiate payment on a portal | The EPFO downward-correction window closes at payment initiation (EV-037) | Product default: payment initiation is the customer's act |
| Credentials: how they are provided, held, rotated and revoked; how OTP and MFA prompts reach the customer | Holding them is the highest-risk surface in the product (research r3/05) | §22 vault |
| Signing: the signatory's DSC stays with the signatory | CR-17d | — |
| A statement that statutory liability for every filing stays with the employer or deductor, and a reference to the liability-allocation clause | K-13; CR-17e | Wording from FR-LEG-002 |
| Access to the "what we did on your behalf" log | Evidence for the customer and for any inspection | §22 |
| Revocation: immediate, with the effect on filings in flight | The customer must be able to stop us at once | — |
| Change of authorised signatory, term and renewal | Authority must track the customer's own authority chain | — |

#### 23.13.5 Liability allocation — the principles counsel drafts from

1. The employer's and deductor's statutory liability is non-delegable and is never described as
   transferred (K-13; B8).
2. The company's obligation is a portal-accepted artefact plus best-efforts assisted submission
   under written authority (Mode B), or a portal-accepted artefact alone (Mode A).
3. The cap and indemnity are set on that basis (CR-17e), and their insurability is checked
   (CR-17f).
4. The compliance SLA's remedy (§19) is a capped commercial remedy, not a transfer of statutory
   liability.

**Worked example — a Mode B ECR that misses its due date.** A portal outage and a CAPTCHA loop
keep our operator from submitting a 90-person tenant's ECR before the due date. EPFO calculates
s.7Q interest automatically and it is mandatory (EV-039); the establishment owes it. Whether the
company reimburses any of it is decided by the contract's allocation clause and the SLA remedy,
within its cap — never by a promise in sales copy. The filing ledger records the attempt
history, the mode and the approver, so the allocation can be applied on facts.

#### 23.13.6 Requirements — the attended-filing fence

**FR-LEG-034 · Submission-mode fence and record** · **P0** · Owner: Product + Legal lead
Mode B is a per-tenant, per-registration, per-portal, per-filing-type flag. It can be switched
on only when the counsel register shows CR-17a to CR-17f cleared for that surface, an executed
FR-LEG-035 instrument covers it, and the liability clause (FR-LEG-036) is in the customer's
contract. Every filing records the mode used, the approver, the operator (Mode B), and the
receipt.
- **AC1** With any gate red, the operator console offers no submit action for that surface; the
  artefact is delivered for the customer to submit.
- **AC2** Metrics and the SLA read the mode from the filing ledger, so a Mode A filing is never
  counted or sold as submitted by us (§19).

**FR-LEG-035 · The authority-to-act instrument** · **P0 before any Mode B filing** · Owner: Legal lead
The instrument is a versioned, counsel-drafted template with the §23.13.4 elements, executed by
the customer's authorised signatory, stored against the tenant and each covered registration,
and revocable in product with immediate effect.
- **AC1** The vault accepts a credential only for a registration and portal covered by an
  executed, unrevoked instrument.
- **AC2** Revocation disables Mode B for every covered surface within
  `authority_revocation_sla_minutes` and notifies the operator team; filings in flight revert
  to Mode A.

**FR-LEG-036 · Liability language on filing surfaces** · **P0** · Owner: Legal lead + Product
The approver's sign-off screen, filing receipts, SLA reports and customer emails about filings
use registered wording (FR-LEG-002) stating that statutory liability for the filing stays with
the employer or deductor. No surface says or implies that the company "files for" the customer
or takes on the statutory liability (B8).
- **AC1** The banned-claim lint (FR-LEG-003) covers filing-surface templates.

---

### 23.14 Records, registers and retention — the conflicts the engine must not resolve silently

§14.7 owns the retention engine and §17 NFR-DPDP-506 the schedule. This subsection lists the
legal conflicts inside the notified text that the engine must surface rather than resolve.

**The only statutory record-retention periods this PRD states as periods the product applies**
are EV-054's central-sphere figures: Wages Rules r.51(4), "five years after the date of last
entry"; OSH r.72(1)(vii) and SS r.53(1)(e), "five calendar years from the date of last entry" —
not identically worded; OSH r.76(2), which bars destroying the leave register even after five
years unless it has been properly transferred to a new register; and IR r.47, which makes
electronic maintenance compulsory and sets no period. The one other period the product applies
is CERT-In's 180 days of ICT logs in India, which is a log-residency duty (EV-062). DPDP's
r.6(1)(e) and r.8(3) periods are not in force and appear in this PRD only as the questions in
CR-09 and CR-11. Every other period is a named configurable parameter set on counsel's opinion
(Part D-11, CR-11).
Research round five located candidate provisions — under the Income-tax Act 2025 and Rules 2026,
the Companies Act 2013 and the Code on Social Security (research r5/04 findings 32–37, 45–46).
They are inputs to counsel, never product defaults. State-sphere periods are unknown.

| # | Conflict in the notified text | Why it matters | Product behaviour until counsel answers | Item |
| --- | --- | --- | --- | --- |
| 1 | SS maternity Schedule para 11(a)(2) requires entries in the Register of Women Employees (Form XXII) to be "made in ink"; SS r.53(1)(b) permits registers "electronically or otherwise" | An electronic Form XXII could be challenged | Kept electronically, with a print-and-sign fallback the tenant can choose; the choice is recorded | CR-33 |
| 2 | OSH r.72(4) keeps registers at an office or nearest building within the precincts of the workplace, or within a radius of three kilometres, "unless otherwise provided for"; SS r.53(3) is worded differently and reserves the dispensing power to the Central Government | Cloud-hosted registers against a physical-location rule | Registers are producible at the establishment on demand; no copy claims that cloud hosting satisfies r.72(4) | CR-34 |
| 3 | The Wages Rules define "electronically" narrowly (r.2(j): email, a designated portal, a mobile application, a website, digital payment); the OSH and SS Rules adopt the IT Act's broad "electronic form"; IR r.47(1) defines nothing | A private employer database may not be "electronic" under the Wages definition | Registers are generated in the notified formats; "fully electronic statutory registers" is banned (B22) | CR-34 |
| 4 | OSH r.72(7)(ii) requires true copies of lost manual originals to be kept "for a specified period"; the phrase appears once in the 318-page rule-set and is defined nowhere | An undefined period cannot be computed | `retention.osh_true_copies` is unset, so true copies are held, never erased; the UI shows "interpretation pending counsel" and states no period | CR-36 |
| 5 | IR r.47(2) requires compliance with "the requirement of retention of records" and gives no period | Same | `retention.ir_records` held and never erased while unset | CR-36 |
| 6 | Every labour-code clock runs from "the date of last entry made therein" — a property of the register, not of an employee (inference) | A continuously open register never starts its clock, so no row in it ever becomes erasable | Registers are period-scoped objects (Form IX is headed "For the Month of") and the clock starts at close (§14.7) | — (research r5/04 finding 44) |
| 7 | OSH r.76(2) — a destruction bar conditioned on transfer, not a timer | A timer-based purge would breach it | Destruction eligibility requires a recorded transfer-to-new-register event | — |
| 8 | Form I field 24 is the Aadhaar number; Sharing Reg 6(5) limits retention to the consented purpose | A register rendered years later may carry a number the vault had to delete | Rendered only from the vault at generation time; whether a register may carry the full number is open | CR-35 |
| 9 | Form I field 35 is "Specimen Signature/Thumb Impression" | A thumb impression may be SPDI biometric information needing written consent (EV-060) | Captured only with written consent until answered | CR-35 |
| 10 | Form IX signature rows are footnoted as required where the register is kept physically | Electronic signature for an electronic register is not addressed | Suppressed for electronic maintenance per the footnote; the signature question goes to counsel | CR-35 |
| 11 | DPDP r.8(3) one-year floor — not in force, scope contested | §23.3.5 | Neither immediate purge nor one-year suppression hard-coded | CR-09 |
| 12 | Income-tax Rules 2026 r.46(8)–(9) — residency and retention for electronic books of account | Whether payroll artefacts are part of a customer's books is fact-specific | India residency with daily in-India backup; the retention period is a counsel-set parameter | CR-36 |

Sources: EV-053–EV-055; research r5/04 findings 9–16, 33–34, 44.

**FR-LEG-037 · Conflicts are flagged and interpretations are labelled** · **P0** · Owner: Statutory lead + Legal lead
Every retention class, register rendering and location behaviour listed in the table carries a
`legal_conflict_ref` to its counsel item. Any value the product applies in place of a missing or
undefined statutory period is shown to tenants as "interpretation pending counsel", never as a
statutory period, and appears in the counsel register until answered.
- **AC1** The erasure statement (§17 NFR-DPDP-506) lists each class held under an interpretation
  with its label and counsel item.
- **AC2** No customer-facing copy states a retention period other than EV-054's central-sphere
  figures (Part D-11).

---

### 23.15 Contract architecture — the named workstream

This PRD does not draft contracts. It names the instruments the positioning implies, the
minimum each must contain on the evidence, and what stays open, so the contract workstream
starts from a list rather than a blank page (research r5 synthesis: "name it as a workstream;
do not draft it here").

| Instrument | Must contain at minimum | Open (counsel) | Owner |
| --- | --- | --- | --- |
| **Master services agreement** | The filing-liability allocation (§23.13.5); the SLA remedy schedule (§19); the statement that statutory liability is non-delegable; a cap and indemnity consistent with both | Cap, indemnity scope and insurability; the company's own statutory exposure as a processor (CR-03, CR-17e, CR-17f) | Legal lead |
| **Data processing agreement** | Reasonable security safeguards — the only clause DPDP's Rules mandate (r.6(1)(f)), from on or about 13 May 2027; erasure on the customer's instruction (s.8(7)(b)); the SaaS's own SPDI r.7 and r.8 commitments, which bind it on either reading of Part D-4; a DPDP schedule that switches on at commencement. No warranty of compliance with DPDP before it is in force. Enterprise buyers will ask for GDPR-style terms whatever the statutory floor (research r4/01 finding 13) | Whether r.8(3)'s one-year floor is a DPA commitment (CR-09); whose consent artefact is whose (CR-04) | Legal lead |
| **Sub-processor schedule and change notice** | The per-tenant register (§17.7); notice before any addition or swap; prior written consent for regulated tenants | The notice period, set by `subprocessor_change_notice_days` — research suggests 30 days with a right to object, **[Hypothesis]** (research r4/02) | Legal lead + Security lead |
| **Authority to act** | §23.13.4 | CR-17a–d | Legal lead |
| **AI and model-vendor terms** | No training on customer data; no onward disclosure; zero or bounded retention; deletion on instruction; a named processing location (research r4/02). The no-onward-disclosure term mirrors SPDI r.6(4)'s bar on a recipient disclosing further. Whether r.6 binds the SaaS directly turns on CR-04, so the term is drafted as a contract obligation that holds on either answer, and no copy says who owes the statutory duty (Part D-4) | Inspection rights for regulated tenants, which frontier-model vendors may not grant (research r4/02 finding 26) | Legal lead |
| **Terminal-vendor terms** | FR-LEG-017's minimums | Controller or processor role per deployment model (CR-26) | Legal lead + Engineering |
| **Regulated-tenant riders** | RBI paras 16(n)–(r) and 21 where material; SEBI Principle 7(x)'s 20 terms, the 7(vii) expunging clause, 7(xi) and a RACI annexure; the IRDAI reg 53 undertaking | Materiality (CR-14); SEBI Regulatory Data scope (CR-41); IRDAI packaging (CR-42) | Legal lead |
| **Competitor comparisons in collateral** | Comparative advertising is permitted; disparaging a competitor's goods is actionable (Trade Marks Act 1999 s.29(8) read with s.30(1)), and ASCI's comparative-advertising provisions apply to collateral. Each claim needs clearance, a dated capture and a note of whether the product was executed or only its documentation read (research r5 counsel review) | Clearance of each claim (CR-47) | GTM + Legal lead; §21 |

**FR-LEG-038 · Model-vendor minimum terms gate** · **P0** · Owner: Legal lead + Engineering
A model or AI vendor enters any tenant's eligible provider set (§12.14, §13.10) only after its
executed terms cover the minimums in the table. The router cannot route to a provider without a
current terms record.
- **AC1** The provider registry blocks enabling a provider whose terms record is missing or
  expired; a canary test confirms no traffic reaches it.

**FR-LEG-039 · Sub-processor changes are notified, and objections are handled** · **P1** · Owner: Legal lead + Product
Adding or swapping a sub-processor notifies every affected tenant `subprocessor_change_notice_days`
before first use, with the purpose, data classes and region. A regulated tenant's use starts only
on recorded consent (§12.8.3 rail 4). An objecting tenant's data is kept off the new
sub-processor, and the feature degrades for that tenant rather than routing around the objection.
- **AC1** The router's eligible set for a tenant equals its consented set at every point in
  time; an audit query proves it for any past date.

---

### 23.16 The counsel register

Every question this PRD refuses to answer is listed here with the section it bites on, the
behaviour the product ships until it is answered, an owner and a status. CR-01 to CR-20 carry
Part D's numbering. CR-21 onward are the questions other sections route to §23, and the ones this
section raises. Owners are roles; "Tax counsel" and the Legal lead may be external. **Status is
as of 11 September 2026: every item is open.** "Standing" marks a drafting rule rather than a
question. The gate column names the latest point by which an answer is needed; "none" means the
build proceeds on the default indefinitely.

| ID | Question | Where it bites | Behaviour until answered | Owner | Status | Gate |
| --- | --- | --- | --- | --- | --- | --- |
| CR-01 (D-1) | Do employees hold DPDP access, correction and erasure rights against an employer relying on s.7(i)? Both answers are dangerous to state | §07 FR-CHR-076; §14.7; §17 NFR-DPDP-502; §12.8.3 rail 5 | Machinery built as a capability; responses never assert an entitlement (B15) | Legal lead | Open | Before DPDP-regime response templates are cleared |
| CR-02 (D-2) | Does s.7(i), once in force, authorise biometric attendance capture, or does the most intrusive means need consent or a proportionality justification? | §09.2; §23.8 | Written consent on; a non-biometric path always; no "lawful" claim (B20) | Legal lead | Open | Before any biometric marketing copy; before the post-switch capture default changes |
| CR-03 (D-3) | Does the SaaS carry direct statutory penalty exposure as a processor (s.33(1), Schedule item 7)? | §23.3.7; MSA and DPA; insurance | Nothing stated (B16); cap and indemnity drafted conservatively | Legal lead | Open | Before the DPA template is final |
| CR-04 (D-4) | Does the MeitY press note of 24 Aug 2011 take the SaaS outside SPDI r.5 and r.6, and who owes the written-consent duty? | FR-CHR-100; notices; DPA | Capture built either way; `artefact_owner` recorded; r.7 and r.8 are our stated floor | Legal lead | Open | Before notice templates are cleared |
| CR-05 (D-5) | Is Aadhaar masking a statutory duty on a plain employer? | FR-CHR-099 | Last-four display on security grounds (B17) | Legal lead | Open | None |
| CR-06 (D-6) | Does the Aadhaar Data Vault and HSM regime bind a non-requesting entity? | §14 vault; cost model | Token vault designed so a formal vault is a migration | Legal lead + Security lead | Open | Before the vault architecture is frozen |
| CR-07 (D-7) | Does keying an Aadhaar number into the EPFO or ESIC portal make the employer a requesting entity? | §16.5; FR-CHR-101 | Data-entry characterisation; the ESIC biometric path is never built | Legal lead | Open | Before Mode B on EPFO or ESIC |
| CR-08 (D-8) | Does the chain Sharing Regs 5–6, via reg 7, to s.38(g) hold? | §23.9.1 | Build as though it holds; say nothing about whether it does | Legal lead | Open | None — the posture is fixed |
| CR-09 (D-9) | Is DPDP r.8(3) a universal one-year floor, or scoped to the Seventh Schedule? | §14.7; §23.3.5; template erasure | `retention.dpdp_r8_3` unset; neither behaviour hard-coded | Legal lead | Open | Before on or about 13 May 2027 |
| CR-10 (D-10) | May Aadhaar submission or biometric enrolment be a condition of employment, payroll or any benefit? | FR-CHR-101; §09.12; FR-LEG-016 | Never a condition; no hard-block configuration exists | Legal lead | Open | None — no hard block ships on any answer |
| CR-11 (D-11) | What statutory retention periods apply beyond EV-054's central-sphere figures — EPF, ESI, TDS and Forms 138 and 130, gratuity, appointment letters, IR records, consent evidence, every state period — and, from DPDP commencement, the r.6(1)(e) log period (`retention.dpdp_r6_logs`) and how it combines with CERT-In's 180 days? | §14.7; §17 NFR-DPDP-506; FR-LEG-037 | Held, never erased, while the parameter is unset | Legal lead + Statutory lead | Open | Before automatic erasure of any of those classes |
| CR-12 (D-12) | Do the SPDI Rules survive the omission of IT Act s.43A and s.87(2)(ob)? | FR-LEG-008; §09.2 AC2 | SPDI behaviours stay armed after the switch | Legal lead | Open | Before on or about 13 May 2027 |
| CR-13 (D-13) | Is an HR and payroll SaaS an "intermediary" under IT Act s.2(1)(w)? | FR-LEG-028 | No audio-visual generation ships | Legal lead | Open | Before any audio-visual feature |
| CR-14 (D-14) | Is the arrangement "material" outsourcing for a given RBI entity? | FR-LEG-031 | The entity's recorded decision; RBI controls on | Legal lead, per deal | Open, per customer | Each RBI deal |
| CR-15 (D-15) | Is hosting Aadhaar numbers outside India, or exposing them to a foreign sub-processor, lawful for a non-requesting entity? | Vault; sub-processors | India-only vault; excluded from every sub-processor and model call | Legal lead | Open | Before any non-India option for the vault |
| CR-16 (D-16) | Every unprovable negative — no SDF designated, no s.16(1) country notified, no s.17(3) notification, no DPDP amendment gazetted since November 2025, no UIDAI penalty on a private entity, no Board appointments | All copy | "We are not aware of any … as of [date]", with a re-check owner | Legal lead | Standing | Each use |
| CR-17 (D-17) | Attended-filing legality: a) acting on portals under employer credentials; b) portal terms of use; c) the e-Return Intermediary route for TDS; d) the signatory's personal DSC; e) liability allocation; f) insurability | §23.13; §22; §05.7; §19 | Mode A everywhere | Legal lead | Open | Before any Mode B filing |
| CR-18 (D-18) | That AI-hiring controls are legally mandated | Collateral; §10.13b | Never said; s.90 framing only (B13) | GTM + Legal lead | Standing | — |
| CR-19 (D-19) | Describing anything as sensitive "under DPDP" | All copy | Never; cite SPDI r.3 (B3) | Legal lead | Standing | — |
| CR-20 (D-20) | Customer-facing legal claims as product surface with a named owner and clearance | FR-LEG-001 | The claim register | Legal lead | Standing | — |
| CR-21 | Does the s.8A(4)(b) OVSE storage bar reach the same legal entity's separate, employer-capacity holdings? The answer is a corporate-structure decision | FR-LEG-019 | No UIDAI registration; separation assumed in the corporate plan | Founder + Legal lead | Open | Before any UIDAI registration |
| CR-22 | Is the SaaS itself an "entity which collects" under Sharing Reg 5, needing its own purpose and consent? Can one artefact satisfy reg 5 and a DPDP notice? | FR-CHR-099; FR-CHR-100 | `artefact_owner` recorded; separate records per regime | Legal lead | Open | Before notice templates are cleared |
| CR-23 | Are LLM prompt and completion logs "ICT system logs" under CERT-In direction (iv)? | §12.8.3 rail 2; §17 NFR-CERT-602 | Kept in India for 180 days as though they are; `llm_log_retention_days` unset beyond that | Legal lead + Security lead | Open | None for the build |
| CR-24 | For a platform incident affecting tenants, who reports to CERT-In — the company, each customer, or both? Does direction (ii) reach a customer that is not incorporated (a proprietorship, partnership or trust)? | FR-LEG-013 | Our report plus a pack per tenant; no statement to customers either way | Legal lead + Security lead | Open | Before the first paying customer (runbook wording) |
| CR-25 | The edges of s.7(i): any notice duty for s.7(i) processing; whether "the purposes of employment" reaches candidates, background checks, monitoring and ex-employee records; whether s.17(1)(a) covers disciplinary and litigation-hold processing | §23.3.2; §10.13 | Candidate consent under both regimes; an employee notice ships anyway; FR-LEG-026 holds | Legal lead | Open | Before on or about 13 May 2027 |
| CR-26 | Is the SaaS a processor throughout, or a fiduciary for processing it decides itself (model-vendor choice, aggregate data use)? What is its role for each terminal deployment model? | FR-LEG-029; DPA; FR-LEG-017 | No self-determined processing of tenant data | Legal lead | Open | Before any change to data use |
| CR-27 | Does in-app capture satisfy SPDI r.5(1)'s "letter or Fax or email"? | §09.2 AC1; FR-LEG-011 | Capture form labelled on every artefact | Legal lead | Open | Before biometric general availability |
| CR-28 | May an employer take disciplinary or pay action against an employee who refuses biometric enrolment, tracking or Aadhaar? | FR-LEG-016 | The product supports no such action on any answer | Legal lead | Open | None — the posture is fixed |
| CR-29 | What basis and proportionality does continuous location tracking or other monitoring need? | §09.11; FR-LEG-015 | Opt-in, acknowledgement, template notice; never marketed as lawful | Legal lead | Open | Before live-tracking general availability |
| CR-30 | Aadhaar optionality in filings: the final default (exclude-and-flag), the alternatives, and when the employee share is deducted while the member's line is excluded | FR-CHR-101; §08 | Exclude-and-flag; payroll never blocked | Legal lead + Statutory lead | Open | Before v1 general availability |
| CR-31 | What follows for the deductor when an employee's PAN is inoperative? Which Income-tax Act 2025 provision governs PAN–Aadhaar linkage (not gazette-verified)? | FR-LEG-020 | A non-blocking nudge; no statement either way | Tax counsel | Open | Before any consequence wording |
| CR-32 | What happens to Aadhaar Act s.30, which defines sensitive data by reference to the s.43A Explanation, once s.43A is omitted? | §23.4.1 | No reliance on s.30's classification | Legal lead | Open, low | — |
| CR-33 | May the Register of Women Employees be electronic despite the "in ink" requirement? | §23.14 row 1 | Electronic, with a print-and-sign fallback | Legal lead + Statutory lead | Open | Before registers general availability |
| CR-34 | How do the three-kilometre location rules and the Wages Rules' narrow "electronically" apply to cloud-hosted registers? | §23.14 rows 2–3 | Producible at the establishment; B22 banned | Legal lead | Open | Before registers marketing copy |
| CR-35 | May Form I carry the full Aadhaar number given reg 6(5)? Is the Form I thumb impression SPDI biometric information? How is Form IX signed electronically? | §23.14 rows 8–10; §14 | Rendered from the vault at generation; written consent for thumb impressions; signature rows suppressed | Legal lead | Open | Before registers general availability |
| CR-36 | What periods apply where the rules leave them undefined (OSH r.72(7)(ii), IR r.47(2))? Are payroll artefacts part of a customer's books of account under Income-tax Rules 2026 r.46? | §23.14 rows 4, 5, 12; §23.6 | Interpretation labelled; in-India daily backup | Legal lead + Tax counsel | Open | Before automatic erasure of those classes |
| CR-37 | May an appointment letter be back-issued to migrated employees who never had one, and may state-prescribed forms be executed electronically? | §10.8; FR-T-O06 | Surfaced as a review task, never as an asserted breach | Legal lead | Open | Before migration copy |
| CR-38 | Does Code on Wages s.3 reach managerial and administrative hires? Which appropriate Governments have notified a s.4 authority? | FR-LEG-024; collateral | No "covers all hiring" claim | Legal lead | Open | Before recruiting collateral |
| CR-39 | On what basis are decision snapshots retained, and how does that interact with candidate erasure once DPDP commences — pseudonymisation, or a named legal-retention basis (RPwD s.22 and Rule 9; Code on Wages s.50)? | FR-T-D002 | Snapshots held under their hold rules; held snapshots never erased | Legal lead | Open | Before on or about 13 May 2027 |
| CR-40 | Has the Transgender Persons Amendment Act 2026 commenced, where does the constitutional challenge stand, and what copy fits the narrowed class? | FR-T-D009 | Copy version-flagged; no claim about the scope of coverage | Legal lead | Open — watch | On notification |
| CR-41 | SEBI: is a regulated entity's own employee HR data "Regulatory Data"? Does CSCRF PR.IP.S15 point 6 reach every SaaS? Is the chosen India region MeitY-empanelled and STQC-audited in every data centre? | FR-LEG-032 | Treated as in scope; region status confirmed in writing | Legal lead + Security lead | Open | Before the first SEBI tenant |
| CR-42 | IRDAI: does a self-service licence fall outside reg 2(14)? What does the Master Circular (19 June 2024, supplemented 5 September 2024) add on materiality? Has the records-regulations successor been notified? | FR-LEG-033 | The licence reading is not relied on until confirmed | Legal lead | Open | Before the first IRDAI tenant |
| CR-43 | Should the product build to RBI's draft Model Risk Management guidance before BFSI go-to-market? | §12; §10.13b | Human confirmation already built; AI off by default | Legal lead | Open — watch | Before BFSI go-to-market |
| CR-44 | Does r.13(3) reach scoring and inference? Which Schedule item — 4 or 7 — would a breach fall under? Could aggregate multi-tenant processing make the vendor an SDF candidate? | §17 NFR-DPDP-504 | SDF seam open; no SDF features built | Legal lead | Open, low | — |
| CR-45 | Does the s.39 civil-court bar, in force before the Board's powers, leave an interim gap in remedies that affects contract risk allocation? | §23.15 | None | Legal lead | Open, low | — |
| CR-46 | Are CA reseller or referral arrangements consistent with the ICAI Code of Ethics on fees and commission? | §18 | No reseller rate offered | GTM + Legal lead | Open | Before any CA reseller launch |
| CR-47 | Clearance of each competitor comparison for disparagement | §21; FR-LEG-001 AC4 | No uncleared claim ships | GTM + Legal lead | Standing | Each claim |
| CR-48 | What is the principal employer's exposure for a contractor's defaults (the OSH r.98(8) wage-guarantee trigger; the r.98(9) annual return), and does contract labour count toward the principal employer's own thresholds? | §09.9-A; §06.1 | The r.98(8) trigger surfaces as a task; no assertion on counting | Legal lead + Statutory lead | Open | Before contract-labour general availability |
| CR-49 | What do POSH ss.19, 21, 22, 25 and 26 require (duties, the annual report, penalties)? Not re-verified in round five | FR-T-D011 | Internal Committee record and intake only | Statutory lead | Open — verification | Before the IC annual-report feature |
| CR-50 | Is any Good Governance (SWIK) purpose arguable for a customer's own Aadhaar-attendance programme? | §23.8.4 | Not pursued | Legal lead | Open, low | — |

**FR-LEG-040 · The counsel register is a live artefact, and answers flow through the rule pipeline** · **P0** · Owner: Legal lead
The register is kept in the same system as the claim register (FR-LEG-001), not in this PRD.
Each item records its owner, status, gate, the default behaviour it holds in place, and every
product parameter, template or flag it controls. An answer is recorded as an opinion reference
with date, scope and author, and changes behaviour only as a rule or template change through the
§22 pipeline's two-person review — never as a code edit. An answer can be reopened by a watch
item (§23.17).
- **AC1** Every parameter named in this section as "set by counsel" resolves to a register item;
  a parameter with no item fails the configuration lint.
- **AC2** A gated release (for example, Mode B, biometric general availability or the DPDP-regime
  templates) cannot be enabled while an item gating it is open.
- **AC3** The register is reviewed at every operating review while any P0-gating item is open,
  and a monthly summary is produced for the founder.

---

### 23.17 Legal watch list — dated triggers and pre-agreed responses

Each item is registered with the §22 watcher as a legal-class source. It routes to the Legal lead
and the counsel register rather than to rule authoring (FR-LEG-041). Statutory rule changes —
rates, slabs, forms — stay with §22 and §06.

| ID | Watch | Source | Trigger | Pre-agreed response |
| --- | --- | --- | --- | --- |
| LW-01 | DPDP tranche (c) date and the primary copies of G.S.R. 843(E) and 846(E) | e-Gazette; MeitY | Primary copy pulled and matched, or any notification amending the tranches | §02 re-grades EV-058; FR-LEG-008 dates confirmed; dependent claims re-cleared |
| LW-02 | The January 2026 compression proposal | e-Gazette; MeitY | Gazetted, with its scope | Run FR-LEG-009 against the new date; re-sequence the §17 rights work; tell customers only through cleared claims |
| LW-03 | DPDP amendments, a MeitY DPDP FAQ, Board appointments, and the constitutional challenge to the Act and Rules | MeitY; PIB; Supreme Court | Any issue | Reopen CR-01, CR-25 and CR-09 as relevant |
| LW-04 | s.10(1) SDF notifications; s.16(1) country notifications; r.15 orders; r.13(4) specifications; s.17(3) startup exemptions | e-Gazette | Any notification | SDF seam (§17 NFR-DPDP-504); residency configuration; review CR-44 |
| LW-05 | Transgender Persons Amendment Act 2026 commencement, and the Supreme Court challenge | e-Gazette; Supreme Court | Commencement notification or an order | Switch the FR-T-D009 copy version; re-clear EOP and onboarding claims (CR-40) |
| LW-06 | The Union's model transgender EOP under *Jane Kaushik* para 217 | MoSJE; Supreme Court | Issued | Template for tenants without their own; it becomes enforceable at establishments that have none |
| LW-07 | Compliance with the *Jane Kaushik* complaint-officer directions by States and UTs | State notifications | Any State measure | Update FR-T-D009 prompts per state |
| LW-08 | MeitY converting voluntary AI measures into "mandatory baseline requirements" | MeitY | Any draft or notification | Map to §12 rails; re-clear AI claims |
| LW-09 | The first Indian judgment or CCPD order on algorithmic screening or performance scoring | Courts; CCPD | Any decision | Re-examine FR-T-D003 and FR-T-D004; update §23.10 |
| LW-10 | RBI Model Risk Management guidance — final text; any binding FREE-AI measure | RBI | Final text issued | Answer CR-43; update the RBI profile |
| LW-11 | SEBI's data-localisation consultation (FAQ Q26) | SEBI | A circular or amendment | Update the SEBI profile and key-management design |
| LW-12 | UIDAI private-verifier registration, a photocopy-collection bar, or a change to the Aadhaar Data Vault's scope | UIDAI gazetted notifications; circulars | Any notified instrument or circular | Switch onboarding to Aadhaar Verifiable Credential or QR verification with token storage (§23.9.5); reopen CR-06 |
| LW-13 | The successor to IRDAI's Maintenance of Insurance Records Regulations | IRDAI | Notified | Update the IRDAI profile |
| LW-14 | Amendments or FAQs to the CERT-In Directions | CERT-In | Any issue | Update the runbook and FR-LEG-013 |
| LW-15 | The Jan Vishwas (Amendment of Provisions) Bill 2026 — whether it reaches RPwD, the Codes or the IT Act | Parliament | Schedule published | Re-check the penalty rows in §23.10.2 |
| LW-16 | State rules under the Codes, and state-level transgender protection rules | State gazettes | Any state publication | Retention and form parameters per state (CR-11); FR-T-D009 variants |
| LW-17 | EPFO and ESIC Aadhaar-seeding and UAN guidance after November 2025 | EPFO; ESIC | Any circular | Revisit CR-30 and FR-CHR-101 |
| LW-18 | The ESI position when the Code on Social Security's savings window closes (EV-004), and any further corrigendum to the Code's commencement notifications | ESIC; MoLE; e-Gazette | A successor scheme, or a corrigendum | §06.9 owns the statutory answer; re-check the retention parameters and any claim that names the regime |

**FR-LEG-041 · Legal watch items are registered sources with owners** · **P1** · Owner: Legal lead
Each LW item is a watcher source in §22 with a cadence, an owner and linked claim-register and
counsel-register entries. A detected change creates a task and suspends dependent claims
(FR-LEG-001 AC2).
- **AC1** A watcher run that fails to fetch a source raises an alert; a silent gap longer than
  the source's cadence is a defect.

---

### 23.18 Requirements index, acceptance scenarios and section status

#### 23.18.1 Requirements index

| ID | Title | Pri | Owner | Subsection | Depends on |
| --- | --- | --- | --- | --- | --- |
| FR-LEG-001 | Legal-claim register and clearance gate | P0 | Legal lead | §23.1 | — |
| FR-LEG-002 | Legal text rendered from versioned templates | P0 | Legal lead | §23.1 | FR-CHR-100 |
| FR-LEG-003 | Banned-claim lint | P0 | Legal lead + Engineering | §23.1 | FR-LEG-001 |
| FR-LEG-004 | External distribution of this PRD | P0 | Founder + Legal lead | §23.1 | — |
| FR-LEG-005 | The assistant's legal-answer posture | P0 | Product (AI) + Legal lead | §23.1 | §12.8 |
| FR-LEG-006 | Commencement-honest compliance displays | P1 | Product | §23.1 | FR-LEG-008 |
| FR-LEG-007 | Security-review answer library | P1 | Legal lead + Security lead | §23.1 | FR-LEG-001 |
| FR-LEG-008 | Commencement dates are rule data | P0 | Legal lead + Statutory lead | §23.3 | §22 pipeline; CR-12 |
| FR-LEG-009 | Pull-forward drill | P1 | Statutory lead | §23.3 | FR-LEG-008 |
| FR-LEG-010 | Request and grievance clocks bounded by the applicable cap | P0 | Product | §23.3 | FR-CHR-076 |
| FR-LEG-011 | Consent evidence pack | P0 | Product | §23.4 | FR-CHR-100; CR-27 |
| FR-LEG-012 | Certification claims stay inside what the certificate proves | P1 | Security lead + Legal lead | §23.4 | §17.15 |
| FR-LEG-013 | Incident reporting pack and allocation record | P0 | Security lead + Legal lead | §23.5 | §17.6; CR-24 |
| FR-LEG-014 | Residency statements are attestations of configuration | P0 | Security lead | §23.6 | §17.1 |
| FR-LEG-015 | Tenant acknowledgement before biometric or continuous-location capture | P0 | Product + Legal lead | §23.8 | CR-02; CR-29 |
| FR-LEG-016 | No automated adverse action on refusal or withdrawal | P0 | Product | §23.8 | CR-28 |
| FR-LEG-017 | Terminal-vendor legal minimums | P0 | Legal lead + Engineering | §23.8 | §09.3 |
| FR-LEG-018 | Aadhaar design-review gate | P0 | Legal lead + Security lead | §23.9 | FR-CHR-099 |
| FR-LEG-019 | UIDAI registration control | P0 | Founder + Legal lead | §23.9 | CR-21 |
| FR-LEG-020 | PAN-status handling makes no legal statement | P1 | Product + Tax counsel | §23.9 | CR-31 |
| FR-LEG-021 | Due-diligence dossier | P1 | Product + Legal lead | §23.10 | FR-T-D001–D011 |
| FR-LEG-022 | The EOP's "manner of selection" derived from live configuration | P1 | Product | §23.10 | FR-T-D006 |
| FR-LEG-023 | Positioning discipline for discrimination controls | P0 | GTM + Legal lead | §23.10 | FR-LEG-001; FR-LEG-003 |
| FR-LEG-024 | Basis records for pay differences and sex-based criteria | P2 | Product | §23.10 | FR-T-D004; CR-38 |
| FR-LEG-025 | Complaint intake routes by statute | P1 | Product | §23.10 | FR-T-D008–D011 |
| FR-LEG-026 | Legal hold on complaints and proceedings | P1 | Product + Legal lead | §23.10 | §14.7 |
| FR-LEG-027 | Inspect-and-correct for AI-derived attributes | P1 | Product (AI) | §23.11 | §12 |
| FR-LEG-028 | Synthetic audio-visual generation gate | P0 | Product + Legal lead | §23.11 | CR-13 |
| FR-LEG-029 | No self-determined processing of tenant data without a basis decision | P0 | Founder + Legal lead | §23.11 | CR-26 |
| FR-LEG-030 | Sector questionnaire sets the tenant profile | P0 | Product + Legal lead | §23.12 | §17.1 |
| FR-LEG-031 | RBI materiality is the regulated entity's recorded decision | P0 | Legal lead | §23.12 | CR-14 |
| FR-LEG-032 | SEBI lane declaration and evidence pack | P1 | Security lead + Legal lead | §23.12 | CR-41 |
| FR-LEG-033 | IRDAI packaging recorded per tenant | P1 | Product + Legal lead | §23.12 | CR-42 |
| FR-LEG-034 | Submission-mode fence and record | P0 | Product + Legal lead | §23.13 | CR-17; §22 |
| FR-LEG-035 | The authority-to-act instrument | P0 | Legal lead | §23.13 | CR-17 |
| FR-LEG-036 | Liability language on filing surfaces | P0 | Legal lead + Product | §23.13 | FR-LEG-002 |
| FR-LEG-037 | Conflicts flagged and interpretations labelled | P0 | Statutory lead + Legal lead | §23.14 | §14.7; CR-11 |
| FR-LEG-038 | Model-vendor minimum terms gate | P0 | Legal lead + Engineering | §23.15 | §12.14 |
| FR-LEG-039 | Sub-processor changes notified, objections handled | P1 | Legal lead + Product | §23.15 | §12.8.3 |
| FR-LEG-040 | The counsel register is live; answers flow through the rule pipeline | P0 | Legal lead | §23.16 | §22 pipeline |
| FR-LEG-041 | Legal watch items are registered sources with owners | P1 | Legal lead | §23.17 | §22 watcher |

#### 23.18.2 Acceptance scenarios — the section's definition of done

```gherkin
# Representation control (FR-LEG-001, FR-LEG-003)
Given a draft help-centre article containing "Under DPDP you don't need employee consent"
When the content pipeline runs
Then the banned-claim lint fails the build
And the article cannot be published until the sentence is replaced by a cleared register entry

# The assistant never answers a counsel-reserved question (FR-LEG-005)
Given an employer admin asks the assistant "Can I refuse my employee's erasure request?"
Then the answer states that the product handles erasure requests as a capability
And that the statutory basis is under counsel review
And it states no legal entitlement in either direction and cites no foreign decision

# The regime switch versions, it never rewrites (FR-LEG-008)
Given an employee's SPDI written-consent artefact captured on 2 March 2027
When dpdp_commencement_date passes
Then the artefact keeps its regime tag, text version and capture date unchanged
And new collections are captured under the rule counsel has set for the DPDP regime

# Declining Aadhaar never blocks pay (FR-CHR-101, CR-30)
Given an employee who declines to provide Aadhaar and whose UAN is unseeded
When the monthly pay run and ECR are prepared
Then the employee is paid in the same run
And the member's ECR line is excluded and flagged, with notices to the operator and the employee
And no tenant setting exists that would block the pay run for want of Aadhaar

# Biometric enablement (FR-LEG-015, FR-LEG-016)
Given a tenant admin who has not recorded the biometric acknowledgement
When a terminal sends an enrolment
Then the enrolment is refused and the admin is prompted
And no configuration exists that links a worker's method election to pay, leave or discipline

# The attended-filing fence (FR-LEG-034)
Given CR-17b is open for a state PT portal
When an operator opens that tenant's PT return
Then the console offers the artefact for the customer to submit and no submit action
And the filing ledger records the filing as Mode A

# Regulated tenants start with AI off (FR-LEG-030)
Given a tenant whose sector questionnaire records "SEBI - stock broker"
When the tenant is provisioned
Then the AI kill switch is engaged, data and inference are pinned to India
And no model provider outside the tenant's consented set is reachable

# Complaints hold the evidence (FR-LEG-026)
Given an open RPwD Rule 3(2) case for a rejected candidate
When the candidate's erasure request arrives
Then the decision snapshot and related records are retained under the case hold
And the response states that the data is held for proceedings

# Counsel-set parameters cannot be invented (FR-LEG-040, FR-LEG-037)
Given a retention class whose period is a counsel-set parameter with no value
When the erasure engine evaluates a request touching that class
Then the class is held, never erased
And the erasure statement shows "interpretation pending counsel" with its counsel item
```

#### 23.18.3 Section status

- **[Verified]** — the regime map (§23.2), the commencement tranches (§23.3.1, EV-058
  **[Verified — mirror]** pending the primary pull), the SPDI and s.43A texts (§23.4, EV-060
  **[Verified — provenance caveat]**), the CERT-In duties (§23.5), the Aadhaar provisions and the
  five rules (§23.9), the discrimination instruments and case law (§23.10), and the sectoral
  texts (§23.12, EV-087 **[Verified — mirror]**). Each rests on primary text read in research
  r4–r5, with the markers shown. The exceptions are flagged where they appear and are not
  Verified: the IT Amendment Rules' commencement date and the MoLE s.142 statement
  (secondary sources), the Transgender Persons Rules' timelines (**[Verified — mirror]**), the
  contents of the RBI draft model-risk guidance (not opened), and the POSH duty and penalty
  provisions (not re-verified, CR-49).
- **Counsel-open** — fifty register items (§23.16), none answered as of 11 September 2026. Every
  one has a default behaviour that ships without the answer.
- **[Hypothesis]** — the sub-processor notice period (`subprocessor_change_notice_days`), and every
  timing parameter named in the FR-LEG requirements, until set.
- **What this section does not do.** It gives no legal opinion. It does not draft contracts
  (§23.15 names them). It does not own statutory computation (§06, §08), competitor evidence
  (§21) or the filing operation (§22). Where those sections state a legal proposition, this
  section governs it.
