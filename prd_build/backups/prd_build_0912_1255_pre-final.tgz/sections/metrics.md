## 19. Success Metrics & Instrumentation

Every other section of this PRD argues that **the statutory filing, not the payslip, is the unit of delivery** (front matter; §04; §08). This section makes that claim measurable. If it is true, then the primary number the company optimises cannot be a generic SaaS metric — not MRR, not DAU, not "payslips generated" — because none of those distinguishes us from a spreadsheet, from Tally, or from a free tier that also generates payslips (§04). It has to be a metric that only a product delivering **portal-accepted filings** — the artefact plus attended, assisted submission under the employer's written authority to act (§22) — can move.

That is the discipline this section enforces. It defines a **north-star metric grounded in filing delivery**, decomposes it into a metrics tree of leading and lagging indicators, specifies the **filing-accuracy and on-time-filing metrics as the core quality bar** (with the Indian statutory due-dates and penalty exposure that make them load-bearing), and lays out an **instrumentation plan** that captures per-tenant, per-user, per-agent, per-model attribution **from v1, while AI is still bundled free** (§13 requires this explicitly — retrofitting attribution after pricing exists is far harder). It closes with **targets per phase** aligned to the roadmap in §05.

One inherited rule governs every number below. §02.3 established that the first two research rounds retracted roughly ninety claims (the Draft 1 figure; the round-two critic tallied about sixty, and §02.3 carries both unreconciled), that every round-one-to-two retraction moved in the optimistic direction, and that later rounds found some of those corrections had themselves overshot — so an unrechecked early claim is roughly 70–75% reliable in either direction. The same skepticism applies to *our own* metrics: **a target is a [Hypothesis] until a cohort reports it, and a vanity metric is one that goes up whether or not a customer got a filing done on time.** §19.13 bans the specific vanity metrics that would otherwise creep into a board deck.

**How to read this section.** It runs top-down through the metrics tree. §19.1 defines the north star; §19.2 places every other metric relative to it as leading or lagging; §19.3–19.9 define each layer's metrics with worked examples in rupees and days; §19.10 consolidates them into one weekly index; §19.11 specifies the events beneath every metric; §19.12 sets per-phase targets with kill criteria; §19.13–19.15 govern hygiene, definitions and the single measurement that validates the thesis. Every number that is a planning anchor rather than a measured fact is tagged **[Hypothesis]** and carries a kill/validation criterion, exactly as §02 requires, with validation routed to §20.

---

### 19.1 North-star metric: On-Time, Accepted Statutory Filings (OTAF)

The north star is a single number, reported monthly, that rises only when the product delivers its core unit of value at scale.

> **North Star — OTAF**
> The count of **filing instances** (one registration × obligation × period, §08 FR-PAY-711), on a line the tenant's coverage statement holds **IN_SLA** on the instance's due date (§05.21), whose artefact the platform generated, that were **submitted in an attended portal session** — by the employer, or by our operator acting under the employer's written authority to act (§22) — and **reached FILED on or before the due date, with no REJECTED attempt and no REVISED or SUPPLEMENTARY transition inside the instance's settlement window**, summed across all active tenants in the period.

The statutory liability for every one of these filings stays with the employer and deductor — it is non-delegable — whoever presses submit (EV-K24; §22, §23). Operator submission is itself fenced until counsel clears the attended-filing questions (Part D-17, §23); until then the employer submits and the four gates below are unchanged.

A filing instance counts toward OTAF only if it clears **all four** gates, each read off the §08 FR-PAY-711 transition log:

1. **Generated** — the instance passed through GENERATED from the LOCKED payroll snapshot (FR-PAY-711 F4): an ECR return file (EV-035), an ESI contribution upload, a state PT return, or a Form 138 statement (EV-051) — not hand-assembled outside the product. **Form 130 is not in this list:** it is valid only if TRACES generates it (EV-048), so the product prepares its data and distributes it; its timeliness is tracked as certificate issuance (§19.3.1), not as an OTAF filing.
2. **On time** — the instance reached **FILED** (acknowledgement stored and, for a payment-bearing filing, the payment receipt captured — FR-PAY-711 F15/F16) on or before the due date computed for that instance (§08 FR-PAY-710; canonical calendar §06.11), judged on the authority's own timestamp on the acknowledgement or receipt, not on the time we recorded it. This gate is §01's `on_time(f)` — the completion predicate `complete(f)` over the `Filing` entity (§14.4.5) plus the authority timestamp — so a return approved and challaned by the due date but receipted the day after is late (§01 TS-01.3).
3. **Accepted first time** — the instance reached ACCEPTED (F9) with **no SUBMITTED → REJECTED transition** (F7): for the ECR, the employer approved the return statement and the challan carries a TRRN (EV-036); for Form 138, a Return Receipt Number was issued (EV-051); for ESI and PT, the portal acknowledgement was captured. The employer's rejection of an EPFO return statement at reconciliation is a failed attempt too, and is counted here once §08 names it as an F7 trigger (proposal §22.12 O17); until then it is read from the §22 session log.
4. **Right-first-time (RFT)** — no REVISED (F10) or SUPPLEMENTARY (F12) transition was linked to the instance within its settlement window (§19.3.1). For the ECR these are the only correction routes: a Revised return needs an approved Regular, no other return in process and **no payment initiated**; a Supplementary return may carry only members absent from every prior return for the month; an approved return can never be cancelled (EV-036, EV-037).

**Which instances can count.** "In-coverage" throughout this section means an instance on an IN_SLA line of the coverage-statement version in force on its due date (§05.21). §05.21 fixes every other state's treatment, and this section applies it without re-deciding: SLA_PENDING_FIRST_SUBMISSION instances stay outside the on-time denominator and are reported beside OTAF as **pre-SLA accepted filings**, never added to it; CARVED_OUT_FENCE and CARVED_OUT_PARAMETER instances go to the coverage-gap register; TENANT_SELF_FILES instances sit outside Filing Coverage; NOT_OFFERED lines are recorded as unmet demand against their named hold. OTAF is reported split by delivery mode — A employer-attended, B co-attended, C operator-attended, D CA-attended (§22 FR-OPS-001) — read from the filing ledger, so a Mode A filing is never counted or sold as submitted by us (§01 AC-01.5; §23 FR-LEG-034 AC2).

**Why this is the right north star.** It is the only metric that simultaneously (a) reflects the thesis — filings, not payslips; (b) is *not reported by the alternatives we displace* — a spreadsheet + CA cannot report an OTAF number; the two incumbents do different jobs (Tally owns accounting and the statutory artefacts, and how many firms run Tally *payroll* is unknown; greytHR owns the HRMS job — EV-032, EV-K34); no vendor in the six-vendor set claims to submit any filing (EV-030); and the freemium players give away computation and charge for the outputs — challans, bank files, the annual certificate (EV-029); (c) predicts revenue and retention, because a tenant whose filings all land on time has no reason to churn and every reason to add establishments; and (d) is honest — it cannot be inflated by signups, seats, or bundled AI usage.

**Why a count, not a rate, is the north star.** A rate (filing-integrity %) is the *quality* metric (§19.3) and is guard-railed below. But the north-star must grow with the business, so it is the absolute count. The rate is its most important guardrail: **OTAF may never be grown by loosening the RFT/on-time definitions.** Both move together on the metrics tree.

#### 19.1.1 North-star formula and its guardrails

```
OTAF(month) = Σ  filing instances where (generated ∧ on_time ∧ accepted_first_time ∧ right_first_time)
             tenants

Filing-Integrity Rate = OTAF / (all in-coverage filing instances due across active tenants in period)
```

| | Metric | Role | Guardrail rule |
| --- | --- | --- | --- |
| Primary | **OTAF (count/month)** | North star | Grows with business |
| Guardrail 1 | **Filing-Integrity Rate (%)** | Quality floor | If Rate falls, OTAF growth is disqualified as growth-by-degradation |
| Guardrail 2 | **Penalty incidence (₹ and count)** | Harm floor | Any interest, damages, fee or penalty charged to a customer on a covered filing — EPF interest (portal label s.7Q) or damages (legacy s.14B), the 1961-Act s.234E fee or s.271H penalty or their 2025-Act equivalents (unmapped, §06.13) — is a Sev-1 metric event. The liability stays with the employer (EV-K24); the metric records the event and whether our causation is established |
| Guardrail 3 | **Filing Coverage (%)** | Scope honesty | Filings the product *can't yet* do are excluded from the denominator but tracked separately, so Rate isn't gamed by narrowing scope |

#### 19.1.2 A worked OTAF example — one 60-employee tenant, one month

To make OTAF concrete, take a single beachhead tenant with 60 employees in Maharashtra — one EPF, one ESI and one PT registration — for the **September 2026 wage month**. The month is chosen because it closes Q2 of Tax Year 2026-27, so the central instruments have a published format and a live regime: Form 138 Q4 is fenced (EV-046) and ESI after 22 November 2026 is unresolved (§06.13). For illustration, assume the tenant's coverage statement holds every line shown IN_SLA; in practice Form 138 stays SLA_PENDING_FIRST_SUBMISSION until the family's first real quarterly submission (§05.20). Its filing instances, and how each contributes to OTAF, are:

| Filing instance | Due date | GENERATED from locked snapshot? | FILED by due date? | REJECTED attempt? | REVISED / SUPPLEMENTARY in window? | Counts to OTAF? |
| --- | --- | --- | --- | --- | --- | --- |
| EPF ECR + challan (Sep) | 15 Oct 2026 (§06.11) | Yes | FILED 12 Oct — TRRN, receipt | No | No | **1** |
| ESI contribution (Sep) | 15 Oct 2026 (§06.11) | Yes | FILED 14 Oct | No | No | **1** |
| Maharashtra PT return (Sep) | **Unconfirmed** — the due day is parameter `pt.MH.due_day`, not captured; Maharashtra assigns the frequency per registration each year (§06.11) | Yes | FILED 14 Oct | No | No | **Not judged** — coverage-gap register |
| Form 138 Q2 (Jul–Sep) | 31 Oct 2026 (EV-049) | Yes | FILED 20 Oct | No | Correction statement 3 Nov (PAN error), on the Q1–Q3 correction format published August 2026 (r5/02) | **0** — RFT fails |

This tenant contributes **2** to OTAF for the period, not 4. The PT return was generated and filed, but its due day is an uncaptured parameter and §06.11 forbids computing any on-time metric against an unconfirmed date — so the instance goes to the coverage-gap register and leaves the rate's denominator until `pt.MH.due_day` is captured from the state source (§20 V-09). The Q2 statement was generated, filed on time and accepted — but a correction statement for a wrong PAN inside the settlement window disqualifies it under gate 4 (FR-PAY-711 F10). That single miss is exactly what the RFT gate exists to catch: an accepted-but-then-corrected filing looks like success in a naive dashboard and is a trust event and a rework cost in reality. The tenant's **Filing-Integrity Rate for the month is 2/3 ≈ 67%**, which is *below* the Phase-1 floor and would trigger a filing-integrity standup review (§19.11.5). Aggregate this across all active tenants and periods and you have the company OTAF and its rate.

**Denominator discipline.** The rate's denominator is "all in-coverage filing instances *due* across active tenants in the period," where "due" respects Filing Coverage (guardrail 3): if this tenant also owed a Karnataka PT return but the product cannot yet file Karnataka PT, that obligation is tracked in the **coverage-gap register**, not silently dropped from the denominator to flatter the rate. The BLOCKED state (FR-PAY-711 F2) is split the same way. An instance BLOCKED for an **external** reason — format unpublished (Form 138 Q4, EV-046; the ECR arrear return, EV-043) or regime unresolved (post-cliff ESI, §06.13) — leaves the denominator and enters the coverage-gap register. An instance BLOCKED for a **tenant-side** reason — a chronology gap on the per-establishment ledger (EV-038, §08 FR-PAY-712) or a pending joint declaration (EV-041) — stays in the denominator, because the obligation is live and the deadline still runs. An instance whose due date is an **uncaptured parameter** (every state PT due day, and every LWF due date except Karnataka's — §06.8, §06.11) is treated as externally gated: it is filed and tracked, but never judged on time and never counted in the rate until the date is captured. §19.12.1's Phase-1 note on Form 130 is the same discipline applied to an externally-gated instrument.

**Why RFT-within-window, not RFT-forever.** A revision filed two years later for an unrelated reason should not retroactively demote a filing that was correct when delivered. So RFT is judged against an **instrument-specific settlement window** (§19.3.1) — a versioned metric parameter, not a statutory period. This keeps the north star stable and effective-dated (§19.14 rule 2) rather than perpetually re-litigating closed periods.

**[Verified — as to the superseded schedule read]** ICAI's recommended fee schedule prices TDS return filing, PT registration and PT returns but has **no payroll-processing line item at all** (EV-017; ICAI Recommended Scale of Fees, full-text search — r2/05; §04). The schedule read is at least nine years old and pre-GST, so its rupee figures are banned (EV-K05); a superseding February 2020 revision exists and its text was not retrieved, so the negative is unverified for the current revision and must be re-run on it before use outside this PRD (EV-017; §02.2 G15). What the schedule read evidences is how practitioners itemise the work — by filing, not by processing — which is the basis for a filing-delivery north star over a payslip- or seat-based one. **[Hypothesis]** That OTAF predicts retention better than seat count. Kill/validate: at month 18, regress logo churn on (a) OTAF-per-tenant and (b) seat count; if OTAF has no additional explanatory power over seats (partial R² increment < 0.05, p > 0.05), demote it to a quality metric and pick a revenue-shaped north star.

---

### 19.2 The metrics tree — leading vs lagging

The north-star sits at the top of a causal tree. Everything below it is either a **leading** indicator (moves *before* OTAF, tells us what OTAF will do) or a **lagging** indicator (moves *after* OTAF, tells us what OTAF did to the business). The single most common metrics mistake — and one §02's bias analysis predicts we are prone to — is celebrating lagging metrics we can no longer influence. The instrumentation plan (§19.11) therefore over-invests in the leading layer.

<!-- DIAGRAM: metrics-north-star-tree -->

| Layer | Question it answers | Lead/lag vs OTAF | Example metrics |
| --- | --- | --- | --- |
| **Input** | Are tenants set up to file at all? | Leading (weeks–months) | Activation rate, time-to-first-filing, data-migration completeness, statutory-registration linkage (PF/ESI/PT codes captured) |
| **Process** | Is a payroll+filing cycle running cleanly? | Leading (days) | Payroll-run success rate, wage-base recompute correctness, pre-filing validation pass rate, AI deflection rate |
| **Output** | Did the filing land, on time, right? | **The north star (OTAF) + its rate** | OTAF, filing-integrity rate, on-time rate, RFT rate, rejection rate |
| **Outcome** | Did delivered filings turn into a durable business? | Lagging (months–quarters) | NRR, logo retention, band-crossing rate, penalty incidence, NPS, gross margin |

**Reading the tree.** A drop in *activation* (input) predicts an OTAF shortfall two quarters out. A spike in *pre-filing validation failures* (process) predicts a rejection-rate spike this cycle. A healthy OTAF that is *not* converting to NRR (outcome) means the value is delivered but not monetised or not perceived — a pricing/positioning problem, not a product-quality one. Each layer routes to a different owner, which is why the tree, not a flat dashboard, is the organising structure.

#### 19.2.1 Lead times, quantified — how far ahead each layer sees

The value of a leading metric is only realised if you know *how much* lead time it buys. These are planning estimates, to be replaced by measured lead-lag correlations once ≥3 filing cycles exist:

| Leading metric | Predicts | Typical lead time | So the play is |
| --- | --- | --- | --- |
| Activation rate (input) | OTAF volume | 1–2 quarters | Fix onboarding *before* the OTAF shortfall shows in a board deck |
| Migration completeness (input) | Rejection/correction rate | 1 filing cycle | A tenant that migrated with 90% completeness will throw validation errors on its first run |
| Pre-filing validation pass rate (process) | Rejection rate | Same cycle, days | A validation-failure spike on the 12th predicts a rejection spike on the 15th |
| Statutory-change lead time (process) | Correction rate after a rule change | Until next affected filing | A rule that lands late causes wrong figures at the next cycle for that instrument |
| AI COGS per account trend (process) | Inference-cost erosion (one COGS line of four, EV-088) | 1–2 months | Re-point the router before the unit economics show in finance's monthly close |

**[Hypothesis]** These lead times hold empirically. Kill/validate: after 3 cycles, compute the cross-correlation lag between each leading metric and its target lagging metric; if a claimed "leading" metric shows peak correlation at lag 0 or negative lag, it is coincident or lagging and must be re-labelled on the tree — a leading metric that does not actually lead is worse than none, because it invites premature celebration (§02 bias check).

---

### 19.3 Filing quality metrics — the core quality bar

These are the metrics the whole product exists to move. They are specified per statutory instrument because **each instrument has its own due date, its own acceptance definition, its own correction window, and its own penalty regime** — and a single blended "compliance %" would hide exactly the failures that generate customer penalties. This is the operational expression of §05.15's org-design point: we are a compliance-maintenance operation (the operation itself is §22), and these are its yield metrics.

#### 19.3.1 The statutory due-date calendar (the on-time denominator)

On-time is defined against these dates. A filing that reaches FILED on the 16th for a 15th deadline is a *miss*, full stop — there is no partial credit, because the penalty exposure opens the moment the deadline passes. The canonical calendar is §06.11 and each instance's due date is computed by §08 FR-PAY-710; this table carries only what the metrics need. The **settlement window** is the metric parameter `rft_window_days[instrument]` — how long after FILED a REVISED or SUPPLEMENTARY transition still demotes RFT. It is a versioned definition in the metric register (§19.14.1), not a statutory period, and no value is set here: it is routed to §20.

| Instrument | Frequency | Statutory due date | Correction routes that end RFT | Late-payment / late-filing consequence | Source cue |
| --- | --- | --- | --- | --- | --- |
| **EPF ECR + challan** | Monthly | 15th of the following month (§06.11) | Revised return only before PAYMENT_INITIATED; Supplementary for members absent from every prior return; an approved return is never cancelled (EV-036, EV-037) | Simple interest, mandatory and auto-calculated, paid with the contribution (EV-039) **[Verified]**; the 12% p.a. rate per S.O. 2698(E), read through a professional alert, **[Verified — mirror]**, pull from the primary source before customer use (§06.2); damages at the employer's option, scale = parameter `epf.damages_scale` with no shipped default, **[Hypothesis]** (§06.2, §06.13); late return ₹500/day capped at the month's admin charges **[Verified — mirror]**, pull from the primary source before customer use (§06.2) | EPF Scheme 2026; §06.2 |
| **ESI contribution** | Monthly | 15th of the following month (§06.11) | Not specified in this PRD's sources — routed to §20 V-23 (ESIC portal facts) | Simple interest 12% p.a. (S.O. 2698(E)) **[Verified — mirror]**, pull from the primary source before customer use (§06.3); damages scale = parameter `esi.damages_scale`, no shipped default, **[Hypothesis]** (§06.3) | ESI regime unresolved after 22 Nov 2026 — post-cliff instances are BLOCKED (§06.13) |
| **Professional Tax return** | Monthly or annual, **per state and per registration** | Per state and registration — due days are parameters `pt.<state>.due_day`, none captured; Maharashtra assigns frequency per registration each year, ingested from MAHAGST (§06.11) | State-specific, unknown | State-specific interest and late fee, parameters `pt.<state>.interest_rate` and `pt.<state>.late_fee` with no shipped default **[Hypothesis]** (§06.4) | State PT Acts — dataset pending §20 V-09 |
| **Form 138 (ex-24Q) statement** | Quarterly | Q1 31 Jul, Q2 31 Oct, Q3 31 Jan, **Q4 31 May** of the year following the Tax Year (r.219, EV-049) | Correction statement where the period's correction format is published; the Q4 regular and correction formats are not (EV-046) | Late fee ₹200/day (1961-Act s.234E, from a secondary source — `tds.late_fee_per_day`), cap = parameter `tds.late_fee_cap`; statement penalty = parameter `tds.penalty.statement_default` (1961-Act s.271H, v0.3's range carried, not re-captured) — all **[Hypothesis]**; 2025-Act equivalents unmapped (§06.5, §06.13) | r.219; EV-046, EV-049, EV-051 |
| **Form 130 (ex-Form 16) — certificate issuance, not an OTAF filing** | Annual | 15 Jun of the year following the Tax Year (r.215(1), §06.11) | Not applicable — TRACES generates it (EV-048); for Tax Year 2026-27 it is BLOCKED pending the Q4 format (EV-046) | Late-issue penalty per day = parameter `tds.penalty.certificate_delay` (1961-Act s.272A(2)(g), carried, not re-captured) **[Hypothesis]**; 2025-Act equivalent unmapped (§06.5) | r.215(1); EV-046, EV-048 |
| **LWF contribution** | State-specific (monthly / half-yearly / annual) | Per state — parameter `lwf.<state>.due`, none captured except **Karnataka: annual, calendar year, due 15 January** (periodicity **[Verified]**, r2; amounts disputed — §06.8, §06.11) | State-specific, unknown | State-specific **[Hypothesis]** (§06.8) | State LWF Acts — dataset pending §20 V-09 |

**[Reversed]** An earlier draft cited "Frappe ships 14 states" of LWF here; that is false at source (EV-K12). Frappe HR v16's India payroll names no Indian state and carries no PT slabs or LWF, and TallyPrime has no state PT slab table and no LWF engine (EV-031, EV-032): multi-state PT and LWF is greenfield in both incumbents, so its coverage metric measures a differentiator, not parity.

**[Verified]** The EPF interest is mandatory and auto-calculated (EV-039), and the Form 138 and Form 130 due dates are live (EV-049; r.215(1); §06.11). **[Verified — mirror]** The 12% p.a. EPF and ESI interest rate (S.O. 2698(E), §06.2, §06.3) — pull from the primary source before customer use. **[Hypothesis]** The EPF/ESI damages scales, the 1961-Act TDS late fee, fee cap and penalty amounts themselves (§06.5 holds them as parameters), their 2025-Act equivalents, and every state PT/LWF due date other than Karnataka LWF's. Kill/validate: §06.13 and §20 V-09 — until a state's dataset is gazette-verified, its PT/LWF instances sit in the coverage-gap register and cannot enter OTAF, and no unverified rate is shown to a customer as current.

#### 19.3.2 Worked penalty examples — why one missed filing is a rupee number, not a percentage

The penalty formulas above are abstract until they are attached to a tenant's actual liability. Every rejection or correction opens a penalty-exposure record (AC-3) that estimates the ₹ at risk *the moment it is detected*, so the harm guardrail (§19.1) is a live rupee number, not a quarterly surprise. Worked cases for a representative 60-employee beachhead tenant:

**Case A — EPF ECR filed and paid 10 days late.** Monthly EPF liability (employer + employee, 12% + 12% on a ₹15,000 wage ceiling base, §06.2) for 60 employees ≈ ₹15,000 × 24% × 60 ≈ **₹2,16,000**. A 10-day delay incurs:
- Simple interest @ 12% p.a. (**[Verified — mirror]**, §06.2), auto-calculated by the portal and payable with the contribution (EV-039): ₹2,16,000 × 12% × (10/365) ≈ **₹710**. This is a forecast: the day-count convention, whether the admin charge sits in the base and the rounding are uncaptured parameters (`epf.interest_day_count`, `epf.interest_base`, `epf.rounding_method` — §06.2), so the exposure record replaces the forecast with the portal's own figure once the portal shows it, and a difference is a reconciling item, never an overwrite (§06.2).
- Late-return fee, because the return itself is late: 10 × ₹500 = ₹5,000, capped at the month's administrative charges (**[Verified — mirror]**, pull from the primary source before customer use — §06.2). At the carried admin-charge rate of 0.50% of PF wages (**[Hypothesis]**, not re-verified — §06.2) the cap is 0.50% × ₹9,00,000 = **₹4,500**, so this line is ₹4,500 at most and is tagged with both markers.
- Damages, at the employer's option (EV-039): ₹2,16,000 × `epf.damages_scale`(10 days). The scale has no shipped default — v0.3's graded percentages are carried, not re-captured, and EPFO's EDLI page still shows a legacy per-month figure (§06.2) — so the exposure record carries this line as "rate unverified", computes no rupee value until the parameter is captured from the notified text (§20), and never shows it to a customer as current (§08).
- Total exposure ≈ **₹710 interest + up to ₹4,500 late-return fee + the unpriced damages line** for one late month on one tenant. Small per event — but it is a *penalty incidence > 0*, which under §19.1 guardrail 2 is a **Sev-1 metric event** regardless of size and regardless of who caused it; the causation flag then decides whether it is also a product defect (for example, funds the employer did not remit are not). (Source: §06.2 — interest notified by S.O. 2698(E), portal label s.7Q; damages legacy s.14B / CoSS s.128.)

**Case B — a Form 138 quarterly statement filed 20 days late.** At the carried late fee of ₹200/day (`tds.late_fee_per_day`): 20 × ₹200 = **₹4,000**, subject to `tds.late_fee_cap`; the statement penalty `tds.penalty.statement_default` is also exposed, with no rupee value until it is re-captured. A single late quarterly statement therefore opens a **₹4,000 fee line + an unpriced contingent penalty line**, both marked **[Hypothesis]**. (Source: 1961-Act s.234E — ₹200/day from a secondary source, not primary-verified — and s.271H, carried, not re-captured; 2025-Act equivalents unmapped — §06.5, §06.13.)

**Case C — Form 130 (ex-Form 16) issued late.** The late-issue penalty is a per-day amount held as `tds.penalty.certificate_delay` (1961-Act s.272A(2)(g), carried, not re-captured, **[Hypothesis]**; 2025-Act equivalent unmapped — §06.5). Whether it accrues **per certificate** — the reading under which it scales with headcount × days — is not established in this PRD's sources and is routed to §20; if it does, 60 employees at 15 days late is **900 certificate-days** × `tds.penalty.certificate_delay`, a base that grows with headcount where Case A's grows only with the contribution amount. Two qualifiers keep this honest: Form 130 is **generated by TRACES**, not by us (EV-048), so our share of the chain is data preparation and distribution; and for Tax Year 2026-27 it is **BLOCKED pending the Q4 format** (EV-046), so a late issue caused by the unpublished format is a coverage gap (§19.12.1), not a product miss.

The lesson these cases encode into the metrics: **penalty incidence is reported in both count and ₹, and the ₹ is estimated at detection time using these formulas, each line tagged with its confidence marker.** A dashboard that shows "1 penalty incident" hides that Case C, under the per-certificate reading, multiplies a per-day amount by every affected employee while Case A's interest is a few hundred rupees. An exposure line whose rate is an uncaptured parameter is shown as **"unpriced"**, never as ₹0 and never with a guessed figure. Both the count (for the harm guardrail) and the ₹ (for materiality and for the customer's own compliance-SLA evidence board, §19.11.4) are first-class.

#### 19.3.3 The core quality metrics, defined

| Metric | Definition | Why it matters | Target direction |
| --- | --- | --- | --- |
| **On-Time Filing Rate** | in-coverage instances reaching FILED ≤ due date ÷ in-coverage instances due (§08 FR-PAY-711) | Directly gates the penalty clock | → 100% |
| **First-Time-Right (RFT) Rate** | FILED instances with no REVISED or SUPPLEMENTARY transition inside `rft_window_days` ÷ FILED instances | A late correction is a customer penalty and a trust event | → 100% |
| **Rejection Rate** | instances whose first SUBMITTED transition went to REJECTED ÷ instances submitted; reported per artefact family and per FR-PAY-713 error family (SA-FMT … SA-PORT), reproducible from the transition log alone (AC-713.3) | Rejections cause misses even when submitted early; the family split says *why* | → 0% |
| **Correction/Revision Rate** | instances with a REVISED or SUPPLEMENTARY transition ÷ instances ACCEPTED or FILED | Corrections are the leading signal of engine or data error | → 0% |
| **Penalty Incidence** | count and ₹ of interest, damages, fees and penalties charged to customers on covered filings, each flagged for whether platform causation is established | The harm metric; any non-zero value is Sev-1. The statutory liability stays with the employer (EV-K24) | = 0 |
| **Filing Coverage** | coverage-statement lines in IN_SLA — instrument-states the product takes from GENERATED to FILED as a portal-accepted artefact plus attended, assisted submission — ÷ applicable lines across the customer base, TENANT_SELF_FILES and NOT_APPLICABLE lines excluded from both (§05.21); externally BLOCKED instances are logged in the coverage-gap register | Prevents gaming the rate by narrowing scope | → 100% over phases |
| **Pre-Filing Validation Pass Rate** | payroll runs clearing all validation checks pre-submission ÷ runs | *Leading* indicator of rejection/correction | → 100% |
| **Time-to-Correct** | median hours from rejection/error detected to corrected filing accepted | Bounds penalty exposure when something does go wrong | ↓ minimise |
| **On-Time Margin** | median hours between the authority's FILED timestamp and the due-date deadline | A filing that lands 30 min before the 15th-midnight cutoff is fragile; measures buffer, not just pass/fail | ↑ maximise |
| **Product-Caused Miss Rate** | in-coverage instances missed with `miss_class` = product-caused (§05.9) ÷ in-coverage instances due | The rate the compliance desk and the SLA are held to (§05.9; §19.9.2); §05.3 DG-2b gates the 200–999 band on it | → 0% |
| **Late-Warning Share** | tenant-side blockers whose warning reached the tenant after the `tenant_action_lead[family]` point (§05.9 SS-3) ÷ tenant-side blockers warned | A tenant-caused miss is only tenant-caused if the warning was timely; a late warning converts it into a product-caused miss | → 0% |

**On-Time Margin — a leading refinement.** On-Time Filing Rate is binary and lagging; **On-Time Margin** is its continuous, leading cousin. A tenant base whose filings routinely land 2 hours before the deadline is one portal-outage away from a miss-spike; a base filing 5 days early is resilient. Tracking the *distribution* of on-time margin (p50/p90) surfaces fragility before it becomes a miss. **[Hypothesis]** On-Time Margin p10 collapses around due-date-day portal congestion (EPFO/TRACES load on the 15th and on 31 May). Kill/validate: if the margin distribution is uniform across the month, drop the metric; if it spikes toward zero on deadline day, it justifies the "file early" nudges and the due-date-window availability target (§19.9, §17 NFR-AVAIL-802).

#### 19.3.4 Acceptance criteria for the filing-quality subsystem

These are the pass/fail bars the instrumentation must be able to prove, not aspirations:

- **AC-1** Every filing instance carries the machine-readable transition log of the §08 FR-PAY-711 state machine — SCHEDULED, BLOCKED, GENERATED, VALIDATED, SUBMITTED, REJECTED, ACCEPTED, REVISED, SUPPLEMENTARY, PAYMENT_INITIATED, FILED — each transition with a UTC timestamp synced to NIC/NPL NTP (EV-062, §17), and every metric in §19.3 is reproducible from that log alone (FR-PAY-711 AC-711.1). A correction is a new REVISED or SUPPLEMENTARY transition linked as a diff, never a mutation of the accepted record (Part E-1).
- **AC-2** On-time is computed against the **instrument-and-state-specific due date**, effective-dated, so a due-date change (common in PT) recomputes historically correctly.
- **AC-3** A rejection or correction automatically opens a **penalty-exposure record** estimating the ₹ at risk (using the §19.3.1/§19.3.2 penalty formulas) and starts the Time-to-Correct clock.
- **AC-4** The wage-base engine's **two concurrent wage computations** (the 50% add-back base vs the payment-of-wages base — §08, the hardest calculation in the build) are each independently validated pre-filing; a mismatch between the base used and the base required for that instrument is a validation failure, not a warning.
- **AC-5** No statutory or monetary figure in any filing is model-generated (§08/§12 rules-first). The instrumentation must record the **computation provenance** (rule version, effective date) for every figure, so an audit can prove determinism.
- **AC-6** Every filing event stores the **due-date rule version** it was judged against, so that if a PT state later back-dates a deadline change, historical on-time is recomputed under the version in force for the period (AC-2), never silently overwritten.
- **AC-7** Every in-coverage instance not FILED by its due date carries exactly one `miss_class` — product-caused, tenant-caused or authority-caused (§05.9) — with a root-cause reference, an FR-PAY-713 family code wherever one applies. A miss still unclassified when the next instance of the same family falls due is counted product-caused until classified, because the burden of the causation record is ours (§18.3).
- **AC-8** The On-Time Filing Rate counts every miss, whatever its class; only the SLA measures (Product-Caused Miss Rate, §19.9.2) set tenant- and authority-caused misses aside. The rate the customer experiences is never improved by re-attributing misses.

**[Verified]** The two-wage-base requirement and rules-first/no-model-generated-figures constraints are load-bearing correctness decisions from §08/§12, restated here as measurable acceptance criteria (Source: Code on Wages s.2(y); Code on Social Security s.2(88) — EV-010; PRD §06.10, §08, §12).

---

### 19.4 Activation metrics — from signup to first filing

Activation is the leading input-layer metric that most strongly predicts OTAF. For a filing-first product, **"activated" is not "logged in" or "ran a payroll" — it is "completed a first accepted statutory filing."** That definition is deliberately hard, because a tenant that never files never delivers value and will churn regardless of engagement.

| Metric | Definition | Why | Target (see §19.12) |
| --- | --- | --- | --- |
| **Activation Rate** | tenants reaching first accepted filing ÷ tenants onboarded | The core input metric | Phase-gated |
| **Time-to-First-Filing (TTFF)** | median days from signup to first accepted filing | Mid-year cutover is the churn-concentration point (§18) | ↓ minimise |
| **Migration Completeness** | % of required opening balances captured (YTD earnings, TDS-already-deducted, PF UAN/ESI IP continuity, leave balances, gratuity accrual) | Migration is a first-class surface (§18); incomplete migration causes downstream filing errors | → 100% before first filing |
| **Statutory-Registration Linkage** | % of tenants with PF code, ESI code, PT registration(s), TAN captured and validated | Cannot file without these; hypothesised to be the #1 activation blocker (below) | → 100% |
| **Importer Conversion** | % of tenants who used a Tally/Zoho/Kredily/Frappe importer and reached first filing | Importers are acquisition infrastructure (§18), so their yield is an activation metric | Track per importer |
| **Cutover-Timing Mix** | share of activations at start-of-FY (Apr) vs mid-year | Mid-year cutover concentrates opening-balance risk (§18); the mix predicts migration-error load | Track; nudge to Apr |

**The activation funnel (onboarding sub-funnel):**

```
Signup
  → Company + statutory codes captured        [Registration Linkage]
  → Employees imported / migrated             [Migration Completeness]
  → First payroll run completed               [Process metric]
  → First filing generated + validated        [Pre-Filing Validation]
  → First filing submitted + accepted         [ACTIVATED]
```

Each arrow is an instrumented drop-off point. **[Hypothesis]** The largest activation drop-off is at statutory-registration linkage, because a 20–49 tenant crossing the EPF threshold of 20 (EV-057, §06) may not yet have its PF code sorted. Kill/validate: instrument the funnel from first cohort; if linkage is the top drop, ship a guided PF/ESI/PT registration assist (a candidate AI use case, §12) and measure lift.

#### 19.4.1 A worked activation funnel — 100 onboarded tenants

Illustrative Phase-1 numbers (planning anchors, **[Hypothesis]**, to be replaced by the first cohort) showing how a 60% activation target decomposes and where to intervene:

| Funnel stage | Tenants reaching stage | Step conversion | Cumulative | If this is the worst step → |
| --- | --- | --- | --- | --- |
| Signup | 100 | — | 100% | Acquisition problem, not activation (§19.7) |
| Statutory codes captured | 78 | 78% | 78% | Ship guided PF/ESI/PT registration assist (§12) |
| Employees imported/migrated | 70 | 90% | 70% | Improve Tally/Zoho importers (§18) |
| First payroll run completed | 66 | 94% | 66% | Payroll UX / validation clarity (§08) |
| First filing generated + validated | 63 | 95% | 63% | Pre-filing validation false-positives |
| **First filing accepted [ACTIVATED]** | **60** | 95% | **60%** | Portal/format defects, rejection handling |

In this profile, **statutory-registration linkage (78%) is the dominant leak** — consistent with the hypothesis above — and a 10-point improvement there flows straight through to ~7 more activated tenants, more than any downstream fix. The funnel's job is to make that arithmetic obvious every week. **[Hypothesis]** These step-conversion rates. Kill/validate: instrument all six steps from cohort 1; re-rank interventions by measured step loss × downstream flow-through, not by assumption.

**Activation-quality caveat.** A tenant can be "activated" (one accepted filing) and still be fragile — e.g. it filed ECR but has not yet run a clean quarter of TDS. So activation is reported alongside **Activation Depth**: the count of *distinct instruments* a tenant has filed at least once. A tenant filing ECR + ESI + PT + TDS is durably activated; one filing only ECR is a partial activation that will churn if the other obligations bite. This distinction prevents gaming activation by counting the easiest single filing.

---

### 19.5 Retention metrics

Retention is the primary lagging outcome metric and the one that ultimately validates the whole thesis: if filings-as-delivery creates switching cost, retention should exceed the SMB-SaaS norm.

| Metric | Definition | Notes |
| --- | --- | --- |
| **Gross Revenue Retention (GRR)** | recurring revenue retained ex-expansion ÷ starting recurring revenue | The truest churn measure; SMB payroll should retain well due to switching cost |
| **Net Revenue Retention (NRR)** | (retained + expansion) ÷ starting | The single most important SaaS health metric; see §19.6 |
| **Logo Retention** | tenants retained ÷ starting tenants | Watch by band — 20–49 (funnel) will churn differently from 50–199 (core) |
| **Filing-Cohort Retention** | of tenants who hit ≥1 OTAF in month 0, % still filing in month N | Ties retention directly to the north star |
| **Band-Crossing Rate** | % of 20–49 tenants crossing into 50+ within 12 months | The core §05 land-and-expand assumption; its own kill criterion below |
| **Involuntary Churn** | churn from failed payment vs deliberate cancellation | Separated because remedies differ |
| **Filing-Streak Health** | share of active tenants with an unbroken monthly OTAF streak ≥ N months | A broken streak is the earliest churn precursor for a payroll product |

**Instrumented churn triggers.** §20's risk register and the market research both name **implementation friction as the most-cited churn trigger, concentrated at mid-year cutover** (§20.8 R-28; §18.9) — **[Hypothesis]**, as both sections mark it. The instrumentation must therefore tag every churn with a reason code drawn from an evidence-based taxonomy: `migration-friction | filing-failure/penalty | price | grew-into-different-product | acquired/shut-down | competitor-switch | free-tier-pull (Zoho/Kredily)`. Churn without a reason code is a data-quality defect.

#### 19.5.1 Filing-cohort retention — a worked cohort table

Because retention should be *caused* by filing delivery, the primary retention view is a filing cohort, not a signup cohort. Illustrative Phase-1 shape (**[Hypothesis]**), tenants who logged ≥1 OTAF in month 0:

| Cohort month 0 | M0 | M3 | M6 | M9 | M12 | Read |
| --- | --- | --- | --- | --- | --- | --- |
| 100% filing at M0 | 100% | 94% | 90% | 88% | 86% | Curve should flatten — filing = switching cost |
| Of which 20–49 band | 100% | 90% | 84% | 80% | 76% | Funnel band, thinner switching cost |
| Of which 50–199 band | 100% | 97% | 94% | 93% | 92% | Core band, revenue-carrying (§05) |

The thesis prediction is a **flattening curve** (retention loss decelerates because each successful filing deepens switching cost), with the **50–199 band retaining materially better than 20–49**. If instead the curve is linear or the two bands retain identically, the "filing creates switching cost" thesis is weakened. **[Hypothesis]** Filing-cohort retention exceeds the SMB-SaaS norm — for which this PRD holds no sourced figure; it is the named parameter `smb_logo_retention_benchmark`, routed to §20. Kill/validate: at month 12, if 50–199 logo retention < 85%, switching cost is weaker than assumed and the pricing/lock-in model (§18) must be revisited — the filing may be a delivery unit without being a retention moat.

#### 19.5.2 Churn reason-codes — a worked breakdown

Churn without a reason code is a data-quality defect (above), because the *remedy* differs entirely by cause. Illustrative Phase-1 breakdown of 20 churned logos (**[Hypothesis]**), showing how the taxonomy routes action:

| Reason code | Share | What it means | Owner + remedy |
| --- | --- | --- | --- |
| `migration-friction` | 35% | Cutover pain, mostly mid-year (§18) | Onboarding — improve importers, nudge Apr cutover (§19.4) |
| `free-tier-pull (Zoho/Kredily)` | 20% | Lost to a free alternative | GTM/pricing — the §18 free-tier risk made visible; freemium gives computation away and charges for outputs (EV-029), so the exit interview records which output the tenant stopped needing from us |
| `filing-failure/penalty` | 15% | We caused a miss or penalty | **Product Sev-1** — the harm guardrail's churn tail (§19.1) |
| `price` | 10% | Explicit price objection | Pricing — feeds the §20 V-03 realised-ARPU question |
| `grew-into-different-product` | 10% | Outgrew the beachhead shape | Expected; not a defect if band-crossing captured value first |
| `acquired/shut-down` | 5% | Business event, not our failure | Involuntary — exclude from remediable churn |
| `competitor-switch` | 5% | Lost to a paid competitor | Competitive — feeds §04 positioning |

The single most important cell is **`filing-failure/penalty` (15%)**: it is the churn tail of the harm guardrail, and it is the only reason code that is a product Sev-1 rather than a GTM signal. If it grows, the north-star thesis is failing at its own job. **[Hypothesis]** migration-friction is the top churn reason (consistent with §20). Kill/validate: reason-code every churn from cohort 1; if `filing-failure/penalty` — not migration — leads, the product-quality bar (§19.3) is the priority over onboarding.

**[Hypothesis]** The §05 land-and-expand model requires ≥25% of 20–49 tenants to cross into 50+ within 12 months. Kill criterion (restated from §05): if cohort analysis at month 18 shows <25% crossing, stop acquiring the 20–49 half and raise the commercial floor to 50. This is the metric that decides whether the beachhead's lower half is a funnel or a leak.

---

### 19.6 Expansion metrics

Expansion is where the beachhead economics (§05) either work or don't, and it has three distinct engines, each metered separately because §10 (recruiting cost) and §11 (benefits attach revenue) are explicit that neither may be blended into the software line.

| Expansion engine | Metric | Why metered separately |
| --- | --- | --- |
| **Organic seat growth** | net PEPM seats added from tenant headcount growth (no upsell) | This is the "size gate" thesis (§18.2 P1), billed on actual headcount with no seat floor (§18.2 P6) — a tenant hiring pays more without a sales touch |
| **Band-crossing upsell** | ACV lift when a tenant crosses 20→50→200 | Ties to §05 phasing; the statutory step-function (§06) is the natural upsell trigger |
| **Module attach** | attach rate + ACV of Recruiting (per requisition/hire), Benefits/FBP, CA-console seats | §10: recruiting priced per requisition/hire because cost doesn't track headcount; attach revenue modelled as a separate line from software PEPM |
| **NRR decomposition** | NRR split into (organic growth + upsell + attach − contraction − churn) | So we know *which* engine drives NRR, not just that it moved |

#### 19.6.1 NRR decomposition — a worked example

NRR that "moved" without knowing *why* is un-actionable. Take a Phase-1 starting cohort at ₹100 of recurring revenue (indexed) and decompose the year (**[Hypothesis]** shape):

| Component | Δ (indexed) | Source engine | Instrumented by |
| --- | --- | --- | --- |
| Starting recurring revenue | 100.0 | — | `subscription.*` snapshot |
| + Organic seat growth (tenants hiring) | +6.0 | Automatic size-gate (§18.2) | `seat.changed` |
| + Band-crossing upsell (20→50, 50→200) | +5.0 | Statutory step-function (§06) | `subscription.upgraded` |
| + Module attach (recruiting, FBP, CA console) | +3.0 | Metered SKUs only (never bundled AI) | `module.attached` |
| − Contraction (tenants shrinking) | −2.0 | Layoffs / seat reduction | `seat.changed` (negative) |
| − Gross churn | −8.0 | Reason-coded (§19.5) | `subscription.churned` |
| **Ending recurring revenue** | **104.0** | — | — |
| **NRR** | **104%** | — | — |

This 104% NRR is *only* interpretable because it is decomposed: it says organic seat growth (+6) is the largest expansion engine, band-crossing (+5) is working, attach (+3) is nascent, and churn (−8) is the biggest single drag. A board deck that reports "NRR 104%" and stops has thrown away every actionable signal. The rule: **NRR is never reported without its decomposition.** **[Hypothesis]** Organic seat growth is the dominant NRR engine. Kill/validate: if after 4 quarters organic growth contributes < band-crossing + attach combined, the size-gate thesis (§18.2) is weaker than assumed and expansion must be re-planned around active upsell.

**Benefits/FBP attach — track the data-model adoption, not the money moved.** §11 is explicit that benefits attach is *distribution rent, not software*, and that GMV/money-moved is a banned vanity metric (§19.13). So the attach metric here is **FBP-configuration adoption** — the share of tenants that have configured FBP declarations, wallet rules and proof-of-spend — because that is the option value on the attach business (§11), reported as a *separate, never-blended* line. One dated tailwind to instrument around: effective **1 April 2026** the tax-free meal perquisite rose ₹50→₹200 per meal and the gift/voucher nil-value threshold ₹5,000→₹15,000 during the tax year — a ~3.8× wallet expansion (**[Hypothesis]**, EV-019 — the figures concur across two dated secondary sources and a counsel spot-check, but the rule text was not read; §11). The meal figure holds **only under its conditions**, which the engine carries as constraints (§11 BEN-62): meals provided during working hours at office or factory premises, or non-transferable vouchers usable only at eating outlets. Without them the perquisite is taxable, payslips under-deduct, and the demand plus interest lands on the employer (EV-K30). The rule citation under the Income-tax Rules 2026 is unconfirmed and routed to §20 V-18 (§06.13). So FBP-adoption uplift after April 2026 counts as a real, dated signal only for configurations that meet the conditions — a meal component configured as a cash allowance is not adoption of the exemption. **[Hypothesis]** FBP-config adoption predicts later attach monetisation. Kill/validate: if configured tenants monetise attach no better than unconfigured ones once monetisation ships, the data model is option value only, and no attach revenue forecast may lean on config adoption.

**AI-attach caution (from §12).** The AI assistant is bundled free (the market price of HR AI is zero — seven vendors, §13.1; greytHR's NAVOS "included in every plan", EV-090). Expansion metrics must **not** count bundled-AI usage as expansion. Only *metered* AI SKUs — recruiting per requisition, bulk document generation, HR-analyst copilot per admin seat — are expansion revenue, and each carries the §13 caveat that willingness-to-pay is unvalidated (§20 V-07). **[Hypothesis]** Metered AI SKUs contribute meaningfully to NRR. Kill: if §20 conjoint shows zero willingness everywhere, these SKUs drop out and NRR must come entirely from seats + band-crossing + benefits attach.

---

### 19.7 Funnel and acquisition metrics

Two acquisition motions run in parallel (§18): **self-serve** (published price card, importer-led — the only way to be evaluable by a 30-person company that won't sit through a demo, §18) and **CA-referred** (the unvalidated-but-central GTM bet, §20 V-05). They are instrumented as separate funnels because their CAC, conversion and payback differ.

| Stage | Self-serve funnel | CA-referred funnel |
| --- | --- | --- |
| Top | Website visitor → price-card view → signup | CA console signup → client added |
| Mid | Importer run → activation (first filing) | Client provisioned → first client filing FILED in a CA-attended session (Mode D, §22 FR-OPS-001; P1) |
| Bottom | Free/land tier → paid conversion | Client billed (CA or client pays) |
| Efficiency | CAC, CAC-payback (months), LTV:CAC | Referred-client CAC, CA-productivity (clients/CA) |

**Cross-cutting acquisition metrics:**

- **CAC and CAC-payback (months)** — payback is the metric that matters most at SMB scale where ACV is low (₹24k–60k for 20–49; §05). A long payback on a funnel-tier customer is fatal.
- **LTV:CAC** — computed per band; the 20–49 band is expected to be marginal or negative on its own and justified only by band-crossing (§19.5).
- **Importer-attributed signups** — Tally/Zoho/Kredily/Frappe importers as acquisition infrastructure; measure signup share and downstream activation by source importer.
- **Price-card engagement** — because publishing the price card is a strategic bet (§18), instrument whether self-serve prospects actually convert off it without sales touch.

#### 19.7.1 CAC-payback worked example — why the 20–49 band is fragile

CAC-payback, not LTV:CAC, is the metric that governs survival at low ACV. Worked case using PRD-anchored figures (all list-price-derived and therefore **[Hypothesis]** until §20 V-03 reports realised ARPU):

- Price has two anchors — a **value floor near ₹50 PEPM** (Qandle, greytHR at 50 employees) and a **mid-market clearing band of ₹80–200 PEPM** (Zimyo, HROne, Keka) — with our ₹80–150 planning anchor inside the band (EV-027; §18). A 30-employee tenant billed on its actual 30 seats (six of six priced competitors impose a 50-employee minimum billing block, Keka's was 100 — EV-026; we do not, §18.2 P6) at ₹80–150 PEPM → ARPU ≈ ₹2,400–4,500/month → **₹28,800–54,000 ACV**. At the ₹50 floor it is ₹1,500/month.
- Gross margin is the named parameter `gm_blended` and is **unknown today**: inference is the smallest of four COGS lines, and the dominant one — supervised filing, per registration × state × filing type — is unsized (EV-088; §13, §22; routed to §20). So payback is stated **before COGS** (CAC ÷ monthly revenue); the true figure is that number ÷ `gm_blended`, and is always longer.
- CAC inputs below are illustrative scenario values, not estimates. If self-serve CAC is ₹15,000 (mostly importer + content, no sales touch): **payback ≥ 3.3–6.3 months** at ₹80–150, and **≥ 10 months** at the ₹50 floor.
- If the same tenant needs a sales touch (CAC ₹40,000): **payback ≥ 8.9–16.7 months** before COGS — at the low end of the band it breaches the 12-month line even at a 100% gross margin, which is fatal at this band because 20–49 logo churn is higher (§19.5) and band-crossing is unproven.

The arithmetic is the reason §18 insists on a **published price card and importer-led self-serve** for the lower band: it is the only CAC structure whose payback survives the low ACV. The metric that polices this is **self-serve share of 20–49 activations** — if that band is being won by sales touch, payback breaks. **[Hypothesis]** 20–49 can be acquired self-serve at CAC-payback ≤ 12 months. Kill/validate: if blended payback for the band exceeds 12 months over 2 quarters, either the price card is not converting (raise floor to 50, §05) or CAC attribution is missing a hidden sales cost.

**[Hypothesis]** The CA channel is a net-positive acquisition engine. Kill criterion (from §20 V-05): if CAs see the product as disintermediation, the channel inverts into an opponent — the leading signal will be CA-console signups that add clients but then *block* client self-serve conversion; instrument that conflict explicitly (CA-added clients whose self-serve conversion rate is *below* the non-CA baseline).

---

### 19.8 AI cost and efficiency metrics — cost-per-account

§13 is unambiguous: **build full token, cache and cost attribution per tenant, user, agent and model from v1, while the price is still zero.** These metrics are that mandate made concrete. They are cost-of-goods metrics, not revenue metrics — AI is COGS, never the revenue line (§13). And they measure **one COGS line of four**: inference is the smallest; WhatsApp messaging scales per message; **supervised filing** — the dominant line — scales per registration × state × filing type; compliance curation scales per state maintained (EV-088). Gross margin is decided on the supervised-filing line, which is why its instrument sits in this table too.

| Metric | Definition | Why | Source/target |
| --- | --- | --- | --- |
| **AI COGS PEPM** | inference spend ÷ active employees, per tenant | The inference line's unit number | ₹0.15–3.27 PEPM — placeholders, **[Hypothesis]** (EV-008, §13.6) |
| **Cost per Account (per tenant/month)** | full inference + cache spend attributed to a tenant | The "AI-cost-per-account" the brief names; must stay a small share of revenue | vs price between the ~₹50 PEPM value floor and the ₹80–200 clearing band (EV-027, §18) |
| **Inference Share of Revenue** | inference spend ÷ tenant revenue, per tenant | Early warning on one COGS line. **[Reversed]** An earlier draft reported a "93–99% gross margin on inference"; withdrawn — it was a margin on the smallest of four lines, not a gross margin (EV-K13, EV-088, §13) | Investigate any tenant above ~5% (§13.9; §20 V-14 pass line) |
| **Supervised Minutes per Filing Cycle** | staff minutes metered by §22 FR-OPS-010, per registration × filing type × cycle: active session minutes (Modes B and C, and any staff minutes on a Mode A or D instance) plus reason-coded preparation and exception minutes logged against the instance; OTP and instruction waits are metered separately and added only where they block the operator (§22.7 `f_wait`); a Mode A instance with no staff involvement meters zero | The dominant COGS line, unsized (EV-088); revenue scales per employee, this cost per registration | vs `max_supervised_minutes_per_filing_cycle` — derived by the §22.7 formula, unsized, measured under §20 V-26 |
| **Cost per Cost Class / per Model** | inference spend split by cost class A0–A6 (§13.3) and by model backend | Model choice *is* the inference-cost decision (§13.5); routing needs this to re-point task classes | Router-driven |
| **Deflection Rate** | support/HR queries resolved by assistant without human ÷ total | The assistant's value is deflection, not revenue | ↑ maximise |
| **Abstention Rate** | assistant answers that abstained and routed the gap (§12's fail-closed abstention) ÷ eligible queries, per use case, reported beside deflection | A high rate is a coverage gap to fill — a missing policy or an unpublished rule — never a guardrail to loosen (§12) | Trend per use case; no target |
| **Cache Effectiveness** | cache-read savings vs cache cost (write premium and storage-hours), per provider × tenant-size band | §13.11 [Killed] "cache everything": a held, storage-hour-priced cache on Gemini costs over 100× the no-cache input price for a 100-employee tenant; read-priced prefix caching is the opposite economics | Held caches off on the beachhead; read-priced prefix caching on where supported (§13.11) |
| **Rate-Limit / Budget-Cap Incidents** | count of per-tenant/per-user budget caps hit | One heavy user can exceed a seat's entire ARPU (§13); caps are P0 | Track + alert |
| **Cost per Recruiting Action** | inference + external cost per requisition/hire, metered separately | Recruiting cost doesn't track headcount — 15× spread between fast- and slow-hiring tenants (§10) | Per-action, not PEPM |
| **Model-Mix Ratio** | share of inference spend by model tier (cheap/mid/frontier) | The 52.7× model spread (EV-007, EV-089) means mix *is* inference cost; drift toward frontier is a cost leak | Track weekly |

#### 19.8.1 Worked AI COGS example — one tenant, and why the ratio matters more than the absolute

Take a 100-employee tenant. The PRD's engineering estimate is **23,675 input / 2,045 output tokens per employee-month** (§13, explicitly unvalidated). At that volume:
- Monthly tokens ≈ 100 × (23,675 in + 2,045 out) ≈ **2.37M input + 0.20M output**.
- On r2/03's disciplined case (21,272 in / 1,894 out per employee-month, with cache reads — §13.6), **Gemini 2.5 Flash-Lite** lands at the band floor (~₹0.15 PEPM → ~₹15/tenant/month) and **Sonnet 5** at the band top (~₹3.27 PEPM → ~₹327/tenant/month); the frontier model on the same volumes is ₹8.19 PEPM (EV-008, §13.6 — all placeholders).
- The **52.7× spread [Verified]** between cheapest and dearest credible model is a ratio of list prices on the agentic-loop volumes (EV-007, EV-089); it survives FX, the absolutes do not.

Against the two price anchors — ₹50 PEPM floor to ₹200 PEPM band top (EV-027), ₹5,000–20,000 a month for this tenant — even the ₹327 case is **~1.6–6.5% of revenue**. **[Reversed]** Earlier drafts read that ratio as a 93–99% inference gross margin (EV-K13). It is not a gross margin: inference is the smallest of four COGS lines, and gross margin is decided on the unsized supervised-filing line (EV-088; §13; Supervised Minutes per Filing Cycle above). **The inference absolute also rests entirely on the unvalidated token estimate.** If real tokens-per-query are **5×** the estimate (the §20 V-04 kill case), the ₹327 case becomes ~₹1,635/tenant — **~33% of the revenue of a 100-employee tenant at the ₹50 floor**, and free-bundling breaks at the low end. This is exactly why the metric that is *reported* is **measured AI COGS PEPM from v1 instrumentation**, and the estimate is only a placeholder.

The defensive posture the metric enforces: because the **ratio (52.7×) is [Verified]** but the **absolute is [Hypothesis]**, the router's job (§13.5) is to keep the **Model-Mix Ratio** weighted toward the cheap tier for the deterministic-adjacent tasks, spending the 52.7× only where a frontier model measurably lifts deflection. A rising Model-Mix Ratio toward frontier is an inference-cost leak visible *before* it shows in the monthly COGS number.

#### 19.8.2 The cache-inversion guard — a worked negative

§13's [Killed] "cache everything" is not a soft preference; it is a rupee trap that the metric must actively prevent. Worked case (§13.11 figures): a **50k-token per-tenant policy cache held continuously on Gemini Flash-Lite** costs roughly **₹34.47 per employee** at a 100-employee tenant on hourly cache-storage pricing, against **₹0.27** for simply paying full input price — **over 100× worse**. So:
- **Cache Effectiveness** is computed per provider × tenant-size band, and **held, storage-hour-priced caching is off by default** on the beachhead; it turns on only where the metric proves net-positive savings for that provider and band. Read-priced prefix caching — no storage-hour charge — is the opposite economics and is on by default where the provider supports it, provided reads repay the write premium (§13.11 design rule).
- For sub-1,000-employee tenants on hourly-storage providers, the expected value of a held cache is *negative*, so the metric's job is to keep it **off** and flag any config that turns it on. A "cache hit rate went up" celebration is a §19.13 vanity trap if cache *cost* went up more. **[Verified]** cache-inversion economics (Source: PRD §13; Gemini hourly cache-storage pricing).

#### 19.8.3 FX sensitivity — every AI cost metric carries three columns

USD-priced inference means every AI COGS number is an FX bet. §13 requires FX sensitivity at **₹90/95/100** and treating the **Gemini 3.x Flash doubling (scheduled 1 Jan 2027) as the base case, not the downside** (Gemini 2.5 Flash-Lite carries no announced increase). So the AI COGS board reports every headline as a three-column band:

| Scenario | USD/INR | Gemini 3.x Flash pricing | Effect on AI COGS PEPM |
| --- | --- | --- | --- |
| Favourable | ₹90 | pre-increase | lower bound |
| **Base case** | **₹94.43 [Verified] (EV-089)** | **2× (post 1 Jan 2027)** | **the number we plan against** |
| Stress | ₹100 | 2× | upper bound; triggers router re-point (§20 R-13) |

**[Verified]** ₹94.43/USD (Sep 2026) and the scheduled Gemini 3.x Flash doubling (EV-089); the ₹90/95/100 sensitivity mandate is §13.2 and §13.12. Reporting a single-point AI COGS figure without the band is a metric-hygiene violation, because it hides a scheduled, known cost increase.

#### 19.8.3.1 Deflection rate — the assistant's value is measured in avoided humans, not tokens

The assistant is bundled free (§12); its value is therefore **deflection** — HR/support queries resolved without a human — not revenue and not usage. This is the metric that turns AI COGS into a defensible cost: every deflected query is a support-headcount cost avoided. Worked case, a 100-employee tenant:

- Employee self-service queries ≈ 2.0 helpdesk + 0.3 onboarding per employee-month → **~230 A1 queries/month** (leave balance, payslip explain, PT/PF query, policy lookup) — r2/03's engineering estimate, the most load-bearing unmeasured rate after token size (§13.3).
- At a **40% deflection rate** (Phase-1 target), ~92 queries resolved by the assistant, ~138 escalate to a human.
- At **60%** (Phase-2 target), ~138 deflected, ~92 escalate.
- The rupee value of a deflected query is the named parameter `loaded_cost_per_human_query` — unmeasured, routed to §20. The break-even is computable without it: at 40% deflection, the ₹327/month band-top inference cost for this tenant (§19.8.1) is repaid if a human-handled query costs more than ₹327 ÷ 92 ≈ **₹3.6**; at the ₹15 band floor, ≈ ₹0.16. *That* comparison, not the token count, is the justification for bundling AI as COGS — and it covers the inference line only, not the supervised-filing line (EV-088).

The trap the metric guards against (§19.13): **tokens processed can rise while deflection falls** — a chattier assistant that resolves less. So deflection is reported *against* AI COGS per account, never alone. **[Hypothesis]** The 2.3 queries/employee-month rate, the 40%→60% deflection targets and `loaded_cost_per_human_query`. Kill/validate: instrument `ai.deflected` from v1; if deflection cannot clear 40% of eligible queries, the assistant is a cost without an offsetting saving and its scope must narrow to the query classes where it does deflect.

#### 19.8.4 Per-class cost attribution — the seven cost classes

Model choice is the inference-cost decision (§13.5), but so is *class* choice: a cheap class invoked constantly can cost more than an expensive class invoked rarely. Per-class attribution (the `task_class` field, §19.11.2) is what lets the router re-point task classes. **[Reversed]** An earlier draft attributed cost to a "six-agent architecture" with invented shares; §13.3 prices seven cost classes, A0–A6, against the §12.4 task classes, and the only derivation of their shares is r2/03's (§13.6, **[Hypothesis]**, replaced by measured spend):

| Cost class (§13.3) | Correct tier (§13.3) | Volume driver | Share of input tokens in the only derivation (§13.6) | Deflection contribution |
| --- | --- | --- | --- | --- |
| A0 Triage / router classifier | Cheapest | Every inbound interactive turn | Inside the helpdesk line — no line of its own | None directly — routes |
| A1 Employee policy Q&A | Cheap | Headcount, event-driven | Helpdesk 50.7% (with A0) + onboarding 5.1% | Highest — the deflection workhorse |
| A2 Filing / compliance copilot | Mid | Admin actions | 12.7% | Admin-facing; explains, never calculates |
| A3 Bulk document generation | Cheap, batch | Document volume, review cycles | Letters 1.6% + performance review 14.8% | Medium; bulk runs metered above a quota (§13.8) |
| A4 Recruiting agent | Mid | Hiring velocity | 15.2% — metered separately | Metered per requisition/hire (§19.8.5) |
| A5 HR-analyst copilot | Mid–high | Admin seats | Outside the r2/03 budget — `a5_queries_per_admin_month`, unestimated | Metered per admin seat (§13.8) |
| A6 Statutory-change watcher | Mid | Per notification, org-wide | Not a per-tenant cost | Reliability, not deflection |

The read: the headcount-scaling cheap classes (A0/A1) carry the largest token share and most of the *deflection value*, while the mid–high admin classes are lower-frequency and, where metered, monetised. Token share is not cost share — A1 runs on the cheap tier — so the board shows both. If per-class attribution shows a mid or frontier class creeping up in COGS share without a matching deflection or metered-revenue lift, that is the router's signal to re-point it (§13.5) — visible per class, before it shows in blended COGS. **[Hypothesis]** these shares. Kill/validate: measure per-class spend from v1 (§13.9); if measured shares diverge from the §13.6 derivation, the router's cost ceilings are re-set against the measured shape.

#### 19.8.5 Cost per recruiting action — why it is metered, not PEPM

§10 is explicit: recruiting cost does not track headcount — a tenant hiring at 15%/month costs ~**15×** a tenant hiring at 3%/month on identical PEPM pricing (§13.7). Two vendors already price hiring per recruiter, not per employee: greytHR's Recruit (pricing page read, not executed — r2/03 capture, 2026; re-check at source before external use) and Keka's archived hiring card, PRO ₹1,500 and ADVANCED ₹2,500 per recruiter per month (EV-022). Worked contrast, two 100-employee tenants, on r2/03's assumptions:

| | Tenant A (steady-state hiring) | Tenant B (recruiting-heavy) |
| --- | --- | --- |
| Monthly hires | ~3 (3%/month; 40 CVs per hire, 3,000 tokens per CV) | ~15 (15%/month; 50 CVs per hire, 10,000 tokens per CV) |
| CV screens per month | ~120 (1.2 per employee) | ~750 (7.5 per employee) |
| Screening cost, per employee-month on Sonnet 5 | ₹1.13 | ₹17.00 — ~15× |
| If priced flat PEPM | subsidises B | B is subsidised by A — margin leak |
| **Correct metric** | **Cost per Recruiting Action** (per requisition/hire) | same — decoupled from headcount |

This is why **Cost per Recruiting Action** is tracked per requisition/hire and recruiting is a *metered* SKU, never folded into software PEPM (§10). The metric prevents a fast-hiring tenant from silently destroying the margin of a flat-priced plan. **[Verified]** the 15× hiring-rate cost spread, FX-invariant (r2/03, §13.7), and the per-recruiter pricing precedent (EV-022; greytHR per r2/03).

**The one ratio that is [Verified], and the ones that aren't.** §13 is explicit: the **52.7× spread between cheapest and dearest credible model on identical workload is [Verified]** (a ratio of USD prices, survives FX). The **absolute PEPM figures are [Hypothesis]** — they rest on an unvalidated 23,675-input/2,045-output tokens-per-employee-month estimate (§13; §20 V-04). Therefore:

- Report **AI COGS PEPM as a measured value from v1 instrumentation**, not the estimate — the estimate is a placeholder to be replaced by real tokens-per-query the moment the prototype is instrumented (§20 V-04, V-14).
- Use **FX-sensitivity at ₹90/95/100** on every AI cost metric, and treat **the Gemini 3.x Flash doubling (scheduled 1 Jan 2027) as the base case, not the downside** (EV-089).
- Never report an inference figure as a gross margin: it is one COGS line of four, and the smallest (EV-088).

**[Verified]** The requirement to attribute cost per tenant/user/agent/model from v1, the cache-inversion economics, and per-tenant rate limits as P0 are all §13 decisions (Source: §13.7, §13.9, §13.11; Gemini hourly cache-storage pricing). **[Hypothesis]** ₹0.15–3.27 PEPM inference cost (EV-008). Kill/validate: §20 V-04 — instrument tokens-per-query against a real policy corpus; if actual is 5× estimate, free-bundling breaks at the low end and the beachhead floor moves up.

---

### 19.9 Reliability and statutory-maintenance metrics

These are the SLA-shaped metrics that back the strategic bet in §18: **sell the compliance SLA as the thing no free alternative offers** — we are not aware, as of September 2026, of a free tier that carries a remedy (§18.3). The SLA is a contractual service commitment with a capped remedy — not a transfer of statutory liability, which is non-delegable and stays with the employer and deductor (EV-K24; §18.3; Part D-17 and D-20, §23). If we make that promise, these are the numbers that prove we keep it; §19.9.2 specifies the promise itself.

| Metric | Definition | Why | Target direction |
| --- | --- | --- | --- |
| **Payroll-Run Success Rate** (the "payroll-run reliability" §05.3 DG-3d reads) | process attempts (FR-PAY-301 M4 or M5) that reach PROCESSED with every fixed-point node converged within `fixed_point.max_iterations` (FR-PAY-211) and no engine fault, and whose result version is never later corrected for a root cause classed SA-CALC (FR-PAY-713) ÷ process attempts whose M4 guard passed. Attempts refused by the guard (evaluation context incomplete) and M7 returns for correction are input or approval events, counted under Pre-Filing Validation, not here. Source: `PayRun` (§14.4.4) and the FR-PAY-301 transition log | A failed run cascades into a filing miss | → 100%; DG-3d's 99.5% over two quarters is §05's gate for the 1,000–1,999 band |
| **Statutory-Change Lead Time** | days from a gazette/notification (or **corrigendum**) to the rule being live and effective-dated in the engine | §12: the watcher must catch *amendments, not just new instruments* — a corrigendum inverted the entire Nov-2026 analysis (§06) | ↓ minimise; SLA-bound |
| **Corrigendum-Catch Rate** | amendments/corrigenda caught by the watcher ÷ amendments that occurred (audited retrospectively) | The Nov-2026 miss was a *corrigendum*, not a new notification (§06); a watcher keyed only to new instruments scores 100% on new and 0% on the thing that actually broke | → 100% |
| **Device Integration Success Rate** | ADMS/WDMS terminals successfully pushing punches ÷ configured terminals | Deals are won/lost on device-fleet talk (§09); note the retracted 85–98% figure is **banned** (EV-K03, §20.4) — measure our own (§20 V-10) | Measure, don't assume |
| **Windowed Availability** | successful-request ratio at the load balancer, reported separately for the payroll critical window and the rest of the month (§17 NFR-AVAIL-801) | The availability SLO is windowed, not blended (Part E-13) | Proposal: 99.95% from the 25th to the 2nd, 99.5% otherwise — **[Hypothesis]**, owned by §17 |
| **Due-Date-Window Availability** | availability inside each declared statutory window — the 7th (TDS deposit, **[Hypothesis]** until read against r.218), the 15th (ECR, ESI), state PT dates once captured (§17 NFR-AVAIL-802, §06.11) | General uptime hides the hours that carry penalty risk | Window length and target per §17; not restated here |
| **CERT-In Readiness** | log-retention coverage (180 days, within Indian jurisdiction), NTP clock-sync health, six-hour incident-reporting path tested, point of contact named (EV-062) | Binds from day one, not at enterprise scale (§17) | Continuous compliance |

**Why two availability metrics.** A blended monthly figure hides where the downtime lands: an outage on a day with no statutory window is an inconvenience; the same outage at 23:30 on the 15th, when a tenant is filing ECR, is a penalty event. The windowed SLO follows the payroll cycle (Part E-13); **Due-Date-Window Availability** follows the statutory calendar, whose windows §17 declares. Both targets are §17's and are **[Hypothesis]** until §20 instrumentation replaces them. This is the reliability expression of the on-time-margin fragility point (§19.3.3): the metric follows the penalty clock, not the calendar month.

#### 19.9.1 Worked statutory-change lead time — the November 2026 episode

Statutory-Change Lead Time is abstract until run against the exact event that nearly broke the research (§06.9). Trace the EPF re-notification, in date order, as the watcher must have handled it:

| Step | Event | Watcher must | Lead-time clock |
| --- | --- | --- | --- |
| 1 | Code on Social Security commencement notified by **S.O. 5319(E)**, effective 21 Nov 2025 | Ingest the commencement; do not yet conclude which repeals commenced | starts at notification |
| 2 | **Corrigendum S.O. 5936(E)** of 19.12.2025 substitutes the S.O. 5319(E) entries: s.164(1), including the EPF Act 1952 repeal, commenced 21.11.2025 except for a pension-related slice already in force since 03.05.2023 under S.O. 2060(E), and s.164(2)(b) saves the EPF, EDLI, EPS schemes and all ESI subordinate law for one year, to on or about 21 Nov 2026 (indiacode still reproduces the uncorrected S.O. 5319(E)) | **Catch the corrigendum, not just the new instrument** — this is the step one research round missed; flag the ~21 Nov 2026 expiry as a dated risk | corrigendum-catch |
| 3 | Successor **EPF Scheme 2026**; 12% re-notified by **S.O. 3582(E)** of 01.07.2026, retrospective to 21.11.2025 | Encode 12% effective-dated to 21.11.2025 (retrospective) | days-to-live |
| 4 | ESI side: no successor instrument we are aware of as of September 2026 (EV-004; §06.9; §20 V-08) | Keep post-cliff ESI instances BLOCKED-pending-regime; alert before the date | open |
| 5 | EPF rule live and effective-dated in engine | On-time/RFT for EPF recompute under the correct rule version | clock stops |

The lesson the metric encodes: a watcher scoring **100% on new notifications** but **0% on corrigenda** would have read the uncorrected enumeration and reached the opposite conclusion on the EPF Act's survival and the one-year sunset — building the EPF engine against the wrong instrument: an AC-5 provenance failure even where a figure happens to coincide, and a correction-rate spike one cycle later wherever the two instruments diverge. So **Corrigendum-Catch Rate** is tracked as a first-class reliability metric alongside lead time, and the watcher is validated by replaying this exact episode (§19.12.3 Phase-1 gate). **[Verified]** S.O. 5319(E), corrigendum S.O. 5936(E), the S.O. 3582(E) retrospective re-notification and the indiacode uncorrected-footnote trap (EV-002, EV-003; Source: §06.2, §06.9; Code on Social Security s.164).

**[Verified]** The statutory watcher must catch corrigenda not just new notifications, device push (ADMS/WDMS) is the dominant integration path, and CERT-In binds from day one (Source: PRD §12, §09, §17; S.O. corrigendum episode, §06). **[Killed]** The 85–98% device-integration success figure — it was marketing from the vendor selling the fix; device-integration effort is unsized and must be measured from our own fleet, never assumed (EV-K03; §20.4 banned-numbers table; §20 V-10). **[Hypothesis]** Corrigendum-Catch Rate can reach 100% via the watcher. Kill/validate: run the watcher retrospectively against the known S.O. 5319(E) → S.O. 5936(E) corrigendum → S.O. 3582(E) episode (§06.9); if it would not have flagged the corrigendum, the watcher's source coverage is incomplete and must expand before any compliance-SLA is sold.

#### 19.9.2 The compliance SLA as a specification

§18.3 prices the compliance SLA and bounds its remedy; §05.9 fixes the miss taxonomy and the boundary rules SS-1 to SS-5; §05.21 issues the per-tenant coverage statement the SLA reads. This subsection is the one measurable statement those sections — and §01's PC-5 and §23's master-services-agreement row — point to: what is covered, what is excluded, what opens a claim, what proves it, and what it can pay. It is customer-facing legal text. Its wording has a named owner (the Legal lead), needs counsel clearance before any contract carries it (§05.8 PL-05; Part D-20; §23), and every commercial term in it is **[Hypothesis]** until §20 V-07 and V-16 report.

| Element | Specification | Measured or evidenced by |
| --- | --- | --- |
| **Covered obligations** | Only instances on lines the tenant's coverage statement holds IN_SLA, read at the version in force on each instance's due date (§05.21); only instances due at least `sla_onboarding_lead_days` after the line entered IN_SLA (SS-1); only periods from the tenant's first live wage month (SS-2). Which artefact families can be IN_SLA in each release is §05.9's matrix. The SLA clause cites the coverage-statement version (§05.20 O2); an obligation absent from the statement is not covered by implication | `coverage.versioned` events; the statement version carried on each `filing.*` event |
| **The promise, per covered instance** | **Mode C** (operator-attended — offered per portal only once F-08[portal] is SHIPPED, §05.18): the instance satisfies `complete(f)` and `on_time(f)` (§01), provided the employer closed inputs, approved and funded no later than `tenant_action_lead[family]` before the due date (SS-3). **Modes A and B, and every portal while F-08 is open:** the SLA narrows to artefact readiness, warning lead time and co-attended guidance (§05.12; §05.18 F-08) — the instance reaches VALIDATED (FR-PAY-711 F5) no later than `sla.artefact_ready_lead[family]` before the due date, and every tenant-side blocker is warned before the SS-3 point. In no mode is it a promise of statutory outcome — the authority's acceptance, a penalty waiver, or a refund of the tenant's own liability (§05.9) | Gates 1–3 of §19.1; Artefact Readiness Rate and Late-Warning Share (below) |
| **Exclusions** | (1) Instances on any line not IN_SLA — SLA_PENDING_FIRST_SUBMISSION; CARVED_OUT_FENCE, for example Form 138 Q4 and Tax Year 2026-27 Form 130 on F-01 (EV-046), the ECR arrear return on F-03 (EV-043), post-lapse ESI on F-04; CARVED_OUT_PARAMETER; TENANT_SELF_FILES; NOT_OFFERED. (2) Authority-caused misses (§05.9) — a portal outage or format change on the due date, an unpublished format. (3) Tenant-caused misses where the warning reached the tenant before the SS-3 point. (4) Instances whose due-date rule is unconfirmed, which are never judged on time or late (SS-4). (5) Periods before the first live wage month (SS-2). (6) The statutory liability itself, which is non-delegable and never described as transferred (EV-K24; §23.13.5) | `miss_class` (AC-7); the coverage-gap register |
| **Claim trigger** | A claim opens automatically — not only on the tenant's request — when a covered instance records a product-caused miss (AC-7). It is priced when `penalty.incurred` records an amount the authority charged on that instance. A tenant may also open a claim; either way it enters the same lifecycle. A warning that reached the tenant after the SS-3 point makes the miss product-caused whatever the tenant did (SS-3) | `filing.miss_classified`, `penalty.incurred`, `sla.claim_opened` (§19.11.1) |
| **Evidence** | The causation record §18.3 requires, assembled from records the product keeps anyway: the FR-PAY-711 transition log with authority timestamps (AC-1); the completion-predicate fields (§01); `submission_mode`, the delivery mode and, for Mode C, the authority-to-act document and the session log (§22 FR-OPS-008); the tenant's approval and funding timestamps and each warning's delivery timestamp (SS-3); the coverage-statement version and the due-date rule version (AC-6); the authority's own interest, damages or fee figure — the portal's figure governs, never our forecast (§06.2). A claim may not be declined for want of a record the product was obliged to keep: a record missing on our side decides the miss as product-caused | The per-tenant compliance-SLA evidence board (§19.11.4) |
| **Remedy and cap** | Remediation of the instance — fix, refile on whatever correction route EV-037 still allows, disclose — plus a contractual remedy for interest, damages, fees or penalties charged on the instance **solely** because of a product-caused miss, within a cap of `sla_remedy_cap_months` × the tenant's monthly platform fee, per incident and per annum (§18.3). Whether a product-caused miss that drew no charge also earns a service credit is the remedy schedule's decision (§18.3; counsel, CR-17e) and is not set here. No damages percentage or fee cap is quoted in any contract until §06's parameters are re-captured from the notified text (§18.3). Counsel drafts the cap and indemnity and checks their insurability (CR-17e, CR-17f; §23.13.5) | Remedy Cap Utilisation (below) |
| **Disclosure** | Every miss on a covered instance, whatever its class, is root-caused and disclosed to the tenant with its class and evidence (§05.9). A class the tenant disputes is re-reviewed, and the dispute is itself counted | Claim Dispute Share (below) |

**The claim lifecycle, as a transition table.** A claim is in exactly one state at a time; every transition is an `sla.*` event carrying the claim ID, the instance ID and the actor.

| # | From → To | Event | Guard | Side effect | Who may trigger |
| --- | --- | --- | --- | --- | --- |
| C1 | *(none)* → OPEN | Product-caused miss recorded, or the tenant opens a claim | The instance was on an IN_SLA line at its due date | Evidence bundle assembled from the records above; tenant notified | System; tenant admin |
| C2 | OPEN → CLASSIFIED | Root cause confirmed | `miss_class` set with its root-cause reference (AC-7) | Class and evidence shown to the tenant | Statutory desk lead |
| C3 | CLASSIFIED → DECLINED | Class is tenant- or authority-caused, or an exclusion applies | The exclusion is named with its evidence | Reason disclosed | Statutory desk lead |
| C4 | CLASSIFIED → ACCEPTED | Class is product-caused | — | Remedy computed from the authority's charged figures, capped (AC-10) | Statutory desk lead, with a finance approver |
| C5 | DECLINED or ACCEPTED → DISPUTED | Tenant disputes the class or the amount | Within `sla.claim_dispute_window_days` of the decision | Re-review queued to a person other than the classifier | Tenant admin |
| C6 | DISPUTED → ACCEPTED or DECLINED | Re-review decided | Reviewer is not the original classifier | Decision and reason recorded | Legal lead |
| C7 | ACCEPTED → SETTLED | Remedy paid or credited | Amount within the cap version in force | `sla.claim_settled` | Finance |

`sla.artefact_ready_lead[family]` and `sla.claim_dispute_window_days` are named here, unsized, and routed to §20 (the pricing-and-commercial family of §20.13); `sla_onboarding_lead_days` and `tenant_action_lead[family]` are §05.9's and `sla_remedy_cap_months` is §18.3's.

**The SLA measures.**

| Measure | Numerator | Denominator | Target |
| --- | --- | --- | --- |
| Product-Caused Miss Rate | In-coverage instances missed with `miss_class` = product-caused | In-coverage instances due | → 0%; bounded above by 1 − On-Time Filing Rate. §05.3 DG-2b gates the 200–999 band at below 2% over a quarter |
| Artefact Readiness Rate (Modes A and B) | In-coverage Mode A and B instances reaching VALIDATED at least `sla.artefact_ready_lead[family]` before the due date | In-coverage Mode A and B instances whose source payroll month reached LOCKED by the `tenant_action_lead[family]` point | → 100% |
| Late-Warning Share | As §19.3.3 | As §19.3.3 | → 0% |
| Claim Incidence | Claims ACCEPTED, as a count and in ₹ | Tenant-months on the File tier | 0; an accepted claim that carries a charge is also a Sev-1 under guardrail 2 |
| Remedy Cap Utilisation | ₹ settled for a tenant in the contract year | That tenant's annual cap under the cap version in force | Trend; a tenant nearing its cap is reviewed by the Legal lead, because the cap is the insurability boundary |
| Claim Dispute Share | Claims entering DISPUTED | Claims DECLINED or ACCEPTED | Trend; no target |
| Classification latency | Median days from OPEN to CLASSIFIED | — | Trend; no target |

**Worked decisions — one 60-employee tenant, one September ECR (Case A's tenant, dues ₹2,16,000).**

| Situation | Class | Covered? | Claim outcome | On the raw On-Time Filing Rate |
| --- | --- | --- | --- | --- |
| Mode C, IN_SLA. The employer approved and funded on time; our operator's queue overran and the receipt was captured on the 17th | Product-caused (§05.9: a submission we were authorised and funded to make was not made) | Yes | OPEN → CLASSIFIED → ACCEPTED. Interest forecast ₹2,16,000 × 12% × 2 ÷ 365 ≈ ₹142 (rate **[Verified — mirror]**; the portal's figure replaces the forecast); late-return fee 2 × ₹500 = ₹1,000, capped at the month's admin charges (**[Verified — mirror]**, §06.2); damages unpriced until `epf.damages_scale` is captured. At the ₹80–150 PEPM planning anchor (**[Hypothesis]**, EV-006) the monthly fee is ₹4,800–9,000, so a cap of even one month covers the interest and fee lines; the damages line, once priced, is where the cap can bind | A miss |
| As above, but the employer funded the challan on the 16th, and our warning reached it before the SS-3 point | Tenant-caused | No — exclusion 3 | DECLINED, with the warning's delivery timestamp as evidence | A miss; guardrail 2 records the penalty incidence with causation "not ours" |
| As above, but the warning reached the employer after the SS-3 point | Product-caused (SS-3) | Yes | ACCEPTED, as in row 1 | A miss |
| EPFO portal outage on the 15th; Mode C session could not complete | Authority-caused | No — exclusion 2 | DECLINED and disclosed; the instance is prepared for the next available window in the tenant's chosen mode (§05.9) | A miss — AC-8 keeps it in the raw rate |
| Mode A. The artefact was VALIDATED before the `sla.artefact_ready_lead[family]` point; the employer uploaded on the 16th | Tenant-caused — the Mode A promise, artefact readiness, was kept | No — exclusion 3 | No claim opens | A miss |
| Form 138 Q4 of Tax Year 2026-27, format unpublished | — | No — exclusion 1 (CARVED_OUT_FENCE, F-01) | None possible; the instance sits in the coverage-gap register (EV-046) | Not in the denominator |

- **AC-9** Whether an instance is covered, and if not which exclusion applies, is computable from the coverage-statement version, the FR-PAY-711 transition log and `miss_class` alone; two evaluators on the same day reach the same answer.
- **AC-10** A remedy can never exceed the cap in force. The computation stores the cap version, the monthly fee it used and the authority's charged figures it paid against.
- **AC-11** No SLA measure reads a delivery mode other than the one recorded on the filing (§23 FR-LEG-034 AC2); a Mode A filing never appears as operator-submitted.
- **AC-12** The SLA clause cites the tenant's coverage-statement version and each statement version names the SLA wording it implements; a paying tenant whose clause cites no version fails §05.20 R1X-04.

---

### 19.10 Leading vs lagging — the consolidated index

A single table the team reads weekly. Leading metrics are actionable *now*; lagging metrics are scorekeeping. The rule: **if a leading metric is red, act; if a lagging metric is red and the leading metrics were green, the model is wrong — revisit the tree.**

| Metric | Layer | Lead/Lag | Owner | Review cadence | Alert threshold |
| --- | --- | --- | --- | --- | --- |
| Activation Rate | Input | Leading | Onboarding/Product | Weekly | < 60% (Phase 1) |
| Time-to-First-Filing | Input | Leading | Onboarding | Weekly | median > 30 days |
| Migration Completeness | Input | Leading | Product/Implementation | Per onboarding | < 95% at first filing |
| Pre-Filing Validation Pass Rate | Process | Leading | Payroll Eng | Per run | any run-blocking fail |
| Payroll-Run Success Rate | Process | Leading | Payroll Eng | Per run | < 100% |
| AI Deflection Rate | Process | Leading | AI/Product | Weekly | < 40% (Phase 1) |
| Statutory-Change Lead Time | Process | Leading | Statutory team | Per change | SLA breach |
| **OTAF (north star)** | Output | **Both — the pivot** | Whole company | Weekly | MoM decline |
| On-Time Filing Rate | Output | Lagging | Payroll/Statutory | Weekly | < 99% (Phase 1, §19.12.1) |
| Filing-Integrity Rate | Output | Leading→Lagging | Payroll/Statutory | Weekly | < 97% (Phase 1 — the RFT-inclusive floor of §19.15; it cannot sit above the RFT target) |
| Product-Caused Miss Rate | Output | Lagging (SLA) | Statutory desk lead | Weekly | any product-caused miss is reviewed that week (§19.9.2) |
| On-Time Margin (p10) | Output | Leading | Payroll Eng | Weekly | p10 < 24h |
| Rejection / Correction Rate | Output | Leading | Payroll Eng | Per filing cycle | > 2% / > 3% (Phase 1 — the rejection target and the complement of the ≥ 97% RFT target, §19.12.1) |
| Penalty Incidence | Output | Lagging (harm) | Statutory/Support | Real-time alert | **any > 0 = Sev-1** |
| AI COGS per Account | Output | Leading (inference cost) | AI/Finance | Weekly | trending → ARPU |
| Model-Mix Ratio | Process | Leading (inference cost) | AI Eng | Weekly | frontier share ↑ |
| Supervised Minutes per Filing Cycle | Process | Leading (margin — the dominant COGS line, EV-088) | Compliance Ops (§22) / Finance | Per filing cycle | above `max_supervised_minutes_per_filing_cycle` (unsized, §20) |
| NRR / GRR | Outcome | Lagging | Finance/GTM | Monthly | NRR < 100% / GRR < 85% |
| Band-Crossing Rate | Outcome | Lagging | GTM | Monthly cohort | < 25% by mo-18 |
| Logo Retention | Outcome | Lagging | GTM/Success | Monthly cohort | 50–199 < 90% |
| CAC-Payback | Outcome | Lagging | GTM/Finance | Monthly | > 12 months |

**The escalation rule made concrete.** When Penalty Incidence goes > 0, it pages the statutory/support on-call in real time (it is the only real-time alert in the table) because it is the harm guardrail and every incident is a rupee number (§19.3.2). Every other threshold routes to its owner's weekly or monthly forum (§19.11.5). A leading metric breaching its threshold is a *this-week action*; a lagging metric breaching while leading metrics were green is a *model is wrong* signal that sends the team back to the tree (§19.2).

---

### 19.11 Instrumentation plan

Metrics are only as good as the events beneath them. This plan specifies the event taxonomy, the attribution requirement, the pipeline, and the governance — built so that **per-tenant/user/agent/model attribution exists from v1** (§13) and so that analytics itself meets the CERT-In Directions (EV-062) and the data-protection posture in §19.11.4.

#### 19.11.1 Event taxonomy (the minimum event set)

Every metric above traces to named events. The taxonomy is small on purpose; each event carries a stable schema so metrics recompute historically — within the limit set by bitemporality scoped by entity class (Part E-2, §14). Filing, rule and payroll events are statutory records and replayable. Events derived from **erasable** classes — punches, biometric templates, consent artefacts, rendered documents — are not: metrics over them are computed from aggregate counters kept after erasure, and a recompute after an erasure returns the aggregate, not the erased record. **[Reversed]** An earlier draft implied every metric could be recomputed from raw history (EV-K35).

| Event domain | Key events | Feeds |
| --- | --- | --- |
| **Filing lifecycle** | One event per §08 FR-PAY-711 transition: `filing.scheduled`, `filing.blocked` (with reason), `filing.generated`, `filing.validated`, `filing.submitted` (with who submitted and on whose authority, §22), `filing.rejected`, `filing.accepted`, `filing.revised`, `filing.supplementary`, `filing.payment_initiated`, `filing.filed`; plus the derived `filing.miss_classified` (instance, `miss_class`, root-cause reference — AC-7) and `filing.rft_settled` (the settlement step that resolves `right_first_time` when `rft_window_days` closes) | OTAF, integrity, rejection/correction, on-time, RFT, time-to-correct, on-time-margin, product-caused miss rate, coverage-gap register |
| **Coverage** | `coverage.versioned` (`tenant_id`, `version`, `trigger`, `lines_changed[]` — emitted by §05.21 on every coverage-statement version) | Filing Coverage, the coverage-gap register, the in-coverage denominator, SLA scope |
| **Supervised filing** | `ops.session_started`, `ops.session_ended` (operator, registration, filing type, delivery mode, active and wait minutes), `ops.minutes_logged` (reason-coded preparation and exception minutes against an instance) — the FR-OPS-010 meter feeding the §15.6.4 cost ledger | Supervised Minutes per Filing Cycle |
| **Penalty** | `penalty.exposure_opened`, `penalty.incurred`, `penalty.resolved` | Penalty incidence, harm guardrail |
| **SLA claims** | `sla.claim_opened`, `sla.claim_classified`, `sla.claim_declined`, `sla.claim_accepted`, `sla.claim_disputed`, `sla.claim_settled` — one per §19.9.2 transition | Claim incidence, remedy cap utilisation, dispute share |
| **Payroll** | `payroll.run_started`, `payroll.run_succeeded`, `payroll.run_failed`, `wagebase.computed` (both bases), `validation.failed` | Run success, pre-filing validation |
| **Onboarding/activation** | `signup`, `statutory_code.linked`, `migration.field_captured`, `first_filing.accepted`, `importer.used` | Activation funnel, TTFF, migration completeness, activation depth |
| **AI/inference** | `ai.request` (carrying the §13.9 attribution record), `ai.cache_event`, `ai.deflected`, `ai.budget_cap_hit` | AI COGS per account, per-class/model cost, deflection, rate-limit incidents, model-mix |
| **Commercial** | `subscription.created/upgraded/downgraded/churned` (+reason code), `seat.changed`, `module.attached`, `invoice.issued` | NRR/GRR, band-crossing, attach, CAC-payback |
| **Reliability** | `device.punch_received`, `device.integration_failed`, `statutory_rule.effective`, `uptime.probe` | Device success, statutory lead time, corrigendum-catch, uptime |

#### 19.11.2 Sample event schemas (the load-bearing two)

The two event families that the entire thesis depends on — filing lifecycle (proves OTAF) and AI inference (proves the unit economics) — carry these minimum schemas. They are illustrative shapes, not a chosen serialization:

```jsonc
// filing.filed — the FR-PAY-711 F15 transition; closes the "on_time" gate of OTAF
{
  "event": "filing.filed",
  "ts_utc": "2027-04-12T09:41:07Z",          // our record time, NIC/NPL NTP-synced (AC-1, EV-062)
  "authority_ts_utc": "2027-04-12T09:38:52Z",  // the portal's own receipt time — on-time is judged on this
  "tenant_id": "t_0xA3",
  "registration_id": "r_0x17",                 // filing instance = registration × obligation × period
  "instrument": "EPF_ECR",                     // EPF_ECR | ESI | PT | TDS_138 | FORM_130 (issuance) | LWF
  "state": null,                               // set only for state-specific instruments (PT/LWF)
  "period": "2027-03",                         // wage month / quarter the filing covers
  "coverage_statement_version": 7,             // version in force on the due date (§05.21)
  "coverage_state": "IN_SLA",                  // only IN_SLA instances enter OTAF and its denominator (§19.1)
  "return_type": "REGULAR",                    // REGULAR | SUPPLEMENTARY | REVISED (EV-037)
  "due_date": "2027-04-15",                    // effective-dated (AC-2)
  "due_date_rule_version": "epf.due.v3",       // AC-6: which rule judged on-time
  "on_time": true,
  "on_time_margin_hours": 62.3,                // due_date - authority_ts_utc (feeds §19.3.3)
  "rejected_attempts": 0,                      // any value above 0 fails gate 3
  "submission_mode": "employer",               // employer | operator_under_written_authority (§14.4.5)
  "delivery_mode": "A",                        // A | B | C | D (§22 FR-OPS-001); field proposed in §22.12 O19 —
                                               // until §14 adds it, read from the session log (FR-OPS-008)
  "submitted_by": "u_0x2C",                    // the acting user — the employer's user in Modes A and B
  "authority_to_act_document_id": null,        // required when submission_mode is operator_under_written_authority
  "computation_provenance": {                  // AC-5: no figure model-generated
    "wage_base_rule": "cow.s2y.v2",            // illustrative rule-version id
    "effective_date": "<rule object's effective_from>"  // copied from the rule object (§14), never typed in
  },
  "ack_ref": "TRRN-...",                       // §14.4.5 ack_ref: return file ID and challan TRRN for the ECR (EV-036)
  "right_first_time": null                     // resolved when rft_window_days closes
}

// ai.request — proves cost-per-account (the §13.9 attribution record, plus metric fields)
{
  "event": "ai.request",
  "ts_utc": "2027-04-12T09:40:55Z",
  "tenant_id": "t_0xA3",
  "user_id": "u_0x91",                         // priced per employee, consumed per user (§13)
  "task_class": "A1",                          // cost class A0–A6 (§13.3)
  "model": "gemini-2.5-flash-lite",            // for per-model cost + model-mix ratio
  "model_list_price_ref": "gemini-2.5-flash-lite@2026-09",  // list price the call was costed at (§13.9)
  "input_tokens": 4120,
  "output_tokens": 388,
  "cache_read": 0,                             // read-priced prefix caching where supported (§19.8.2)
  "cache_write": 0,
  "cost_inr": 0.0536,                          // (4,120 × $0.10 + 388 × $0.40) per 1M tokens × ₹94.43
  "fx_rate_at_call": 94.43,
  "residency_region": "in",                    // §13.10
  "escalated": false,
  "rules_fallback": false,
  "deflected": true,                           // resolved without human handoff
  "budget_cap_hit": false
}
```

The `right_first_time` field being resolved *later* (when the settlement window closes, §19.1.2) is why filing events must be immutable-append with a settlement step, not overwritten — otherwise historical OTAF cannot recompute (§19.14 rule 2).

#### 19.11.3 The attribution requirement (non-negotiable, from v1)

Every `ai.*` event **must** carry the §13.9 attribution record — `{tenant_id, user_id, task_class, model, model_list_price_ref, input_tokens, output_tokens, cache_read, cache_write, escalated, fx_rate_at_call, residency_region, rules_fallback}` — plus the metric fields `{cost_inr, deflected, budget_cap_hit}`. §13.9 owns the schema; this section consumes it. This is the §13 mandate: build cost attribution while AI is free, because retrofitting it after pricing exists is far harder. Without it, none of §19.8 is computable and the inference-cost thesis (§13) is unfalsifiable.

Similarly, every `filing.*` event carries `{tenant_id, registration_id, instrument, state, period, return_type, coverage_statement_version, coverage_state, due_date, due_date_rule_version, computation_provenance(rule_version, effective_date)}`, and `filing.submitted` and `filing.filed` also carry `{submission_mode, delivery_mode, submitted_by, authority_to_act_document_id}` — the §14.4.5 field names, with `delivery_mode` pending §22.12 O19 — so that on-time and RFT recompute correctly even after a due-date or rule change (AC-2, AC-5, AC-6) and every operator submission traces to a written authority to act (§22).

**Attribution completeness is itself a metric.** The share of `ai.*` events missing any required field, and the share of `filing.*` events missing provenance, are tracked as **instrumentation-coverage metrics** with a target of 100%. A metric computed on incomplete events is a §19.13 vanity risk; the coverage metric is what keeps the analytics honest from v1.

#### 19.11.4 Pipeline, tooling and residency

- **Event bus → warehouse → metrics layer.** Product events land on an append-only bus, stream to a warehouse, and are modelled into the metrics tree. Event logs are treated as ICT logs under the CERT-In Directions whether or not every event strictly is one: **retained at least 180 days within Indian jurisdiction**, with clock-sync to NIC/NPL NTP so every timestamp is authority-comparable (EV-062, §17; relevant for on-time proof, AC-1). LLM prompt and completion logs stay in India (Part E-7, §12.8.3).
- **Data-protection posture — two regimes, stated exactly.** **[Reversed]** An earlier draft stated DPDP s.7(i) — employment-purpose processing without consent — as the current basis for this pipeline (EV-K14). It is **not in force** until on or about 13 May 2027 (EV-058); when it commences it disapplies consent and notice for employment purposes only, and does not disapply the s.8 duties. **Today**, the SPDI Rules 2011 treat financial information and biometric information as sensitive personal data (r.3) and require **consent in writing before collection** (r.5(1)), and r.7 restricts cross-border transfer (EV-060). DPDP itself creates no sensitive category (s.2(t), EV-059). Either way, the product treats analytics as a purpose separate from payroll processing: **instrumentation separates statutory-processing events from product-analytics telemetry**; analytics runs on tenant- and cohort-level aggregates or pseudonymous identifiers, never on raw salary, bank-account or biometric fields, so no analytics event carries SPDI-sensitive data and none leaves India. Who owes the SPDI written-consent duty, and whether analytics needs a basis of its own, is under counsel review (Part D-4, §23).
- **Dashboards, three tiers:** (1) a **company north-star board** (OTAF + guardrails, weekly); (2) **operational boards** per layer/owner (§19.10); (3) a **per-tenant cost-and-health board** (AI COGS per account, filing integrity, penalty exposure, and for File-tier tenants the SLA claims and their evidence) — the same board that is the compliance-SLA evidence for the customer (§18.3, §19.9.2).
- **Self-serve buildability.** Because this is a PRD, not a build (per project constraint), no tooling is specified as chosen. The requirement is only that whatever is chosen supports per-tenant/user/agent/model attribution and effective-dated recomputation from day one.

#### 19.11.5 Review cadence and ownership

| Forum | Cadence | Looks at |
| --- | --- | --- |
| Filing-integrity standup | Weekly | OTAF, rate, rejections/corrections, on-time margin, any penalty exposure, product-caused misses and open SLA claims |
| Growth review | Weekly | Activation funnel, TTFF, acquisition funnels, CAC-payback |
| Unit-economics review | Weekly | AI COGS per account, per-model spend, model-mix, FX sensitivity, cap incidents, supervised minutes per filing cycle |
| Cohort/retention review | Monthly | NRR/GRR (decomposed), logo retention, band-crossing, churn reason-codes |
| Statutory-change review | Per change / weekly | Statutory-change lead time, corrigendum-catch rate, coverage-gap register |
| Metric-integrity audit | Quarterly | Are any metrics being gamed? (§19.13) Re-confirm definitions haven't drifted (§19.14) |

---

### 19.12 Targets per phase

Targets map to the §05.4 roadmap — **Phase 1** is v1 (files the beachhead, 20–200) and **Phase 2** is v2 (expansion into 200–1,999) — plus a **Phase 0** this section adds for month-zero foundations before the first paying customer; §05.4's Vision phase carries no metric targets yet. Against §05's release vocabulary (§05.17 PR-12): Phase 0 is R1 in PLANNED or IN_BUILD up to the pre-launch gate; Phase 1 runs from R1 RELEASED to the R3 gate; Phase 2 is v2. Where a §19 target is stricter than a §05.4 exit criterion (Phase-1 on-time ≥ 99% here against §05.4's ≥ 98% over a full quarter), §05.4's figure is the gate that opens the next phase and §19's is the operating target and the bar for selling the compliance SLA (§19.15). Per §02's discipline, **every target below is a [Hypothesis] until a cohort reports it** — they are planning anchors with kill criteria, not commitments, and they inherit the optimism-bias haircut.

#### 19.12.1 North-star and quality targets

| Metric | Phase 0 (found.) | Phase 1 (v1 beachhead) | Phase 2 (expansion) |
| --- | --- | --- | --- |
| OTAF (monthly) | Instrumented; internal test artefacts through the published validators (gates 2–4 need live filings) | Growing MoM; first real customer filings | Compounding with band-crossing + new tenants |
| **On-Time Filing Rate** | n/a (no live filings) | **≥ 99%** | **≥ 99.5%** |
| **First-Time-Right Rate** | n/a | **≥ 97%** | **≥ 99%** |
| Rejection Rate | n/a | ≤ 2% | ≤ 1% |
| **Penalty Incidence** | 0 | **0** (any penalty = Sev-1) | **0** |
| On-Time Margin (p10) | n/a | ≥ 24h before deadline | ≥ 48h before deadline |
| Filing Coverage | ECR Regular, Supplementary and Revised (EV-035–037; arrear return fenced, EV-043); ESI computation, with the upload only once its template is captured (F-05, §05.18) and post-cliff periods BLOCKED (§06.13); Form 138 Q1–Q3 (EV-051, EV-052); PT only for states whose slabs are gazette-verified and whose due day is captured (§06.11, §06.13). Each family enters IN_SLA only after its own PL-01 evidence (§05.8) | + Form 138 Q4 and Tax Year 2026-27 Form 130 distribution once the Q4 format is published (F-01; EV-046, EV-048); PT/LWF states as §20 V-09 verifies them | Multi-state PT/LWF near-complete |
| Corrigendum-Catch Rate | watcher tested retrospectively | ≥ 95% | 100% |

**Note on Filing Coverage, Phase 1.** The **Form 138 Q4 regular and correction formats are unpublished** (re-checked September 2026), and the missing Q4 Annexure II blocks the annual salary certificate — Form 130, which TRACES alone generates (EV-046, EV-048). So Form 130 coverage is *gated on an external event*, not on our velocity. This is why coverage is tracked separately from the integrity rate (guardrail 3, §19.1): we must not appear to "improve quality" merely because Form 130 isn't yet in the denominator. **[Verified]** the Q4 format gap and the Form 130 dependency (EV-046, EV-048).

#### 19.12.2 Growth, retention and economics targets

| Metric | Phase 0 | Phase 1 (v1) | Phase 2 |
| --- | --- | --- | --- |
| Activation Rate (→ first accepted filing) | design-partner cohort | ≥ 60% | ≥ 75% |
| Time-to-First-Filing (median) | measured | ≤ 30 days | ≤ 14 days |
| Migration Completeness (pre-first-filing) | 100% (manual) | ≥ 95% via importers | ≥ 98% |
| GRR | n/a | ≥ 85% | ≥ 90% |
| NRR | n/a | ≥ 100% | ≥ 110% |
| Band-Crossing (20–49 → 50+, 12-mo) | n/a | measured (kill-gate ≥ 25% by mo-18) | ≥ 30% |
| CAC-Payback (blended) | n/a | ≤ 12 months | ≤ 9 months |
| **AI COGS per Account** | measured on prototype (§20 V-04) | << ARPU; measured value replaces the ₹0.15–3.27 PEPM placeholder band **[Hypothesis]** (EV-008) | stable/declining as routing matures |
| **Supervised Minutes per Filing Cycle** | measured on design-partner filings | ≤ `max_supervised_minutes_per_filing_cycle` (unsized; §22.7 formula, §20 V-26) | declining as automation matures |
| AI Deflection Rate | baseline | ≥ 40% of eligible queries | ≥ 60% |
| Instrumentation coverage (events with full attribution) | 100% by the Phase-1 gate (§19.12.3; §05.17 C-27) | 100% | 100% |

#### 19.12.3 Phase gates — what each phase must prove before the next

Targets are only useful if a *gate* attaches to them. The phase gate is the minimum set that must hold before spending the next phase's money:

| Gate into… | Must have proven | If not proven |
| --- | --- | --- |
| **Phase 1** (start selling) | Instrumentation live with 100% attribution; internal test artefacts pass gate 1 and every published validator — the FVU for Form 138 (EV-052) and the EV-035/EV-040 format and severity checks for the ECR — since gates 2–4 can only be proven on live filings; corrigendum-watcher validated retrospectively (§19.9); operator submission offered only once counsel clears Part D-17 (§23); the §19.9.2 SLA wording signed off (§05.8 PL-05), and each artefact family sold under it only after its own PL-01 evidence (§05.8) | Do not onboard paying tenants — you cannot yet prove OTAF or its cost |
| **Phase 2** (expand to 200–1,999) | §05.4's v1 exit criteria, measured by this section: every v1 artefact authority-validated and submitted for ≥ 40 paying tenants across ≥ 1 full statutory cycle; On-Time Filing Rate ≥ 98% over a full quarter with every miss root-caused; Corrigendum-Catch proven on ≥ 1 real in-flight change; all four COGS lines instrumented — AI COGS per account measured at real tokens, supervised minutes per filing cycle measured against `max_supervised_minutes_per_filing_cycle`; ≥ 10 mid-year migrations with continuity intact. Separately, the SLA-sale bar: On-Time ≥ 99% + zero penalty over **≥ 2 quarters** (§19.15). The 20–49 band-crossing reading (≥ 25% by month 18) is a §05.1 kill-gate on the lower half, not a v2 gate | Fix the failing gate before expansion spend; until the SLA-sale bar holds, the compliance-SLA (§18) is not yet earned |

**[Hypothesis]** All Phase-1/Phase-2 targets. Consolidated kill/validation criteria:
- **On-time <99% or any penalty incidence >0 in Phase 1** → the compliance-SLA positioning (§18) is not yet earned; do not sell the SLA until the rate is proven over ≥2 quarters.
- **Activation <60%** → the onboarding/migration surface (§18) is under-built; re-prioritise migration before acquisition spend.
- **Band-crossing <25% by month 18** → stop acquiring 20–49; raise floor to 50 (§05 kill criterion).
- **AI COGS per account trending toward ARPU** → §20 V-04's 5×-token risk has materialised; re-point router, re-open metered-AI pricing, or move the beachhead floor up.
- **Supervised minutes per filing cycle above `max_supervised_minutes_per_filing_cycle`** → the dominant COGS line is out of bounds (EV-088); the registration cap or multi-registration line in §18 becomes mandatory and the floor is re-tested (§05.1).
- **NRR <100% in Phase 1** → value is delivered (if OTAF healthy) but not monetised/perceived; pricing/positioning problem, not product.
- **CAC-payback >12 months on 20–49** → self-serve is not converting off the price card (§18); raise the floor or fix the importer funnel before more spend.

---

### 19.13 Anti-metrics — vanity numbers banned from every dashboard and deck

§20.4 keeps a banned-numbers list to stop retracted figures from re-entering a model. This section keeps the metrics equivalent: **numbers that go up whether or not a customer got a filing done, and therefore must never headline a review or a board deck.**

| Banned as a headline metric | Why it's a vanity metric | What to use instead |
| --- | --- | --- |
| Total signups / registered accounts | Registered ≠ activated ≠ filing; §04 already shows registered-vs-contributing establishments inflate by ~3× — the same trap applies to our own funnel | Activation Rate (→ first accepted filing) |
| Payslips generated | The whole thesis is that the payslip isn't the unit of delivery; a spreadsheet generates payslips too | OTAF |
| AI messages / tokens processed | Usage is COGS, not value; more tokens can mean *worse* deflection | Deflection Rate + AI COGS per account |
| Blended "compliance %" | Hides which instrument/state is failing — exactly where penalties originate | Per-instrument on-time + RFT rates |
| Logins / DAU / MAU | Engagement without filing is not value; a well-run payroll product is used *rarely and successfully* | Filing-Cohort Retention |
| Bundled-AI "adoption" as revenue | HR AI's market price is zero (§13.1); bundled usage is not expansion | Metered-AI SKU revenue only |
| "Gross margin" computed on inference alone | **[Reversed]** the 93–99% figure: a margin on the smallest of four COGS lines, while the dominant line — supervised filing — is unsized (EV-K13, EV-088, §13) | Inference Share of Revenue + Supervised Minutes per Filing Cycle (§19.8) |
| "Filings we submitted" as a headline | Submission is attended and, where our operator acts, under the employer's written authority; liability stays with the employer (EV-K24). A submission count is not delivery | OTAF (FILED, accepted first time, right-first-time) |
| GMV / money-moved (if benefits attach ships) | §11: attach is distribution rent, not software; blending it flatters software economics | Attach revenue as a *separate, never-blended* line |
| Registered PF codes as reachable market | §04 [Killed]: 3× overstatement vs contributing establishments | Contributing-establishment denominators only |
| Cache hit rate | §13.11: a hit rate can rise while a held, storage-hour-priced cache costs over 100× the no-cache input price (§19.8.2); hits are not savings | Cache Effectiveness (net ₹ savings) |
| NRR reported without decomposition | A single NRR number throws away which engine moved (§19.6.1) | NRR + its decomposition, always together |
| Device-integration success assumed at 85–98% | §20.4 [Killed] (EV-K03): marketing from the vendor selling the fix; must be measured from our own fleet | Measured Device Integration Success Rate |

**[Killed]/[Verified]** The registered-vs-contributing and payslip-vs-filing distinctions, the HR-AI-price-is-zero fact, the attach-is-distribution-not-software finding, and the banned 85–98% device figure are all established PRD conclusions carried forward here as metric-hygiene rules (Source: PRD §04, §11, §13.1, §20).

---

### 19.14 Metric governance and confidence

Three governance rules close the section, each inherited from the document's own methodology (§02):

1. **A target is a [Hypothesis] until a cohort reports it.** Every number in §19.12 carries the optimism-bias haircut §02 mandates. When a metric graduates to [Verified] (measured over ≥2 cohorts), record the date and the measured value, exactly as §02 requires for any claim promotion.
2. **Definitions are versioned and effective-dated, like the statutory rules.** If "activated" or "on-time" is redefined, historical metrics recompute under the definition in force for the period — the same effective-dating discipline the wage engine uses (§08). A metric whose definition silently drifts is worse than no metric.
3. **The metric-integrity audit (quarterly) asks one question:** is any metric going up while customer value is flat? If OTAF rises but penalty incidence or churn also rises, the north star is being gamed and the audit halts the celebration. This is the §02 bias-check applied to our own scoreboard.

#### 19.14.1 The metric-definition register

Every metric in §19 has a registry entry with these fields, so that "on-time" or "activated" cannot silently drift:

| Field | Purpose |
| --- | --- |
| `metric_id`, `definition_version`, `effective_from` | Effective-dating (rule 2) — historical recompute under the version in force |
| `numerator`, `denominator`, `filters` | The exact computation, so two teams cannot compute it two ways |
| `source_events` | Which §19.11 events feed it — a metric with no event source is not shippable |
| `source_table` | The entity or ledger the events are modelled into (§14, §15.6.4, §05.21), so a disputed figure can be re-derived from rows |
| `target`, `target_judged_from` | The phase target (§19.12) and the point from which it is judged — a release gate or cohort age, never an undated "eventually" |
| `confidence` | [Verified] / [Hypothesis] / [Killed], per §02 |
| `kill_criterion` | For every [Hypothesis] metric-target, the condition that retires or demotes it |
| `owner`, `review_forum` | Who acts when it breaches (§19.10, §19.11.5) |

A metric proposed for a dashboard without a complete registry entry is rejected — this is how §02's provenance discipline is enforced on our own scoreboard rather than only on external claims.

#### 19.14.2 Metric confidence at time of writing

| Metric family | Confidence | Basis / what would promote it |
| --- | --- | --- |
| OTAF definition & four gates | [Verified] as a *definition* | Computed off the §08 FR-PAY-711 state machine; the *targets* remain [Hypothesis] |
| Statutory due-dates & penalty formulas | Mandatory auto-calculated EPF interest, Form 138 and Form 130 due dates and Karnataka's LWF due date [Verified] (EV-039, EV-049; r.215(1); §06.8); the 12% EPF/ESI interest rate [Verified — mirror] (S.O. 2698(E), §06.2) — pull from the primary source before customer use | EPF/ESI damages scales, the 1961-Act TDS fee, fee cap and penalty amounts (parameters in §06.5), their 2025-Act equivalents, and every other PT/LWF date [Hypothesis] — §06.13, §20 V-09 |
| 52.7× model-cost spread | [Verified] | Ratio of USD prices, survives FX (EV-007, EV-089) |
| Absolute AI COGS PEPM (₹0.15–3.27) | [Hypothesis] | Promote when §20 V-04 / V-14 instrument real tokens-per-query |
| Supervised minutes per filing cycle | Unsized | Measured from the first design-partner filings (§22 FR-OPS-010); target by the §22.7 formula, routed to §20 V-26 |
| Compliance SLA terms (§19.9.2) | [Hypothesis]; counsel-gated | Promote the wording on PL-05 sign-off; the remedy cap on §20's pricing validation (V-07, V-16) |
| All Phase-1/2 targets | [Hypothesis] | Promote per-metric when a cohort reports over ≥2 quarters |
| Band-crossing ≥25% | [Hypothesis] | Kill-gated at month 18 (§05.1) |
| CA channel as net-positive | [Hypothesis] | Gated on §20 V-05 |

#### 19.14.3 The metric catalogue — numerator, denominator, source table, target, and when it is judged

The register's first entries, one row per metric this section defines. "In-coverage" is §19.1's (IN_SLA on the due date); "Filing" is the §14.4.5 entity with its FR-PAY-711 transition log. No calendar date is set for any target, because no release date is evidenced: each target is judged from a named gate or cohort age. Every target is **[Hypothesis]** (§19.14 rule 1). §03.14's persona success measures are adopted as persona-level views of these rows, computed exactly as §03.14 defines them.

| Metric | Numerator | Denominator | Source table · events | Phase-1 target | Judged from |
| --- | --- | --- | --- | --- | --- |
| OTAF | In-coverage instances passing gates 1–4 (§19.1) | — (count per month) | Filing; coverage statement (§05.21) · `filing.*`, `coverage.versioned` | Growing month on month | First month after R1 RELEASED |
| Filing-Integrity Rate | OTAF | In-coverage instances due | As OTAF | ≥ 97% (§19.15) | First full quarter after R1 RELEASED |
| On-Time Filing Rate | In-coverage instances with `on_time(f)` (§01) | In-coverage instances due | Filing; Challan (§14.4.6) · `filing.filed` | ≥ 99% | First full quarter after R1 RELEASED — the window §05.8 V1X-03 reads |
| First-Time-Right Rate | FILED instances with no REVISED or SUPPLEMENTARY inside `rft_window_days` | FILED instances whose window has closed | Filing · `filing.revised`, `filing.supplementary`, `filing.rft_settled` | ≥ 97% | First quarter whose windows have all closed |
| Rejection Rate | Instances whose first SUBMITTED went to REJECTED, per artefact and FR-PAY-713 family | Instances submitted | Filing · `filing.submitted`, `filing.rejected` | ≤ 2% | First full quarter after R1 RELEASED |
| Correction/Revision Rate | Instances with a REVISED or SUPPLEMENTARY transition | Instances ACCEPTED or FILED | Filing · `filing.revised`, `filing.supplementary` | ≤ 3% (complement of the RFT target) | As RFT |
| Product-Caused Miss Rate | In-coverage misses with `miss_class` = product-caused | In-coverage instances due | Filing · `filing.miss_classified` | → 0% | First full quarter after R1 RELEASED; DG-2b for the 200–999 band |
| Late-Warning Share | Tenant-side blockers warned after the SS-3 point | Tenant-side blockers warned | Filing; notice records · warning-delivery events | → 0% | First full quarter after R1 RELEASED |
| Artefact Readiness Rate | Mode A and B in-coverage instances VALIDATED by `sla.artefact_ready_lead[family]` | Mode A and B in-coverage instances whose month LOCKED by the SS-3 point | Filing; PayRun (§14.4.4) · `filing.validated`, payroll-month transitions | → 100% | First full quarter after R1 RELEASED |
| Penalty Incidence | Charges on covered filings, count and ₹, with causation flag | — (count; ₹) and per tenant-month | Penalty-exposure record (AC-3) · `penalty.*` | 0 | From the first live filing |
| Filing Coverage | Instrument-states IN_SLA across the customer base | Applicable instrument-states, TENANT_SELF_FILES excluded (§05.21) | Coverage statement · `coverage.versioned` | Rising release by release (§19.12.1) | Each release gate (§05.20) |
| Pre-Filing Validation Pass Rate | Payroll months clearing every blocking validation (FR-PAY-1004) before submission | Payroll months processed | PayRun · `validation.failed`, payroll-month transitions | → 100% | First run after R1 RELEASED |
| Time-to-Correct | Median hours, REJECTED or error detected → corrected instance ACCEPTED | — | Filing · `filing.rejected`, `filing.accepted` | Minimise; no target | First full quarter |
| On-Time Margin (p10) | Hours between the authority timestamp and the deadline, 10th percentile | — | Filing · `filing.filed` | ≥ 24h | First full quarter |
| Activation Rate | Tenants reaching a first accepted filing | Tenants onboarded | Tenant; Filing · `signup`, `first_filing.accepted` | ≥ 60% | First onboarding cohort after R1 RELEASED, at cohort age of one full filing cycle |
| Activation Depth | Distinct instruments a tenant has filed at least once | — (per tenant) | Filing · `filing.filed` | Trend; no target | As activation |
| Time-to-First-Filing | Median days, signup → first accepted filing | — | Tenant; Filing · `signup`, `first_filing.accepted` | ≤ 30 days | As activation |
| Migration Completeness | Required opening-balance heads captured | Required heads | Migration / opening-balance entities (§14.4.10) · `migration.field_captured` | ≥ 95% at first filing | Each migration |
| Statutory-Registration Linkage | Tenants with PF, ESI, PT and TAN registrations captured and validated | Tenants onboarded | Registration (§14.2) · `statutory_code.linked` | → 100% | As activation |
| Payroll-Run Success Rate | As §19.9 | As §19.9 | PayRun · `payroll.run_*` | → 100% | First run after R1 RELEASED; DG-3d over two quarters |
| Statutory-Change Lead Time | Days, notification or corrigendum → rule live and effective-dated | — (per change) | Rule-version registry; pipeline log (FR-RULE-003, FR-RULE-016) · `statutory_rule.effective` | Minimise; SLA-bound | Every change from the Phase-1 gate |
| Corrigendum-Catch Rate | Amendments and corrigenda caught | Amendments and corrigenda that occurred, audited retrospectively | Pipeline log · `statutory_rule.effective` | ≥ 95% | Retrospective replay at the Phase-1 gate; first real in-flight catch (V1X-05) |
| Device Integration Success Rate | Configured terminals pushing punches | Configured terminals | Device enrolment ledger (§09) · `device.*` | Measure; no assumed figure (EV-K03) | First pilot fleet (§20 V-10) |
| Windowed Availability | Successful requests, per window | Requests, per window | Load-balancer SLI (§17 NFR-AVAIL-801) · `uptime.probe` | §17's, **[Hypothesis]** | From R1 RELEASED |
| Supervised Minutes per Filing Cycle | FR-OPS-010 minutes per registration × filing type × cycle | — | Cost ledger (§15.6.4) · `ops.*` | ≤ `max_supervised_minutes_per_filing_cycle` | First design-partner quarter (§20 V-26) |
| AI COGS PEPM | Inference and cache spend | Active employees, per tenant | Cost ledger · `ai.request` | Measured value replaces the placeholder band | From v1 instrumentation (§20 V-04, V-14) |
| Inference Share of Revenue | Inference spend per tenant | Tenant revenue | Cost ledger; invoices · `ai.request`, `invoice.issued` | Investigate above ~5% (§13.9) | From the first invoice |
| Deflection Rate | Eligible queries resolved without a human | Eligible queries | `ai.request` (`deflected`); ticket events | ≥ 40% | From v1 instrumentation |
| Abstention Rate | Abstentions routed as gaps, per use case | Eligible queries, per use case | `ai.request`; §12 abstention records | Trend; no target | From v1 instrumentation |
| Model-Mix Ratio | Inference spend by tier | Total inference spend | Cost ledger · `ai.request` | Frontier share not rising without a measured deflection lift | From v1 instrumentation |
| Instrumentation coverage | Events carrying every required field | Events emitted, per family | Event bus · all | 100% | Phase-1 gate |
| GRR | Recurring revenue retained, ex-expansion | Starting recurring revenue | Invoices (§18.13) · `subscription.*` | ≥ 85% | Month 12 of the first paying cohort |
| NRR | Retained + expansion, decomposed (§19.6.1) | Starting recurring revenue | Invoices · `subscription.*`, `seat.changed`, `module.attached` | ≥ 100% | Month 12 of the first paying cohort |
| Logo Retention | Tenants retained | Starting tenants, per band | Tenant; invoices · `subscription.churned` | Kill line 85% for 50–199 (§19.5.1) | Month 12 of the first paying cohort |
| Filing-Cohort Retention | Tenants still filing at month N | Tenants with at least one OTAF instance in month 0 | Filing; Tenant · `filing.filed` | Flattening curve (§19.5.1) | Month 12 of the first filing cohort |
| Band-Crossing Rate | 20–49 tenants crossing into 50+ within 12 months | 20–49 tenants landed | `band_history` (§05.11) · `seat.changed` | Measured; kill gate ≥ 25% | Month 18 (§05.1) |
| CAC-Payback | Months, CAC ÷ monthly revenue, before COGS until `gm_blended` is sized | — (per band, per channel) | Invoices; acquisition spend ledger | ≤ 12 months | Two quarters after R1 RELEASED |
| Claim Incidence; Remedy Cap Utilisation; Claim Dispute Share | As §19.9.2 | As §19.9.2 | SLA claim records · `sla.*` | 0; trend; trend | From the first File-tier invoice |

---

### 19.15 The one measurement that validates the thesis

Everything above serves a single falsifiable claim. **The one measurement that validates the entire product thesis:** sustained **On-Time Filing Rate ≥ 99% with zero penalty incidence across ≥2 quarters** on real beachhead tenants, with the **Filing-Integrity Rate (RFT-inclusive) ≥ 97%** over the same window so that "on-time" is not being bought with silent corrections.

Until that number exists, "the filing is the unit of delivery" is the most important [Hypothesis] in this document — and every other metric here is instrumentation in service of proving or killing it. Concretely, the thesis is **confirmed** when:

- On-Time ≥ 99% **and** Penalty Incidence = 0 **and** RFT ≥ 97%, each for ≥ 2 consecutive quarters, on at least `thesis_min_cohort_tenants` real paying tenants (a named parameter — no value is set here; routed to §20, and never below §05.4's v1 exit cohort of 40); **and**
- Filing-Cohort Retention flattens with tenure (§19.5.1), evidencing that delivery creates switching cost; **and**
- AI COGS per account, measured at real tokens (not the §13 estimate), stays << ARPU under the FX base case (₹94.43, Gemini 3.x Flash 2× — EV-089); **and** supervised minutes per filing cycle, the dominant COGS line, hold at or below `max_supervised_minutes_per_filing_cycle` (EV-088).

And the thesis is **killed or downgraded** if, after 2 quarters of live filing:
- On-Time cannot hold 99% or any penalty incidence recurs → the compliance-SLA (§18) is unsellable and the differentiation-vs-Zoho/Tally case (§18) collapses to parity; **or**
- OTAF is healthy but NRR < 100% and retention does not flatten → filings are a delivery unit but not a moat, and the business case must be rebuilt on a different retention mechanism; **or**
- AI COGS at real tokens trends toward ARPU (§20 V-04 5× risk) → free-bundling breaks and the beachhead floor moves up; **or**
- supervised minutes per registration cannot be held to the target → the attended-filing delivery model is a services business at this price, and §18's registration line and §05's floor are re-opened.

This is the §02 bias-check applied to the whole product: the scoreboard is designed so that the thesis can *lose*. A metrics section that cannot report the product's own failure is the vanity trap §19.13 exists to prevent.
