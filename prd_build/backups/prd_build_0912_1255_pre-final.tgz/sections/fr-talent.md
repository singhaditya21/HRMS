## 10. Functional Requirements — Talent (Recruiting & Performance)

Talent is the **wedge, not the spine**. The spine is the statutory filing (§06, §08); recruiting and performance are the modules that widen the surface a customer sees every week and that create the *records* the payroll engine later consumes — a new hire's UAN, a revised CTC from an appraisal, an appointment letter in the state-prescribed form. This section specifies those modules as numbered functional requirements, and it does two things the rest of the PRD demands of it:

1. **It respects the zero anchor for AI (§12, §18.5) — and the market's paywall for talent modules.** The market price of talent *AI* is zero: 15Five includes its AI features in its $11 Perform tier and Culture Amp includes AI Coach in every band (pricing pages read, not executed; research round r2 — r2/07, which records no capture date, so re-capture before any external use), and greytHR's NAVOS assistant is "included in every plan" (claim posture, not tested — EV-090). **[Verified]** The talent *modules* are not free: every tiered Indian vendor gates performance and recruitment upward (EV-028), and greytHR sells its Performance Management System as a ₹35–45/user/month add-on from its Growth tier and Recruit at ₹2,500/recruiter/month (pricing page captured 4 Sep 2026, read not executed — research r1/01, r1/08). **[Reversed]** Earlier drafts said performance must be bundled because the market prices it at zero; EV-028 shows the market charges for it. Performance still carries no per-unit meter here, for a different reason — talent add-ons are the market's most predictable source of bill shock, and removing that shock is a wedge (research r1/01) — and which plan tier carries it is §18's decision. Recruiting is monetised only where the unit of value is legibly incremental — **per requisition or per hire, metered separately from PEPM** because recruiting cost does not track headcount (§13). Every FR below carries a monetisation marker, and the deferred ones are consolidated in §10.12.
2. **It respects the hard external dependency.** A new entrant can build recruiting in India, but *inbound only*: Info Edge owns the passive-candidate graph (Resdex), has published no path for a third-party ATS to search it that we are aware of as of September 2026, and markets in-ATS Resdex search as exclusive to its own ATS (§10.1; §16). This is not a footnote — it is the single fact that shapes the entire recruiting architecture, so it leads the section (§10.1) before any FR is written.

<!-- DIAGRAM: talent-module-map -->

### 10.0 Scope, phasing, and how to read these FRs

Talent does **not** ship in v1. v1 is the statutory beachhead (§05). But one talent surface is a v1 dependency and cannot wait: **onboarding handoff** (§10.8), because it issues the appointment letter — which OSH Code s.6(1)(f) requires of an establishment of ten or more workers, in the form the appropriate Government prescribes (EV-057; §06.1) **[Verified — central-sphere text]** — and because the onboarding step is what creates UAN/ESI-IP continuity that the payroll engine needs. **[Reversed]** Earlier drafts called the letter a statutory artefact "from employee one" in a single notified format; the duty attaches at ten workers and the form is state-sphere. So the phasing is:

| Phase | Talent scope | Rationale |
| --- | --- | --- |
| **v1** | Onboarding handoff only (§10.8), as the terminal step of the core-HR record-creation flow | Statutory: appointment letter (state-prescribed form, establishments of 10+ workers), UAN linkage and ESI IP registration, the EPF and ESI joining declarations and nominations, previous-employer income for TDS (Form 122, ex-12B). Not "recruiting" — it is record creation the payroll engine already needs. |
| **v1.5** | Recruiting: requisitions, job-board multi-post, candidate pipeline/ATS core, offer management | The talent wedge proper. Ships once the beachhead payroll is stable and the onboarding handoff exists to receive hires. Metered/deferred monetisation. |
| **v2** | Performance: goals/KRAs, review cycles, calibration, increment/promotion → payroll feedback loop; recruiting depth (referrals, BGV, interview kits) | No per-unit meter; tier placement per §18 (point 1 above). The increment→CTC→effective-dated-retro loop (§10.10) is the reason performance is genuinely valuable *to a payroll product* and not just table stakes. |

**How these phases map onto §05's release plan.** §05 phases the product as v1 (releases R1, R2, R3), v2 and Vision; "v1.5" is this section's label, not a §05 phase. The mapping: **v1** here is the onboarding set inside §05's R1 (Form 122 intake is register row A-10 and the appointment letter row A-19, both R1); **v1.5** is recruiting "bring your own job-board contract", which §05.5 lists as item 19 (P1) and so ships no earlier than R2, after the statutory R1 list; the recruiting *price* stays at zero until §05's v2 turns on metered SKUs (item 25), which is why FR-T-X01 counts events "while the price may still be zero"; **v2** here is performance, §05.5 item 26 (v2). Where this section and §05 disagree on timing, §05 governs.

<!-- DIAGRAM: talent-phasing-lane -->

**FR identifier scheme.** Talent FRs are numbered `FR-T-<area><nn>`:

| Prefix | Area |
| --- | --- |
| `FR-T-R` | Recruiting (requisitions, distribution, pipeline, offer, sourcing) |
| `FR-T-O` | Onboarding handoff |
| `FR-T-P` | Performance (goals, reviews, feedback, calibration) |
| `FR-T-X` | Cross-cutting (metering, consent, audit, AI rails) |
| `FR-T-D` | Discrimination defensibility — AI-influenced decisions, protected-attribute bar, EOP, records and complaint workflows (§10.13b; three-digit IDs, `FR-T-D###`) |

**Column legend used in every FR table below:**

- **Pri** — `P0` (module cannot ship without it), `P1` (module is materially incomplete without it), `P2` (fast-follow). Pri is **module-relative**: §05 reserves "P0" at product level for the R1 release list, and of the FRs here only the v1 onboarding set (FR-T-O01–O07, O10) falls inside R1. A `P0` on a v1.5 or v2 FR means "the module's release cannot ship without it", never an R1 commitment.
- **Phase** — `v1` / `v1.5` / `v2` per the table above.
- **Money** — `Bundled` (no per-unit meter; included in whichever plan tier §18 assigns — onboarding sits in the entry tier with payroll, EV-028), `Metered` (billed per requisition/hire/seat — see §10.12), `Free-acq` (deliberately free as acquisition infrastructure), `—` (not a billable surface).
- **Conf** — `[Verified]` / `[Hypothesis]` / `[Killed]` per the standing rule (§02). Hypotheses carry a kill/validation criterion.

**On Hypotheses:** every FR marked `[Hypothesis]` carries a kill/validation criterion. Where the criterion is load-bearing it is stated inline in the FR's section; the rest are consolidated in the **Hypothesis ledger (§10.16)** so no `[Hypothesis]` marker in this section is orphaned. Two kinds of Hypothesis appear: *demand* hypotheses (does the beachhead want this feature — default-safe response is "defer, don't build ahead of demand") and *mechanism* hypotheses (does a compliant technical/legal path exist — default-safe response is "don't build until a gazette/portal citation confirms it"). The ledger tags which is which.

Acceptance criteria are written as **Given / When / Then** and appear either inline in the FR row or, for the load-bearing flows, as a dedicated block. §10.13 consolidates the cross-cutting acceptance criteria that no single FR owns. Every value this section does not state — because neither the evidence register nor the research gives it — is a backticked named configuration parameter, and §10.17 registers each one with its §20 route, owner and behaviour while unset.

---

### 10.1 Recruiting — the external-dependency map (the constraint that writes the architecture)

Before a single recruiting FR, state the wall plainly, because it determines which FRs are even buildable.

<!-- DIAGRAM: recruiting-integration-topology -->

**[Verified]** Info Edge owns the passive-candidate graph, and we are not aware of any published licensing path for it as of September 2026. Resdex — the resume-database *search* product recruiters actually buy — is available inside an ATS **only through Info Edge's own ATS (Zwayam), which markets this as an exclusive** ("The only platform with in-built Naukri RESDEX" — zwayam.com, re-fetched in research round r2, r2/08 finding 4). That is the incumbent's own marketing, not a statement of licensing terms: strong evidence, not proof, that no third party can licence Resdex, so one business-development conversation with Info Edge precedes roadmap freeze (§20). What a third-party ATS gets against a customer's own Naukri contract is **job posting plus application sync — never database search**, corroborated across four independent ATS vendors including Keka (r2/08 finding 5). All vendor pages in this paragraph were read, not executed, and round r2 records no capture date for them, so each is re-captured with a date before any external use (§21). We found no Naukri developer API, self-serve key or partner documentation, and are not aware of any as of September 2026: its recruiter support corpus has no API, integration or developer folder, and its "ATS integration" page is a 2015 image stub (r2/08 findings 6–7).

**[Verified]** Right-size the moat, do not inflate it. Naukri's "118M" is an investor metric for *total resumes ever* (118 million as of 30 June 2026); Resdex, the product recruiters buy, is described by Naukri's own FAQ as **"over 50 million profiles"** (EV-020; r2/08 findings 1–2). Do not quote 118M in any collateral.

**[Verified]** LinkedIn is the exception — the one large passive graph with a documented, certifiable partner path: **Recruiter System Connect (RSC)**, **Apply Connect**, CRM Connect and the **Job Posting API**, all on LinkedIn's Middleware Platform (Microsoft Learn documentation dated 1 April 2026, read not executed — r2/08 finding 16). Four conditions travel with it: approval by LinkedIn and a signed API agreement with data restrictions; the customer holding a Recruiter licence; LinkedIn's sequencing rule that the Job Posting integration is built before RSC; and per-module certification demoed to LinkedIn. Profile data enters the ATS by recruiter-initiated one-click export, never bulk search. This is the integration to do properly and early, with the approval and certification time on the v1.5 plan.

**[Verified]** Scraping is forbidden, in architecture and in collateral. The only working Resdex extraction found copies an authenticated request out of a live Resdex session (a third-party scraper listing with five monthly users — r2/08 finding 18); it is legal exposure for us *and* for the customer (§16; §23). No FR below may be satisfied by scraping any candidate database.

**The consequence for the product**, restated as a design invariant that governs §10.2–§10.7:

> We build a **bring-your-own-contract, inbound-only ATS**. The customer holds the Naukri / LinkedIn / foundit / apna / Indeed contracts; we fan a requisition *out* to those boards and ingest applications *back*, deduplicating across sources. We never resell, proxy, or search a third party's candidate database. Outbound sourcing beyond LinkedIn RSC is out of scope until a licensed path exists.

**[Hypothesis]** The India board mix a 20–200 employer actually uses splits by collar: **Naukri + LinkedIn + foundit + Indeed** for white-collar/desk roles; **apna + WorkIndia + Indeed** for blue/grey-collar and frontline roles (which matters directly for the deskless segment in §09). *Kill/validate:* a board-usage question added to the §20 buyer research (V-07 already samples 30–40 buyers across 20–200 and 200–1,000; §10.15 T-1); if fewer than 3 boards are used by the median beachhead employer, cut the multi-post connector matrix to the top 2 and treat the rest as CSV/email fallback.

---

### 10.1a The talent data model (so the FRs below are unambiguous)

The FRs reference a small set of entities; naming them once prevents the ambiguity that produces re-keying and broken handoffs. The load-bearing property is that a **person** moves through three lifecycle states — candidate, pre-boarding (accepted offer), employee — without losing identity or history, while the processing basis for each state is recorded per data-protection regime: the SPDI Rules 2011 today, DPDP from on or about 13 May 2027 (§10.13; EV-058, EV-060).

| Entity | Owns | Key relationships | Lifecycle-critical field | Temporal class (§14.6.1a) |
| --- | --- | --- | --- | --- |
| **Requisition** | Role, openings, band, wage-band structure, approval state | 1→N Applications; 1→1 Offer per fill | `openings_remaining`, `statutory_crossing_flag` (FR-T-R06) | R — append-only; an edit is a new version with actor and reason |
| **Candidate (person)** | PII, resume, source(s), consent record | N→N Applications (one person, many roles); dedup key = email+phone (FR-T-R12) | `consent`, `retention_horizon` (FR-T-X02/X03) | Personal fields encrypted under the person's subject key; erased by crypto-shredding at the FR-T-X03 horizon unless a `RetentionHold` applies |
| **Application** | A candidate's pursuit of one requisition; pipeline stage; scorecards | Candidate→Requisition edge | `stage`, `source_board`, `dedup_group_id` | R — stage moves and submitted scorecards are append-only (FR-T-R20, FR-T-R32); personal fields fall with the candidate's subject key |
| **Offer** | CTC structure (two wage bases), letter version, e-sign, approval | Application→Offer→Pre-boarding record | `wage_base_addback_resolved` (FR-T-R51) | R — each revision is a new version that re-runs FR-T-R51; the rendered letter is an E-class `Document` |
| **Pre-boarding record** | Provisional employee carrying CTC forward | Offer→Onboarding case | `becomes_employee_on` (joining date) | R until commit; the CTC it carries becomes a B-class `CompensationAssignment` at FR-T-O10 |
| **Onboarding case** | Statutory doc checklist, UAN/ESI-IP, appointment letter | Pre-boarding→Employee (register commit) | `uan_linked_or_generated`, `register_committed` | R for the checklist; uploaded proofs and the rendered appointment letter are E-class `Document`s; statutory identifiers are B-class (§07) |
| **Employee** | The system-of-record record the payroll engine runs | Onboarding→Employee; Employee→Reviews | `processing_basis` per regime, with its consent artefact where one is required (FR-T-X06) | Per §14: assignments and statutory attributes B, consent records E |
| **Goal/KRA, Review, Increment** | Performance artefacts and the CTC-revision outcome | Employee→Review→Increment→effective-dated CTC change | `effective_date` (FR-T-P15/P16) | Goal versions and calibration moves R (FR-T-P05, FR-T-P13); the increment lands as a B-class `CompensationAssignment` row |
| **Decision snapshot** | Criteria, model version and configuration, driving features, confirmer, reason — written at decision time (FR-T-D002) | Application or Review→Snapshot, 1→N | `snapshot_written_at`, `hold_id` | R — never recomputed; personal fields under the subject key, so erasure leaves the FR-T-X03 tombstone; a `RetentionHold` blocks erasure (§23 FR-LEG-026) |
| **Consent record** | Purpose, data classes, regime, notice version, whose artefact it is (§07 FR-CHR-100) | Candidate or Employee→Consent, 1→N | `regime`, `withdrawn_at` | E — versions forward; never rewritten at the ~May 2027 regime switch (Part E-6) |

Nothing talent-side is bitemporal except what payroll already makes bitemporal: the CTC that an offer or increment produces enters the B-class salary-structure and assignment rows the engine replays (§14.6.1a); every other talent record is either an append-only record of fact or erasable. That is what lets FR-T-X03 honour a candidate erasure without breaking any replayed payroll figure.

The single rule that keeps this from decaying into two disconnected products: **the same person entity persists from first application through payslip N**, so source-of-hire, BGV, offer structure, and appraisal history are all queryable against one identity. A recruiting product bolted on later, with its own candidate table, cannot do the appraisal→payroll arrears loop (§10.10) or the candidate→employee processing-basis record (FR-T-X06). Build the shared identity from v1.5.

---

### 10.2 FRs — Requisitions & requisition management

A requisition is the atomic unit that recruiting is metered on (§10.12), so it is modelled first and precisely.

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-R01** | Create a requisition with: title, department/cost-centre, location(s), band, headcount (N openings), employment type (full-time / fixed-term / apprentice / contractor), target CTC range broken into the two wage bases (§10.7), hiring manager, recruiter, and a required approval chain. | P0 | v1.5 | Metered | [Verified] |
| **FR-T-R02** | Multi-opening requisitions: one requisition with N openings tracks N independent fills; closing the Nth opening closes the requisition. Metering counts the **requisition**, not the openings, unless a per-hire plan is active (§10.12). | P1 | v1.5 | Metered | [Verified] |
| **FR-T-R03** | Requisition approval workflow: configurable serial/parallel approvers (e.g. hiring manager → finance → CXO), with SLA timers, delegation, and full audit trail. Approval is a precondition to job-board distribution (FR-T-R10). | P1 | v1.5 | Bundled | [Hypothesis] |
| **FR-T-R04** | Budget/headcount guardrail: a requisition cannot be *approved* if it pushes an approved-headcount counter for the cost-centre over its ceiling, unless an over-hire is explicitly authorised and logged. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R05** | Requisition templates and cloning: save a role as a template (JD, screening questions, interview kit, wage-band structure) and clone it, so repeat hiring (e.g. sales reps, plant operators) is one click. | P2 | v2 | Bundled | [Verified] |
| **FR-T-R06** | Requisition-to-vacancy statutory tag: flag whether a fill moves the hiring establishment across a threshold in the §06.1 table — 10 (ESI — 20 for the central-sphere-extended establishment classes — gratuity, maternity benefit and the appointment letter, as four separate rows, each with its own counting unit and latch); 20 (EPF; the Grievance Redressal Committee, counted in workers); 50 (contract labour, crèche); 100 (canteen; a Works Committee only where the appropriate Government orders one); 300 (standing orders, retrenchment approval) — counted per establishment in each statute's own counting unit (EV-057), and surface the crossing to the founder/HR before the offer (ties to §03, §05). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R07** | **Employment-type statutory classification** locked at requisition create, so the offer builder (§10.7) and onboarding (§10.8) inherit the correct statutory treatment: *permanent/regular* (PF/ESI/gratuity as normal); *fixed-term* (PF/ESI as regular **and pro-rata gratuity** — CoSS s.53 removes the five-year condition on fixed-term expiry and mandates pro-rata payment, **[Verified]**; the one-year qualifying service is a rules-level reading from two professional-services sources, not the Code's own text, **[Hypothesis]** until confirmed against the Social Security (Central) Rules 2026 — §06.6, §06.13; research r1/06, r3/04); *apprentice* (Apprentices Act stipend; the exclusion from PF/ESI/gratuity and from those headcount counts is carried from legacy citations with no Code-era basis located, **[Hypothesis]** — §06.1, §06.13); *contractor* (**not on payroll** — principal-employer contract-labour obligations under the OSH Code and CoSS (§06.1), not an employee record). The classification itself, and the fact that each type carries different statutory treatment, is what this FR requires; the two hypothesised consequences are parameters (`fte_gratuity_qualifying_service`, `apprentice_excluded_from_counts`), effective-dated, set only when §06.13 closes. | P1 | v1.5 | Bundled | [Verified] |

**Acceptance — FR-T-R06 (the statutory-crossing nudge, the one talent FR that earns its keep against the spine):**

```gherkin
Given an establishment with 19 employees counted for EPF (§06.1 counting unit)
And an open requisition for that establishment with 1 remaining opening
When the recruiter moves a candidate to "Offer accepted"
Then the product surfaces a banner: "This hire takes you to 20 employees — EPF obligation turns on"
And it links to the establishment's EPF-coverage task in the §06.1 obligation profile
And the crossing is recorded with effective date = joining date, not offer date
```

**[Verified — central-sphere text]** thresholds per §06.1 (EV-057). For most 20–200 private employers the State is the appropriate Government, so the operative values are per-state configuration.

**Edge case — who actually counts toward a threshold (FR-T-R06 × FR-T-R07).** The statutory-crossing nudge is only correct if headcount is counted by *statutory profile*, not raw seats. A fill that adds an **apprentice** engaged under the Apprentices Act 1961 is carried in §06.1 as not moving the EPF-20 or ESI-10 counter (legacy citations Apprentices Act s.18 and EPF Act s.2(f)) — but that exclusion is **[Hypothesis]** until §06.13 confirms a Code-era basis, and §06.1's kill criterion forbids dropping anyone from a count before then. A **contractor** engaged through a vendor is not on the tenant's own register, though the tenant carries principal-employer liability for the contractor's PF/ESI contributions (CoSS ss.17, 31 — §06.1, **[Verified]**); whether contractor-supplied workers also count toward the principal employer's own threshold is open (§06.1, **[Hypothesis]**). A **fixed-term employee**, by contrast, *does* count like a regular employee (FR-T-R07). So FR-T-R06's counter is defined per establishment and per statute's counting unit (§06.1), and FR-T-R07's classification is the input that decides which heads those are.

Until the apprentice exclusion is confirmed, the counter behaves conservatively: `apprentice_excluded_from_counts` defaults to *false*, so an apprentice hire that would cross a line raises the banner with the qualifier "crossing depends on the apprentice exclusion — unconfirmed (§06.13)" rather than staying silent. The asymmetry is deliberate: a false alarm costs the founder a minute; a missed crossing costs an un-registered establishment. The exact headcount-inclusion rule per state is effective-dated (state rules under the Codes notify unevenly — §20 risk register).

| Hire | EPF-20 counter | ESI-10 counter | Banner text if the hire crosses a line |
| --- | --- | --- | --- |
| Permanent employee | +1 | +1 | "Crosses {line} — {obligation} turns on from the joining date" |
| Fixed-term employee | +1 | +1 | Same as permanent |
| Apprentice (Apprentices Act) | +1 while `apprentice_excluded_from_counts` = false | +1 while false | Same text, plus "depends on the apprentice exclusion — unconfirmed (§06.13)" |
| Company-designated "trainee" who is not a statutory apprentice | +1 | +1 | Same as permanent (§06.1: such trainees count) |
| Contractor-supplied worker | Not on the tenant's register; principal-employer contribution liability tracked (§06.1) | As EPF | "Principal-employer liability — whether this worker counts toward your own threshold is unconfirmed (§06.1)" |

**Edge case — the talent-law lines the same counter feeds (FR-T-R06 × §10.13b).** The statutory-crossing nudge also watches the lines that switch on the §10.13b duties, each in its own counting unit (§23.10.2): RPwD Rule 3(2), the written-response duty, at **twenty or more persons** (EV-076); the full Rule 8(3) EOP content and the Rule 9(1) record at **twenty or more employees** (EV-077; research r5/05 findings 6–7); the HIV and AIDS Act Complaints Officer at **100 or more persons in any capacity, 20 or more in healthcare** (EV-082); and POSH, where the Internal Committee binds every employer and fewer than ten **workers** only changes the complaint route to the Local Committee (EV-056). Crossing twenty persons enables the Rule 3(2) case type (FR-T-D008); crossing twenty employees raises tasks to upgrade the EOP (FR-T-D006) and open the Rule 9(1) record (FR-T-D007) — and because persons, employees and workers are different counts, the same tenant can cross one of these lines on a day it does not cross another. **[Verified]** on the lines and units (EV-056, EV-076, EV-077, EV-082); whether a given contractor or apprentice counts toward each is the same open question as above.

**Edge case — the apprentice cap and stipend floor.** A requisition typed *apprentice* should also carry the notified apprentice-stipend minimum (a named parameter, `apprentice_stipend_floor`) and the establishment's apprentice-engagement band (a named parameter, `apprentice_engagement_band`) — neither value is captured in the research rounds, so both are sourced from the Apprentices Act and its rules through §20 desk validation before any value ships — because a plant-heavy beachhead employer that over-engages apprentices to dodge PF is running a real compliance risk the requisition stage is the cheapest place to flag. **[Hypothesis]** on surfacing the band cap in v1.5 — *kill/validate:* if beachhead interviews (§20) show apprentice hiring is negligible in the 20–200 desk-role segment, drop the band-cap check and keep only the stipend-floor default; retain the classification (FR-T-R07) regardless because the payroll treatment differs.

---

### 10.3 FRs — Job-board distribution / multi-post (bring-your-own-contract)

This is the FR set that operationalises the §10.1 invariant. It is deliberately narrow: **post out, ingest in, dedup — never search.**

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-R10** | Multi-post a single requisition to the customer's *own* contracts on Naukri, LinkedIn, foundit, apna, and Indeed from one screen, mapping our requisition fields to each board's posting schema. The posting path is captured for LinkedIn (Job Posting API) and Naukri (post plus application sync against the customer's contract, as four third-party ATSs do — r2/08); for foundit, apna and Indeed no posting or ingest path is captured in r1–r5, so each connector ships only after a dated capture of that board's employer integration terms (§20), and until then that board runs through the FR-T-R15 fallback. | P0 | v1.5 | Metered | [Verified] |
| **FR-T-R11** | Application ingest: pull applicants back from each board (via API where one exists — LinkedIn Apply Connect; via authorised email/inbox parsing where none does — Naukri) into the pipeline (§10.4), with source attribution per candidate. | P0 | v1.5 | Metered | [Verified] |
| **FR-T-R12** | **Cross-source dedup:** when the same candidate arrives from two boards (e.g. Naukri + LinkedIn), collapse to one candidate record, preserving all source touchpoints, using email + phone (E.164, +91 normalised) as the primary match key and name+DOB as a secondary signal. | P0 | v1.5 | Bundled | [Verified] |
| **FR-T-R13** | LinkedIn RSC / Apply Connect / Job Posting API integration built to LinkedIn's certified partner path — the one large passive graph with a documented, legitimate integration (§10.1). | P1 | v1.5 | Metered | [Verified] |
| **FR-T-R14** | Naukri handling *without* a public API: job posting + application sync only, against the customer's contract; **explicitly no Resdex/database search**, and the UI must state this limit so the customer is not surprised. | P0 | v1.5 | Metered | [Verified] |
| **FR-T-R15** | CSV/email fallback board connector: any board without an integration can still be used via a structured email-forward + CSV-import path, so "bring your own contract" degrades gracefully to any board. | P2 | v2 | Free-acq | [Hypothesis] |
| **FR-T-R16** | Career-site / hosted job page: a tenant-branded public jobs page and per-requisition apply link, with consent capture at point of application built for both data-protection regimes, using counsel-cleared notice text (FR-T-X02; §23). | P1 | v1.5 | Free-acq | [Verified] |
| **FR-T-R17** | Employee referral portal: an employee submits a referral against an open requisition; referral is tracked through to hire for referral-bonus payout via payroll (ties to §08 earnings). | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R18** | **No-scrape enforcement:** architecture forbids, and the codebase contains no path for, authenticated-session scraping of any candidate database; sales collateral states the prohibition (§16). | P0 | v1.5 | — | [Verified] |

**Worked example — the dedup that makes multi-post usable.** A beachhead employer posts a "Field Sales Executive, Pune" requisition to Naukri and apna. Candidate *Rahul Deshmukh* applies on both (common for blue/grey-collar candidates who spray applications). Without FR-T-R12 the recruiter sees two Rahuls, schedules two calls, and looks incompetent. With it, one record shows "Applied via Naukri (12 Sep) and apna (13 Sep)," and source attribution later tells the customer *which board actually converts* — the input to whether renewing the apna contract is worth it. This is the quiet reason inbound-only can still be a good product: **the value is in the funnel intelligence, not in owning the graph.**

<!-- DIAGRAM: requisition-to-hire-pipeline -->

**Design note — ingest fragility, and why parsing is never authoritative (FR-T-R11).** The ingest paths are not equal in reliability, and the architecture must treat them accordingly. LinkedIn's **Apply Connect** delivers structured applications via a certified API — high fidelity. Naukri, with no public API we are aware of (§10.1), is ingested by parsing the customer's own application-notification inbox — inherently fragile: email formats change without notice, fields arrive as free text, and a parser silently drifts. So FR-T-R11 must (a) attribute every ingested candidate to its source path, (b) surface parse-confidence and flag low-confidence records for human review rather than dropping them, and (c) never let a parsed field populate a statutory field (PAN, UAN, DOB) without human verification — the same rules-first/LLM-last invariant that governs FR-T-R22 résumé parsing (§13). The failure mode to design against is not "parsing is imperfect" (it always is) but "an imperfect parse silently became payroll truth."

**Acceptance — FR-T-R13 (LinkedIn certified-partner path):**

```gherkin
Given the tenant holds its own LinkedIn Recruiter/Jobs contract
And our LinkedIn partner approval, signed API agreement and module certification are in place
When a requisition is posted to LinkedIn and applications flow back
Then posting uses the Job Posting API and ingest uses Apply Connect / RSC per LinkedIn's certified partner path
And no RSC capability is enabled for a tenant before the Job Posting integration is certified (LinkedIn's sequencing rule)
And profile data from RSC enters only by recruiter-initiated export, never by bulk search
And no candidate data is obtained by scraping or by proxying LinkedIn search
And source attribution records "LinkedIn (Apply Connect)" distinct from other boards for FR-T-R12 dedup and FR-T-X05 analytics
```

---

### 10.4 FRs — Candidate pipeline / ATS core

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-R20** | Configurable pipeline stages per requisition (default: Applied → Screened → Interview → Offer → Hired → Onboarding; plus Rejected / Withdrawn / On-hold as terminal or holding states), with drag-or-click stage moves and a full stage-change audit trail. | P0 | v1.5 | Bundled | [Verified] |
| **FR-T-R21** | Candidate profile: contact, resume (parsed to structured fields), source, current/expected CTC, notice period in days (a real pipeline variable in India, because the joining date waits on the notice the candidate must serve), location/relocation, and a timeline of every touchpoint. | P0 | v1.5 | Bundled | [Verified] |
| **FR-T-R22** | Resume parsing to structured fields (name, contact, skills, experience, education) with human-correctable output. Parsing is an AI cost-of-goods task (§13), rules-checked, never authoritative for any statutory field; every model call runs under the FR-T-X11 rails (Aadhaar, PAN and bank details denied by default at the §12 chokepoint), and parsed output never feeds a barred attribute into scoring (FR-T-D004). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R23** | Screening questions / knockout criteria per requisition (e.g. "Do you hold a valid commercial driving licence?"), auto-flagging or auto-rejecting on hard knockouts with candidate notification. Knockouts are deterministic rules the candidate answers, validated against the protected-attribute bar and sex-criterion check (FR-T-D004); no model output may auto-reject (FR-T-D001). | P1 | v1.5 | Bundled | [Hypothesis] |
| **FR-T-R24** | Bulk actions: bulk reject-with-template-email, bulk move, bulk tag — because a high-volume requisition (frontline and blue/grey-collar roles especially) can draw more applicants than one-by-one handling absorbs; applicant volume per requisition is not measured in our research, so the bulk-action batch size is a named parameter (`bulk_action_max_batch`), sized from v1.5 ingest data. | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R25** | Candidate communications: templated email + WhatsApp, respecting the frontline reach ceiling — a newly created WhatsApp business portfolio may send business-initiated messages to only **250 unique users per rolling 24 hours** (r2/04 finding 23; §09), so bulk candidate WhatsApp must queue and rate-limit, not blast. Each WhatsApp message is also a billed cost line (per message since 1 July 2025; conversations the candidate initiates are free inside the 24-hour window — EV-088), so candidate-initiated threads are the preferred channel. | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R26** | Talent pool / silver-medallist bank: rejected-but-good candidates parked for future requisitions, subject to the retention and re-consent rules of FR-T-X02/FR-T-X03 — **not** a substitute for licensed database search. | P2 | v2 | Bundled | [Verified] |
| **FR-T-R27** | Recruiter/hiring-manager collaboration: shared candidate notes, @mentions, and hiring-manager review actions (advance/reject with reason) without giving the hiring manager full ATS access. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R28** | Structured **rejection-reason taxonomy** (e.g. skills gap, CTC mismatch, notice-period too long, failed knockout, candidate withdrew) captured on every reject — the raw material for source-of-hire quality analytics (FR-T-X05) and for a defensible, non-discriminatory audit trail. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R29** | Duplicate-application guard within a single requisition: a candidate who re-applies to the same open requisition is merged into their existing application, not created anew (distinct from cross-source dedup, FR-T-R12). | P2 | v1.5 | Bundled | [Verified] |

**[Verified]** The 250-unique-users/24h ceiling is Meta's messaging limit for a newly created business portfolio, rising through 2,000 / 10,000 / 100,000 / unlimited as the portfolio scales, and it applies only to business-initiated messages outside the service window (Meta documentation re-fetched in research r2/04, finding 23) — the same constraint that reshapes frontline onboarding (§09). It applies to candidates as much as employees. The WhatsApp Business Account must also move to INR billing by 31 December 2026 or delivery stops on 1 January 2027 (EV-088), a tenant-level dependency the notification layer (FR-T-X07) surfaces.

**Edge case — dedup false positives on shared contacts (FR-T-R12 × FR-T-R21).** The naive dedup key (email + phone) misfires in exactly the Indian segment where multi-post matters most. Blue/grey-collar candidates frequently **share a phone number** (a household or PCO number) or reuse a **generic email created by a cyber-café operator**, so two genuinely different people can collide on the primary key; conversely one person may apply with a personal number on apna and a spouse's number on Naukri, defeating the match. So FR-T-R12's merge must be **suggest-then-confirm above a confidence threshold**, not silent: a high-confidence match (email *and* phone *and* name align) auto-merges; a partial match (phone only, names differ) is surfaced as a *suspected duplicate* for recruiter confirmation, never auto-collapsed. The cost of a wrong auto-merge is a real candidate silently disappearing into another person's record — worse than the two-Rahuls problem FR-T-R12 solves. **[Hypothesis]** on the exact threshold — *kill/validate:* tune against real ingest data in early v1.5 tenants; if shared-contact collisions are rare in the actual beachhead board mix, raise the auto-merge aggressiveness; if common, bias toward suggest-only.

**Acceptance — FR-T-R12 (cross-source dedup, confidence-gated):**

```gherkin
Given two applications ingested from different boards
When email AND phone (E.164, +91-normalised) AND name all match
Then the records auto-merge into one candidate, preserving both source touchpoints and timestamps
When only phone matches but names differ materially
Then the pair is flagged as a suspected duplicate for recruiter confirmation
And neither record is auto-collapsed until confirmed
And no candidate history is lost on any merge (merges are reversible / audited)
```

---

### 10.5 FRs — Interview scheduling & evaluation

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-R30** | Interview scheduling with calendar integration (Google / Microsoft 365), interviewer availability, and candidate self-scheduling links; timezone-aware but India-default (IST). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R31** | Structured interview kits / scorecards per stage: competency questions and a rating rubric, so evaluation is comparable across interviewers (reduces the unstructured-gut-feel bias common in SMB hiring). | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R32** | Interview feedback capture: each interviewer submits a scorecard; aggregate view shows all feedback before an advance/reject decision; feedback is immutable once submitted (audit). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R33** | Video-interview link support (embed a Meet/Teams/Zoom link on the interview event) — integration, not a first-party video product. | P2 | v2 | — | [Verified] |
| **FR-T-R34** | Panel interviews: schedule multiple interviewers against one slot; each submits an independent scorecard (FR-T-R32); no interviewer sees another's rating before submitting (anti-anchoring). | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R35** | Interviewer availability + load view so recruiters do not overbook a small number of senior engineers — a bottleneck at 20–200 firms where the same few senior people interview everyone. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R36** | Reschedule / no-show handling: candidate- or interviewer-initiated reschedule with a captured reason; auto-nudge on missed slot; a candidate no-show is recorded (feeding the funnel analytics of FR-T-X05 and the reneg signal of FR-T-R55), and a repeat-no-show flag surfaces to the recruiter — because every no-show spends the small senior-interviewer pool. How often candidates no-show in the beachhead is not measured in our research; the repeat-no-show threshold is a named parameter (`no_show_repeat_threshold`) and the rate itself is a §20 measurement. | P2 | v2 | Bundled | [Hypothesis] |

**India note on FR-T-R30/R35.** In the beachhead, the interviewers *are* the senior team, and interview load is a genuine constraint on hiring velocity, not an afterthought. Scheduling that respects interviewer load is worth more here than fancy rubrics; hence R35 (load view) ranks alongside R31 (kits) despite being simpler.

**Worked example — the anti-anchoring panel that survives a bias challenge (FR-T-R32/R34).** A 40-person firm runs a 3-person panel for a lead-engineer role. Two interviewers submit "strong hire" scorecards; the third, submitting last, can see the first two and rates "hire" — quietly anchored upward. FR-T-R34 forbids this: no interviewer sees another's rating until their own is submitted, and FR-T-R32 makes each scorecard immutable once submitted. The aggregate view then shows three *independent* judgements, which is what makes the hire/no-hire decision defensible if a rejected candidate later alleges discriminatory treatment. That exposure is live today and does not wait for DPDP: RPwD s.3(3) is actor-neutral and reverses the onus (EV-075), and Code on Wages s.3(2)(ii) bars sex discrimination in recruitment at any size (EV-081; whether the Code's exclusion of managerial and administrative staff narrows this for senior hiring is a counsel question — §23.10.2); DPDP, when it commences, adds no right to explanation or human review (EV-066). India has no general private-sector anti-discrimination statute for caste, religion, age or sexual orientation (EV-084, a negative finding dated September 2026), so coverage is characteristic-by-characteristic (§10.13b). The value is not the rubric aesthetics; it is a contestable, auditable decision trail.

**Acceptance — FR-T-R32/R34 (independent scorecards):**

```gherkin
Given a panel of N interviewers scheduled against one candidate stage
When interviewer i opens the scorecard screen
Then no other interviewer's rating or written feedback is visible to i until i submits
And once i submits, i's scorecard is immutable (edits create an audited new version, never overwrite)
And the advance/reject decision screen shows all N scorecards only after all are submitted or the stage is force-closed with a reason
```

---

### 10.6 FRs — Sourcing & background verification (India-specific)

Sourcing beyond inbound is constrained (§10.1); BGV, by contrast, is an India-specific surface reachable through ordinary vendor contracts.

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-R40** | Background-verification orchestration via third-party BGV vendors (candidates for diligence: AuthBridge, IDfy, SpringVerify, OnGrid — none of their APIs or terms is captured in r1–r5): trigger education, employment, address, and criminal/court-record checks against a candidate, track status, and store the report against the candidate/employee record as an E-class `Document` (§14.6.1a). **No Aadhaar number leaves the product for a BGV check:** the §07 token store is excluded from every sub-processor (FR-CHR-099(e)), and the product never performs offline verification on a customer's behalf (EV-070). A vendor that runs an Aadhaar-based check does so as its own act, under its own registration and the consent the candidate gives it — AuthBridge, for one, appears on UIDAI's registered-OVSE list as on 30.06.2026, though which of its product lines uses that registration is not established (research r4/04). | P2 | v2 | Metered | [Hypothesis] |
| **FR-T-R41** | **DigiLocker document pull** with candidate consent: fetch issuer-verified education certificates and PAN from DigiLocker for onboarding, reducing forgery risk and manual collection. **Never Aadhaar:** a multi-tenant product may not perform Aadhaar offline verification or share an e-KYC licence key on a customer's behalf (EV-070); an Aadhaar number enters only the §07 token store, and only if the joiner chooses (FR-CHR-099, FR-CHR-101). The partner-API path itself is not captured in research r1–r5 (§10.6 note below). | P2 | v2 | Metered | [Hypothesis] |
| **FR-T-R42** | **UAN-based prior-employment signal:** with candidate consent, a candidate's UAN service history (via the EPFO member passbook the candidate authorises) corroborates claimed prior employers and dates — a uniquely-Indian, statutory-grade employment check. **Consent-gated; never scraped; read-only.** | P2 | v2 | Metered | [Hypothesis] |
| **FR-T-R43** | **BGV consent + adverse-action workflow:** capture explicit candidate authorisation *before* any check is triggered (today, SPDI written consent wherever the check collects sensitive personal data such as financial information — SPDI r.3 and r.5(1), EV-060; DPDP itself creates no sensitive category, EV-059; consent is also the default-safe basis once DPDP commences on or about 13 May 2027, because whether s.7(i) reaches background verification is a counsel question — §23), and enforce a documented adverse-action step — surface the discrepancy to the candidate, allow a response window, and require a recorded reason — *before* a candidate is rejected on BGV grounds. The check result is never silently decisive. | P2 | v2 | Bundled | [Verified] |

**India-specific BGV notes.** We are not aware of any **unified criminal-records database** open to private employers as of September 2026; "criminal/court-record" verification runs jurisdiction-by-jurisdiction (district-court and police-station level, keyed to the candidate's declared addresses), so a court check is only as good as the address history it runs against — which is why address verification and the employment timeline are prerequisites, not parallel checks (BGV-vendor methodology as described by AuthBridge/IDfy; not captured in research r1–r5 — **[Hypothesis]**, confirm in vendor diligence). Two India-specific signals the beachhead genuinely cares about: **employment gaps** (unexplained months that the UAN history in FR-T-R42 can corroborate or contradict) and **dual/overlapping employment** — concurrent PF contributions under one UAN from two establishments in the same month is a moonlighting signal (how much beachhead employers weigh it is not measured in our research — a §20 interview question, not a claim). Both are read-only, consent-gated inferences on the candidate's own UAN passbook, never an employer-side database query.

**[Hypothesis]** on FR-T-R42's mechanism: EPFO exposes member service history to the *member*; the product surfaces it only via candidate-authorised sharing, not any employer-side lookup. *Kill/validate:* confirm a compliant candidate-consent flow exists (EPFO member portal export or Account Aggregator-style consent) before building; if no compliant path exists, drop FR-T-R42 and fall back to FR-T-R40 employment checks. This is a *bet*, flagged as such — do not put it in collateral until the consent path is verified with a gazette/portal citation.

**Worked example — the fabricated experience letter caught by the UAN.** A candidate for a ₹9L accounts role submits an experience letter claiming three years at a Pune firm. FR-T-R40 employment verification is slow (the ex-employer is unresponsive, common with small firms). With candidate consent, FR-T-R42 pulls the UAN passbook: it shows PF contributions from that establishment for only **seven months**, not three years, and a six-month gap the candidate did not declare. FR-T-R43 then governs what happens next: the discrepancy is surfaced to the candidate with a response window (perhaps the ex-employer under-reported PF — itself informative), a reason is recorded, and only then may the recruiter reject. This is a uniquely Indian check, and it is also why FR-T-R43's adverse-action gate matters: a UAN discrepancy can have an innocent explanation, and rejecting silently on it is both unfair and legally exposed.

**Acceptance — FR-T-R42/R43 (consent-gated check + adverse action):**

```gherkin
Given a candidate at the BGV stage
When a UAN-history or any BGV check is triggered
Then explicit candidate authorisation for THIS check type must exist and be logged first (no consent -> no check)
And the check is read-only against the candidate-authorised source (never an employer-side lookup or scrape)
Given a check returns a discrepancy that could drive rejection
Then the discrepancy is surfaced to the candidate with a response window
And a rejection on BGV grounds requires a recorded reason from the recruiter after that window
And the full sequence (consent, result, candidate response, decision) is retained as an immutable audit trail
```

**[Hypothesis]** DigiLocker partner integration and the BGV vendors' APIs (IDfy, AuthBridge) are assumed to be documented integration paths, but neither is captured in research r1–r5; each needs a dated capture of the vendor or MeitY documentation before build (§20). Whether the beachhead will pay for BGV as a metered pass-through (FR-T-R40/R41's monetisation) is a separate [Hypothesis] — see §10.15 T-5 and §10.16.

---

### 10.7 FRs — Offer management (where recruiting meets the payroll spine)

Offers are where the talent module stops being a CRM and starts being a *payroll* product, because the CTC structured in the offer is the same structure the engine will run. This is the highest-leverage integration point in the whole talent section.

<!-- DIAGRAM: offer-ctc-to-payroll-wage-base -->

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-R50** | Offer builder that constructs a CTC from a component structure (Basic, HRA, special allowance, employer PF, gratuity accrual, variable/bonus, FBP components) and shows gross, net-in-hand, and total CTC. | P0 | v1.5 | Metered | [Verified] |
| **FR-T-R51** | **50%-add-back validation at offer time:** the offer builder computes the two wage bases (§06) and warns if the excluded heads (HRA, conveyance, commission, etc. — §06.10) exceed one-half of all remuneration (a notified variable, not a constant — §06.10), because that excess is *deemed wages* and re-bases PF/gratuity. An offer must not be issued with a structure that silently understates the statutory wage base. | P0 | v1.5 | Bundled | [Verified] |
| **FR-T-R52** | Offer approval workflow (recruiter → hiring manager → finance/CXO) with the same audit/SLA machinery as requisition approval (FR-T-R03). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R53** | Offer-letter generation in a maintained template, mergeable with the CTC structure and statutory annexures; e-signature capture; versioned so a revised offer supersedes cleanly with history. | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-R54** | Offer acceptance → **pre-boarding record**: on acceptance, create a provisional employee record (not yet on payroll) that carries the CTC structure forward into onboarding (§10.8) without re-keying. | P0 | v1.5 | Bundled | [Verified] |
| **FR-T-R55** | Notice-period / joining-date tracking with a configurable "likely to renege" nudge, and requisition auto-reopen if a candidate reneges. Offer-decline and no-join rates are widely reported as a pain in Indian hiring but are not measured in our research, so the nudge ships only once joined-versus-reneged data exists (§10.16). | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-R56** | **Joining bonus / retention / notice-buyout clawback terms** modelled in the offer and carried to payroll as a recoverable advance with a clawback schedule (e.g. joining bonus repayable if the employee exits within 12 months), so the offer promise and the payroll recovery are one structured object, not a side letter the engine cannot see. | P2 | v2 | Bundled | [Hypothesis] |

**Edge case — the revised offer must re-run the add-back (FR-T-R51 × FR-T-R53).** A candidate negotiates; the recruiter bumps total CTC and, to keep net-in-hand attractive, loads the increase entirely into HRA and conveyance. This can *newly* trip the 50% add-back that the original structure passed (loading a special allowance would not — it is not an excluded head, §06.10). FR-T-R53's versioning must therefore re-invoke FR-T-R51 on every revision — a revised offer is not a text edit, it is a fresh statutory-wage-base computation. The superseding offer version carries its own corrected PF/gratuity base, and only that version flows to the pre-boarding record (FR-T-R54).

**Edge case — the "net take-home" offer and gross-up.** Blue/grey-collar and some sales offers in India are negotiated on *in-hand* rather than CTC. If the offer is expressed net, the builder must gross up to a CTC that yields the promised net after PF, PT, ESI and TDS — and that gross-up itself changes the wage bases, so it iterates with FR-T-R51 as a bounded fixed-point evaluation (the same `fixed_point.max_iterations` and `fixed_point.tolerance` parameters — FR-PAY-211, §15) rather than running once; a net target the engine cannot reach within the bound is reported to the recruiter, never silently rounded. The persisted offer is always the gross CTC structure (the engine runs gross); the net figure is a display target, never the stored basis. **[Hypothesis]** on how common net-offers are in the beachhead — *kill/validate:* if §20 interviews show net-offer negotiation is rare in the 50–200 desk segment, keep gross-up as a calculator convenience, not a first-class offer type.

**Worked example — the offer that would have been non-compliant.** A hiring manager builds a ₹10,00,000 annual offer (cash remuneration; employer PF is set aside here and brought into the test in the table below; gratuity accrual is outside the test — §06.10) as Basic ₹3,00,000 + HRA ₹3,00,000 + conveyance ₹1,00,000 + sales commission ₹2,00,000 + special allowance ₹1,00,000, deliberately keeping Basic low to minimise PF. FR-T-R51 computes: excluded heads (HRA + conveyance + commission) = ₹6,00,000 = 60% of ₹10,00,000. Half is ₹5,00,000, so the ₹1,00,000 excess is deemed wages, and the add-back base is Basic ₹3,00,000 + special allowance ₹1,00,000 + ₹1,00,000 = ₹5,00,000 — not the ₹3,00,000 the manager intended. **[Reversed]** An earlier version of this example treated the special allowance as excludable and still mis-stated the test (₹4,50,000 of excluded pay against a ₹5,00,000 half-way line does not trip it); a special allowance is not an excluded head (§06.10). The builder shows the corrected base and the true employer PF cost (subject to the PF wage ceiling or the employer's opt-in — §06.2) **before** the offer goes out, so the offer letter and the eventual payslip agree. Without this, the offer promises a net-in-hand the payroll engine later contradicts, and the payroll operator (§03) inherits the dispute on payslip one. **[Verified]** on the mechanism per Code on Wages s.2(y) / Code on Social Security s.2(88) (§06.10).

**The same example with the employer's PF contribution in the test — and why it can become a fixed point.** The example above sets employer PF aside, as §08.12 Example G does. §06.10 lists the employer's PF or pension contribution as head (c) of the nine excluded heads, but the proviso speaks of payments made by the employer *to the employee*, and whether a contribution paid into a fund enters E (and "all remuneration" R) is a reading our evidence does not settle. So the offer builder does not assume it: the wage-definition rule payload (§06.10) carries a named switch, `addback.employer_pf_in_test`, set by the rule author with its citation, routed to §20 desk validation and counsel (§23). Gratuity accrual is head (j), outside the test either way (§08.12). With the switch **off**, the answer is the ₹5,00,000 above. With it **on**:

| Case | Employer PF (annual) | R | E | Half of R | Deemed excess | Add-back base | Passes to converge |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Employer PF at the statutory ceiling (12% of ₹15,000 × 12 — §06.2) | ₹21,600 | ₹10,21,600 | ₹6,21,600 | ₹5,10,800 | ₹1,10,800 | ₹5,10,800 | 1 — the base (≈ ₹42,567 a month) stays above the ₹15,000 ceiling, so employer PF does not move |
| Employer opts to contribute on actual wages (§06.2) | 12% of the add-back base W | ₹10,00,000 + 0.12W | ₹6,00,000 + 0.12W | — | — | W = ₹5,00,000 + 0.06W ⇒ **₹5,31,914.89** | Iterates: ₹5,00,000 → ₹5,30,000 → ₹5,31,800 → ₹5,31,908 → ₹5,31,914.48 → … |

Whenever the add-back triggers, the base equals half of R (the non-excluded pay plus the excess over half of R is exactly R/2), which is why both rows land on R/2. In the second row employer PF depends on the base and the base depends on employer PF — the add-back re-bases a component that feeds its own test. The offer builder therefore calls the engine's bounded fixed-point node (FR-PAY-211), never a single-pass formula: it iterates until successive bases differ by less than `fixed_point.tolerance` or stops at `fixed_point.max_iterations`, and a structure that has not converged blocks "Issue offer" with the node and last two iterates named (the §08 AC-211.3 behaviour). Each pass here shrinks the change by a factor of 0.06, so convergence to the paisa takes a handful of passes; statutory rounding applies once, after convergence (FR-PAY-209). The converged employer PF is ₹63,829.79 a year against ₹60,000 on the single-pass answer — the gap the offer letter and payslip one would otherwise disagree on. **[Verified]** arithmetic; **[Hypothesis]** whether head (c) enters the test at all (the switch above). Either way the fixed-point node is required, because gross-up (next edge case) and a balance-figure gratuity accrual (§08.12 Example G) loop regardless.

**Acceptance — FR-T-R51:**

```gherkin
Given an offer with all remuneration R and excluded-head sum E (heads (a)–(i), §06.10)
And gratuity accrual (head (j)) is in neither R nor E, and the employer's PF contribution (head (c)) is in both only if the rule payload's addback.employer_pf_in_test is on
And the add-back threshold t in force on the offer's effective date (0.5 today — a notified variable)
When E > t * R
Then the offer builder deems (E - t*R) as wages
And recomputes the PF/gratuity wage base upward accordingly
And where a component of R or E depends on the base, evaluates the base as a bounded fixed point until successive bases differ by less than fixed_point.tolerance
And refuses to issue the offer if fixed_point.max_iterations is reached without convergence
And blocks "Issue offer" until the recruiter acknowledges the corrected base
And the corrected structure is the one persisted to the pre-boarding record (FR-T-R54)
```

**Edge case — FBP components at offer time and the tax-perquisite windows.** The offer builder's FBP section (FR-T-R50) is where flexible benefit choices — meal card, fuel/LTA, telephone, books & periodicals — are structured, and it must carry the *current* tax-free perquisite limits, because a wrongly-set limit becomes a taxable-perquisite error on the first payslip. Effective **1 April 2026** the Income-tax Rules 2026 raised the tax-free meal perquisite from ₹50 to **₹200 per meal** and the gift/voucher threshold from ₹5,000 to **₹15,000 per tax year**, and the meal exemption is reported as available under the new regime as well (EV-019; research r2/02). **[Hypothesis]** — the figures concur across two dated secondary reads and a counsel spot-check, but the gazette text has not been read; the rule provision and its conditions are §20 V-18, so the limits ship as effective-dated parameters (`perq.meal_per_meal_cap`, `perq.gift_voucher_annual_cap`), re-versioned if V-18 finds a difference. **The ₹200 figure is conditional, and the conditions are engine constraints, not help text:** the meal must be provided during working hours at the office or factory premises, or through non-transferable vouchers usable only at eating outlets; a cash meal allowance is taxable. Without the conditions the perquisite is taxable, payslips under-deduct, and the demand plus interest lands on the employer. The ~3.8× wallet expansion is a ratio computed on a two-meals-a-day, 22-working-day convention — the ratio holds, the rupee level does not (research r2/02). Two further consequences the builder must encode: (a) these limits are **effective-dated**, not constants — an offer dated before 1 April 2026 uses the old limits — consistent with the engine's effective-dating requirement (§06); (b) FBP components are part of all remuneration in the **50% add-back (FR-T-R51)** test, and any FBP component that falls in an excluded head (for example an amenity under head (b) or a special-expense reimbursement under head (e)) also enters E — which head each FBP component falls in is classified in the §08 component catalogue, never assumed by the offer builder — so loading FBP to reduce Basic can itself trip the add-back. The FBP data model this offer surface writes into is the same one §11 (benefits-attach) says to build in v1 and defer monetising — the offer builder is its first writer.

**Edge case — e-signature for the offer and appointment letter (FR-T-R53, FR-T-O06).** The product supports electronic execution of offers and appointment letters and stores the signed artefact with its audit trail. Aadhaar-based **eSign** is performed by a licensed eSign service provider; the product never performs Aadhaar authentication itself (EV-070). Two limits to encode, not paper over: (a) the IT Act excludes certain instruments from electronic execution, so a maintained exclusion list prevents the product from ever e-signing a document that requires a wet signature; (b) eSign is a metered third-party cost, so the bulk-document quota logic (§10.12) applies. **[Hypothesis]** — the electronic-signature position (IT Act 2000 s.5 and its Schedules) is not re-verified in research r1–r5, and whether each state-prescribed appointment-letter form may be executed electronically is a counsel question (§23 CR-37); the appointment letter itself is FR-T-O06's state-prescribed artefact.

**Edge case — the CTC-vs-take-home gap the offer must show honestly (FR-T-R50).** Indian "CTC" bundles employer-side costs the employee never receives in hand: employer PF (12% of PF wages), gratuity accrual (conventionally **4.81%** of the gratuity wage base — 15/26 of a month's wages per year of service, divided by 12; the formula is CoSS s.53, §06.6), employer ESI where applicable, and sometimes a notional insurance or variable figure. A headline ₹10,00,000 CTC can therefore yield a monthly net-in-hand well below the ₹83,333 a naïve candidate expects, and discovering that on payslip one is a new-joiner grievance and a plausible reneg trigger (how often it drives a renege is not measured in our research — FR-T-R55). The builder must display **three distinct figures — total CTC, gross, and estimated monthly net-in-hand** — and label employer PF/gratuity explicitly as *employer cost, not employee income*. This is not cosmetic honesty: the offer letter (FR-T-R53) and the first payslip (§08) must reconcile to the rupee, or the product has recreated the exact offer-vs-payslip mismatch it sells against (§01). **[Verified]** on the components (employer PF 12% — §06.2; gratuity formula — CoSS s.53, ex-Payment of Gratuity Act s.4, §06.6). The 4.81% is an accrual convention derived from the formula, not a statutory rate.

**Edge case — variable pay and the offer that is not a payroll promise.** A large slice of Indian offers (sales, senior desk roles) carry a **variable/performance component** — a share of CTC that varies by role and is not sized in our research — that is *conditional*, paid quarterly or annually against targets, and is neither guaranteed nor part of monthly net-in-hand. The builder must model variable pay as a distinct, clearly-conditional line (not folded into gross monthly), because (a) it changes the monthly net-in-hand display materially, (b) its treatment in the 50% add-back (FR-T-R51) depends on its statutory head — commission is an excluded head (§06.10), while every other variable component is classified in the §08 component catalogue, never assumed by the offer builder — and (c) the eventual payout runs through the performance-variable path (FR-T-P17), never the statutory-bonus path. An offer that shows a variable component as if it were guaranteed monthly pay is the same dishonesty as the CTC-illusion above, one layer up.

---

### 10.8 Onboarding handoff — the bridge (v1 dependency)

This is the only talent surface in v1, because it produces statutory records. Its job is a **clean handoff from "hired" to "employee on the payroll register"** with zero re-keying and full UAN/ESI-IP continuity. It is where recruiting hands off to core HR/payroll (§07, §08) — and, for migrated customers, where mid-year cutover data lands (§16).

<!-- DIAGRAM: onboarding-handoff-sequence -->

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-O01** | Convert a pre-boarding record (FR-T-R54) or a directly-added hire into an onboarding case with a checklist of statutory + operational tasks, without re-entering CTC, personal, or contact data. | P0 | v1 | Bundled | [Verified] |
| **FR-T-O02** | Collect and validate statutory joining documents: PAN, bank (name/IFSC/account, penny-drop verified), photo, and address proof. Bank details are financial information — sensitive under SPDI r.3, so written consent is captured before collection (EV-060; §07 FR-CHR-100); DPDP itself creates no sensitive category (EV-059). **Aadhaar only if the joiner chooses to provide it**, written only to the §07 token store and never a precondition to register commit (FR-CHR-099, FR-CHR-101). | P0 | v1 | Bundled | [Verified] |
| **FR-T-O03** | The **EPF joining declaration** (including any existing UAN), the **EPF nomination** and the **ESI joining declaration** collected digitally and mapped to the payroll engine's statutory registers (§07 FR-CHR-044, FR-CHR-045a). Form identifiers are read per scheme version from `epf.form_catalogue` (§06.2) and `esi.form_catalogue`, never hard-coded: the legacy names — EPF Form 11 and Form 2 under the 1952 Scheme, ESI Form 1 — are carried, not re-captured, the forms under EPF Scheme 2026 are not captured, and the ESI regime after 22 Nov 2026 is unresolved (§20 V-08). | P0 | v1 | Bundled | [Verified] |
| **FR-T-O04** | **Previous-employer income (Form 122, ex-Form 12B, or a declaration)** and current-year TDS-already-deducted capture, so the new employer's salary TDS u/s 392 (ex-s.192) computes on full-year income rather than on this employer's months alone. The previous-employment block is a first-class field set of four items — income after exemptions, income tax already deducted, professional tax, and EPF from each prior employer (the field set Zoho Payroll's IT-declaration help page documents — read not executed, round r3 records no capture date; research r3/02 finding 21 — used here as a field list, not as a competitor claim) — held per prior employer, so a joiner with two earlier employers in the same Tax Year is two rows, not a summed figure. Both vocabularies are accepted in labels, search and imports (EV-050). | P0 | v1 | Bundled | [Verified] |
| **FR-T-O05** | Investment-declaration capture (Form 124, ex-Form 12BB — EV-050; Chapter VI-A, HRA, home-loan in the 1961-Act vocabulary practitioners still use) at onboarding so the first payslip uses the right regime and TDS, not a default. | P1 | v1 | Bundled | [Verified] |
| **FR-T-O06** | **Appointment letter in the state-prescribed form** generated and issued as part of onboarding for every joiner of an establishment of ten or more workers (OSH Code s.6(1)(f) — EV-057; counting unit per §06.1), from a template configured per state; below the threshold the same letter is issued as good practice, not as a statutory artefact. **[Reversed]** Earlier drafts said the letter was due "from employee one" in one notified format. | P0 | v1 | Bundled | [Verified] |
| **FR-T-O07** | **UAN handling:** link an existing UAN (from the EPF joining declaration, FR-T-O03); for a joiner with none, route them to UAN allotment and activation through Aadhaar face authentication in the UMANG app — since 1 August 2025 the only route, save for International Workers and citizens of Nepal and Bhutan, for whom the employer still generates the UAN as an attended portal task (EPFO circular of 30.07.2025 — research r4/04, finding 7; §22). Track Aadhaar-seeding status without making Aadhaar a gate (FR-CHR-005, FR-CHR-101). **ESI IP** registration for ESI-eligible joiners is an attended ESIC-portal task (§22). Both portal tasks are the employer's: the product prepares them, and our operators act on them only as attended, assisted filing under the employer's written authority to act, whose legality is under counsel review (§22; §23). Continuity is a hard requirement for migrated employees (no duplicate UANs). | P0 | v1 | Bundled | [Verified] |
| **FR-T-O08** | Onboarding task assignment + status: IT/asset, seating, manager intro, policy acknowledgements — the operational (non-statutory) checklist, so onboarding is one surface not two. | P2 | v1.5 | Bundled | [Hypothesis] |
| **FR-T-O09** | Employee self-service onboarding: the joiner completes their own documents/declarations via the employee app before day one, respecting shared-device and low-bandwidth frontline constraints (§09). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-O10** | Onboarding → payroll register commit: on completion, the employee is added to the active register with effective joining date, and appears in the next ECR/ESI/PT computation for the correct period. | P0 | v1 | Bundled | [Verified] |

**Why onboarding is v1 and the rest of talent is not.** Every FR in §10.8 produces a record the *statutory engine* consumes: the EPF joining declaration decides the joiner's ECR line, the ESI declaration and IP number decide the ESI contribution line, Form 122 (ex-12B) feeds TDS, and the appointment letter is a statutory artefact for every establishment of ten or more workers. A payroll product that cannot onboard a joiner correctly cannot file correctly. Recruiting and performance, by contrast, can be absent from v1 without breaking a single filing. That asymmetry is the phasing rule.

**Acceptance — FR-T-O07 (UAN continuity, the migration-critical one):**

```gherkin
Given a new joiner who declares an existing UAN in the EPF joining declaration
When onboarding is committed
Then the product links the existing UAN to the employee record
And does NOT request or generate a new UAN (no duplicate)
And the first ECR generated for this employee carries the linked UAN
Given a new joiner with no existing UAN in an establishment covered for EPF (§06.1)
Then the joiner is routed to UMANG face-authentication UAN allotment and the case waits for the declared UAN
And an employer-side UAN task is created only for an International Worker or a citizen of Nepal or Bhutan
And an ESI IP registration task (an attended ESIC-portal action) is created if the joiner is ESI-eligible
And an absent or unseeded Aadhaar never blocks the register commit (FR-CHR-101 exclude-and-flag)
Given a joiner with no existing UAN who declines to provide Aadhaar, so cannot use UMANG face authentication
When onboarding is committed
Then the register commit proceeds and the joiner is paid from the first run
And the joiner's line is left out of each ECR while no UAN exists, recorded on the FR-CHR-101 exception register with an operator task and an employee notice saying what was excluded, why and how to fix it
And once a UAN is declared, the product prepares a Supplementary return for each affected wage month (EV-037) showing the system-computed s.7Q interest (EV-039)
And whether the employee share is deducted while the line is excluded follows the counsel-set FR-CHR-101 default, never a product assumption (§23)
```

**[Verified]** appointment-letter duty per OSH Code s.6(1)(f) (EV-057); EPF under the Employees' Provident Funds Scheme 2026, with the 12% rate re-notified for it by S.O. 3582(E) of 01.07.2026 (research r2/10; §06.9); UAN allotment by the employee through UMANG face authentication since 1 August 2025 (EPFO HO circular of 30.07.2025, read from an archived copy of EPFO's own PDF — research r4/04, finding 7; the round-four critic flags it as single-sourced, so pull it from the primary source before customer use). Note the §06 caveat: **the ESI regime after 22 Nov 2026 is unresolved** (§20 V-08, R-2) — FR-T-O03/O07 ESI paths must be effective-dated so they can switch to the successor scheme without a re-build.

**Acceptance — FR-T-O06 (state-prescribed appointment letter at ten or more workers):**

```gherkin
Given a new joiner (fresh hire or migrated employee) in an establishment of 10 or more workers (§06.1 counting unit)
When onboarding is completed
Then an appointment letter is generated in the form configured for that establishment's state, populated from the record (no re-keying)
And if no state form is configured, the letter is generated from the central template and flagged "state form unverified" to the operator
And it is issued and stored against the employee under its §14.7 retention class, whose period is a counsel-set parameter (no statutory period beyond EV-054's central-sphere register figures is stated in this PRD)
And a migrated employee with no appointment letter on file is surfaced as a review task, not as an asserted breach (back-issuance: counsel, §23 CR-37)
```

**Edge case — the migrated employee with no appointment letter on file.** A firm migrating mid-year has employees who joined before the Codes commenced on 21 Nov 2025 and never received a letter in any prescribed form. Whether the OSH Code requires a letter for employees appointed before commencement is not settled in our research, so onboarding-as-migration (§10.8) distinguishes "issue on hire" from "existing workforce without a letter" and surfaces the latter as a counsel-routed review task (§23 CR-37) — never as an asserted statutory breach, and never by silently skipping it. **[Reversed]** Earlier drafts asserted a from-employee-one mandate with a required one-time back-issuance; the duty attaches at ten workers (EV-057) and the back-issuance requirement is unverified.

**Worked example — the mid-year cutover joiner, where onboarding and migration are the same surface.** A 60-person firm migrates to us in September (mid-Tax Year). Its 60 existing employees enter through the *same* onboarding pipeline (§10.8) as a fresh hire, but each carries opening balances a new hire does not: YTD earnings, TDS already deducted by the same employer earlier in the year (not Form 122, ex-12B — same employer, different system), leave balances, gratuity accrual clock, and — critically — an **existing UAN and ESI IP that must be linked, never regenerated** (FR-T-O07). If onboarding regenerates a UAN for a migrated employee, the ECR breaks and the EPFO passbook forks. So FR-T-O07's "link existing UAN" path is not only a new-joiner nicety — it is the mechanism that makes mid-year migration (§16; §05 v1 exit criterion 5) work without a reconciliation break in the annual TDS certificate. Onboarding and migration share one code path; the difference is whether opening balances are zero.

**Edge case — probation confirmation.** A joiner on probation is on the payroll register from day one (FR-T-O10) but their *confirmation* is a performance event (a lightweight probation review, FR-T-P10 cycle type) that may carry a CTC revision on confirmation. The confirmation review therefore feeds the same effective-dated CTC path as an appraisal increment (FR-T-P15) — so probation confirmation is modelled as a performance cycle type, not a separate onboarding step, and its increment (if any) runs through FR-T-P16 arrears logic if confirmation is back-dated.

**Edge case — the ESI-eligibility decision at joining, and the contribution-period lock (FR-T-O07).** ESI applies to employees drawing wages up to **₹21,000/month** (₹25,000 for persons with disability) (Source: ESIC coverage page, limit effective 01.01.2017, fetched September 2026 — research r1/06; §06.3). Onboarding must make this eligibility call at joining because it decides whether an ESI IP registration is raised at all. Two India-specific traps the onboarding→payroll handoff must get right:

- **Mid-period wage crossing.** ESI runs on two fixed **contribution periods** — 1 April–30 September and 1 October–31 March (research r1/06; §06.3). If an employee is ESI-covered at the start of a contribution period and their wages *cross* ₹21,000 mid-period (e.g. an appraisal increment from FR-T-P15), they **remain covered and contributions continue until the end of that contribution period** — coverage does not stop the month the ceiling is breached. So the effective-dated CTC change (FR-T-P16) must not silently drop ESI mid-period; the register keeps contributing to period-end, then re-evaluates. Getting this wrong under-remits ESI and breaks the return.
- **Joining above the ceiling.** A joiner already above ₹21,000 is **not** ESI-eligible, so FR-T-O07 raises no IP registration. If a *later* structure change (rare) brings them under, when coverage begins is not captured in our research — §06.3 verifies only the exit rule — so the entry timing is a named parameter (`esi.entry_on_wage_drop`: from the month of the change, or from the next contribution-period boundary), with no shipped default, routed to §20 alongside V-08. It is the first-entry counterpart of §06.3's `esi.reentry_timing` (an employee back under the ceiling after an exit) and is resolved in the same read; if the statute treats the two alike, the two parameters collapse to one. The eligibility rule must therefore be effective-dated and period-aware, consistent with the §06 caveat that the **entire ESI regime after 22 Nov 2026 is unresolved (§20 V-08, R-2)** — so this ceiling and the period logic are configuration, not hard-coded constants. **[Verified]** on the current ₹21,000 ceiling and contribution-period mechanics; **[Hypothesis]** on the successor regime's ceiling — *kill/validate:* watch ESIC/MoLE notifications before 22 Nov 2026 (§20 V-08); do not hard-code ₹21,000.

**Worked example — the mid-month joiner's first ECR (FR-T-O10).** A joiner starts on **18 September** at ₹40,000/month gross. The register-commit step (FR-T-O10) must place them on the September run with a **prorated** first-month wage under the tenant's configured day-rate convention (§08) — 13 of 30 days on a calendar-day basis, and the first EPF ECR generated for September carries the prorated EPF wage against the **full, linked or newly allotted UAN** (FR-T-O07), not a proxy. The ECR file itself has no date-of-joining field — its eleven fields run from UAN to Refund of Advance (EV-035) — but EPFO accepts contributions only between the member's valid date of joining and date of leaving (EV-040), so an 18 September joining date recorded wrongly on the member's UAN record gets the September line rejected. **[Reversed]** An earlier version of this example placed a "date of joining" field inside the ECR. So the onboarding→register handoff must pass three things atomically to the engine: the effective joining date, the prorated first-period wage basis, and the correct UAN/IP identity. Getting proration right but joining-date wrong (or vice versa) is a rejected filing, which is the failure this module exists to prevent. This is why FR-T-O10 is P0 and v1: it is the exact seam where a talent action becomes a statutory filing input.

**Edge case — the tax-regime election at onboarding, and why the default is now the trap (FR-T-O05).** Since FY2023-24 the **new tax regime has been the default** unless the employee communicates a preference in writing (s.115BAC(6) in 1961-Act numbering — research r1/06 finding 40; §02); an employee must *affirmatively opt for the old regime* to claim HRA exemption, Chapter VI-A deductions (80C/80D/etc.) and home-loan interest. From Tax Year 2026-27 salary TDS falls under s.392 of the Income-tax Act 2025 (ex-s.192 — EV-050); the 2025-Act location of the default-regime rule is not in our mapping and is routed to §20. Onboarding must capture the regime election *before the first payslip*, because the employer deducts salary TDS on the declared regime from month one — a joiner who assumed the old regime but never elected it sees inflated TDS on payslip one, yet another first-month grievance the product exists to prevent. Two rules the handoff must encode: (a) if no election is made, the engine applies the new regime and *surfaces* that the employee left deductions unclaimed (rather than silently defaulting); (b) whether an employee may change the regime intimation mid-year for TDS purposes is unconfirmed in our research, so the engine supports an effective-dated recompute for the balance of the Tax Year behind a tenant policy flag — and because salary TDS averages the year's tax across remaining months on a **cumulative** basis, any such change is a recompute, not a clean-slate reset. This ties directly to the effective-dating requirement of the engine (§06) and to the Form 130 (ex-Form 16) reconciliation at year-end. **[Verified]** the s.392/s.192 mapping (EV-050) and the new-regime default in 1961-Act numbering — the latter read through vendor compliance content, not re-verified against a CBDT circular (r1/06 finding 40), so it rides on the same §20 desk check as the mid-year question below; **[Hypothesis]** on a mid-year change of the intimation — *kill/validate:* confirm the TDS-side rule against the current CBDT employer circular in §20 desk validation before enabling the policy flag.

**Acceptance — FR-T-O05 (tax-regime election at onboarding):**

```gherkin
Given a new joiner at onboarding who makes no tax-regime election
When the first payslip's salary TDS (s.392, ex-s.192) is computed
Then the engine applies the default new regime
And it records and surfaces that no old-regime deductions were claimed (not a silent default)
Given the tenant's policy flag permits a mid-year change and the same employee later elects the old regime within the same Tax Year
Then TDS for the remaining months is recomputed on a cumulative full-year basis, not reset month-by-month
And the regime election and its effective date are stored on the employee record for the Form 130 reconciliation
```

---

### 10.9 FRs — Performance: goals / KRAs / OKRs

Performance is v2 and carries **no per-unit meter** (§10.0 point 1; tier placement per §18). It earns its place in a *payroll* product for exactly one reason: the appraisal outcome becomes a revised CTC that must flow, effective-dated, into the engine (§10.10). Design the whole module backwards from that loop.

<!-- DIAGRAM: goal-to-increment-trace -->

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-P01** | Goal/KRA definition: set individual goals with metric, target, weight, and period; support the KRA/KPI vocabulary Indian firms actually use, not only OKR framing. | P1 | v2 | Bundled | [Verified] |
| **FR-T-P02** | Goal cascade/alignment: link individual goals to team/company objectives so a review can show line-of-sight; optional (many beachhead firms will not use it). | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-P03** | Goal progress updates and check-ins during the cycle, with a lightweight update UI usable from the employee app. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-P04** | Weighted goal scoring that rolls up to a goal-component of the final rating, with the weighting scheme visible to the employee. | P1 | v2 | Bundled | [Verified] |
| **FR-T-P05** | **Goal versioning & mid-cycle change control:** a goal edited mid-cycle (target moved, weight changed, goal added/dropped) creates an audited new version with a reason and, where configured, an approver; the review scores against the goal version *in force for the period*, never a silently-changed target. | P1 | v2 | Bundled | [Verified] |

**Worked example — the mid-year joiner's pro-rata goals.** An employee joins on 1 October, half-way through an April–March cycle. Their goals are set for the six-month in-service window, not the full year, and FR-T-P05 records that window so the review does not penalise them against annual targets they were never set. When the increment outcome (FR-T-P15) is computed, the eligibility band can be prorated or the cycle can mark them "not yet due" — a configuration choice, but one the data model must support, because forcing a six-month employee onto a full-year curve produces a rating the employee can fairly contest. This is the goals-side mirror of the mid-year onboarding case (§10.8): the person entity is continuous, but the *period* they are measured over is not.

**Edge case — the moved goalpost (why FR-T-P05 exists).** A manager, mid-cycle, quietly raises a report's sales target from ₹80L to ₹1.2Cr, then rates them "below expectations" at review for missing ₹1.2Cr. Without versioning this is invisible and indefensible; with FR-T-P05 the review shows the target was ₹80L for the first eight months of the twelve-month cycle and ₹1.2Cr for the last four, and the score is computed against the version in force per period. This is the same integrity principle as effective-dated payroll rules (§10.10, §06) applied to performance data: *what was true when* is auditable, not overwritten. It is also what makes a rating survive a contested exit.

**Acceptance — FR-T-P05 (goal versioning):**

```gherkin
Given an active goal with target T1 and weight W1 in force from the cycle start
When the manager edits the goal to target T2 mid-cycle on date D
Then a new goal version (T2) is created effective D, with a captured reason and, if configured, an approval
And the prior version (T1) is retained, not overwritten
And the review's goal score is computed against the version in force for each sub-period, not only the latest
```

**Acceptance — the pro-rata mid-year joiner (FR-T-P01 × FR-T-P10 × FR-T-P18):**

```gherkin
Given an employee who joined on 1 October, mid-way through an annual (Apr–Mar) cycle
When goals are set and the FY-end review runs
Then goals are scored against the joiner's actual in-service window (Oct–Mar), not the full year
And the increment-eligibility band (FR-T-P18) is prorated or marked "not yet due" per tenant config
And the review record stores the measurement window so a contested rating shows the period actually assessed
```

**Edge case — the beachhead firm where half the workforce has no KRAs.** A 60-person manufacturer has 20 desk staff (who have goals) and 40 plant operators (who do not — their "performance" is attendance, output/piece-rate, quality-rejection rate and safety, not OKRs or KRAs). Forcing a goal-based review on operators is the wrong model and will simply not be used. So the module must support **metric-driven review populations** — a cycle whose scored inputs are operational KPIs sourced from attendance/production (§09) rather than manager-set goals — as distinct from **goal-driven populations** (desk staff on FR-T-P01 KRAs), and a tenant must be able to run one cycle for one population and none for the other (FR-T-P10 population scoping). This matters because the beachhead is not uniformly white-collar and the deskless segment is explicitly in scope (§09); a performance module that only speaks OKR is a desk-worker tool. **[Hypothesis]** on whether beachhead firms run *any* structured performance process for operators — *kill/validate:* if §20 interviews show operator performance is handled entirely through attendance/output in payroll (§09) and never a review cycle, keep FR-T-P10's population scoping but do not build operator-specific review templates ahead of demand (a demand hypothesis; default-safe is defer).

---

### 10.10 FRs — Performance: review cycles, calibration & the payroll feedback loop

<!-- DIAGRAM: performance-review-cycle -->

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-P10** | Configurable appraisal cycle: annual / half-yearly / quarterly / probation-confirmation, with defined windows, populations, and reviewers. | P1 | v2 | Bundled | [Verified] |
| **FR-T-P11** | Review form builder: goal score + competency ratings + qualitative sections, with self-appraisal, manager appraisal, and optional skip-level/reviewer stages. | P1 | v2 | Bundled | [Verified] |
| **FR-T-P12** | 360°/multi-rater feedback (peer, direct-report, manager) as an optional cycle type. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-P13** | **Calibration / normalisation:** support bell-curve or grid-based rating calibration across a population, with a calibration UI for managers/HR — including the ability to run a cycle *without* forced distribution, because bell-curving is contested and many firms reject it. | P1 | v2 | Bundled | [Verified] |
| **FR-T-P14** | 9-box grid (performance × potential) for talent review and succession input. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-P15** | **Increment / promotion outcome → CTC revision:** a completed appraisal produces a revised CTC (increment %, promotion band change) that generates an **increment/promotion letter** and pushes an **effective-dated CTC change** into the payroll engine. | P0 | v2 | Bundled | [Verified] |
| **FR-T-P16** | **Effective-dated retro/arrears from appraisal:** if the increment's effective date precedes the run date (common — appraisals effective 1 April but processed in June), the engine computes arrears against the *rule and structure versions in force for each intervening period*, with an audit trail (ties to §06 effective-dating requirement). | P0 | v2 | Bundled | [Verified] |
| **FR-T-P17** | Variable-pay / performance-bonus payout driven by rating, kept **distinct from statutory bonus** under Code on Wages s.26 (8.33%–20%; eligibility and calculation ceilings set by the appropriate Government — §06.7) — the two must never be conflated in the payslip or the register. | P1 | v2 | Bundled | [Verified] |
| **FR-T-P18** | Rating scale configuration (e.g. 1–5, 1–4, or descriptive bands) per tenant, with a fixed mapping from final rating to increment/promotion eligibility bands, so the review→increment step (FR-T-P15) is deterministic and auditable, not a manager's free choice. | P2 | v2 | Bundled | [Hypothesis] |

**Worked example — the calibration that must survive an audit.** A 120-person firm runs its FY26 cycle and applies a forced bell curve: 10% "outstanding," 20% "exceeds," 60% "meets," 10% "below." A manager rates all six of their reports "exceeds"; calibration (FR-T-P13) forces two down to "meets." The two down-rated employees will each get a smaller increment — a decision that is contestable and, if challenged, must be defensible. So calibration must record **who moved a rating, from what, to what, and why**, immutably. This is also why FR-T-P13 *must* offer a no-forced-distribution mode: bell-curving is contested and many firms reject it, and forcing it on a tenant that rejects it loses the deal. The product's opinion is "support both, default to neither." Where an AI output informs a rating or a calibration move, the move also carries a named confirmer and a decision snapshot (FR-T-D005).

**Acceptance — FR-T-P13 (calibration audit trail):**

```gherkin
Given a calibration session over a population with a chosen distribution mode (forced curve OR no forced distribution)
When a calibrator changes an employee's rating from R_old to R_new
Then the change records the actor, timestamp, R_old, R_new, and a required reason
And the pre-calibration rating is retained alongside the post-calibration rating (never overwritten)
And the employee's final increment eligibility (FR-T-P18) is derived from the post-calibration rating
And the full before/after distribution and every individual move are exportable for an audit or a contested-exit review
```

**Worked example — the appraisal that becomes an arrears run.** An employee is rated in the FY-end cycle; HR calibrates; the outcome is a 9% increment **effective 1 April 2026**, but the cycle only closes and is approved on **10 June 2026**. FR-T-P15 revises the CTC effective 1 April; FR-T-P16 detects that April and May have already been paid at the old CTC and computes two months of arrears — and it does so against the *statutory rule versions in force in April and May* (PF ceiling, PT slab, the 50% add-back version), not June's, because arrears recompute against the period's rules (§06). The June payslip shows current-month salary + April/May arrears as named lines, PF/TDS recomputed correctly. **This is the entire reason performance belongs in this product and not in a standalone tool** — a standalone performance app cannot run a compliant arrears computation; a payroll engine can, if performance feeds it structured, effective-dated outcomes.

**Acceptance — FR-T-P15 / FR-T-P16:**

```gherkin
Given a completed, approved appraisal with increment effective date D_eff
And the current payroll run date D_run where D_run > D_eff
And periods P1..Pn between D_eff and D_run already paid at the prior CTC
When the increment is committed to payroll
Then a new effective-dated CTC record starts at D_eff
And arrears for P1..Pn are computed as (new - old) per period
And each period's arrears use the statutory rule version in force in THAT period
And PF, PT, ESI and TDS on arrears are recomputed and shown as named lines
And an increment/promotion letter is generated and issued to the employee
```

**[Verified]** effective-dating/retro-recompute is a stated non-negotiable engine property (§06.10); statutory-vs-performance-bonus distinction (§06.7). Bonus ceilings: see the FR-T-P17 example below.

**Worked example — the two bonuses that must not be conflated (FR-T-P17).** A 120-person firm pays two things a payslip can carelessly merge into one "Bonus" line, and they are governed by entirely different rules:

1. **Statutory bonus** under Code on Wages s.26, which subsumed the Payment of Bonus Act 1965 — an *obligation*, not a reward. The Code fixes the band — at least 8.33% of wages earned (or ₹100, if higher) for an employee with at least 30 days' work in the accounting year, at most 20%, depending on allocable surplus — and delegates the eligibility and calculation ceilings to the appropriate Government (§06.7). The familiar **₹21,000/month** eligibility ceiling and **₹7,000-or-minimum-wage** calculation ceiling are legacy 2015-amendment figures; no re-notification under s.26 has been located, so they drive only a provisional, labelled computation until the tenant's state ceiling is confirmed (§06.7, §20). **[Reversed]** Earlier drafts marked these ceilings [Verified] under the Payment of Bonus Act as if it were current law. This is a payroll-engine computation, tied to allocable surplus and to the ceilings — it is **not** performance-driven, and a high performer above the eligibility ceiling is simply *ineligible*.
2. **Performance/variable pay** driven by the appraisal rating (FR-T-P17) — a *reward*, discretionary, uncapped, and entirely a management decision.

The rule the payslip and the statutory records must enforce: these appear as **two distinct named lines**; the statutory bonus flows into the bonus records and whatever annual return the period's regime requires (`bonus.annual_return_form` — legacy Form D; the Code-era return is unconfirmed, §06.7), and the performance bonus does not. Under the provisional legacy ceilings, an engineer rated "outstanding" on ₹1,20,000/month wages gets a large *variable payout* and **zero statutory bonus** (above the eligibility ceiling); a ₹18,000/month operator rated "meets" gets a small variable payout *and* a statutory bonus computed on the calculation ceiling (the notified amount or the minimum wage, whichever is higher). Merging them understates the statutory bonus liability in the annual return — a filing error, which is the whole thing this product exists to prevent (§01). **[Verified]** the s.26 band and base structure (§06.7); **[Hypothesis]** the Code-era ceilings and annual return — *kill/validate:* per §06.7, confirm the tenant state's notified ceilings before any post-21.11.2025 accounting year's bonus is paid.

**Acceptance — FR-T-P17 (bonus separation):**

```gherkin
Given an employee with monthly wages W and an appraisal-driven variable payout V
And the eligibility ceiling E_max and calculation ceiling C in force for the tenant's state and accounting year (§06.7)
When the payslip and registers are generated
Then statutory bonus is computed only if W <= E_max
And, if eligible, on a base of min(W, max(C, applicable minimum wage)) at the employer's declared rate in [8.33%, 20%]
And statutory bonus and performance variable V appear as two distinct named lines
And only the statutory bonus posts to the bonus records and the configured annual return
And the two are never summed into a single "Bonus" figure anywhere in the payslip or register
And where E_max or C is a legacy value awaiting confirmation, the computation is labelled provisional
```

---

### 10.11 FRs — Continuous feedback & 1:1s

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-P20** | Lightweight continuous feedback (praise/constructive), attachable to goals; visible in the next review. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-P21** | 1:1 meeting notes and shared agendas between manager and report. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-P22** | Pulse/engagement surveys (anonymous, aggregated) — explicitly a fast-follow, not a differentiator: engagement is the core product of specialists such as Culture Amp and 15Five (pricing pages read in research r2/07, not executed). | P2 | v2 | Bundled | [Verified] |

**[Hypothesis]** for the whole of §10.11: beachhead employers (20–200) may not use continuous-feedback tooling at all — it is mid-market/enterprise behaviour. *Kill/validate:* if §20 interviews show <20% of 50–200 firms want it, defer §10.11 entirely and keep only the review cycle (§10.10). Do not build ahead of demand here; with no per-unit meter on performance (§10.12), no direct revenue line recovers the build cost.

---

### 10.12 Monetisation — deferred items, consolidated, and the metering model

Per §12 and §18.5, the price of talent AI is zero, so **nothing in talent is a premium AI SKU**. What *is* monetisable is recruiting on a unit that is legibly incremental and that does not track headcount. Résumé-screening inference alone spans ~15× between a steady-state tenant (3%/month hiring, 40 CVs per hire, 3,000 tokens per CV) and a recruiting-heavy one (15%/month, 50 CVs, 10,000 tokens) on identical PEPM (research r2/03; the ratio is FX-invariant, the rupee absolutes are placeholders — §13). And incumbents already price recruiting *per recruiter*, not per employee: greytHR Recruit at ₹2,500/recruiter/month (pricing page captured 4 Sep 2026, read not executed — research r1/01, r1/08) and Keka's archived Hiring card at ₹1,500/₹2,500 per recruiter per month (EV-022).

| Surface | Monetisation | Why deferred / how metered | Conf |
| --- | --- | --- | --- |
| **Recruiting module (requisitions, ATS, multi-post)** | **Metered — per requisition or per hire, separate line from PEPM** | Cost scales with hiring velocity, not headcount: résumé screening alone spans ~15× across otherwise identical tenants (r2/03). Never blend into PEPM. Meter the requisition (FR-T-R01/R02) or the hire, per the plan; the price stays zero until §05's v2 turns on metered SKUs (§05.5 item 25), and its value is the §20.13 pricing parameter `recruiting_price_per_requisition` (a per-hire price, if T-2 chooses that unit, joins the same family). | [Verified] cost driver; [Hypothesis] buyer acceptance of either unit — §10.15 T-2 |
| **Job-board multi-post / ingest** | Metered (rolls into recruiting) | Board fees sit on the customer's own contracts (bring-your-own-contract, §10.1); our cost per post and per ingested application is processing and parsing inference (§13) — real, attributable (FR-T-X01) and unsized. | [Hypothesis] — cost unsized until FR-T-X01 data exists |
| **BGV / DigiLocker / UAN checks** | **Metered — per check, pass-through + margin** | Direct third-party vendor cost per check; a natural per-transaction charge, not a subscription. | [Hypothesis] |
| **Bulk document generation (offer/appointment/increment letters at volume)** | Metered above a bundled quota | Named in §18.5 as a legitimate incremental-value monetisation. Bundle a fair-use quota; meter overage. | [Hypothesis] — shares §18.5's kill criterion, §20 V-07 |
| **HR-analyst copilot (talent analytics: funnel, source-of-hire, review insights)** | **Metered — per admin seat** | Named in §18.5. Per-admin-seat, not per-employee: an HRMS is priced per employee but consumed per user (§13). | [Hypothesis] — shares §18.5's kill criterion, §20 V-07 |
| **Performance module (goals, reviews, calibration, feedback)** | **No per-unit meter; tier placement per §18** | **[Reversed]** rationale: the market does not give performance away — every tiered vendor gates it upward (EV-028; greytHR's PMS is a ₹35–45/user/month add-on). Keeping it free of a per-unit meter is a bill-shock wedge (research r1/01), not a response to a zero market price. | [Hypothesis] — tier placement is validated with §18's pricing work (§20) |
| **Onboarding handoff** | **Bundled (in payroll base)** | It produces statutory records; charging for it would be charging to be compliant. | [Verified] |
| **Talent AI assistant (JD drafting, resume summarisation, review-text drafting)** | **Bundled (cost-of-goods)** | AI is architecture, not the revenue line (§12). Never a paid SKU. | [Verified] |

**FR-T-X — metering & attribution (cross-cutting, P0 for the module):**

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-X01** | **Per-tenant recruiting metering built from day one of v1.5:** count requisitions, hires, posts, ingested applications, BGV checks, bulk docs, and copilot-seat usage, attributable per tenant/user/agent/model — *while the price may still be zero* (§13: retrofitting attribution after pricing exists is far harder than building it before). | P0 | v1.5 | — | [Verified] |
| **FR-T-X04** | Per-tenant and per-user rate limits + budget/degrade on all AI-backed talent features (resume parsing, JD/review drafting), because an HRMS is priced per employee but consumed per user (§13). | P0 | v1.5 | — | [Verified] |
| **FR-T-X05** | Recruiting cost dashboard for the tenant: source-of-hire, cost-per-hire, board ROI — the funnel intelligence that makes inbound-only worth paying for (§10.3 worked example). | P1 | v2 | Metered | [Hypothesis] |

**[Verified]** metering-from-v1 and rate-limit rationale are stated P0 requirements in §13 (Source: §13 AI unit economics, this PRD).

---

### 10.13 Cross-cutting acceptance criteria & candidate data protection (the criteria no single FR owns)

Recruiting has a data-protection wrinkle the rest of the HRMS does not: **candidates are not employees**, and two regimes govern their data across the life of this product.

<!-- DIAGRAM: candidate-lawful-basis-lifecycle -->

**[Reversed]** Earlier drafts stated, as current law, that DPDP s.7(i) lets an employer process employee data without consent and that only candidates need it. DPDP's substantive provisions, s.7(i) included, commence only on or about 13 May 2027 (EV-058). **Today** the SPDI Rules 2011 require consent in writing before sensitive personal data is collected — financial information (such as bank details) and biometric information among it — from candidates *and* employees (r.3, r.5(1); EV-060); DPDP itself creates no sensitive category (EV-059). When s.7(i) commences it disapplies consent and notice for employment purposes only, and the s.8 duties still apply (EV-058). Whether "for the purposes of employment" reaches recruitment-stage candidates and background verification is a counsel question (research r4/01; §23 CR-25), so the recruiting module captures candidate consent under both regimes and never relies on s.7(i) for a candidate. Who owes the SPDI written-consent duty is also with counsel; the product captures consent either way (§07 FR-CHR-100; §23).

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-X02** | **Candidate consent capture at point of application** (career site, board ingest), naming purpose (recruitment for this/related roles) and retention period; consent is logged and revocable. Each consent is a versioned record (§07 FR-CHR-100) stating whose artefact it is and which regime it serves; where sensitive personal data is collected (bank details at offer, financial checks at BGV) the SPDI written consent is captured before collection (SPDI r.3 and r.5(1) — EV-060; DPDP itself has no sensitive category — EV-059), using the counsel-cleared notice text for that regime (§23). | P0 | v1.5 | — | [Verified] |
| **FR-T-X03** | **Candidate data retention + erasure:** auto-purge or re-consent rejected-candidate data at the stated retention horizon; honour erasure requests; talent-pool retention (FR-T-R26) requires explicit extended consent. The horizon is a tenant-configured parameter (`candidate_retention_horizon`) whose value is set only on counsel sign-off — neither an immediate purge nor a one-year suppression is hard-coded (§23). Erasure is by crypto-shredding the candidate's subject key or by tombstone (§14.6.1a); a record under a `RetentionHold` (§14; §23 FR-LEG-026) is not erased, and the requester is told it is held. After erasure, any view or reconstruction (FR-T-D002) returns a tombstone — that a record existed, its class, and when and on what basis it was erased — never the content. | P0 | v1.5 | — | [Verified] |
| **FR-T-X06** | On candidate → employee conversion (onboarding commit), the product records the processing basis per regime for each data class. Today (SPDI) the written consents captured as a candidate or at onboarding carry forward and nothing shifts to a no-consent basis; from on or about 13 May 2027 (DPDP), employment-purpose processing may rely on s.7(i) while the consent artefacts stay on file (EV-058, EV-060). The audit trail shows *which basis under which regime* governed the data at each point. | P1 | v1.5 | — | [Hypothesis] |

**Consolidated Given/When/Then acceptance across the talent module:**

```gherkin
# Inbound-only invariant (§10.1)
Given any recruiting feature
When it sources or enriches a candidate
Then it uses only inbound applications, the customer's own board contracts, or LinkedIn's certified partner APIs
And it never searches, proxies, or scrapes a third-party candidate database

# Dedup (FR-T-R12)
Given the same person applies via two connected boards
When both applications are ingested
Then the pipeline shows exactly one candidate record with both source touchpoints

# Candidate consent (FR-T-X02/X03)
Given a candidate applies via the career site
Then consent (purpose + retention) is captured and logged before the record is usable
And on reaching the retention horizon without hire, the record is purged or re-consented, unless a RetentionHold applies (the horizon exists only once counsel sets candidate_retention_horizon — §10.17)

# Offer-to-onboarding continuity (FR-T-R54 -> FR-T-O01)
Given an accepted offer
When onboarding begins
Then CTC structure, personal, and contact data carry forward with zero re-keying

# Appraisal-to-payroll loop (FR-T-P15/P16)
Given an approved increment effective before the run date
Then payroll produces effective-dated arrears computed on each period's own statutory rule version

# Metering (FR-T-X01)
Given any billable recruiting event (requisition, hire, post, BGV check, bulk doc, copilot seat)
Then it is counted and attributed per tenant/user even while its price is zero

# AI-influenced decisions (FR-T-D001, FR-T-D002, FR-T-X11)
Given a candidate rejection at a stage where an AI output was shown to or used by the decider
Then the rejection records a named confirmer, a timestamp and a reason before it commits
And a decision snapshot is written at that moment and is never recomputed
```

---

### 10.13a Notifications, SLAs & the assistant surface (cross-cutting)

Talent is notification-heavy, and every notification is a cost surface (§13) and a frontline-reach constraint (§10.4). These FRs govern the plumbing shared by recruiting, onboarding, and performance.

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-X07** | Multi-channel notifications (in-app, email, WhatsApp) for stage moves, interview invites, offer status, onboarding tasks, review deadlines — with per-tenant channel config and the WhatsApp 250/24h rate-limit + queue (FR-T-R25); per-message WhatsApp cost attributed per tenant for FR-T-X01, and a tenant-level warning, with automatic fallback to email and in-app, if the tenant's WhatsApp Business Account has not moved to INR billing ahead of the 31 December 2026 deadline after which delivery stops (EV-088). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-X08** | SLA timers on approval steps (requisition FR-T-R03, offer FR-T-R52) and on candidate-response windows, with escalation on breach and a dashboard of breached SLAs. | P2 | v2 | Bundled | [Hypothesis] |
| **FR-T-X09** | Talent AI assistant (bundled, cost-of-goods): JD drafting from a requisition, résumé summarisation (FR-T-R22), review-text drafting, and interview-question suggestions — **rules-checked, never authoritative for any statutory or monetary field** (§13 rules-first/LLM-last), and never generating a CTC number, a PF figure, or a rating; runs under the FR-T-X11 rails. | P2 | v2 | Bundled | [Verified] |
| **FR-T-X10** | Every AI-drafted artefact (JD, summary, review text) is clearly marked as draft-for-human-edit and is logged for the per-tenant token/cost attribution required by FR-T-X01 and in the per-person AI disclosure record (FR-T-X11). | P1 | v1.5 | — | [Verified] |
| **FR-T-X11** | **AI safety rails on every talent AI call site** (FR-T-R11 where a model parses, FR-T-R22, FR-T-X09): (a) every outbound model call passes the §12 redaction/tokenisation chokepoint — Aadhaar, PAN, bank account/IFSC and biometric templates denied by default, enforced structurally in the call graph; (b) prompt and completion logs stay in India (log residency — §15, §17), a product decision that also keeps them inside CERT-In's separate requirement to hold 180 days of ICT logs within Indian jurisdiction (EV-062); (c) a per-tenant kill switch and per-feature opt-out, with every talent AI feature **default off** for RBI-, SEBI- and IRDAI-regulated tenants, because silently adding a model vendor can breach a regulated customer's own outsourcing obligations (EV-087); (d) the §12 sub-processor-change gate, wired to per-tenant consent; (e) a per-person AI disclosure record — candidate or employee — written at every call site; (f) a named human confirmer for any output feeding a hiring, appraisal, promotion, PIP or termination decision (FR-T-D001, FR-T-D005). | P0 | v1.5 | — | [Verified] |

**[Verified]** the rules-first / LLM-last invariant and per-tenant cost attribution are P0 platform decisions (§13). Applied to talent: the assistant may *draft* an offer letter's prose but the CTC numbers inside it come only from the deterministic offer builder (FR-T-R50/R51); the assistant may *summarise* a résumé but the parsed statutory fields (PAN, UAN) are human-verified (FR-T-R22, FR-T-O02).

---

### 10.13b Discrimination defensibility — AI-influenced decisions and complaint workflows (FR-T-D)

Recruiting and performance are where an Indian employer's discrimination exposure concentrates, and AI assistance makes that exposure harder to answer, not easier. The legal position these FRs are built on, and the limit on how they may be sold:

- **The duties run characteristic by characteristic; there is no general statute.** RPwD s.3(3) is actor-neutral and reverses the onus: an exclusion is discrimination unless shown to be "a proportionate means of achieving a legitimate aim" (EV-075). RPwD s.20 binds Government establishments only and is not the private-sector hook (EV-075). The Transgender Persons Act 2019 binds every establishment with no size threshold (EV-080); Code on Wages s.3(2)(ii) bars sex discrimination in recruitment at any size (EV-081), subject to a counsel question on whether the Code's exclusion of managerial and administrative staff narrows it for senior hiring (§23.10.2); the HIV and AIDS Act 2017 prohibition binds every employer, with a Complaints Officer at 100+ persons (20+ in healthcare) (EV-082). India has no general private-sector anti-discrimination statute for caste, religion, age or sexual orientation in employment (EV-084, dated September 2026); the SC/ST (Prevention of Atrocities) Act's economic-boycott offence is criminal, and whether an algorithmic rejection could be charged under it is untested and would need proof of imposition, not adverse effect alone — so it is never a product driver on its own (research r5/05 finding 33; §23.10.2).
- **The twenty-person line lands on the ICP floor.** Under RPwD Rule 3(2), a private establishment of twenty or more persons that receives a disability-discrimination complaint must initiate action or tell the complainant *in writing* how the act was a proportionate means of achieving a legitimate aim; the Commissioner disposes of a complaint within 60 days (30 in exceptional cases) (EV-076). No employer can write that letter about a decision no human made and no system can reconstruct.
- **No AI-specific rule we are aware of, and no case law yet.** We are not aware of any Indian statute or rule specific to AI in hiring as of September 2026, and DPDP has no right against automated decisions, to explanation or to human review (EV-066). We are not aware of any Indian case law on algorithmic hiring as of September 2026; the first case will be a matter of first impression (EV-084). MeitY's voluntary AI Governance Guidelines map "discrimination in hiring decisions using AI recruitment tools" to RPwD, the Transgender Persons Act, the Code on Wages and the SC/ST (PoA) Act — an illustrative table — and contemplate hardening voluntary measures into mandatory baselines (EV-073). Indirect discrimination turns on effect, not intent, and no quantitative threshold has been laid down (*Nitisha* — a State-employer case that reaches private employers only by analogy through RPwD s.3(3); EV-083).
- **Positioning: defensibility, never mandate.** RPwD s.90 deems the company and every person in charge guilty, with an express escape for anyone who proves he "had exercised all due diligence" (EV-079). These FRs are how a founder or HR head evidences that diligence. Saying they are legally required is false and checkable (FR-T-D012; §23).

| ID | Requirement | Pri | Phase | Money | Conf |
| --- | --- | --- | --- | --- | --- |
| **FR-T-D001** | **Named human confirmer on every AI-influenced rejection.** A rejection or knock-out at any stage where an AI output (parse, summary, suggested question, ranking) was shown to or used by the decider records a named human confirmer, a timestamp and a free-text reason; without all three the rejection cannot commit. No model output auto-rejects, and no AI shortlist is final. Rationale (defensibility, not a legal mandate — FR-T-D012): at twenty or more persons, a disability-discrimination complaint obliges a written, reasoned response (Rule 3(2) — EV-076), and no employer can write one about a decision no named human made. The control runs for every tenant regardless of size. | P0 | v1.5 | — | [Verified] |
| **FR-T-D002** | **"Reconstruct this decision."** For any candidate decision, produce the criteria applied, the model version and configuration in force, the features that drove any score, the confirmer and the recorded reason — from a snapshot written at decision time, never recomputed, so it survives retraining and configuration changes. It is the evidence for a Rule 3(2) response (FR-T-D008) and for production of records, whose failure is punishable under RPwD s.93 at up to ₹25,000 per offence plus up to ₹1,000 per day of continued failure (EV-079). The snapshot's retention basis, and its interplay with candidate erasure (FR-T-X03) once DPDP commences, go to counsel (§23 CR-39). Opening a complaint case or receiving notice of proceedings places the case's snapshots under a `RetentionHold` that no erasure request or retention expiry releases (§23 FR-LEG-026); an erased snapshot reconstructs only as the FR-T-X03 tombstone, and the reconstruction says so rather than presenting a partial record as complete. | P0 | v1.5 | — | [Verified] |
| **FR-T-D003** | **Adverse-impact monitoring** on shortlist and stage pass-rates (and rating and promotion distributions under FR-T-D005) as a standing employer report, computed only from attributes a candidate or employee has voluntarily self-declared for monitoring, under a separate consent record for that purpose (FR-CHR-100), and never from inferred attributes. Data collected for reasonable accommodation or the Rule 9(1) record (FR-T-D004, FR-T-D007) is not repurposed for it, and HIV status is never collected for it. Results are shown only in aggregate and are suppressed for any cell smaller than a named parameter, `adverse_impact_min_cell_size`, because at 20–200 employees a small cell identifies a person; the value is an owner decision with counsel (§10.17). **No quantitative threshold is committed or presented as a legal line** — no four-fifths or other ratio test — because *Nitisha* declined to lay one down and held that the absence of statistical evidence cannot alone defeat a claim (EV-083). | P1 | v2 | Bundled | [Verified] |
| **FR-T-D004** | **Structural bar on protected attributes.** HIV status, disability status, gender identity, caste and pregnancy/maternity status are never ingested as, or inferred into, a scoring feature, model input, knock-out rule or ranking signal; scoring services have no read path to them. Disability data is collected only for reasonable accommodation and the Rule 9(1) record (FR-T-D007), in a walled store — the CCPD template (EV-077) asks the EOP to state that disability information will not prejudice an application (research r5/05). An accommodation record never carries a charge to the person: RPwD Rule 3(4) bars an establishment from compelling a person with disability to pay any part of the cost of reasonable accommodation (research r5/05 finding 3), so no cost-recovery or payroll deduction may be linked to one. HIV testing is never a pre-requisite for employment (HIV Act s.3(l) — research r5/05). A sex-based criterion in a requisition, knock-out or score is blocked unless the tenant records the statutory prohibition or restriction on women's employment it relies on (Code on Wages s.3(2)(ii) — EV-081). | P0 | v1.5 | — | [Verified] |
| **FR-T-D005** | **The same controls for performance and exit decisions.** Any AI output that feeds an appraisal rating, a calibration move, an increment or promotion recommendation, a PIP or a termination recommendation carries a named confirmer and timestamp (the FR-T-D001 pattern), a reconstruction snapshot (FR-T-D002) and adverse-impact monitoring (FR-T-D003). The CCPD template's reach into performance evaluation is permissive ("could"), so this is defensibility, not compliance (EV-077; research r5/05). On promotion specifically, the product does not rely on RPwD s.20, which binds Government establishments (EV-075; EV-K22); research notes that s.20(3) — no promotion denied merely on the ground of disability — is the one sub-section of s.20 worded without the "Government establishment" qualifier (r5/05 finding 1), and whether it reaches a private employer is a counsel question (§23). The controls apply the same way whatever the answer. | P0 | v2 | — | [Verified] |
| **FR-T-D006** | **Equal Opportunity Policy generator.** Every establishment must publish an EOP (RPwD s.21, Rule 8(1)); content per Rules 8(3)(a)–(e) at twenty or more employees — including the *manner of selection*, filled from the tenant's live AI and confirmer configuration so the published policy cannot drift from what the system does (§23 FR-LEG-022), and a liaison officer for recruitment of persons with disabilities — and the facilities-and-amenities variant of Rule 8(4) below twenty; structured to the CCPD template of 5 November 2024; published on the website or at the premises (Rule 8(2)). Registration under s.21(2) is a document-preparation and correspondence workflow: there is no portal and no prescribed form for private establishments (EV-077). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-D007** | **Disability employment record** holding exactly the five Rule 9(1) particulars — number of persons with disabilities employed and the date from which each is employed; name, gender and address; nature of disability; nature of work rendered; kind of facilities provided — with an export for production on demand. Rule 9(1) applies to the establishments within Rule 8(3), which for a private employer means **twenty or more employees**; production on demand under Rule 9(2) binds every establishment, so below twenty the product keeps the record available but labels it "not prescribed at this size" (research r5/05 finding 7; §23.10.2). **Never Form III** — Rule 14 prescribes it for Government establishments only, and private establishments have no prescribed format (EV-078). Failure to produce is the s.93 exposure (EV-079). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-D008** | **RPwD Rule 3(2) complaint workflow.** For a private establishment of twenty or more persons, a disability-discrimination complaint opens a case with exactly two exits — initiate action under the Act, or issue a written reasoned response on how the act was a proportionate means of achieving a legitimate aim — assembled from FR-T-D002 snapshots. The case tracks the Commissioner's 60-day disposal clock (30 days in exceptional cases) (EV-076); the employer's internal response target is a named parameter (`rpwd_response_target_days`), because no employer-side deadline is in our evidence. Intake is the single statute-routing intake of §23 FR-LEG-025, so a tenant below twenty persons sees no Rule 3(2) case type and a complaint engaging two statutes opens linked cases. | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-D009** | **Transgender Persons Act complaint officer and EOP** for every establishment, with no size threshold: designation of a complaint officer (s.11, Rule 13(1)), complaint intake, and the Rule 13 clocks as configurable parameters with these defaults — designation within 30 days (`tg.designation_days`), enquiry within 15 days of a complaint (`tg.enquiry_days`), action within a further 15 days (`tg.action_days`), grievance resolution within 30 days (`tg.resolution_days`); and the Rule 12 equal opportunity policy for transgender persons, published on the website or at conspicuous places and covering infrastructure (including unisex toilets), applicability of service conditions, confidentiality of gender identity and complaint-officer details (EV-080; Rules 12–13 from a legal-database reproduction of G.S.R. 592(E) dated 25 September 2020, consistent with the Supreme Court's summary in *Jane Kaushik* — research r5/05 findings 27–28; pull from the primary source before customer use, and never quote rule text in customer copy until then). *Jane Kaushik* directed the States and Union Territories to ensure every establishment designates a complaint officer (direction 199(iv) — research r5/05 finding 27; the case is EV-083). The Act's s.18 does not criminalise employment discrimination; the remedy runs through the complaint officer, Rule 13 and writ proceedings (r5/05 finding 25) — so no copy threatens a criminal penalty. That reading is of the Act as it stands: the 2026 Amendment is reported to add new offences, including one relating to employment exploitation, whose text research has not verified (r5/05 finding 25), so the s.18 position is re-read when the Amendment commences. EOP and onboarding copy that turns on the protected-class definition carries a version flag for the 2026 Amendment, which commences only on separate notification and narrows the class (EV-080; §23 CR-40). | P1 | v1.5 | Bundled | [Verified — mirror] |
| **FR-T-D010** | **HIV and AIDS Act workflows.** Complaints Officer designation and intake for establishments of 100 or more persons (20 or more in healthcare); for every employer, a documented-justification pack that must exist before any termination of a protected person — the independent healthcare provider's written assessment and the employer's written statement of hardship — because without them the Act presumes against the employer (EV-082; research r5/05). The s.3 prohibition is enforced by a State-appointed Ombudsman, and failure to comply with an Ombudsman's order is punishable with a fine of up to ₹10,000 plus up to ₹5,000 for each day it continues (s.38 — r5/05 finding 31), so the workflow tracks any Ombudsman order as a case with its own compliance date. | P2 | v2 | Bundled | [Verified] |
| **FR-T-D011** | **POSH Internal Committee record.** Every employer constitutes an Internal Committee (POSH Act s.4(1)); the ten-worker line is s.6(1)'s route to the district Local Committee where no IC exists, not an exemption (EV-056). The product holds the IC constitution order and membership and a complaint intake that routes to the IC; a tenant below ten workers is shown the Local Committee route instead (§23 FR-LEG-025). POSH is a harassment statute, not a hiring-discrimination duty (research r5/05). The IC's further duties — including any annual report — are not re-verified in research, so no feature beyond the record and intake is built until they are (§23 CR-49). | P1 | v1.5 | Bundled | [Verified] |
| **FR-T-D012** | **Claims control.** No product copy, sales collateral or in-app text describes an FR-T-D control as legally required, or cites a foreign decision or a not-yet-in-force DPDP provision as current Indian law; customer-facing legal statements about these controls are product surface with a named owner and require clearance (§23). The sanctioned framing is the s.90 due-diligence defence (EV-079). | P0 | v1.5 | — | [Verified] |

---

### 10.13c Consolidated FR index (traceability)

Every talent FR, its phase, priority, monetisation, and the primary section that owns its acceptance criteria — so downstream (test plan, roadmap, pricing) can trace each requirement without re-reading the prose.

| FR | Title (short) | Pri | Phase | Money |
| --- | --- | --- | --- | --- |
| FR-T-R01 | Create requisition | P0 | v1.5 | Metered |
| FR-T-R02 | Multi-opening requisitions | P1 | v1.5 | Metered |
| FR-T-R03 | Requisition approval workflow | P1 | v1.5 | Bundled |
| FR-T-R04 | Budget/headcount guardrail | P2 | v2 | Bundled |
| FR-T-R05 | Requisition templates/cloning | P2 | v2 | Bundled |
| FR-T-R06 | Statutory-crossing nudge | P1 | v1.5 | Bundled |
| FR-T-R07 | Employment-type statutory classification | P1 | v1.5 | Bundled |
| FR-T-R10 | Job-board multi-post | P0 | v1.5 | Metered |
| FR-T-R11 | Application ingest | P0 | v1.5 | Metered |
| FR-T-R12 | Cross-source dedup | P0 | v1.5 | Bundled |
| FR-T-R13 | LinkedIn RSC/Apply/Job-Post API | P1 | v1.5 | Metered |
| FR-T-R14 | Naukri post+sync (no search) | P0 | v1.5 | Metered |
| FR-T-R15 | CSV/email board fallback | P2 | v2 | Free-acq |
| FR-T-R16 | Career site + consent capture | P1 | v1.5 | Free-acq |
| FR-T-R17 | Employee referral portal | P2 | v2 | Bundled |
| FR-T-R18 | No-scrape enforcement | P0 | v1.5 | — |
| FR-T-R20 | Pipeline stages | P0 | v1.5 | Bundled |
| FR-T-R21 | Candidate profile | P0 | v1.5 | Bundled |
| FR-T-R22 | Résumé parsing | P1 | v1.5 | Bundled |
| FR-T-R23 | Screening/knockouts | P1 | v1.5 | Bundled |
| FR-T-R24 | Bulk actions | P1 | v1.5 | Bundled |
| FR-T-R25 | Candidate comms (WA rate-limited) | P1 | v1.5 | Bundled |
| FR-T-R26 | Talent pool | P2 | v2 | Bundled |
| FR-T-R27 | Recruiter/HM collaboration | P2 | v2 | Bundled |
| FR-T-R28 | Rejection-reason taxonomy | P2 | v2 | Bundled |
| FR-T-R29 | Same-req duplicate guard | P2 | v1.5 | Bundled |
| FR-T-R30 | Interview scheduling | P1 | v1.5 | Bundled |
| FR-T-R31 | Interview kits/scorecards | P2 | v2 | Bundled |
| FR-T-R32 | Interview feedback capture | P1 | v1.5 | Bundled |
| FR-T-R33 | Video-interview link | P2 | v2 | — |
| FR-T-R34 | Panel interviews | P2 | v2 | Bundled |
| FR-T-R35 | Interviewer load view | P2 | v2 | Bundled |
| FR-T-R36 | Reschedule / no-show handling | P2 | v2 | Bundled |
| FR-T-R40 | BGV orchestration | P2 | v2 | Metered |
| FR-T-R41 | DigiLocker document pull | P2 | v2 | Metered |
| FR-T-R42 | UAN prior-employment signal | P2 | v2 | Metered |
| FR-T-R43 | BGV consent + adverse-action | P2 | v2 | Bundled |
| FR-T-R50 | Offer builder | P0 | v1.5 | Metered |
| FR-T-R51 | 50%-add-back offer validation | P0 | v1.5 | Bundled |
| FR-T-R52 | Offer approval workflow | P1 | v1.5 | Bundled |
| FR-T-R53 | Offer-letter generation + e-sign | P1 | v1.5 | Bundled |
| FR-T-R54 | Acceptance → pre-boarding record | P0 | v1.5 | Bundled |
| FR-T-R55 | Notice-period/reneg tracking | P2 | v2 | Bundled |
| FR-T-R56 | Joining-bonus/notice-buyout clawback | P2 | v2 | Bundled |
| FR-T-O01 | Onboarding case (no re-key) | P0 | v1 | Bundled |
| FR-T-O02 | Statutory joining docs | P0 | v1 | Bundled |
| FR-T-O03 | EPF/ESI joining declarations + nomination | P0 | v1 | Bundled |
| FR-T-O04 | Previous-employer income (Form 122, ex-12B) | P0 | v1 | Bundled |
| FR-T-O05 | Investment declaration | P1 | v1 | Bundled |
| FR-T-O06 | State-prescribed appointment letter (10+ workers) | P0 | v1 | Bundled |
| FR-T-O07 | UAN link / UMANG routing + ESI IP | P0 | v1 | Bundled |
| FR-T-O08 | Operational onboarding tasks | P2 | v1.5 | Bundled |
| FR-T-O09 | Employee self-service onboarding | P1 | v1.5 | Bundled |
| FR-T-O10 | Commit to payroll register | P0 | v1 | Bundled |
| FR-T-P01 | Goal/KRA definition | P1 | v2 | Bundled |
| FR-T-P02 | Goal cascade/alignment | P2 | v2 | Bundled |
| FR-T-P03 | Goal progress/check-ins | P2 | v2 | Bundled |
| FR-T-P04 | Weighted goal scoring | P1 | v2 | Bundled |
| FR-T-P05 | Goal versioning / mid-cycle change control | P1 | v2 | Bundled |
| FR-T-P10 | Appraisal cycle config | P1 | v2 | Bundled |
| FR-T-P11 | Review form builder | P1 | v2 | Bundled |
| FR-T-P12 | 360°/multi-rater | P2 | v2 | Bundled |
| FR-T-P13 | Calibration (forced + none) | P1 | v2 | Bundled |
| FR-T-P14 | 9-box grid | P2 | v2 | Bundled |
| FR-T-P15 | Increment → CTC revision | P0 | v2 | Bundled |
| FR-T-P16 | Effective-dated arrears | P0 | v2 | Bundled |
| FR-T-P17 | Perf bonus ≠ statutory bonus | P1 | v2 | Bundled |
| FR-T-P18 | Rating scale config | P2 | v2 | Bundled |
| FR-T-P20 | Continuous feedback | P2 | v2 | Bundled |
| FR-T-P21 | 1:1 notes/agendas | P2 | v2 | Bundled |
| FR-T-P22 | Pulse/engagement surveys | P2 | v2 | Bundled |
| FR-T-X01 | Recruiting metering from day 1 | P0 | v1.5 | — |
| FR-T-X02 | Candidate consent capture | P0 | v1.5 | — |
| FR-T-X03 | Candidate retention/erasure | P0 | v1.5 | — |
| FR-T-X04 | Rate limits/budget on AI | P0 | v1.5 | — |
| FR-T-X05 | Recruiting cost dashboard | P1 | v2 | Metered |
| FR-T-X06 | Per-regime processing-basis record | P1 | v1.5 | — |
| FR-T-X07 | Multi-channel notifications | P1 | v1.5 | Bundled |
| FR-T-X08 | SLA timers/escalation | P2 | v2 | Bundled |
| FR-T-X09 | Talent AI assistant (bundled) | P2 | v2 | Bundled |
| FR-T-X10 | AI-draft marking + cost log | P1 | v1.5 | — |
| FR-T-X11 | Talent AI safety rails | P0 | v1.5 | — |
| FR-T-D001 | Named confirmer on AI-influenced rejection | P0 | v1.5 | — |
| FR-T-D002 | Reconstruct-this-decision snapshot | P0 | v1.5 | — |
| FR-T-D003 | Adverse-impact monitoring (no threshold) | P1 | v2 | Bundled |
| FR-T-D004 | Protected-attribute structural bar | P0 | v1.5 | — |
| FR-T-D005 | Same controls for performance/exit | P0 | v2 | — |
| FR-T-D006 | EOP generator (Rules 8(3)/8(4)) | P1 | v1.5 | Bundled |
| FR-T-D007 | Rule 9(1) disability record | P1 | v1.5 | Bundled |
| FR-T-D008 | Rule 3(2) complaint workflow | P1 | v1.5 | Bundled |
| FR-T-D009 | Transgender Act complaint officer | P1 | v1.5 | Bundled |
| FR-T-D010 | HIV/AIDS Act workflows | P2 | v2 | Bundled |
| FR-T-D011 | POSH IC record | P1 | v1.5 | Bundled |
| FR-T-D012 | Claims control | P0 | v1.5 | — |

**Count:** 94 FRs — 30 P0, 33 P1, 31 P2; 8 v1, 45 v1.5, 41 v2. The **v1** set is exactly the onboarding-handoff statutory core (8 FRs: FR-T-O01–O07 and O10); the operational onboarding tasks (O08) and self-service onboarding (O09) are v1.5, as are the cross-cutting metering/consent/dedup dependencies (FR-T-X01–X04, X02/X03, X06) and the AI rails and decision controls (FR-T-X11, FR-T-D001/D002/D004/D012) that must exist before v1.5 recruiting turns on. Note the shape: **every P0 is either onboarding (statutory), the metering/consent/dedup/offer-integrity plumbing, or a control on AI-influenced decisions** — nothing "recruiting-feature-shiny" is P0, which is the phasing thesis made concrete. (Verify: the 94-row index above and the detailed FR spec tables in §10.2–§10.13b carry identical Pri/Phase/Money values — this index is generated to mirror them, not to diverge.)

---

### 10.14 Non-goals for talent (recorded so they are not resurrected)

| **[No]** | What | Why |
| --- | --- | --- |
| **[No]** | **Reselling / proxying Resdex or any candidate-database search** | We are not aware of any published licensing path for third-party ATSs as of September 2026, and Info Edge markets in-ATS Resdex search as exclusive to its own ATS; the only extraction path found is scraping, which is legal exposure (§10.1, §16). Build inbound-only. |
| **[No]** | **Any scraping of Naukri, LinkedIn, or other candidate databases** | Explicitly forbidden in architecture and collateral (§16); FR-T-R18 enforces. |
| **[No]** | **A premium AI SKU for talent** (JD-writer, résumé-AI, review-AI as paid add-ons) | Seven vendors price HR AI at zero (§12); a surcharge on an expected feature reads as a surcharge. Bundle it. |
| **[No]** | **A per-unit meter on performance management** | Not because the market gives it away — it does not; every tiered vendor gates performance upward (EV-028) — but because talent add-ons are the market's most predictable bill shock and removing it is the wedge (§10.0). Tier placement is §18's decision. |
| **[No]** | **Marketing the FR-T-D controls as legally required** | False and checkable: we are not aware of any Indian AI-specific hiring rule as of September 2026, and DPDP has no right to explanation (EV-066, EV-084). Sell defensibility — the RPwD s.90 due-diligence defence (EV-079; FR-T-D012). |
| **[No]** | **A first-party video-interview product** | Integrate Meet/Teams/Zoom (FR-T-R33); building video is scope with no moat. |
| **[No]** | **Building talent before the beachhead payroll is stable** | Talent is the wedge, not the spine (§05). Only onboarding handoff (§10.8) is v1, and only because it produces statutory records. |
| **[No]** | **Job-distribution to boards the customer has no contract with** | We are bring-your-own-contract (§10.3). We do not resell board access. |

---

### 10.15 Open questions & validation hooks (feeds §20)

These gate build decisions in §10 and must be answered from the field, not this document.

| # | Question | Gates | Kill/validate criterion |
| --- | --- | --- | --- |
| T-1 | How many, and which, job boards does the median 20–200 employer actually pay for? | The FR-T-R10 connector matrix breadth | If < 3 boards used by the median, cut the connector matrix to the top 2 + CSV fallback (FR-T-R15). |
| T-2 | Is recruiting metered *per requisition* or *per hire* acceptable to buyers, and at what price? | The entire recruiting monetisation model (§10.12) | If neither unit is acceptable and buyers expect recruiting bundled free, treat recruiting as pure acquisition and drop metering (keep FR-T-X01 attribution regardless). |
| T-3 | Does a compliant candidate-consent path exist for the UAN prior-employment check (FR-T-R42)? | Whether FR-T-R42 is built at all | If no gazette/portal-cited consent path exists, drop FR-T-R42; keep FR-T-R40 vendor checks only. |
| T-4 | Do beachhead firms want continuous feedback / pulse (§10.11), or only annual reviews? | §10.11 build | If < 20% want it, defer §10.11 entirely; ship review cycle (§10.10) only. |
| T-5 | Will HR admins accept BGV/DigiLocker as a metered pass-through, and which vendor? | §10.6 monetisation and vendor choice | If BGV is expected free/bundled, keep orchestration but zero-rate it as acquisition. |
| T-6 | Is bell-curve calibration (FR-T-P13) demanded, rejected, or both across the beachhead? | The calibration UI investment | Ship both forced-distribution and no-distribution modes regardless (already specified); this question only prioritises which is default. |

**Standing rule reminder (§02):** no talent competitive or statutory claim (board APIs, Resdex profile counts, candidate data-protection obligations under SPDI and DPDP, Code on Wages bonus ceilings, the state-prescribed appointment-letter form, any discrimination-law statement) ships to a website, deck, or contract without a gazette / notified-rule / vendor-page citation captured with URL and date, and a corrigendum check; legal statements additionally need counsel clearance (§23). The ESI-regime uncertainty after 22 Nov 2026 (§06.3, §20 V-08) directly affects FR-T-O03/O07 and must be effective-dated, not hard-coded.

---

### 10.16 Hypothesis ledger (every [Hypothesis] FR, with its kill/validate criterion)

Per §10.0, no `[Hypothesis]` marker in this section is orphaned. The load-bearing ones are argued inline in their sections and in §10.15; this ledger consolidates the remainder so each is traceable. **Type:** `D` = demand hypothesis (does the beachhead want it — default-safe = defer, don't build ahead of demand); `M` = mechanism hypothesis (does a compliant technical/legal path exist — default-safe = don't build until a citation confirms it). Where a §10.15 open question already gates the FR, it is cross-referenced rather than restated.

| FR | Type | Hypothesis | Kill / validate criterion |
| --- | --- | --- | --- |
| FR-T-R03 | D | A 20–200 firm wants a configurable multi-step requisition approval chain | Ship single-approver as default; keep the chain optional. Validate in §20: if the median beachhead uses ≤1 approver, do not build parallel/serial routing depth. |
| FR-T-R04 | D | Finance-owned headcount budgets exist to guardrail against | Build only if beachhead firms maintain a headcount-budget object per cost-centre; if budgets are informal, defer — a guardrail with no ceiling to check is dead code. |
| FR-T-R15 | D/M | A board the customer uses will lack an API/ingest connector | Gated by §10.15 T-1. Build the CSV/email fallback only if a used board has no connector; if the top 2 boards cover the median employer, defer. Until foundit, apna and Indeed each have a captured posting and ingest path (FR-T-R10), the fallback is how those boards are served at all — so if any of them is in the median employer's mix, the fallback is not deferrable. |
| FR-T-R17 | D | Referral hiring is a meaningful channel for the beachhead | Validate in §20: if referrals are <15% of hires at 50–200 firms, defer the portal; the payroll-payout hook (§08) is trivial to add later. |
| FR-T-R23 | D | Knockout/screening questions earn their build for beachhead volumes | Keep for high-applicant blue/grey-collar reqs (volume per requisition measured from v1.5 ingest data — FR-T-R24); if beachhead desk roles draw low volumes, ship simple flagging, not auto-reject. Knock-outs stay deterministic candidate-answered rules either way (FR-T-D001, FR-T-D004). |
| FR-T-R27 | D | Hiring managers will engage inside the ATS | If HMs delegate entirely to recruiters (common at 20–200), defer collaboration depth; keep a single advance/reject email action. |
| FR-T-R28 | D | Structured rejection reasons are used, not skipped | Build alongside FR-T-X05 analytics — the taxonomy is only worth capturing if the funnel dashboard consumes it. Defer if X05 defers. |
| FR-T-R31 | D | Structured interview kits are wanted over gut-feel hiring | §10.5 India note: ranked *below* interviewer-load (R35). Validate demand; if beachhead prefers speed to rubric, keep kits optional. |
| FR-T-R34 | D | Panel interviews with independent scorecards are run at this size | Mechanism specified (acceptance in §10.5). Demand: build if panels are common; else the anti-anchoring rule still applies to sequential single interviews. |
| FR-T-R35 | D | Interviewer load is a real hiring-velocity bottleneck | §10.5 argues yes (the senior team *is* the interviewer pool). Validate: if scheduling conflicts are rare, downgrade to a simple availability view. |
| FR-T-R36 | D | No-show/reschedule rates justify dedicated handling | Low build cost; likely keep. Validate against measured no-show rate in §20; if negligible, fold into generic stage-move logging. |
| FR-T-R40 | D | Buyers accept BGV as a metered pass-through, and which vendor | Gated by §10.15 T-5. If BGV is expected free/bundled, keep orchestration but zero-rate it as acquisition. |
| FR-T-R41 | D/M | Buyers pay for DigiLocker document pull as a metered check, over a partner-API path that exists | The API path is itself uncaptured in research (§10.6) — confirm with a dated capture before build; Aadhaar is excluded regardless (EV-070). Monetisation gated by §10.15 T-5; zero-rate if expected bundled. |
| FR-T-R42 | M | A compliant candidate-consent path to UAN service history exists | Inline kill criterion (§10.6) + §10.15 T-3. Drop if no gazette/portal-cited consent path exists; fall back to FR-T-R40 employment checks. |
| FR-T-R55 | D | Reneg/no-join rates justify a prediction nudge | Reneg rates are reported as a pain but unmeasured in our research; the *nudge model* needs joined-vs-reneged data to be non-arbitrary. Ship auto-reopen first; gate the predictive nudge on having data. |
| FR-T-R56 | D | Joining bonuses / notice-buyouts with clawback are common enough to model | If rare in the 50–200 desk segment, keep clawback as a manual recoverable-advance entry, not a first-class offer object. Validate in §20. |
| FR-T-P02 | D | Beachhead firms cascade goals to company/team objectives | Many will not. Ship goals flat; make cascade optional. Defer default-on until mid-market expansion (200+). |
| FR-T-P03 | D | Mid-cycle goal check-ins are used | Tied to §10.15 T-4 (continuous vs annual). Defer if firms run annual-only reviews. |
| FR-T-P12 | D | 360°/multi-rater feedback is wanted at 20–200 | Mid-market behaviour. Optional cycle type; defer default until §20 shows demand. |
| FR-T-P14 | D | 9-box talent review is used by the beachhead | Enterprise/succession behaviour. Defer until 200+ expansion; the data model (perf × potential) is cheap to reserve. |
| FR-T-P18 | M/D | A fixed rating→increment-band mapping makes review→CTC deterministic | Mechanism is sound and required for auditable FR-T-P15. Build with P15; the hypothesis is only whether tenants want the mapping fixed vs advisory — default to advisory-with-override. |
| FR-T-P20 | D | Continuous feedback tooling is used by 20–200 firms | §10.11 whole-section kill: if §20 shows <20% of 50–200 firms want it, defer §10.11 entirely. |
| FR-T-P21 | D | 1:1 notes/agendas are wanted | Same §10.11 kill as P20. Defer with the rest of continuous-feedback if demand is <20%. |
| FR-T-O08 | D | Customers want operational (non-statutory) onboarding tasks in one surface | Low risk, high "single surface" value. Build if it prevents a second tool; the *statutory* onboarding (§10.8) ships regardless. |
| FR-T-X05 | D | Recruiting cost/funnel analytics is worth paying for (metered) | Gated by §10.15 T-2 monetisation. Value is argued in §10.3 (source-of-hire is the reason inbound-only works). Build with recruiting; meter per §10.12. |
| FR-T-X06 | M | The per-regime processing-basis record at conversion is legally sound as designed | Validate with counsel (§23) before v1.5 recruiting GA — including whether s.7(i) reaches candidates and whether SPDI consent must be re-taken at conversion; low build cost, keep. Never assume an automatic shift to a no-consent basis. |
| FR-T-X08 | D | Approval/response SLA timers matter to buyers | Defer to v2. Build if §20 buyers cite slow approvals as a pain; the audit trail (FR-T-R03/R52) exists regardless. |

**How to read this ledger against the build plan.** Every FR here is P1 or P2 and nearly all are v2 — i.e. *none of the phasing-critical v1/v1.5 P0 work rests on an unvalidated hypothesis*. The v1 onboarding set (§10.8) and the v1.5 P0 plumbing (dedup, offer-integrity, metering, consent, AI-decision controls) are all `[Verified]`. That is deliberate: hypotheses are permitted to gate *fast-follow* scope, never the statutory spine or the money/consent plumbing that must be right from day one (§08, §10.13).

---

### 10.17 Talent parameter register (routes to §20.13)

Every value this section declines to state is a named parameter. §20.13 holds the sizing register and requires every parameter a section routes there to join exactly one family, with its route, when it is introduced; this table is that joining for §10. It holds no values except the four Transgender Persons Rules defaults, which come from a mirror-sourced reading (FR-T-D009) and are overridable. A parameter with no value blocks only the feature that reads it, never the module.

| Parameter | Read by | §20.13 family | Route to a value | Owner | Behaviour while unset |
| --- | --- | --- | --- | --- | --- |
| `apprentice_excluded_from_counts` | FR-T-R06, FR-T-R07 | Central labour reference values | V-21 (the apprentice exclusion, §06.13) | Statutory | Defaults to *false*: apprentices count, and a crossing banner carries the "unconfirmed" qualifier |
| `apprentice_stipend_floor`, `apprentice_engagement_band` | FR-T-R07 (apprentice requisitions) | Central labour reference values | Apprentices Act and rules, desk read | Statutory | No floor or band check runs; the requisition shows "not configured" |
| `fte_gratuity_qualifying_service` | FR-T-R07, offer builder gratuity line | Central labour reference values | V-21 (fixed-term gratuity at one year, §06.6, §06.13) | Statutory | The offer shows the pro-rata rule with the qualifying-service condition flagged "unconfirmed"; any gratuity computation resting on it routes to operator review (V-21's rule) |
| `addback.employer_pf_in_test` | FR-T-R51 | Central labour reference values | Desk read plus counsel (§06.10; §23) | Statutory, then Legal | Neither reading is assumed: the offer shows both add-back bases side by side, labelled provisional, and the recruiter acknowledges the higher one |
| `esi.entry_on_wage_drop` | FR-T-O07 | Central labour reference values | V-08, with §06.3's `esi.reentry_timing` | Statutory | No automatic ESI entry on a wage drop; an operator task is raised instead |
| `epf.form_catalogue` (owned by §06.2), `esi.form_catalogue` | FR-T-O03, FR-T-O07 | Central labour reference values | §06.13 desk read of the EPF Scheme 2026 forms (V-21); V-08 for the ESI regime | Statutory | The legacy form names are shown, labelled "legacy name, not re-captured"; capture of the declarations themselves never waits on the identifier |
| `bonus.annual_return_form` | FR-T-P17 | Central labour reference values | V-21 (Code on Wages s.26, §06.7) | Statutory | Statutory bonus is computed and labelled provisional; no return artefact is generated |
| `perq.meal_per_meal_cap`, `perq.gift_voucher_annual_cap` | Offer builder FBP section (FR-T-R50) | Tax reference values | V-18 | Statutory | Current EV-019 figures apply as effective-dated values with their conditions enforced, marked [Hypothesis] until V-18 closes |
| `fixed_point.max_iterations`, `fixed_point.tolerance` | FR-T-R51 (employer-PF loop, net gross-up) | Engine numerics | §06.14 golden vectors | Eng / Statutory | The offer builder uses the engine's accepted setting (§08 FR-PAY-211); no talent-specific override exists, and until a setting is accepted the employer-PF loop and net gross-up are unavailable in the offer builder |
| `recruiting_price_per_requisition` | §10.12 recruiting meter | Pricing and commercial | V-07 and §10.15 T-2 | Founder / GTM | Zero: events are counted (FR-T-X01), nothing is billed |
| `candidate_retention_horizon` | FR-T-X03, FR-T-R26 | Retention (`retention.*`) | Counsel (Part D-9, D-11) | Legal | No automatic purge or suppression runs (Part D-9); erasure requests and consent withdrawals are still honoured under FR-T-X03 |
| `bulk_action_max_batch` | FR-T-R24 | Owner decision (product configuration) | Sized from v1.5 ingest volumes | Product | A conservative batch limit set by Product before launch, logged with its reason |
| `no_show_repeat_threshold` | FR-T-R36 | Owner decision (product configuration) | §20 measurement of the beachhead no-show rate | Product | The repeat-no-show flag is off; no-shows are still recorded |
| `adverse_impact_min_cell_size` | FR-T-D003, FR-T-D005 | Owner decision, with counsel | Counsel on re-identification risk at 20–200 heads (§23) | Product + Legal | The adverse-impact report does not render |
| `rpwd_response_target_days` | FR-T-D008 | Owner decision, with counsel | Tenant policy; counsel on whether any employer-side period applies (§23) | Legal | The case shows the Commissioner's 60-day clock (EV-076) and no internal target |
| `tg.designation_days`, `tg.enquiry_days`, `tg.action_days`, `tg.resolution_days` | FR-T-D009 | Central labour reference values | Gazette text of G.S.R. 592(E), replacing the mirror reading (r5/05 finding 28) | Statutory | Mirror-sourced defaults 30 / 15 / 15 / 30 days apply and are labelled "pending primary source" |

Three families in this table — "Owner decision (product configuration)", "Owner decision, with counsel", and the talent use of "Retention" — are not yet rows of §20.13's register; §20 adds them when it next revises the register, and until then this table is their record. Two statutory values in this section are deliberately not parameters here because their owning sections already carry them: the add-back threshold (0.5 today, a notified variable in the §06.10 rule payload) and the ESI wage ceiling (§06.3, effective-dated and never hard-coded — §10.8).

**Acceptance — the register:**

```gherkin
Given any backticked configuration parameter that appears in §10 (entity field names in §10.1a are not parameters)
Then it appears in this table with a family, a route, an owner and its behaviour while unset
And no section-§10 feature ships reading a value that has neither a dated source nor a recorded owner decision
And a parameter whose route is counsel is set by no one other than the named Legal owner
```
