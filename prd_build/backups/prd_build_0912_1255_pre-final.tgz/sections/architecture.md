## 15. System Architecture & Multi-Tenancy

This section specifies the **system architecture as a set of components, responsibilities
and data flows** — not code, not a database schema (that is §14), not a service-by-service
API contract (that is §16). It answers four questions the rest of the PRD assumes an answer
to: *how are the parts arranged, how is one customer's data kept apart from another's, how
does a single statutory rule that changes on a gazette date propagate correctly to a payroll
run for a period three months in the past, and where does the data physically sit when a
bank asks.*

Five decisions taken elsewhere in this PRD are load-bearing here and are stated once rather
than re-argued per component:

- **Rules-first, LLM-last (§12/§13, [Verified]).** No statutory or monetary figure is ever
  model-generated. The architecture therefore has a *deterministic core* (the statutory-rules
  engine and payroll engine) and a *probabilistic edge* (the AI orchestrator). They are
  different trust domains with a hard boundary between them, not two layers of one stack.
- **The filing, not the payslip, is the unit of delivery (§01, [Verified]).** The system's
  primary durable artefact is a *filing* — an ECR, an ESI contribution upload, a PT return,
  a Form 138 — delivered as a **portal-accepted artefact plus attended, assisted submission
  under the employer's written authority to act**. Every statutory surface is an attended
  portal with no API today (EPFO interactive login with CAPTCHA; TDS, where the deductor runs
  the FVU and uploads; ESIC template upload; state PT across many manual portals), and the
  employer's and deductor's statutory liability is non-delegable (EV-030, EV-035–038;
  runbooks in §22). Whether an operator may act on those portals under the employer's
  credentials — portal terms of use, the e-Return Intermediary route for TDS, the authorised
  signatory's personal DSC — is under counsel review (Part D-17; §23 CR-17; §20 V-25), so
  the architecture builds the attended path and makes no claim about its legality. Form 130
  is not our artefact: a certificate not generated from TRACES is invalid, so the product
  prepares its data and distributes the TRACES output (EV-048). The
  event/audit backbone (§15.6) is organised around filings, not around pay runs.
- **Effective-dating is permanent, not transitional (§06/§08, [Verified]).** The 50%
  wage-definition add-back is "or such other per cent as may be notified" — a standing
  variable. The rules engine must be effective-dated and retrospectively recomputable
  *forever*, independent of the November 2026 cliff.
- **Residency is a per-tenant, per-provider configuration, not a global build choice
  (§13/§17, [Verified]).** India neither mandates blanket localisation nor leaves data
  location unconstrained. DPDP's cross-border regime is not in force until on or about
  13 May 2027 (EV-058, **[Verified — mirror]**: pull from the primary source before customer
  use). The live constraints are CERT-In's 180 days of ICT logs within
  Indian jurisdiction (EV-062), SPDI r.7's restriction on cross-border transfer of sensitive
  personal data (EV-060), and sectoral rules that reach us through regulated customers:
  SEBI's in-India residence and MeitY-empanelled-infrastructure rule for SaaS providers
  (EV-085), IRDAI localisation for policy records only (EV-086), and RBI's IT-outsourcing
  directions, whose localisation, audit, sub-contractor-consent and inspection clauses are
  **materiality-gated, determined entity by entity — not turnover-gated** (EV-087,
  **[Verified — mirror]**: pull from the primary source before customer use; Source: RBI
  *Master Direction on Outsourcing of Information Technology Services*,
  DoS.CO.CSITEG/SEC.1/31.01.015/2023-24, 10 Apr 2023, effective 1 Oct 2023). **[Reversed]**
  Earlier drafts said these directions bind any SaaS vendor "with no turnover threshold"; they
  attach only where the arrangement is material to the regulated entity. Residency is
  selectable per tenant; the same abstraction serves the AI cost router.
- **Own the data and the tools, not the assistant (§13, [Verified]).** If enterprise buyers
  converge on Copilot/Glean as the assistant, our differentiation collapses to data quality
  and tool design. The architecture exposes an MCP surface over our own tools; it does not
  bet on our chat UI being the one the user opens.

Everything below follows from taking those five seriously.

<!-- DIAGRAM: architecture-overview -->

---

### 15.1 Architecture principles

These are the constraints every component is measured against. They are ranked; where two
conflict, the higher one wins.

| # | Principle | Consequence | Source / status |
| --- | --- | --- | --- |
| 1 | **Correctness of statutory output is a legal property, not a quality metric.** | The deterministic core is separable, independently testable against gazette fixtures, and never depends on the AI edge for a number. A wrong number is statutory exposure, not a bug ticket: paying an employee less than is due is an offence under Code on Wages s.54(1)(a), fine up to ₹50,000 (verified at gazette, r5/05); a late PF remittance carries s.7Q interest that EPFO's system computes and makes mandatory with the contribution (EV-039). | §08 [Verified] |
| 2 | **Effective-dated, retrospectively recomputable rules.** | Every statutory rule is a versioned record with an effective range and a decision-time range; every computation records the rule-set version and the evaluation context it used (§15.4.1); arrears/retro runs recompute against the version *in force for the period*, not today's. | §06 [Verified] |
| 3 | **Tenant isolation is the default; sharing is the exception that must be justified.** | Only two things are deliberately shared across tenants: the statutory-rules engine (a public dataset — the law is the same for everyone) and the stateless compute tier. Everything with tenant data in it is partitioned. | §15.3 |
| 4 | **Residency and provider are configuration, not architecture.** | A provider seam built for at least three interchangeable AI/inference backends and a per-tenant residency flag from v1 — one backend wired at R1, the full residency matrix at GA later (§05.5 items 15 and 29). No component hardcodes a provider or a region. | §13/§17 [Verified] |
| 5 | **Every state-changing action is an event with an actor, a reason and a rule version.** | The audit backbone is not a log added later; it is the write path. Filings, approvals, rule changes and AI-assisted actions all emit immutable events. | §15.6, CERT-In [Verified] |
| 6 | **Cost is attributed from v1 across all four COGS lines, not only inference.** | Inference (per tenant, user, agent, model) is the *smallest* line; the dominant one is supervised filing, which scales per registration × state × filing type, alongside WhatsApp per message and compliance curation per state (EV-088). Metering is plumbed through the request context and the filing workflow, not bolted on; retrofitting attribution after pricing exists is far harder (§13). | §13, EV-088 |
| 7 | **Degrade, never fail silently, on external dependencies.** | Government portals, banks and device fleets are unreliable. Every integration has an explicit fallback and a queue; a portal being down blocks a *submission*, never a *pay run*. | §15.5 |
| 8 | **Build for divergence between states, not uniformity.** | PT, LWF and state rules under the four Codes notify unevenly. The data model assumes per-state variance as the norm, not an exception (§20 risk register). | §06 [Verified] |

---

### 15.2 Service topology — logical components and responsibilities

The system is described as **logical services** (bounded responsibilities with owned data),
not as a physical deployment (pods, instances, regions — that is an implementation choice
constrained by §15.7). A logical service may run as one deployable in v1 and be split later;
the boundaries below are drawn so that split is cheap.

#### 15.2.1 The four tiers

1. **Client tier** — the surfaces a human or machine touches.
2. **Edge / gateway tier** — authentication, tenant resolution, rate limiting, routing.
3. **Service tier** — the deterministic core, the AI orchestrator, and the platform services.
4. **Data & integration tier** — persistence, the event backbone, and the outbound/inbound
   connectors to the outside world.

#### 15.2.2 Client tier

| Client | Primary users | Notes specific to India beachhead |
| --- | --- | --- |
| **Admin web console** | HR/payroll admin, finance | The pay-run and filing cockpit. Must be evaluable self-serve by a 30-person company that will not sit through a demo (§18 pricing shape). |
| **Employee self-service (web + mobile)** | Employees | Investment declarations, proof upload, payslips, Form 130, leave. Must assume *shared devices* — worker identity ≠ device identity (§09 [Verified]). |
| **Deskless / worker surface** | Frontline, factory, field | WhatsApp-first and low-connectivity. Worker-initiated, not employer-push — a new WhatsApp portfolio reaches only 250 unique users / rolling 24h (§09 [Verified]). |
| **Kiosk / device surface** | Shared shop-floor terminals | Receives biometric punches via the ADMS/WDMS push path (§15.5). No app on the device. |
| **CA / bureau console** | External CAs, payroll bureaus | Multi-client switching, per-client compliance calendar, one-click Form 138 and PT export, read-only audit access (§18). A CA is a *first-class tenant-spanning actor*, which shapes the auth model (§15.3.6). |
| **MCP server (machine client)** | External assistants (Copilot, Glean, Claude), our own AI | Read tools (ACL-inheriting), write tools (idempotent, audited, approval-gated), and per-tenant admin controls to disable specific tools per assistant (§12). |

#### 15.2.3 Edge / gateway tier

One logical component, the **API gateway + tenant router**. Responsibilities:

- **Authentication** and session/token validation (OIDC for humans; scoped API keys and
  short-lived tokens for machines and MCP).
- **Tenant resolution** — every inbound request is resolved to exactly one `tenant_id`
  *before* it reaches a service. A CA-console request resolves to a `(ca_org_id, acting_on
  tenant_id)` pair and carries both. This is the single choke point where a request without
  a valid tenant context is rejected — no service trusts an unauthenticated tenant claim.
- **Residency routing** — reads the tenant's residency profile and routes to the correct
  regional data plane and inference backend (§15.7). A tenant pinned to India-only never has
  a request served from a non-India plane.
- **Rate limiting and budget enforcement** — per-tenant *and* per-user, because the product
  is priced per employee but consumed per user; one heavy user can exceed a seat's entire
  ARPU (§13 [Verified]). The gateway meters and degrades gracefully; hard cut-off at a
  configurable ceiling, `gateway.budget_hard_ceiling`, routed to §20 (Microsoft's Copilot
  Studio documentation says agents are disabled at 125% of prepaid capacity — a documented
  precedent, read from vendor documentation in r2/03, Sep 2026, not executed; §13).
- **Request context injection** — stamps `tenant_id`, `actor_id`, `actor_role`,
  `residency_zone`, `request_id`, `cost_context` onto the request so every downstream service
  and the audit backbone see the same identity. This is the plumbing that makes principle 6
  (cost attribution) and principle 5 (audit) work without per-service effort.

#### 15.2.4 Service tier — the deterministic core

These services compute or persist statutory and monetary truth. They never call the AI
orchestrator for a number.

| Service | Responsibility | Owns (data) | Key cross-refs |
| --- | --- | --- | --- |
| **Core-HR service** | System of record: employees, org structure, positions, statutory identifiers (UAN, ESIC IP, PAN, PT enrolment), lifecycle state (§07.3; entities in §14). Aadhaar never enters its tables — only an opaque token referencing a separate, separately-encrypted, separately-access-controlled store (§07, §14). | Employee master, org units, identifiers, documents metadata. | §07 (core-HR FRs) |
| **Statutory-rules engine** | The single source of every rate, slab, ceiling, wage-definition rule, penalty and cadence — effective-dated and per-jurisdiction. Evaluation is a pure function of `(inputs, rule-set version, evaluation context)` with an enumerated context (§15.4.1). Detailed in §15.4. | Rule packs (versioned), effective-date and decision-time ranges. **Shared across tenants** (the law is public). | §06 (the rules themselves) |
| **Payroll engine** | Orchestrates a pay run: gathers inputs, invokes the rules engine per employee per component, produces gross-to-net, the two concurrent wage bases (add-back vs payment-of-wages, §06 [Verified]), arrears and retro. Its calculation graph permits bounded fixed-point nodes (§15.4.7). Deterministic and replayable. | Pay runs, payslips, component results, computation trace, input snapshots. | §08 (payroll FRs) |
| **Filing orchestrator** | Turns a locked pay run + period data into statutory artefacts: the ECR return file and part-payment contribution file (EV-035, EV-044), the ESI contribution upload, PT returns, and Form 138 Q1–Q3 (EV-051; Q4 fenced, EV-046). Runs the filing state machine of §08.8 (FR-PAY-711) — including REJECTED, REVISED and SUPPLEMENTARY states and a post-FILED correction path that is a diff, never a mutation — and a per-establishment filing ledger that refuses a skipped month (FR-PAY-712, EV-038). Submission is attended (§22), never unattended automation. For Form 130 it prepares the data TRACES needs and distributes the TRACES-generated certificate; it never generates the certificate (EV-048). | Filings, filing artefacts, portal acknowledgments, challans and TRRNs, submission attempts, filing ledger. | §08, §16, §22 |
| **Attendance & leave service** | Ingests punches, applies attendance and OT rules resolved for the work location's jurisdiction, maintains leave balances, feeds payroll input. OT is paid at not less than twice the normal rate (Code on Wages s.14, verified at gazette, r1/06); the 8-hour day and 48-hour week are central-sphere rule values that state rules may vary (r3 critic). **[Hypothesis]** A 144-hours-per-quarter OT cap is reported only by secondary summaries and has never been confirmed against gazette text — it may sit in the OSH rules — so the product may *warn* on it and must never *block* (§09.6; validation §20 V-17). | Attendance records (per-day IN/OUT, EV-055), shifts/rosters, leave balances. | §09 |
| **Documents service** | Generates and stores prescribed-format artefacts: the appointment letter where OSH Code s.6(1)(f) applies — an "establishment" of 10 or more workers, in the form the appropriate Government prescribes, so state-sphere (EV-057); the wage slip and the six central-sphere employer registers, kept as one canonical set with form numbers configurable per state (EV-053). Register retention follows each rule's own wording — "five years after the date of last entry" (Wages r.51(4)) or "five calendar years" (OSH r.72(1)(vii), SS r.53(1)(e)), with OSH r.76(2)'s bar on destruction unless transferred — for the central sphere only; state-sphere periods are configuration pending counsel (EV-054; §14, §23). | Document store (object storage + metadata). | §06, §07 |

#### 15.2.5 Service tier — the probabilistic edge

| Service | Responsibility | Trust boundary |
| --- | --- | --- |
| **AI orchestrator** | The assistant, agentic task classes (query, draft, reconcile, file-prep, support), the model router, guardrails and human-in-loop gating (§12). Explains, drafts, routes, reconciles — *never* computes a statutory number. | Reads the deterministic core's outputs; may *propose* actions but every write it triggers goes through the same approval-gated, audited write path a human uses. It has no privileged compute path. Any output feeding hiring, appraisal, promotion, a PIP or termination takes effect only after a recorded named human confirmer (§12.8.3). |
| **Redaction / tokenisation egress gateway** | The *only* workload with network egress to any model provider and the only holder of provider credentials. Default-denies Aadhaar number, PAN, bank account and IFSC, and biometric templates on every outbound call; blocks and surfaces on ambiguity; token map held in India (policy in §12.8.3). | Structural, not a library: direct provider-SDK use elsewhere fails at build time (lint) and at run time (network policy). |
| **Model router** | First-class, P0 (§05.5 item 13): per-task cost ceilings, logged escalation, re-point a task class at a different backend without a deploy; the seam takes ≥3 interchangeable backends with residency selectable per tenant (§13/§17 [Verified]) — one wired at R1, the full matrix at GA (§05.5 items 15, 29). Enforces the per-tenant AI kill switch and per-feature opt-out — **AI off by default for tenants flagged RBI-, SEBI- or IRDAI-regulated** — and the sub-processor-change gate: a tenant's eligible providers are exactly its consented set (§12.8.3; EV-087). | Enforces the residency profile from the request context — a tenant pinned to India-only inference cannot have a task routed to a US-only workspace geo. |
| **Cost/metering service** | Attribution across the four COGS lines (EV-088): inference per tenant/user/agent/model, WhatsApp per message, supervised-filing minutes per registration × state × filing type, and compliance curation per state. Feeds gateway budget enforcement, §13 and pricing (§18). | Read-only consumer of the request context and the filing workflow's events; no business logic. |

#### 15.2.6 Service tier — platform services

| Service | Responsibility |
| --- | --- |
| **Identity & access (IAM)** | Users, roles, RBAC/ABAC, the CA cross-tenant grant model (§15.3.6), machine credentials, MCP tool ACLs, and consent as a versioned first-class entity (§07, §14). **[Reversed]** Earlier drafts said DPDP s.7(i) lets employers process employee data without consent and so removes a consent layer; s.7(i) is not in force until on or about 13 May 2027 (EV-058, **[Verified — mirror]**: pull from the primary source before customer use). Today the SPDI Rules 2011 require consent *in writing* before collecting sensitive personal data, which includes biometric and financial information (r.3, r.5(1); EV-060) — while DPDP itself creates no sensitive category (s.2(t); EV-059). Written-consent capture is therefore built from v1, and who owes that duty, employer or SaaS, is a counsel question (Part D-4; §23 CR-04). When s.7(i) commences it disapplies consent and notice for employment purposes only, not the s.8 duties, so two consent regimes run concurrently across that date. Whether employees hold DPDP access, correction or erasure rights against an employer relying on s.7(i) is under counsel review (Part D-1; §23 CR-01); the erasure path in §15.6.3 is built either way, within statutory-retention overrides. |
| **Notification service** | Email/SMS/WhatsApp/push. Enforces WhatsApp's messaging-tier limit — a new business portfolio reaches 250 unique users per rolling 24 hours, rising through later tiers (r2/04) — and the worker-initiated rule (§09). |
| **Statutory-change watcher** | Monitors EPFO/ESIC/MoLE/state gazettes and CBDT for new instruments **and amendments/corrigenda** — a watcher keyed only to new notifications would have missed the corrigendum that inverted the Nov-2026 analysis (§02 [Verified]). Feeds the rules-engine change pipeline (§15.4.5; authoring and review operations in §22). |
| **Event/audit backbone** | Append-only event log and audit trail (§15.6). |
| **Scheduler / workflow engine** | Drives the monthly cadence: pay-run windows, filing due dates (the filing calendar), retention expiry, device-health polling. |

---

### 15.3 Multi-tenancy model

The core tension: the beachhead is 20–200 employees, where a *silo per tenant* (one database
per customer) is operationally unaffordable at the number of tenants required for the unit
economics to work, but a *naive shared pool* (one row-set for everyone, isolation left to
application code) fails on three counts. It is hard to defend as a reasonable security
practice under SPDI r.8, the standard behind IT Act s.43A, whose compensation has no
statutory cap (EV-060, EV-061) — whether a given design meets that standard is for counsel
and the ISO 27001 auditor, not this PRD (§23). It fails regulated customers' due diligence
(EV-085–087). And it makes residency impossible. The model below is a deliberate **bridge**:
shared compute, partitioned data, with an escape hatch to full silo for named regulated
accounts.

<!-- DIAGRAM: multitenancy -->

#### 15.3.1 Isolation strategy by data class

| Data class | Isolation model | Rationale |
| --- | --- | --- |
| **Tenant business data** (employees, pay runs, filings, attendance, documents) | **Pool with enforced partition** — shared schema, mandatory `tenant_id` on every row, row-level isolation enforced at the data tier, not trusted to application code. | Affordable at beachhead tenant counts. We treat enforcement below the app as the precondition for arguing reasonable security under SPDI r.8 today (EV-060) and DPDP r.6 once in force (EV-064); the conclusion itself is for counsel and the auditor (§23). |
| **Statutory-rules engine** (rate/slab/ceiling packs) | **Fully shared, read-only to tenants, versioned centrally.** | The law is identical for every employer in a state. Duplicating it per tenant would fork the compliance surface — the exact opposite of the maintainability goal (operating model: §01, §22). |
| **Documents / artefacts** (payslips, letters, registers, filing PDFs) | **Per-tenant object-storage prefix** with tenant-scoped access keys; residency-pinned bucket/region. | Large binary, retention-bound per retention class (EV-054 central-sphere figures; state periods configurable, §14), residency-sensitive. Rendered documents are an erasable class (§15.6.2). |
| **AI context / policy corpora** (a tenant's HR policy docs the assistant reads) | **Per-tenant partition; never co-mingled in a shared cache.** | Caching economics invert per-tenant (§13 [Killed] "cache everything") *and* co-mingling policy text across tenants is a data-leak class. |
| **Regulated / named-account tenants** | **Silo escape hatch** — dedicated data plane, optionally self-hosted as a priced compliance SKU (§20 non-goal: never self-host *for cost*, only as a priced SKU). | RBI audit, access and inspection rights reaching sub-contractors, where the arrangement is material for that entity (EV-087); SEBI in-India residence and processing with the MeitY-empanelled-infrastructure rule applied to SaaS providers (EV-085); IRDAI's regulator-access undertaking reaching sub-contractors, which attaches where the arrangement is outsourcing — managed payroll, not a self-service licence — and whose localisation covers policy records only (EV-086); buyer RFP terms such as SBI's "all data functions and processing … within the boundaries of India" (r2/06). Some accounts contractually cannot share infrastructure. |

**[Hypothesis]** — Pool-with-partition scales to the beachhead's tenant count on one
regional data plane. *Kill criterion:* if, in load modelling before GA, a single pool plane
cannot hold the projected v1 tenant population within the residency/latency budget without
noisy-neighbour breaching the per-tenant rate SLA, shard the pool by tenant-cohort earlier
than planned (§15.3.5) rather than moving to silo.

#### 15.3.2 The tenant, precisely

A **tenant is the paying customer account and the top isolation boundary** (§14: Tenant →
Group → Employer, 1 : 1 : N; TAN on the legal entity). It holds one or more legal employers
of one owning group, and each employer holds its statutory registrations (an EPF establishment
code, ESIC code(s), PT enrolment(s), TAN). One legal employer with multiple EPF/ESIC codes
across states is *one tenant with multiple statutory registration contexts*, not multiple
tenants — because payroll, TDS (one TAN often spans locations) and the employee master are
shared, but PT/LWF/PF-office routing diverge by state. This is why principle 8 (build for
state divergence) lives inside the tenant, not across tenants. Unrelated employers served
by the same CA or bureau are separate tenants, never co-located in one (§15.3.9).

#### 15.3.3 Tenant context propagation

Every request carries a resolved `tenant_id` from the gateway (§15.2.3). The rule:

- **No service accepts a tenant claim from the request body** — only from the
  gateway-injected, signed context. A payroll-engine call that arrives without a valid
  tenant context is a hard reject, logged as a security event.
- **The data tier enforces the partition**, so a query that forgets its `tenant_id` predicate
  returns nothing rather than another tenant's rows. Isolation does not depend on every
  developer remembering a `WHERE tenant_id = ?`.
- **Async/event consumers re-derive tenant context from the event**, which carries it
  immutably; a background pay-run job cannot "lose" its tenant on the way to the queue.

#### 15.3.4 Shared statutory engine + per-tenant application

The most important multi-tenancy nuance is that the **rules are shared but the *application*
of a rule is per-tenant and effective-dated**. The engine answer to "what is the PT slab for
Karnataka on 2026-08-31" is identical for every tenant; but *which* tenant is liable, at what
enrolment, for which employees, on which wage base, is per-tenant. So:

- The rules engine is a shared, versioned, read-only service.
- Each tenant's payroll run *pins* the rule versions in force for the period and records them
  in the computation trace (§15.4.3). Two tenants running the same period get the same rule
  versions; a tenant re-running a *past* period gets that period's versions, not today's.

#### 15.3.5 Noisy-neighbour and fairness

Because compute is shared:

- **Per-tenant and per-user rate limits are P0** at the gateway (§13 [Verified]).
- **Pay-run and filing jobs are queued per tenant** with fair scheduling, so one 200-employee
  tenant's month-end run cannot starve fifty 30-employee tenants running the same day. The
  month-end concurrency spike is predictable (the filing calendar clusters due dates), so the
  scheduler pre-provisions around known dates rather than reacting.
- **Cohort sharding as the pressure-release valve:** if a single pool plane approaches its
  fairness limit, tenants are sharded into pool cohorts (e.g. by size band or region) *before*
  isolation degrades — the partition model is unchanged, only the number of planes grows.

#### 15.3.6 The CA / bureau cross-tenant actor

A CA or bureau acts *across* many tenants and is the primary GTM channel (§18, [Hypothesis]
— unvalidated, gated by §20 V-05). The auth model must therefore support:

- A **CA-org identity** distinct from any single tenant, with an explicit, revocable,
  per-client **grant**. No implicit access. **In v1 a grant carries read, export and
  read-only audit scopes only**: money-of-record is read-only from the CA console and no
  write to a pay result, filing or challan is possible from it (§14 AC-DM-30; §05.5 item
  20). Prepare and assisted-submission scopes are the v2 extension (§15.9), opened only if
  V-05 validates the channel and counsel answers the attended-filing questions. Assisted
  submission would always run under the employer's written authority to act and leave the
  employer's statutory liability where it is; whether acting on portals under employer
  credentials, portal terms of use, the e-Return Intermediary route and personal DSC
  handling permit it is under counsel review (Part D-17; §22, §23 CR-17).
- **Every CA action carries both identities** in the audit trail: `(ca_org_id acting_as →
  tenant_id, actor_user)`. Every export, view and — from v2 — every filing a CA prepares is
  attributable to a named human at the CA org and the tenant it was for.
- **Scope granularity** matching the filing-denominated work lines in ICAI's recommended
  fee schedule (§04; a stale, pre-GST schedule, usable for the shape of the work and not
  for any price, r2/00): TDS return filing, PT registration/returns, TDS compliance review
  — read-only audit access is a distinct scope from preparation, and preparation from
  assisted submission.

**[Hypothesis]** — Modelling the CA as a first-class cross-tenant actor is worth the auth
complexity. *Kill criterion:* if V-05 (§20) finds CAs see us as
disintermediation and will not act as a channel, the cross-tenant grant model degrades to a
simple per-tenant export, and the CA console becomes a thin reporting view rather than a
filing surface.

#### 15.3.7 Edge cases the tenant + effective-dating model must handle by design

These are the cases that break naive HRMS data models; the architecture is drawn so each is
ordinary, not a special path. They are stated here because they cut across the tenant model
(§15.3), the rules engine (§15.4) and the identity model (§15.2.6).

| Edge case | Why it breaks naive models | How this architecture handles it |
| --- | --- | --- |
| **Mid-month join / exit** | PF/ESI are payable on wages for the days actually paid; a 14-day joiner is not a full-month contributor, and ESI coverage is period-scoped rather than a per-month test. | Payroll engine passes actual paid-days as a typed input; the rules engine prorates per its own versioned rule. The ESI contribution-period rule — an employee crossing the ₹21,000 ceiling mid-period keeps contributing to the end of that contribution period — is a rule attribute, not code (Source: esic.gov.in/contribution, verified r1/06). |
| **Employee with two UANs / duplicate ESIC IP** | A joiner from another employer may carry an unlinked UAN or a second IP number, corrupting the ECR and the continuity of service. | Core-HR treats statutory identifiers as first-class, de-duplicated per employee with a linkage state. The ECR generator excludes an unresolved member from the Regular return and flags it — never filing a wrong member id, never blocking the pay run — and a Supplementary return carries the member once resolved (EV-037). The filing ledger surfaces the exclusion as a future blocker, because a Regular return for month M needs every active member of month M−4 filed (EV-038). |
| **Inter-state transfer within one tenant** | The employee's PT liability, LWF cadence and PF-office routing change mid-year while the employee master and TAN stay the same. | This is exactly why a tenant carries *multiple statutory registration contexts* (§15.3.2). The transfer is a new assignment to an establishment in the other state; jurisdiction — state, sphere, Code-regime commencement date — is resolved from the work location into the evaluation context, never stored on the employee (§14, §15.4.1). Both states' periods coexist in the same tax year's filings. |
| **Loss-of-pay (LOP) and negative arrears** | A recovery in a later month can drive a component negative and re-open a prior filing. | Arrears/retro run supports signed deltas, recorded as a diff against the locked run, never a mutation (§08.4). An ECR can be corrected downward only by a Revised return before payment initiation (EV-037) — which is why the verification gate sits immediately before PAYMENT_INITIATED (§08.4). Once payment is initiated the approved return cannot be cancelled or revised downward (EV-036, EV-037): the diff is held as an operator exception linked to the original in the audit chain (§15.6.1), and the research establishes no recovery route for an over-remittance — an open question routed to §20's validation plan, not a behaviour this PRD specifies. |
| **Employee moves between two tenants served by the same CA** | The CA sees both, but the two employers are distinct legal entities with separate UAN/ECR obligations; data must not co-mingle. | CA dual-identity (§15.3.6) grants scope per tenant; the partition (§15.3.1) keeps the two employee records isolated even though one human CA touches both. |
| **Retro rule change after a filing is acknowledged** | The submitted ECR/return is now wrong against the corrected rule. | Recompute-and-notify pipeline (§15.8.3) enqueues the period; the original filing stays immutable in the audit log. The correction takes only the return type the portal permits (EV-037): Revised (needs an approved Regular and no other return in process; downward only before payment initiation — the circular exempts upward revision while EPFO's FAQ hedges, r5/02), Supplementary (only members absent from all prior returns for that month), or the separate arrear-return flow, whose layout is unpublished, so that generator is fenced (EV-043). |
| **Tax-year boundary in a retro run** | A backdated correction spanning 31 March straddles two income-tax vocabularies and two filing stacks. | The engine resolves a *sequence* of period-versions (§15.4.3). TDS on the arrears is reported against its deductee date of payment: Annexure I carries the TDS deducted during each quarter (EV-047), so the arrears land in the quarter and tax year of payment (§08 AC-210.3), not by re-opening earlier quarters. A correction statement arises only where a filed statement was itself wrong, and routes to that period's RPU/FVU stack (EV-052); the Form 138 Q4 correction format is unpublished (EV-046). Search, labels and imports accept both form vocabularies (EV-050). |

#### 15.3.8 Acceptance criteria for tenant isolation

Isolation failure is a security and regulated-customer liability (EV-060, EV-061, EV-087),
so it is tested as a property, not assumed:

- **AC-T1 (partition-below-app).** A deliberately-planted query that omits its `tenant_id`
  predicate returns zero rows, not another tenant's rows — proven against the enforcement
  mechanism (row-level filtering keyed to the gateway-injected context, §15.3.3), not against
  application code review.
- **AC-T2 (no body-supplied tenant).** A request that carries a `tenant_id` in its body but a
  different one in its signed gateway context is rejected as a security event; the body value
  is never consulted (§15.3.3).
- **AC-T3 (async carries tenant).** A pay-run job pulled off the queue re-derives its tenant
  from the immutable event; a job whose event lacks a valid tenant context dead-letters rather
  than executing against a default.
- **AC-T4 (residency honoured end-to-end).** A tenant pinned India-only never has data at rest,
  a log line, or an inference call served outside India — verified by injecting a probe request
  and asserting no non-India plane or workspace geo was touched (§15.7).
- **AC-T5 (no cross-tenant cache bleed).** Two tenants with identical policy-document text get
  isolated AI-context partitions; a cache key can never resolve across tenants (§15.3.1,
  §13 [Killed] "cache everything").

#### 15.3.9 Decision record — pooled vs siloed, and the bureau / CA multi-client shape

**Status: decided for v1** — option T-C and option B-1 below — with the revisit triggers
listed. Two coupled questions: how tenant data is physically separated (T), and where the
boundary sits when one CA or bureau serves many employers (B).

**Options for physical separation**

| Option | Shape | What it costs | What it buys |
| --- | --- | --- | --- |
| **T-A · Silo per tenant** | A database or data plane per customer | Every schema migration, backup, restore, monitor and month-end capacity plan runs once per tenant; the per-tenant fixed cost lands on a 20-employee account whose revenue scales per employee (EV-088) | The strongest isolation story; per-tenant restore and residency are trivial |
| **T-B · Pool with enforced partition only** | Shared schema; `tenant_id` on every row; isolation enforced at the data tier (§15.3.3) | One fleet to operate; month-end fairness must be engineered (§15.3.5) | Beachhead unit cost; a single rule-pack promotion path |
| **T-C · Bridge (chosen)** | T-B as the default; cohort sharding as the pressure valve (§15.3.5); a silo escape hatch for named regulated accounts, sold as a priced compliance SKU (§15.7.3) | Two deployment shapes to keep on one codebase | T-B's cost for the beachhead, T-A's answer where a contract requires it |

**Criteria, in principle order (§15.1)**

| Criterion | T-A | T-B | T-C |
| --- | --- | --- | --- |
| Isolation between employers (principle 3) | Physical | Enforced below the app; proven by AC-T1–T3 | As T-B, physical for silo accounts |
| Regulated due diligence and residency (EV-085–087) | Meets dedicated-infrastructure terms | Fails where a contract demands dedicated infrastructure | Silo SKU for those accounts only |
| Rules stay one shared, versioned dataset (principles 2–3) | Yes — rules are read-only and shared in every option | Yes | Yes |
| Cost per tenant at beachhead revenue (§13, EV-088) | Fixed cost per tenant | Lowest | Lowest for the pool; the silo is priced, not absorbed |
| Month-end cadence (§15.3.5) | Isolated but capacity-planned N times | One fair-share scheduler | One scheduler per plane |
| CA / bureau multi-client work | A CA spans N planes; every multi-client view is a federation | One plane; grants scope the view | One plane for the pool; silo clients federate |
| Per-tenant restore, export, offboarding | Native | Must be engineered (AC-T6) | Must be engineered for the pool |

**Decision T-C.** The deciding criteria are cost per tenant against a per-employee revenue
line and one fair-share month-end scheduler; the price is that per-tenant restore and
export must be engineered in the pool rather than inherited (AC-T6).

**Options for the bureau / CA shape**

- **B-1 · Client-owned tenants, CA as grantee (chosen).** Each employer is its own tenant;
  the CA or bureau is a CA-org identity holding revocable per-client grants (§15.3.6).
- **B-2 · Bureau-owned tenant.** One tenant per bureau, with its clients' legal employers as
  Employer rows inside it.

| Criterion | B-1 | B-2 |
| --- | --- | --- |
| Distinct legal persons, each with non-delegable statutory liability (EV-030, EV-035–038; §22) | Each client is its own isolation boundary | Unrelated employers sit behind an `employer_id` predicate inside one tenant — application scoping, the failure AC-T1 exists to prevent |
| Consent and notices name the right employer (§07, §14) | Native | Must be engineered per Employer row; who owes the SPDI written-consent duty is a counsel question either way (§23) |
| A client leaves its bureau | Revoke the grant; the data never moved | Extract one Employer's full history, registrations and filing ledger into a new tenant |
| Multi-client calendar and queue | A CA-org projection fed from each granted tenant (below) | A query inside one tenant |
| One bill and one console for the bureau | A payer relationship over several tenants (§18) — a commercial link, not a data link | Native |

**Decision B-1.** B-2 buys query convenience at the cost of the isolation boundary between
unrelated employers, which is the wrong trade for a product whose output is each
employer's statutory filing. §14 carries the same decision: a CA or bureau never pools its
clients' legal entities into one tenant, and holds no write access to money-of-record
(§14 Tenant → Group → Employer; AC-DM-30), with v0.3's "CA-run tenant" marked
**[Reversed]** there.

**How the multi-client view is built under B-1.** A per-CA-org **projection** holds only
calendar metadata — client tenant, registration, filing type, period, due date, filing
state, operator assignment — fed by the filing events (§15.6.1) of each tenant that has
granted that CA org. It never holds an employee-level field. Work on employee data needs a
switch into one tenant's context, resolved at the gateway as the `(ca_org_id, acting_on
tenant_id)` pair (§15.2.3) and audited with both identities. A client on a silo plane
appears in the projection only if its contract permits its filing events to leave its
plane; otherwise the console lists it as "dedicated plane — open in client context".

**Revisit triggers**

| Trigger | Re-opened decision |
| --- | --- |
| §20 V-05 finds bureaus will act as a channel only if the client account is theirs | B-2, and then only with `employer_id` enforced below the app as a second partition key and a per-employer export — decided then, not now |
| Hypothesis A1 fails (§15.10) | Cohort-shard the pool earlier; silo is not the answer to load |
| A targeted regulated buyer's due diligence rejects the pool | Silo SKU for that account (§15.7.3) |
| Per-tenant restore cannot meet §17.14's provisional RPO/RTO (NFR-DR-1401) inside the pool | T-C's pool default |

- **AC-T6 (per-tenant restore and export in the pool).** One tenant can be restored to a
  point in time, and exported in full, without reading or writing any other tenant's rows,
  within §17.14's provisional RPO/RTO (NFR-DR-1401); the restore is proven by a drill against a pool holding
  other tenants' data.
- **AC-T7 (CA projection carries no employee data).** A schema test fails the build if an
  employee-level field is added to the CA-org projection; revoking a grant removes that
  client's rows from the projection and refuses the next context switch into it.
- **AC-T8 (no unrelated employers in one tenant).** Adding a second legal employer to an
  existing tenant requires a recorded common-group declaration by the tenant admin; a CA
  org cannot create an Employer inside a tenant on which it holds only a grant.

---

### 15.4 The statutory-rules engine

This is the spine of the product and the component whose design most differentiates it from
a feature-parity clone (§04: win on maintained updates and filing execution, not depth). It
is specified here as a component; the *content* of the rules is §06.

#### 15.4.1 What it is and is not

- **It is** a deterministic, pure evaluation service. Evaluation is a pure function of
  **(inputs, rule-set version, evaluation context)** — no I/O, no clock, no database read
  inside evaluation — returning a typed outcome plus the exact rule versions and clauses
  applied. The **evaluation context** is a closed, enumerated record stored with every run:
  **disbursal date** (planned at approval, replaced by the actual date at disbursal; it sets
  the PF due month for arrears — EPFO FAQ Q15, r5/02 — and the Form 138 date of payment),
  **as-of decision time** (the knowledge cut fixing which rule versions and facts were known;
  replay reuses the original, a recompute takes a new one), **jurisdiction set** (state,
  sphere and Code-regime commencement date, resolved from the work location, never from the
  employee), and **tax-regime election** (the employee's election in force at the decision
  time). The field-level requirement is §08 FR-PAY-210; this is the contract every consumer
  calls through. Same (inputs, rule-set version, context) → same output, forever.
  **[Reversed]** Earlier drafts keyed evaluation on `(rule_class, state, date, inputs)` and
  called that pure; the arrears rule needs the disbursal date, an external and later-known
  event, so the context must be enumerated and injected rather than read.
- **It is not** a calculator that anyone can call ad hoc with hardcoded numbers, and it is not
  where the AI writes rules. A wrong number here is a legal liability, so rule content changes
  go through the certification pipeline (§15.4.5), never a hotfix.

#### 15.4.2 Rule classes (the taxonomy the engine indexes)

| Rule class | Effective-dated? | Per-state? | Notes |
| --- | --- | --- | --- |
| **Wage-definition rule** (the 50% add-back) | Yes | No (central) | Two concurrent wage bases per employee per period; "or such other per cent as may be notified" makes the 50% a variable (§06 [Verified]). The single hardest calculation in the build. |
| **EPF/EPS/EDLI** contribution & ceiling | Yes | No | Build against the Employees' Provident Funds **Scheme 2026** (G.S.R. 525(E), 29 Jun 2026), with 12% re-notified retrospectively to 21.11.2025 by S.O. 3582(E) ([Verified], r2/10). The ₹15,000/month wage ceiling — re-fixed under Code on Social Security s.2(89) by S.O. 2702(E), 29 May 2026 — and the EPS 8.33% split it caps are effective-dated variables; revision is under pressure, and we are not aware of any notified revision as of September 2026 (r1/06). Contribution above the ceiling applies only where the joint higher-wage option is exercised (r1/06, r5/02). EPS 1995 and EDLI 1976 run on the CoSS s.164(2)(b) saving; no successor to either is named in the research, so the EPS/EDLI split after the saving lapses is an open effective-date the engine must accept on notification (§20 V-22). |
| **ESI** contribution & ceiling | Yes | Coverage notified by district, sometimes sub-district, keyed to the work location (r1/06); applies at ten or more persons, extended to notified hazardous occupations at even one employee (CoSS First Schedule, r2/05; EV-057) | Current: ₹21,000/month wage ceiling (₹25,000 for persons with disability), employee 0.75% + employer 3.25% (Source: esic.gov.in coverage and contribution pages, verified r1/06; ESI subordinate legislation saved by CoSS s.164(2)(b) to on or about 21 Nov 2026). The ESI side of the Nov-2026 cliff is **unresolved** — an open effective-date the engine must be able to accept the moment ESIC notifies (§20 V-08). |
| **Professional Tax** slabs | Yes | **Yes — per state**, gender variants, periodicity, slab base | Verified at primary for Maharashtra (top band ₹200 a month and ₹300 in February; women exempt to ₹25,000/month) and Odisha (slabs on *annual* income); Karnataka's effect (₹200 a month at ₹25,000 or above, ₹300 in February) read on the state PT portal, with the instrument itself not retrieved (§20 V-09); in Tamil Nadu and Kerala PT is a local-body levy (r2/10). Every other state is undone build-dependency work (§20 V-09). PT is constitutionally capped at ₹2,500 per person per year (Art. 276(2), r1/06). The engine models the final-month true-up and a monthly-vs-annual slab base as first-class rule attributes, not special cases. **[Reversed]** Earlier drafts said Frappe ships PT across 15+ states free, making PT parity. Frappe v16's India payroll names no Indian state and has no PT slabs, and TallyPrime's PT slabs are hand-entered (EV-031, EV-032): multi-state PT is greenfield in both incumbents and a genuine differentiator. |
| **Labour Welfare Fund** | Yes | **Yes — per state**, schedule/periodicity | LWF sits outside the four Codes; contributions are flat amounts with state-varying periodicity, and no research round has verified any state's rate or employer/employee split from a government source (r1/06, r2/10). The one verified periodicity is Karnataka's calendar-year cadence with a 15 January due date (r2/10); every other cadence and amount is unverified (§20 V-09). The scheduler (§15.2.6) carries per-state LWF due dates distinct from the monthly payroll cadence. **[Reversed]** Earlier drafts said Frappe ships LWF across 14 states free, so LWF was no differentiator. Frappe v16 has no LWF and TallyPrime has no LWF engine (EV-031, EV-032): greenfield in both. |
| **TDS on salary, s.392 (ex-s.192) → Form 138 (ex-24Q)** | Yes | No | Form 138 replaces 24Q with a breaking layout — challan sub-headings 301–312 → A–K with 303 removed, Annexure I remapped (EV-051) — on RPU/FVU 1.2 for Tax Year 2026-27 onward and RPU 6.0/FVU 9.5 for earlier years, routed by period (EV-052). **The Q4 regular and correction formats are not released** (EV-046), so Q4 output and the Form 130 data it feeds are fenced. Due dates are rule data: Q1 31 Jul, Q2 31 Oct, Q3 31 Jan, Q4 31 May of the year following the Tax Year (Rule 219, Income-tax Rules 2026; EV-049). Form 130 is issued by 15 June (Rule 215, r5/02) and is valid only if generated from TRACES (EV-048). Both vocabularies — old and new form and section numbers, FY and Tax Year — are accepted everywhere (EV-050). |
| **Gratuity** accrual & payout | Yes | No | Applies to shops and establishments with 10 or more employees, plus factories, mines and the other listed classes; payable after 5 years' continuous service, a requirement lifted on death, disablement or fixed-term expiry (fixed-term: after one year, r1/06); 15 days' wages per completed year, monthly wage ÷ 26 (Source: Code on Social Security s.53 and First Schedule, verified at gazette, r1/06). **The ceiling is "such amount as may be notified by the Central Government" (s.53(3)), and we are not aware of any such notification as of September 2026** — the familiar ₹20 lakh cap is a legacy of the Payment of Gratuity Act, repealed by s.164(1), and needs a notification under the Code (r1/06). The ceiling is a named parameter, `gratuity.ceiling`, with no default, routed to §20. Under the Code, "wages" for gratuity uses the *add-back* base (§15.4.3), so gratuity accrual is downstream of the wage-definition rule. |
| **Minimum wages** | Yes | **Yes — per state/scheduled employment** | Feeds the equal-pay/payment-of-wages base. |
| **Overtime / hours** | Yes | Per-state rules under Codes | Rate not less than 2× the normal rate (Code on Wages s.14, [Verified]). **[Hypothesis]** A 144-hours-per-quarter cap — secondary summaries only, never confirmed against gazette text; a warn-only rule, never a block (§09.6, §20 V-17). |
| **Headcount-threshold gates** | Yes | Mixed | Obligation gates at the thresholds in §06.1, each carrying its counting unit (worker vs employee) and sphere (central vs state) as fields (EV-057). POSH requires every employer to constitute an Internal Committee; the ten-worker line is the s.6(1) Local Committee, not an exemption (EV-056). |

#### 15.4.3 Effective-dating and retrospective recomputation — the mechanism

Every rule is a record with a **`[valid_from, valid_to)` effective-date range**, a
**decision-time range** (when that version was the believed truth), a **version id**, and the
**source citation** (gazette/notification number and date, with capture date). Rules are a
bitemporal, never-erased class (§15.6.2, §14): the engine never mutates a rule in place; a
change is a *new version* with a new range, and the old version stays queryable forever.

<!-- DIAGRAM: effective-dating-timeline -->

A computation follows this contract:

1. The payroll engine asks: *"resolve wage-definition rule for period 2026-07, run-date
   2026-11-15."* The engine returns the version whose effective range contains the
   **period**, not the run-date, as known at the evaluation context's as-of decision time
   (§15.4.1).
2. The result is stamped into the pay run's **computation trace**: for every component of
   every employee, which rule class, which version, which clauses, which inputs, which
   evaluation context, what output.
3. A **retro/arrears run** for that same past period re-resolves the *period's* versions, not
   today's — so an arrears payment in November for July recomputes PF/gratuity against July's
   rule versions (§08 [Verified] requirement), while the PF *due month* for those arrears
   follows the disbursal date, not the wage month, and is surfaced when the arrears batch is
   approved (EPFO FAQ Q15, r5/02; §08 FR-PAY-210). If the July rule was itself later corrected by
   a corrigendum with retrospective effect, the corrected version carries a
   retro-effective flag and the recompute uses it — this is exactly the case the
   change-watcher must not miss (§15.4.5).

**Worked example — the two wage bases on one payslip.** Employee CTC ₹60,000/month with
basic ₹22,000, HRA ₹11,000, conveyance ₹3,000, special allowance ₹24,000. The
wage-definition rule (add-back base) *excludes* HRA and conveyance; if the excluded
components exceed 50% of total remuneration, the excess is added back to "wages" for PF and
gratuity. The engine computes: excluded = ₹14,000 (HRA + conveyance) which is < 50% of
₹60,000, so no add-back — but if special allowance were reclassified as excludable, the
excluded set (₹38,000) would breach half of ₹60,000 (₹30,000), and the ₹8,000 excess would
be added back, re-basing PF wages from ₹22,000 to ₹30,000. **The same payslip
therefore carries a PF wage base and a separate payment-of-wages/equal-pay base (which
*includes* HRA, conveyance, OT), computed concurrently.** The engine returns both; the
payroll engine persists both; the trace records which rule version drew each boundary. This
is the concrete reason effective-dating is a rules-engine property, not a payroll-engine
convenience.

**Worked example — the EPS ceiling interaction inside the add-back.** Same employee, with
the reclassification above pushing PF wages to ₹30,000/month, and assumed to be an EPS
member — one who joined after 1 Sep 2014 with wages above ₹15,000 is not, and EPFO *flags*
(does not reject) EPS contributions for such a member before filing (EV-040), so the engine
reads EPS membership as its own attribute rather than inferring it. By default contributions are
restricted to the ₹15,000 ceiling: employee ₹1,800; employer ₹1,800, split EPS 8.33% =
₹1,250 and EPF ₹550 — the figures in EPFO's own ECR golden fixture (r5/02). Where employer
and employee have exercised the joint higher-wage option, contributions run on the full
₹30,000: employee ₹3,600; employer ₹3,600, of which EPS stays **capped at the ceiling** at
₹1,250 (not 8.33% of ₹30,000) and ₹2,350 goes to EPF. EDLI is 0.5% of wages up to the
ceiling = ₹75 (Source: EPFO scheme pages, r1/06; ceiling per S.O. 2702(E)). The engine must
apply the *ceiling* rule, the *wage-definition* rule and the employee-level higher-wage
election as separate versioned inputs that compose — a naive "12% of a single wages number"
implementation produces a wrong EPS split and mis-files the ECR. The trace records every
rule version and the ceiling that bit.

**Worked example — arrears that cross a rate change.** A promotion backdated from 2026-06
is processed in 2026-11, spanning the (hypothetical) event that the 50% add-back percentage
is re-notified effective 2026-09-01. The arrears run must split the period: June–August
recomputes on the pre-change wage-definition version, September–October on the post-change
version, each against *that month's* EPF ceiling version. Three outputs are keyed to the
**disbursal date** in the evaluation context, not to the wage months: the PF due month for
the arrears (EPFO FAQ Q15, r5/02), filed through EPFO's separate arrear-return flow whose
layout is unpublished, so that generator is fenced (EV-043); the Form 138 deductee date of payment,
which places the TDS on the arrears in Q3's Annexure I (October–December) rather than
re-opening Q1 or Q2 (EV-047; §08 AC-210.3); and the start of any interest exposure (§08 FR-PAY-210). How each state's PT treats
arrears is unverified — a per-state rule attribute, `pt.arrears_treatment`, routed to §20
V-09. The engine resolves a *sequence* of period-versions, not one; the payroll engine emits
one arrears payslip with a per-period version breakdown in the trace. This is the mechanism
§08's "recompute against the version in force for the period" cashes out to.

#### 15.4.4 Rule packs and the "compliance-as-code" data flow

Rules ship as **versioned rule packs** — a pack is a signed, dated bundle of rule versions
for a jurisdiction (e.g. "Karnataka PT, effective 2026-04-01"). Packs are the unit the
statutory team maintains and the unit the certification pipeline tests. This directly serves
the operating-model decision (§01; the compliance data pipeline is specified in §22): the
company is a **compliance-maintenance operation with a permanent statutory team**, and the
rule pack is that team's deliverable — not a code release.

#### 15.4.5 The change pipeline and certification

A rule change flows: **watcher detects → statutory analyst verifies against primary source
(and checks for a corrigendum — non-negotiable, §02 standing rule) → drafts new rule version
with citation → certification test suite runs against gazette-derived fixtures → staged to a
canary tenant cohort → promoted to all tenants for the effective date.**

- **Certification fixtures** are worked examples derived from the gazette/notified rule (and,
  where they exist, the portal's own validation utility — e.g. the EPFO ECR format validator,
  the RPU/FVU for 24Q/Form 138). A rule version cannot promote unless it reproduces the
  fixture outputs exactly.
- **"Check for a corrigendum" is a pipeline gate**, not a nicety — the Nov-2026 inversion
  happened because a notification was read without checking whether a corrigendum had amended
  it (§02 [Verified]). The watcher indexes corrigenda and amendments explicitly, not just new
  instruments.
- **Retrospective changes** (a corrigendum dated back) enter as a new version with a
  retro-effective flag; the pipeline additionally enqueues affected past periods for
  recompute-and-notify, because filings already submitted against the old version may need
  whatever correction the portal permits (§15.8.3).

**[Hypothesis]** — A single certified rule-pack pipeline can keep pace with the recurring
statutory load (annual Budget, wage-ceiling revisions, per-state PT/LWF, uneven Code
rollout). *Kill criterion:* if, in the first two quarters of operation, the median
notification-to-certified-pack latency exceeds the shortest statutory effective-notice window
observed (the lead time state notifications actually give is unmeasured — instrument it from
the watcher, §20), the maintenance model is under-resourced and the statutory-team sizing
(§22) is wrong — escalate before it causes a missed-filing incident.

#### 15.4.6 Acceptance criteria for the rules engine

These are testable and are the gate on the component shipping in v1:

- **AC-R1 (determinism).** For any `(inputs, rule-set version, evaluation context)`, ten
  thousand repeated evaluations return byte-identical outcomes and identical resolved-version
  ids. No wall-clock, no random, no environment input and no field outside the enumerated
  context (§15.4.1) affects the result; an evaluator with clock and database access removed
  produces the same figures.
- **AC-R2 (period-resolution, not run-date).** Given a rule with versions
  `V1 [2026-04-01, 2026-09-01)` and `V2 [2026-09-01, ∞)`, a query for period 2026-07 with
  run-date 2026-11-15 resolves `V1`. A query for period 2026-10 resolves `V2`. Proven by
  fixture, not by inspection.
- **AC-R3 (retro-corrigendum).** A version inserted with `retro_effective=true` and a
  `[valid_from]` in the past supersedes the previously-resolved version for affected periods,
  and re-resolving those periods returns the corrected version plus a flag that a superseding
  correction occurred (so downstream can enqueue the permitted correction, §15.8.3).
- **AC-R4 (gazette fixture parity).** Every shipped rule version reproduces its certification
  fixtures — worked examples derived from the gazette and, where one exists, the portal's own
  validator (EPFO ECR validator, RPU/FVU for Form 138) — to the last paisa. Rounding is a
  versioned rule attribute, not code, applied once after any fixed-point convergence (§08
  FR-PAY-209); where the evidence states no rounding method for a statute, the method is a
  named configurable parameter routed to §20, never a guessed rule.
- **AC-R5 (no silent gap).** A query for a `(state, date)` with no rule version in range
  returns an explicit `NO_RULE_IN_FORCE` error that blocks the pay run with a named reason —
  never a zero, never a fallback to the nearest version. A missing PT slab for a newly added
  state is a visible block, not a silently-skipped deduction.
- **AC-R6 (citation completeness).** Every version carries a resolvable source citation
  (instrument number + date + clause); a version without one cannot promote past the
  certification pipeline (§15.4.5). This enforces the PRD standing rule at the data layer.

#### 15.4.7 The calculation graph: bounded fixed-point nodes

**[Reversed]** Earlier drafts assumed the payroll calculation graph is a DAG evaluated once
in topological order. It is not always: the s.2(y) / CoSS s.2(88) add-back re-bases components that feed its
own 50% test, and a net-of-tax gross-up solves gross pay from a target net while the tax
depends on the gross. The evaluator therefore permits **bounded fixed-point nodes**:

- A fixed-point node is *declared* in the graph with its loop members, a maximum iteration
  count and a tolerance — versioned engine parameters `fixed_point.max_iterations` and
  `fixed_point.tolerance`, not statutory values (§08 FR-PAY-211). Every node outside a
  declared loop evaluates once, in dependency order; an undeclared cycle fails the build.
- The loop iterates from a defined starting iterate until the change falls under the
  tolerance. Each iterate resolves the add-back against the same pinned rule version — rules
  are never re-resolved mid-loop — so convergence is deterministic and replay reproduces it.
- The computation trace records every iterate, the iteration count and the tolerance that
  stopped it; statutory rounding applies once, to the converged values only (FR-PAY-209).
- A node that has not converged at its limit stops the run with a blocking validation naming
  the node, the employee and the last two iterates. No intermediate iterate is published.

**Worked example — the add-back inside a balance-figure CTC.** When CTC closes on a
special-allowance balance figure and carries a gratuity accrual computed on wages as
defined in CoSS s.2(88) (the same 50% add-back as Code on Wages s.2(y); §06.10), the
loop runs: a larger add-back raises wages → raises the accrual → lowers the balance figure →
lowers "all remuneration" → changes the add-back. §08.12 Example G works it to convergence at
iteration 5 (wages ₹48,826.29); a one-pass evaluator must publish a first iterate and either
under-accrues gratuity or breaks the CTC reconciliation. The rules engine supplies the
add-back rule; the payroll engine's graph owns the loop.

- **AC-R7 (bounded fixed point).** Example G reproduces exactly — iteration count and every
  figure — through the production evaluator on repeated runs and on replay; a deliberately
  non-converging loop stops the run at PROCESSED with the blocking validation above and
  publishes no figure.

---

### 15.5 Integration layer

The integration layer is where the system meets an unreliable outside world: government
portals that go down at month-end and admit only attended use, banks with host-to-host
handshakes, a heterogeneous biometric device fleet, and two incumbents doing two jobs —
Tally owns accounting and the statutory artefacts, greytHR owns the HRMS job; Tally payroll
*adoption*, as distinct from capability, is unknown (EV-032; §20 V-02). Principle 7 governs
all of it: **degrade, never fail silently; every integration has an explicit fallback and a
queue.**

<!-- DIAGRAM: architecture-integration-topology -->

#### 15.5.1 Integration classes and contracts

| Integration | Direction | Contract / protocol | Failure mode | Fallback |
| --- | --- | --- | --- | --- |
| **Biometric devices (eSSL, ZKTeco)** | Inbound (device → us) | **ADMS/WDMS push**: terminal HTTP-POSTs punch packets to a tenant-scoped URL. No middleware, no static IP, no port-forwarding — the best-evidenced call in the corpus (§09 [Verified]); bench-tested across the target fleet before GA (§20 V-11). Outbound, the same channel carries template-deletion commands: two-phase, with per-device acknowledgement, a retry queue and a documented exception state for a decommissioned or lost device (§09). | Device offline / firmware quirk / clock drift / deletion unacknowledged | Buffer-and-replay when the device reconnects; an unacknowledged deletion stays in the retry queue until acknowledged or closed by an admin attestation; the legacy port-4370 pull protocol as a last resort for pre-ADMS firmware. Long-tail brands via the paid connector market (~$345 one-time / $588-yr, §09 [Verified]) — do not build in-house for SDK-bound brands. |
| **Tally** | Inbound (import) + outbound (accounting) | Named-source import is **P1**, Tally first, shipping at R2 (§05.5 item 17); every R1 tenant arrives through the P0 Excel/CSV onboarding import with the YTD tie-out validator (§05.5 item 32). Of the two incumbents, Tally holds the accounting and statutory-artefact job (greytHR holds the HRMS job; EV-032), and migration off it is a primary acquisition path (§16.2, §18). | Malformed export / version drift | Guided import with validation and a mapping preview; never a silent partial import. |
| **Banks — salary disbursement** | Outbound | NEFT/host-to-host salary files per bank's format; reconciliation of success/failure per beneficiary. | Beneficiary reject / file reject / bank downtime | Per-beneficiary retry, partial-batch handling, and a reconciliation queue — a bank reject blocks a *disbursement line*, never the pay run. |
| **EPFO (ECR)** | Outbound, **attended** | The 11-field `#~#` ECR return file and the 6-field part-payment file (EV-035, EV-044), uploaded in an interactive, CAPTCHA-gated employer login; upload → validate → return statement → approve → challan with TRRN → pay → receipt, with an approved return never cancellable (EV-036); strict month-wise sequence (EV-038). | Portal down at month-end / validation rejection / skipped month | The *file* is generated and validated locally even if the portal is unreachable; the submission waits in an attended-filing queue with its due date and the cockpit shows "generated, awaiting portal"; a rejection returns the filing to REJECTED with the error file mapped to employee records (§08.8) — the error-file schema is not public, so the mapper is built from the first real rejection captured on a live registration (§20 V-23). |
| **ESIC** | Outbound, **attended** | Contribution template upload + challan. | Portal down / **Nov-2026 regime change unresolved** | Same attended queue; the engine accepts the new ESI effective-date the moment ESIC notifies (§15.4.2). |
| **TRACES / Protean (TDS)** | Outbound, **attended** | Form 138 (ex-24Q) text file (EV-051); the deductor runs the FVU for the period's stack and uploads (EV-052). Form 130 (ex-Form 16) is TRACES-generated only — we prepare its data and distribute it (EV-048). | **Q4 regular and correction formats not released** (EV-046) | Q1–Q3 supported, pinned to the downloaded format artefact rather than Protean's page label, which differs from the workbook's own version (r5/02); Q4 fenced and flagged in the calendar until the format lands. |
| **State PT portals** | Outbound, **attended** | Per-state PT return + payment; cadence varies by state. | Many state portals, most manual | Generate the exact portal-format file or return for attended upload; never claim automated or unattended submission on any statutory portal (§22). |
| **Job boards (Naukri, LinkedIn, foundit, apna, Indeed)** | Outbound (post) + inbound (application sync) | Multi-post from one requisition; application ingest + dedup. **Inbound-only** — Info Edge publishes no path for a third-party ATS to search Resdex and markets in-ATS Resdex search as exclusive to its own ATS (§10; r2/08). | API limits / no published partner API (Naukri) | "Bring your own job-board contract"; **scraping is forbidden** in architecture and sales collateral (§10 [Verified] legal exposure). LinkedIn partner integration done properly and early. |
| **Accounting / HRIS migration** | Inbound | Importers from Zoho Payroll, Kredily, Frappe — **acquisition infrastructure, not integrations** (§18). | Mid-year cutover complexity | Migration is a first-class product surface (§18): opening balances, YTD earnings, TDS-already-deducted, previous-employer income, UAN/IP continuity, leave/gratuity continuity. |

#### 15.5.2 The device compatibility matrix as an architectural artefact

Device integration effort is currently **unsized** — the "85–98% success" figure was
retracted marketing (§09 [Killed]) and needs a hardware spike. Architecturally, the response
is to ship a **public, model-level device compatibility matrix and a self-serve verification
tool** (§09 highest-leverage cheap artefact): a tenant points a device at a test endpoint and
sees whether its punches arrive and parse, *before* a sales call. This turns an unsized risk
into a self-service check and answers a deal-gating question that, as of September 2026, we
are not aware of any incumbent answering publicly.

#### 15.5.3 Idempotency and reconciliation as first-class

Every outbound integration is **idempotent and reconciled**: a resubmitted ECR or salary
file cannot double-file or double-pay — EPFO permits multiple challans per wage month, so the
guard against paying twice for the same employee is ours (EV-036); every submission has a
client-side idempotency key and
a reconciliation record that pairs "what we sent" with "what the portal/bank acknowledged."
This is the same discipline the MCP write tools require (§12: idempotent, audited,
approval-gated) — one mechanism, two consumers.

#### 15.5.4 The compliance calendar is scheduler data, not a static list

Because the filing is the unit of delivery, the due-date calendar is a first-class,
effective-dated dataset the scheduler (§15.2.6) drives — it clusters the month-end
concurrency spike (§15.3.5) and it is the surface the CA console renders per client
(§15.2.2). The recurring statutory cadence, as of September 2026 (each entry a rule datum
subject to the certification pipeline, not a hardcoded constant):

| Filing | Cadence | Statutory due date | Source cue |
| --- | --- | --- | --- |
| **EPF ECR + challan** | Monthly | Within 15 days of the close of the month | EPF Scheme 2026 (G.S.R. 525(E)), corroborated on EPFO's EDLI page (r1/06) |
| **ESI contribution + challan** | Monthly | Within 15 days of the last day of the month | Regulation 31, ESI (General) Regulations 1950 (r3/02); esic.gov.in (r1/06) — a saved instrument, kept alive by CoSS s.164(2)(b) to on or about 21 Nov 2026; its successor is unresolved, so the date is re-certified the moment ESIC notifies (§20 V-08) |
| **PT return + payment** | Per-state (monthly / half-yearly / annual; Maharashtra reassigns filing frequency per registration each year, r1/06) | Varies by state | Respective State PT Acts — [Hypothesis] on every per-state date; *kill:* replace with the gazette-verified all-state dataset (§20 V-09) |
| **LWF deduction + remittance** | Per-state | Karnataka: calendar year, due 15 January — the one verified periodicity (r2/10); all others unverified | State LWF Acts — [Hypothesis] except Karnataka; same kill as PT |
| **TDS payment (challan)** | Monthly | 7th of the following month; TDS deducted in March by 30 April — values carried from the 1962 Rules (r3/02), **[Hypothesis]** for Tax Year 2026-27 onward | Rule 218, Income-tax Rules 2026 prescribes the dates; its text is not yet read (r5/02; §06.13; §20 V-20) |
| **TDS return (Form 138, ex-24Q)** | Quarterly | Q1 31 Jul · Q2 31 Oct · Q3 31 Jan · Q4 31 May of the year following the Tax Year | Rule 219, Income-tax Rules 2026 (EV-049) |
| **Form 130 (ex-Form 16)** — TRACES-generated; we prepare data and distribute (EV-048) | Annual | 15 June of the year following the Tax Year | Rule 215, Income-tax Rules 2026, s.395(4) (r5/02) |
| **Gratuity / LWF / statutory registers refresh** | Event-/period-driven | On separation / period close; register retention per EV-054 (central sphere; state periods configurable) | Code on Social Security; Wages, OSH and SS Central Rules 2026 (EV-053, EV-054) |

The scheduler pre-provisions capacity around the 7th (carried, pending §20 V-20) and 15th
due-date clusters — which days actually peak is measured, not assumed (§20) — and raises a
filing-at-risk alert at the tenant-set lead time `calendar.alert_lead_days` before each due
date (the same parameter as §03 AC-M06.3, not a second one). A
per-state PT/LWF date that the certified dataset does not yet cover surfaces as a *gap in the
calendar*, consistent with AC-R5 — never a silently-missing obligation.

---

### 15.6 Event and audit backbone

The audit backbone is not observability plumbing added at the end; per principle 5 **it is
the write path** for every state-changing action. This is driven by three forces: statutory
proof (a filing must be defensible years later), CERT-In log retention, and the AI trust
boundary (every AI-assisted action must be attributable).

#### 15.6.1 What emits events

Every state change emits an immutable event carrying `tenant_id`, `actor` (human, machine, or
AI-agent, with the CA dual-identity where applicable), `reason`, `rule_versions_applied`
(where statutory), `request_id`, and a hash chain to the prior event for tamper-evidence:

- **Filing lifecycle** — every transition of the §08.8 filing state machine (FR-PAY-711),
  including rejected, revised, supplementary and payment-initiated, plus each attended
  submission step with the acting operator and the employer's authority-to-act reference
  (§22). This is the primary event stream, because the filing is the unit of delivery.
- **Rule changes** — every rule-version promotion, with citation and the certification result.
- **Approvals and human-in-loop gates** — every statutory action a human confirmed, and every
  AI proposal a human accepted or rejected, with the named confirmer (§12).
- **AI calls** — the per-employee AI disclosure record written at every call site that
  touches an employee's data (§12.8.3).
- **Pay-run lifecycle** — every transition of the §08.4 month machine, from OPEN to FILED,
  including the verification gate before PAYMENT_INITIATED.
- **Access and identity** — grants, CA cross-tenant access, MCP tool invocations, consent
  captured and withdrawn.

#### 15.6.2 Event sourcing where correctness demands replay

The **filing orchestrator and payroll engine are event-sourced**: their current state is a
fold over their event history, so any pay run or filing can be *replayed* to reconstruct
exactly how a number was reached, against which rule versions, by whom. This is what makes
"retrospectively recomputable with an audit trail" (§08 [Verified]) a structural property
rather than a reporting feature. Services that do not compute statutory truth (notifications,
attendance capture) use ordinary state with an audit log — event sourcing is applied where it
earns its complexity, not everywhere.

**Replay is scoped by entity class, not universal.** **[Reversed]** Earlier drafts implied
every attribute is bitemporal and every run replays forever. Erasure requirements make that
false — the Aadhaar retention ceiling tied to the consented purpose (reg 6(5), EV-068),
template destruction (§09), consent withdrawal, and DPDP erasure once in force (EV-058).
Bitemporal, never-forget classes are rules, salary structures, assignments and statutory
attributes. Erasable classes are raw punches, rendered documents, biometric templates (in
their own keyspace) and consent artefacts (§14). Erasable records are encrypted under a
per-subject key, so erasure is crypto-shredding: the key is destroyed, the ciphertext and the
hash chain (§15.6.1) stay verifiable, and a tombstone event records the class, the subject
reference, the actor, the reason and the time. What replay returns after an erasure:

- A pay run replays from its **input snapshot** (paid days, OT hours, attendance totals), not
  from raw punches, so its figures reproduce after the punches are shredded and the
  snapshot's provenance link resolves to the tombstone. The per-day IN/OUT record Form IX
  requires (EV-055) is a derived statutory record held under its register retention class
  (EV-054), not an erasable punch.
- A rendered document is re-rendered from retained bitemporal data while its retention class
  still requires the content; otherwise replay returns the tombstone, never a fabricated copy.
- Records in a bitemporal class are erased only when §14.7's deletion engine clears them
  against their retention class; replay then returns structure, rule versions and aggregates
  with the subject's fields marked ERASED, and never re-derives an erased value.

**Replay supports evidence production; it does not discharge audit obligations.**
**[Reversed]** Earlier drafts said the reproducibility guarantee satisfies RBI's right to
audit by construction. Deterministic replay supports evidence production for RBI inspections;
it does not discharge the contractual audit, access and inspection obligations, which remain
contractual and reach sub-contractors (EV-087; §23).

#### 15.6.3 CERT-In and DPDP obligations baked in

The CERT-In directions bind **from day one, not at enterprise scale** (§17 [Verified]); the
DPDP rows are built ahead of their commencement on or about 13 May 2027 (EV-058):

| Obligation | Architectural consequence | Source |
| --- | --- | --- |
| **6-hour incident reporting** for every body corporate | The event backbone feeds the six-hour incident pipeline below; a named CERT-In point of contact (direction (iii), r4/02) before the first paying customer. | Source: CERT-In Directions under s.70B(6) IT Act, No. 20(3)/2022-CERT-In, 28 Apr 2022, direction (ii) (EV-062) [Verified] |
| **180 days of ICT logs retained within Indian jurisdiction** | Log storage is residency-pinned to India regardless of the tenant's inference residency choice; retention is enforced, not best-effort. This includes LLM prompt and completion logs (as tokenised), attribution and disclosure records — that these count as ICT-system logs is well-grounded inference, not stated text, so counsel confirms (§23 CR-23) and we build as if they do (§12.8.3). No log stream may land only in a non-India observability region. | Source: CERT-In Directions, 28 Apr 2022, direction (iv) (EV-062; r4/02) [Verified] |
| **Clock sync to NIC/NPL NTP** | All event timestamps synced to NIC/NPL NTP servers — non-trivial for distributed services and for reconciling device clock drift against server time. | Source: CERT-In Directions, 28 Apr 2022 (EV-062) [Verified] |
| **Attacks on AI/ML systems are a reportable incident class** | Three reportable surfaces feed one pipeline: attendance terminals as IoT devices (Annexure I item (xiii)), the cloud layer (item (xviii)) and the AI edge (item (xx)). The AI orchestrator, egress gateway and router are instrumented from v1 for the four AI/ML sub-classes — prompt injection, poisoning, extraction and inference-pipeline access (§12.8.4). | Source: CERT-In Directions, Annexure I (EV-062) [Verified] |
| **Retention and erasure** | Retention is per retention class and enforced by the backbone: EV-054's central-sphere register figures where they apply, state-sphere periods as configuration pending counsel, and neither an immediate purge nor a fixed one-year suppression hard-coded (§14.7, §23). Erasure uses the class-scoped mechanism of §15.6.2 and honours statutory-retention overrides. DPDP's erasure duty and its retention rules bind only from on or about 13 May 2027; whether r.8(3) sets a universal one-year floor is a counsel question (Part D-9; §23 CR-09). | Source: EV-054, EV-058; DPDP s.8(7), r.8(3) (not in force) |
| **Detection-capable access logging** | Access to personal data is logged so unauthorised access can be *detected*, not merely recorded — a DPDP r.6(1)(c) requirement once in force, built now (§17). | Source: EV-064 (not in force) |

**The six-hour incident pipeline.** A manual process cannot meet six hours from noticing an
incident, so the pipeline is architecture; §17.6 owns the reporting target and runbook, and
§12.8.4 the AI/ML sub-classes.

1. *Detect* — signals from the event backbone, the gateway (tenant-context violations,
   AC-T2), the egress gateway (blocked identifiers, provider-key use outside it), the device
   receiver, cloud-layer alerts, and the AI layer's four AI/ML sub-classes.
2. *Open* — an incident candidate is created automatically with its evidence attached from
   India-resident logs and NTP-synced timestamps, and the on-call owner is paged.
3. *Classify* — the named incident owner decides reportability under §17.6's runbook; no
   detector and no AI component decides it.
4. *Report* — the CERT-In report fields are pre-staged from system state so the named point
   of contact can file inside the six-hour window.
5. *Fan out* — the same incident drives customer notices and, once DPDP commences, its
   separate breach track to the Board and every affected data principal (EV-063, not in
   force today).

#### 15.6.4 Cost attribution rides the event stream

Because every request carries `cost_context` (§15.2.3), every AI action emits an event and
every attended-filing step is an event (§15.6.1), cost attribution across the four COGS lines
(EV-088) is a *consumer of the event stream*, not a parallel accounting system. **[Reversed]**
Earlier drafts treated inference as the margin question; it is the *smallest* of the four
lines. The dominant line is supervised filing, which scales per registration × state × filing
type while revenue scales per employee (EV-088) — so the stream meters supervised-filing
minutes per registration per filing cycle, the input to the automation target and the
registration cap (§13, §18, §22). Inference attribution per tenant/user/agent/model still
feeds gateway budget enforcement (§15.3.5) and the router's cost ceilings; the 52.7×
model-choice spread is a ratio that survives FX (EV-089), while per-employee inference
absolutes remain placeholders (§13). Attribution must be trustworthy from the first paying
customer.

---

### 15.7 Deployment, residency and provider abstraction

Residency is the segment-specific procurement gate that cannot be deferred (§17 synthesis:
*a segment-specific gate, not a general-market differentiator*). The architecture treats it
as configuration, delivered by two abstractions that are one piece of work serving two
constraints (§17 [Verified]).

#### 15.7.1 Two residency guarantees, tracked separately

Buyers ask about both and they are different (§17 [Verified]):

- **Data-at-rest residency** — where tenant data physically lives. India-only for regulated
  tenants; the default plane is India regardless. This is a product choice and a
  regulated-customer requirement, not a general Indian localisation mandate: the live legal
  constraints are CERT-In log residency (EV-062), SPDI r.7 for sensitive data (EV-060) and
  the sectoral overlays (EV-085–087); Aadhaar hosting outside India is a counsel question
  (Part D-15; §23 CR-15).
- **In-country inference residency** — where AI inference executes. A different guarantee from
  data-at-rest, and provider-dependent.

The tenant's **residency profile** captures both independently and the gateway + model router
enforce them per request.

#### 15.7.2 The provider matrix (must be maintained, not memorised)

**[Verified]** — Residency is a per-provider matrix, and the specific cells below are as
captured in round two (r2/03, Sep 2026; vendor documentation read, no provider executed)
and must be re-verified per procurement (§13; §20 V-13):

| Provider | Data-at-rest India | In-country inference India |
| --- | --- | --- |
| OpenAI | Yes (India data-at-rest) | Via Bedrock for in-country inference |
| Anthropic | No | No — US-only immutable workspace geo |
| Vertex (Google) | India region available | India region available |
| Sarvam | **Unverified** — must not be relied on until verified; prices natively in INR (FX hedge, §13) | Unverified |

Requirement (§13 [Verified]): **≥3 interchangeable backends with residency selectable per
tenant.** The seam is built for that from v1; one backend is wired at R1 and the full matrix
reaches GA later (§05.5 items 15 and 29). The model router (§15.2.5) is where this is
enforced — a tenant pinned to India-only inference simply cannot be routed to an
out-of-region backend, and the router re-points task classes without a deploy when a
provider changes price (Gemini 3.x Flash doubling on 1 Jan 2027 is the *base case*, EV-089;
§13) or residency posture.

#### 15.7.3 Deployment topology

| Topology | Who | Notes |
| --- | --- | --- |
| **Shared multi-tenant plane, India region** | Default — the whole beachhead | Pool-with-partition (§15.3). Serverless-first: serverless beats a list-priced dedicated H100 by roughly 74× at realistic scale — a derived, low-confidence figure whose throughput input is unsourced (r2/03) — and the direction, not the multiple, is what the decision rests on (§20 non-goal: never self-host *for cost*). |
| **Dedicated data plane, India region** | Named regulated accounts | Silo escape hatch; same code, isolated data + inference. |
| **Self-hosted / customer VPC** | Named regulated accounts only, **as a priced compliance SKU** | Never for cost (§20). A bank for which the arrangement is material (RBI audit and inspection rights, EV-087), a SEBI entity (EV-085) or a buyer RFP such as SBI's can force this contractually; IRDAI's localisation reaches policy records only (EV-086). |

#### 15.7.4 The ISO 27001 seasoning clock is an architecture input

Certification carries a **one-year seasoning clock** on top of roughly 3–6 months'
acquisition — Indian Bank's RFP requires a qualifying certification (ISO 27001:2022 is one of
four it accepts) held for at least one year before RFP publication (r2/06; §17.15, §01
[Verified]).
Consequence for month zero: **start ISO 27001 immediately** even with no customer asking; to
be useful at month 18 it must be in hand by ~month 6. This shapes the architecture now because
the controls it certifies (access logging, encryption-at-rest, incident response, the audit
backbone) must be *designed in from v1*, not retrofitted for the audit. "The cheapest year you
will ever buy" (§17.15).

#### 15.7.5 Log residency topology — every log in India, whatever the inference residency

Inference residency (§15.7.1) is per tenant and may, where the tenant's profile permits,
send a tokenised prompt to a backend outside India. **Logs do not follow the inference.**
CERT-In requires 180 days of ICT logs within Indian jurisdiction for every body corporate
(EV-062, direction (iv)); that LLM prompt and completion logs are ICT-system logs is
well-grounded inference rather than stated text, so counsel confirms (§23 CR-23) and we build as
if they are (§12.8.3). The policy lives in §12.8.3 and §17.6; this is the topology.

<!-- DIAGRAM: architecture-log-residency -->

| Log stream | Written by | Contents | Store | Retention | Readable by |
| --- | --- | --- | --- | --- | --- |
| Gateway access and security events | API gateway | Request context (§15.2.3), authentication outcome, tenant-context violations (AC-T2) | India log plane | At least `logs.ict_retention_days`, never set below 180 (EV-062) | Security on-call, incident owner |
| Audit / event backbone | Every service | §15.6.1 events, hash-chained | India, tenant-partitioned | Per retention class (§14.7), never below the ICT floor for ICT-log content | Tenant admin for its own tenant; auditors under grant |
| LLM prompt and completion log | Egress gateway only, after tokenisation | Tokenised prompt and completion, provider, model, task class, tenant, cost context | India, tenant-partitioned | ICT floor; beyond it `llm_log_retention_days`, routed to §20 and §23 (§12.8.3) | AI operations under break-glass; incident owner |
| Token map | Egress gateway only | Token-to-value pairs, keyed per data subject | India, a separate store under separate keys | Life of the subject key; crypto-shredded on erasure (§15.6.2) | The egress gateway's service identity only |
| AI attribution and disclosure records | Egress gateway and AI orchestrator | The per-employee disclosure record (§12.8.3) | India | Exportable per employee; retention per class (§14.7) | Tenant admin; the employee for their own record |
| Device receiver log | ADMS/WDMS receiver | Packet receipt, device id, clock drift against NTP-synced server time | India log plane | ICT floor | Operations, incident owner |
| Metrics and traces | Every service | Identifiers and measurements, no personal-data field | India, complete | ICT floor | Engineering |

A copy of metrics and traces may go to an observability tool outside India only if the
stream carries no personal-data field and the India copy is complete; for a tenant pinned
India-only nothing leaves India at all (AC-T4). What a model provider itself retains from a
tokenised prompt, and where, is recorded per provider in the sub-processor register
(§12.8.3, §17.7) and re-verified per procurement (§20 V-13); this PRD asserts no provider's
retention setting. Every stream feeds the six-hour incident pipeline (§15.6.3) with
NTP-synced timestamps.

These continue the AC-T series of §15.3.8 and §15.3.9:

- **AC-T9 (LLM logs land in India whatever the inference residency).** For a tenant whose
  profile permits a non-India backend, a probe call's prompt and completion are logged only
  to the India store, in tokenised form; a search of every non-India store and observability
  sink finds neither the log line nor any seeded canary identifier.
- **AC-T10 (the ICT floor is enforced).** Any configuration change or operation that would
  expire or delete an ICT-log stream before `logs.ict_retention_days` is refused and logged
  as a security event; the parameter cannot be saved below 180. Any value above that floor
  is an owner decision routed to §20's sizing register, with counsel, alongside
  `llm_log_retention_days` (§23 CR-11, CR-23).
- **AC-T11 (shredding de-identifies logs without deleting them).** After a subject key is
  crypto-shredded, the LLM log lines that referenced that subject remain present and
  hash-chain-verifiable, and their tokens no longer resolve.

---

### 15.8 End-to-end data flows (worked)

Three flows tie the components together. Each names the human-in-loop gate, the audit event,
and the failure fallback.

#### 15.8.1 A biometric punch → payroll input

*Before any punch.* Biometric enrolment happens only after written consent is captured as
a versioned consent entity — the SPDI Rules treat biometric information as sensitive and
require consent in writing before collection (r.3, r.5(1); EV-060), while DPDP creates no
sensitive category (s.2(t); EV-059); who owes that duty, employer or SaaS, is under counsel
review (Part D-4; §23 CR-04). The consent entity records which regime it was captured under,
because the SPDI and DPDP regimes run concurrently across on or about 13 May 2027 (EV-058);
whether s.7(i) will reach biometric capture at all is untested (Part D-2; §23 CR-02), so the
architecture keeps written capture as the default across that date. The template lives in its own keyspace, separate from the attendance event;
no image column or image bucket exists — enrolment images are deleted after template
extraction (§09, §14). Every employee has a non-biometric attendance path, and no
configuration makes biometric the only one (Part D-10; §23 CR-10; §09).

1. Shop-floor terminal **HTTP-POSTs** a punch packet to its tenant-scoped ADMS/WDMS URL
   (§15.5). No middleware. The attendance event we persist references the employee and the
   time and never a template (packet contract: §09, §16).
2. Gateway resolves the tenant from the URL/credential, injects context, rate-limits.
3. Attendance service **dedups and validates** the punch (clock-drift correction against
   NIC/NPL-synced server time, §15.6.3), maps it to the employee's shift/roster.
4. OT/leave rules for the work location's jurisdiction apply — OT at not less than 2× (Code
   on Wages s.14), central-sphere hour limits where they govern, and the 144-hour quarterly
   figure only as a warn-never-block **[Hypothesis]** (§15.2.4) — resolved via the rules
   engine, effective-dated (§15.4).
5. Result becomes a **payroll input** for the period; an event is emitted.
   **Fallback:** device offline → buffer-and-replay on reconnect; the pay run never blocks on
   a single device.

#### 15.8.2 A monthly pay run → filings (the core loop)

<!-- DIAGRAM: pay-run-to-filing-loop -->

The steps follow the §08.4 month machine (OPEN → INPUTS_CLOSED → PROCESSED → APPROVED →
LOCKED → DISBURSED → PAYMENT_INITIATED → FILED, reversible before LOCKED):

1. **Inputs assembled and closed:** attendance, mid-period changes, investment declarations,
   arrears; the input snapshot freezes at INPUTS_CLOSED.
2. **Payroll engine computes** gross-to-net per employee (PROCESSED), invoking the rules
   engine per component against a complete evaluation context (§15.4.1); fixed-point nodes
   converge (§15.4.7); produces the two concurrent wage bases; stamps rule versions into the
   computation trace (§15.4.3). Deterministic — no AI in the number path.
3. **AI reconcile (optional, edge):** the AI orchestrator flags anomalies vs prior period
   (a component that jumped, a missing declaration) — it *explains and routes*, it does not
   change a number (§12). Human reviews.
4. **Human-in-loop approval gate:** the approver approves (APPROVED) and the run locks
   (LOCKED); after LOCKED, any change is a correction run expressed as a diff, never a
   mutation. Event emitted with actor and reason.
5. **Disbursement** (DISBURSED): bank host-to-host salary file generated; per-beneficiary
   reconciliation; the actual disbursal date replaces the planned one in the evaluation
   context. **Fallback:** partial rejects retried per beneficiary; run stays approved.
6. **Filing orchestrator** turns the locked run + period data into the ECR, the ESI upload,
   PT returns and Form 138 Q1–Q3; validates locally *before* the portal is touched —
   mirroring EPFO's hard blocks and flags (EV-040) and the period's FVU stack (EV-052).
7. **Attended submission** by an operator under the employer's written authority to act
   (§22). For the ECR: upload → validate → return statement → approve; then the
   **verification gate** — every statutory payment reconciles to the locked snapshot — sits
   immediately before payment initiation, because once payment is initiated a downward
   correction is impossible (EV-037); then challan with TRRN → pay (PAYMENT_INITIATED) →
   receipt → FILED (EV-036). Artefacts are archived under their retention class (§14).
   **Fallback:** portal down → the filing waits in the attended queue against its due date;
   the file exists and is valid locally; the cockpit shows "generated, awaiting portal." A
   rejection moves the filing to REJECTED with the error file mapped to employee records
   (§08.8). A portal outage never blocks a pay run — it delays a *submission* (principle 7).
8. **Every step is an event** on the filing stream; the run is replayable end to end within
   the class scoping of §15.6.2.

#### 15.8.3 A retrospective correction (the case that justifies the whole design)

1. A corrigendum lands, dated back, changing (say) the PT slab for a state effective a past
   period. The **watcher catches the corrigendum** (not just new instruments, §15.4.5).
2. Statutory analyst verifies against primary source, drafts a new rule version with a
   **retro-effective flag** and citation; certification fixtures pass; pack promoted.
3. The pipeline **enqueues affected past periods** for recompute. The payroll engine replays
   those periods against the *corrected* version for that period (§15.4.3), producing revised
   numbers and a diff.
4. Where a filing was already submitted against the old version, the filing orchestrator
   prepares only the correction the portal permits, as a diff against the filed artefact,
   never a mutation: a Revised or Supplementary ECR under EV-037's guards, the fenced
   arrear-return flow (EV-043), a Form 138 correction statement where that period's
   correction format exists (EV-046), or the state's own correction route for a PT return —
   per-state and unverified (§20 V-09). Where no permitted correction exists, such as a
   downward ECR change after payment initiation, it becomes an operator exception
   (§15.3.7). Each is flagged in the compliance calendar.
5. Human-in-loop approves the corrections, which are then submitted attended (§22); the
   audit trail links original → corrigendum → recompute → correction.

This flow is the concrete reason effective-dating, event sourcing, the corrigendum-aware
watcher and the certification pipeline all exist. It is also exactly the scenario that
inverted the Nov-2026 analysis when done by hand (§02) — the architecture's job is to make it
mechanical and auditable instead of a research accident.

---

### 15.9 Build sequencing (architecture, mapped to phases)

Per the phasing rule (§05.4: the full suite is the vision, not v1). This orders
*architectural capability*, not features (features are §05.5).

| Phase | Architecture delivered | Rationale |
| --- | --- | --- |
| **v1 (beachhead 20–200)** | Gateway + tenant router; pool-with-partition multi-tenancy (India plane); statutory-rules engine with effective-dating, the enumerated evaluation context, bounded fixed-point evaluation and the certification pipeline; payroll engine (event-sourced) + filing orchestrator with the filing ledger; attended-filing tooling for EPFO/ESIC/TRACES/PT (no portal APIs, §22); ADMS/WDMS push receiver; the Excel/CSV onboarding import with YTD tie-out (R1) and the Tally importer (R2, §05.5 items 17, 32); bank H2H; event/audit backbone with class-scoped erasure; per-tenant point-in-time restore and export in the pool (AC-T6); the India log plane for every log stream, LLM logs included (§15.7.5) + NTP + the six-hour incident pipeline; the redaction egress gateway, kill switch and sub-processor gate; four-line cost attribution; model router on a provider seam built for ≥3 backends (one wired at R1, §05.5 item 15); ISO 27001 controls designed in. | Everything needed to produce a portal-accepted artefact and carry it through attended submission under the employer's written authority (§22), isolate tenants, and stay auditable. Inference is the smallest of four COGS lines; supervised filing is the largest (EV-088, §13). |
| **v2 (expansion 200–2,000)** | Cohort sharding of the pool if pressure warrants (§15.3.5); CA cross-tenant grant model matured — the prepare and assisted-submission scopes, if V-05 and counsel clear them (§15.3.6) — with the calendar-only CA-org projection (§15.3.9, AC-T7); talent integrations (job boards, LinkedIn partner); richer MCP tool surface. | Same product shape, more tenants and larger tenants; CA channel scaled *if* validated (§20 V-05). |
| **Vision (enterprise, benefits, full AI)** | Silo/dedicated + self-host compliance SKU; per-provider residency matrix hardened for regulated procurement (RBI/SEBI/IRDAI overlays, buyer RFP terms); benefits-attach data model activated (built in v1, monetised later, §11). | Enterprise procurement is arithmetically closed for ~3 years (§05.2); the ISO seasoning clock started at month 0 makes month-18 bids possible. |

---

### 15.10 Open architecture questions and hypotheses

Consistent with the PRD's standing rule that surviving hypotheses carry a kill/validation
criterion:

| # | Hypothesis | Validation method | Kill criterion |
| --- | --- | --- | --- |
| A1 | Pool-with-partition scales to the v1 tenant population on one India plane within residency + per-tenant rate SLA. | Load model against projected tenant count before GA. | If it cannot without breaching the noisy-neighbour SLA, cohort-shard earlier (§15.3.5). |
| A2 | One certified rule-pack pipeline keeps pace with recurring statutory load. | Track notification→certified-pack latency for two quarters. | Median latency > shortest observed statutory effective-notice window → statutory team under-resourced (§22). |
| A3 | The CA-as-cross-tenant-actor auth model is worth its complexity. | §20 V-05 (20–30 CA interviews). | CAs see us as disintermediation → degrade to per-tenant export + reporting view (§15.3.6). |
| A4 | ≥3 residency-selectable inference backends satisfy every regulated procurement we target in v2–vision. | Per-procurement provider-matrix re-verification. | A required buyer mandates in-country inference no listed provider offers → self-host inference SKU moves up the roadmap. |
| A5 | Inference stays the smallest of the four COGS lines at beachhead ARPU; the absolute per-employee inference figures are placeholders (EV-088). | Instrument the prototype (§20 V-04); four-line attribution built in from v1 (V-14). | Actual tokens ≥5× the estimate (§20 V-04) → router cost ceilings tighten and the bundling decision is re-opened (§13). The larger exposure — supervised-filing minutes per registration — is measured separately (§15.6.4, §22). |
| A6 | Device integration effort is affordable in-house for the common fleet (eSSL/ZKTeco ADMS). | Hardware spike (effort currently **unsized**, §09 [Killed] the old figure; §20 V-10). | If mixed-fleet success is materially below what the spike shows viable, lean on the paid connector market for the long tail (§15.5.1). |
| A7 | Client-owned tenants with CA grants (B-1, §15.3.9) meet bureaus' operating needs without a bureau-owned tenant. | §20 V-05 interviews probe who bureaus expect to hold the client account. | Bureaus will act as a channel only if the account is theirs → re-open B-2, with `employer_id` enforced below the app and a per-employer export. |

**[Killed]** — reminders that must not re-enter the architecture: "cache everything" as a
default (Gemini's hourly cache storage makes explicit caching strictly worse than none for
tenants below roughly 1,000 employees, and can exceed the tenant's inference bill by 100× or
more — r2/03, §13); self-hosting *for cost* (serverless wins by roughly 74× on a derived,
low-confidence estimate, r2/03, §20); and any claim of
automated or unattended submission on any statutory portal — every one is attended, and the
deliverable is a portal-accepted artefact plus assisted submission (§22).

**[Reversed]** — the old reminder not to treat multi-state PT/LWF as a differentiator, on the
ground that "Frappe ships it free", is withdrawn: Frappe v16 has no state PT slabs or LWF and
TallyPrime has neither a state PT slab table nor an LWF engine (EV-031, EV-032). Multi-state
PT and LWF is greenfield in both incumbents — which is why the per-state rule model in §15.4.2
is a differentiator, not parity.

---

### 15.11 Summary — how the pieces enforce the thesis

The architecture is arranged so that the product's two central claims are *structural
properties*, not aspirations:

- **"The filing is the unit of delivery"** is enforced by making the filing orchestrator
  event-sourced and the primary audit stream — the system's durable truth is an acknowledged
  filing, and every other component exists to feed it.
- **"Rules-first, LLM-last"** is enforced by a hard trust boundary: the deterministic core
  computes every statutory number and stamps its rule versions; the AI edge explains, drafts
  and routes through the same audited, approval-gated write path a human uses, with no
  privileged compute path, and every outbound model call passes the redaction egress gateway.

Effective-dating with an enumerated evaluation context, bounded fixed-point evaluation, the
corrigendum-aware certification pipeline, per-tenant partition with a regulated silo escape
hatch, class-scoped replay and erasure, residency-as-configuration with ≥3 interchangeable
backends, India-resident logs feeding a six-hour incident pipeline, and four-line cost
attribution built from v1 — each is one design choice serving a named,
sourced constraint elsewhere in this PRD. None is gold-plating; each has a kill criterion or a
[Verified] source behind it.
