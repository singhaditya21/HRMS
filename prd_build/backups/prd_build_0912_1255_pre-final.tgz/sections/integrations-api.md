## 16. Integrations & External Interfaces

This section specifies **every external system the product talks to**, and — because in
this market most of those systems are hostile, undocumented, or have no API at all — it
specifies the *fallback* for each one with the same weight as the happy path. That is the
governing design stance of the whole section:

> **In an Indian statutory HRMS, the integration is judged by its fallback, not its API.**
> The government portals that carry the unit of delivery (§01 — the filing, not the
> payslip) offer no submission API we are aware of, so every statutory submission is an
> attended portal session (K-13); the two incumbents (§21 — Tally for accounting and the
> statutory artefacts, greytHR for the HRMS job; K-23) are file-import sources, not live
> connections; and the device fleet (§09) speaks an undocumented, reverse-engineered
> protocol (port 4370) on the long tail (r2/04). A design that assumes clean APIs
> everywhere ships a demo, not a product. Every integration below therefore carries a
> **contract, a data-exchange spec, an enumerated failure taxonomy, and a fallback that
> keeps the filing on time when the primary path is down.**

Three framing rules from earlier in this PRD govern this section and are not restated per-integration:

- **The filing is the unit of delivery (§01, [Verified]).** An integration is "working"
  only when the artefact it feeds — an ECR that reaches FILED, a settled bank batch, a
  filed Form 138 — completes (FR-PAY-711). A green API call that does not produce a
  filing that reaches FILED is a red status here.
- **Rules-first, LLM-last (§12.1 P1, [Verified]).** No integration may allow a model to
  generate a statutory or monetary figure that crosses a system boundary. The assistant
  may draft an email to a bank RM or explain a portal rejection; it never computes the
  amount on a challan or a NEFT line. Every outbound file is produced by the deterministic
  engine (§08) and reconciled to the rupee before it leaves the system.
- **Own the data and the tools, not the assistant (§12.7, [Verified]).** The
  public API and MCP posture (§16.11) are built so that when an enterprise buyer's
  assistant (Microsoft Copilot, Glean, or another vendor's assistant) wants our data, we are the
  governed source of tools it calls — not a competitor for the chat surface.

<!-- DIAGRAM: integrations-api-topology -->

---

### 16.1 Integration taxonomy and posture

Not all integrations are the same kind of thing, and conflating them is the most common
architectural error in this category. We classify every external interface on four axes,
because the axis determines the engineering, the SLA, and the fallback.

| Axis | Values | Why it matters |
| --- | --- | --- |
| **Direction** | Inbound (we ingest) · Outbound (we emit) · Bidirectional | Determines who owns the schema and who breaks whom on a change |
| **Transport** | Live API (REST/SOAP) · File exchange (upload/download) · Device push (ADMS) · Attended portal session (no API; a named human present, optionally automation-assisted) · Manual/human-in-loop | Determines reliability, monitorability, and legal exposure |
| **Cadence** | Real-time · Event/webhook · Scheduled batch · One-time (migration) | Determines idempotency and retry design |
| **Criticality to the filing** | On the filing path (blocks a return) · On the pay path (blocks disbursement) · Convenience | Determines on-call priority and the fallback investment |

Applying the taxonomy to the full integration surface. This is the master register; each
row is detailed in the subsection named.

| # | Integration | Direction | Transport | Cadence | Filing-critical? | Phase | Detail |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A | **Tally** (accounting + migration) | Bi | File (XML/CSV) or local connector | Batch + one-time | Pay path (GL) | GL journal export: **P1, R2**, first in the integration queue (§05.17 PR-13). Import: **P1**, first named-source importer (§05.5 item 17) | §16.2 |
| B | **Banks — salary disbursement** | Out | File (the floor) + aggregator API / connected banking (the upsell) | Batch | Pay path | File, separate-approver release and credit reconciliation: **P0, R1** (§05.5 item 33; C-22; §05.17 PR-01). Aggregator payout API: **P1**. Connected banking: a BD track | §16.3 |
| C | **Biometric / attendance devices** | In | Device push (ADMS) + SDK pull | Real-time + batch | Pay path (LOP) | Push receiver: **P0, R1** (§05.5 item 11; C-24). Pull path via connectors: **P1** | §16.4 |
| D | **EPFO** (ECR return; challan reconciliation; UAN and KYC status) | Out | File + attended portal session | Batch (monthly) | **Filing path** | ECR Regular, Supplementary and Revised, submitted in Mode A or B: **P0, R1** (A-01 to A-04; C-09, C-10, C-21). Part-payment file: R2 (A-05). Arrear return: fenced (A-06). Operator-attended submission: R2, fenced on counsel (A-23) | §16.5 |
| E | **ESIC** (contribution, IP) | Out | Template + attended portal session | Batch (monthly) | **Filing path** | Computation: **P0, R1** (A-07; C-11). Upload file: **P0, R1** only if the template capture (F-05) finishes before the gate, otherwise R2 by rule (A-08; C-12). Post-lapse periods: fenced (A-09) | §16.5 |
| F | **Income-tax portal / TRACES** (Form 138 ex-24Q; Form 130 ex-16 is TRACES-generated) | Out | Statement file; deductor runs FVU and uploads in an attended session | Batch (quarterly/annual) | **Filing path** | Q1–Q3 regular and correction generation: **P0, R1** (A-11, A-12; C-14), correction *submission* held while F-02 is open. Form 130 distribution: **P0, R1** (A-14; C-15). Q4 and Tax Year 2026-27 Form 130: fenced, R3 (A-13; EV-046) | §16.5 |
| G | **State PT portals** (per-state) | Out | File + attended portal session, one portal per state | Batch (per-state cadence, §06.4) | **Filing path** | Computation for each state whose row is state-primary-sourced — Maharashtra at R1 entry: **P0, R1** (A-15; C-16). Every return leg, Maharashtra's included: fenced per state, R2 (A-15, A-16) | §16.5 |
| H | **State LWF portals** | Out | File + attended portal session | Batch (per-state periodicity, parameter `lwf.<state>.periodicity`, §06.8) | Filing path | The per-state machinery is built under §05.5 item 7 so a published state pack switches it on without a deploy; **no state's remittance ships in R1** — R2 per state as F-07 ships (A-17; §05.17 PR-03) | §16.5 |
| I | **Accounting systems** (Zoho Books, Busy, ERP GL) | Out | API + file | Batch | Pay path (GL) | P1 | §16.6 |
| J | **HRIS migration importers** (Excel/CSV; Zoho/Kredily/Frappe/greytHR) | In | File + API | One-time | Onboarding | Excel/CSV import with the YTD tie-out and parallel-run month: **P0, R1** (§05.5 item 32; C-05). Named-source importers: **P1** (§05.5 item 17) | §16.7 |
| K | **Recruiting / job boards** (Naukri, LinkedIn, foundit, apna, Indeed) | Bi | API + posting | Event | Convenience | P1 | §16.8 |
| L | **Communication** (WhatsApp, email, SMS-DLT, e-sign) | Out | API | Real-time/event | Pay path (payslip delivery) | Email and DLT-SMS: R1 as infrastructure under C-31, not a separate capability (§05.17 PR-14). WhatsApp and e-sign: **P1** | §16.9 |
| M | **Identity / SSO / SCIM** | Bi | OIDC/SAML/SCIM | Real-time | Convenience | P2 (§05.5 item 24; FR-CHR-092) | §16.10 |
| N | **Public API + webhooks + MCP** | Bi | REST + MCP | All | Platform | REST API and webhooks: **P1**. External MCP server: **P3** (§05.5 item 30). Per-tenant and per-user rate limits: **P0**, under §05.5 item 13 | §16.11 |

Every cell above carries one bare priority per leg, and "P0" appears only on legs that are
on §05.17's closed R1 list; a fenced leg carries its fence and release instead (§05.17
lint L1, L2, L5). Where this register and §05.17 ever disagree, §05.17 wins and this table
is relabelled.

Two posture decisions apply across the whole register:

**[Verified]** — **No statutory surface offers a submission API we are aware of (as of
September 2026); every one is an attended portal, and that is the base case, not the
exception** (K-13). EPFO requires an interactive employer login with a CAPTCHA, then
upload → validate → return statement → approve/reject → Due Deposit Balance Summary →
challan with TRRN → pay → receipt (EV-036; r3/05). For TDS the product produces the
statement `.txt`; the *deductor* runs Protean's File Validation Utility against it with
the `.csi` challan file and uploads the output on the income-tax portal (EV-051, EV-052;
r3/05). ESIC is a template upload on its portal (the template is described by
practitioners and not yet confirmed from ESIC, §16.5.2); state PT is one manual portal
per state (r3/05). The deliverable is therefore **a portal-accepted artefact plus attended,
assisted filing under written authority to act**: **(1) generate the artefact** +
**(2) submit it in an attended session — by the employer, or by our operator under the
employer's written authority (§22)** + **(3) capture and reconcile the acknowledgement and
receipt**. §22 FR-OPS-001 owns the four delivery modes — A employer-attended, B
co-attended, C operator-attended, D CA-attended — and this section uses its letters. In
every mode the **statutory payment leg and any DSC-bound act stay with the employer**: for
no statutory portal act do we hold a bank credential, an OTP-generating factor or a
Digital Signature Certificate (§22; §08 FR-PAY-301 M10). The employer's and deductor's
statutory liability is **non-delegable** and stays with the customer. No vendor in the
six-vendor set claims to submit any filing (EV-030), so attended submission is a
differentiator, not a gap to hide. Whether and how we may act
on these portals under employer credentials is under counsel review (Part D-17, §23), and
operator-attended submission is itself a fenced artefact: until counsel clears the four
attended-filing questions plus liability allocation (§20 V-25), every artefact ships
portal-ready and the employer submits it in Mode A or B (§05.7 A-23, R2 on clearance).
A roadmap that promises "one-click government filing via API" promises something we are
not aware exists: CBDT's Form 138 guidance note speaks of "integration with APIs &
Databases" and the income-tax portal lists "API Specifications" for e-Return
Intermediaries, but neither is evidence that a TDS statement can be filed by API (r5/02;
r3/05) — both are watcher items, not capabilities.

**[Verified]** — **Schema-driven, never hard-coded.** Every file format below — ECR text,
the ESI contribution template, the Form 138 statement (a breaking layout change, EV-051),
each bank's salary template, each state's PT return — is a **versioned schema object**, not
code. Field numbers, column orders and delimiters change by gazette and by bank release.
Form 138 alone remapped challan sub-headings 301–312 → A–K (303 removed) and Annexure I
313–327 → C–N (313, 321, 322 and 325 removed), with the Q4 regular and correction formats
still unpublished (EV-051, EV-046; Source: Protean "Key Features — RPU and FVU version
1.2"; Q1–Q3 regular format published 22 Jul 2026, labelled "Version 1.2" on Protean's page
while the workbook itself says "Version 1.1" — versions are pinned to the downloaded
artefact, r5/02). A hard-coded layout is a guaranteed production incident on the next
notification.

**The schema object, concretely.** Every file-schema integration is described by a
declarative record the runtime interprets — never by branching code:

| Schema-object field | Example (EPFO ECR return file) |
| --- | --- |
| `schema_id` / `version` | `epfo.ecr.return` / internal version, pinned to the source artefact it was built from |
| `effective_from` / `effective_to` | wage month `2025-09` (the revamped ECR applies from it; the file layout did not change, EV-035) / `null` (open) |
| `source_ref` | EPFO User Manual ReECR v3.0 p.8 (Help File) and circular Compliance/ECR Revamp/2025/12997 of 26.09.2025, linked from www.epfo.gov.in/revamped-ecr/ and served from pmvbry.epfindia.gov.in (the URLs printed in the circular itself are dead, r5/02) — URL + capture date (EV-035, EV-045) |
| `delimiter` / `header_row` | `#~#` — **three** characters, 10 per line / `false` — no header row (EV-035) |
| `line_terminator` / `encoding` | not stated in EPFO's published material — named parameters `ecr.line_terminator` and `ecr.encoding`, captured from a portal-accepted upload and routed to §20 V-23 |
| `packaging` | no filename pattern is mandated (EV-035); letters and digits only in the filename, lower-case `.txt`, at most 8 MB per upload, compress with zip above 2 MB, and a zip may contain only the one text file (EPFO User Manual ReECR v3.0 p.7, r5/02 finding 5) |
| `columns[]` (ordinal, name, type, rule) | 11 columns, ordered (see §16.5.1) |
| `portal_controls[]` | Wage Month, Return Type, Contribution Rate, Remark — entered in the portal's form, **never** written into the file (EV-035) |
| `validators[]` | EPFO's own checks at EPFO's own severity — age-58 EPS **block**; post-01.09.2014 high-earner EPS **flag**; date-of-joining to date-of-leaving window; rate at or above statutory (EV-040); arithmetic ties (employer EPS at most ₹1,250) |
| `blocked` (bool) + `blocked_reason` | `false` (contrast Q4 Form 138 = `true`, EV-046; ECR arrear return = `true`, EV-043) |

A gazette change edits the schema object's data and mints a new `version` with a new
`effective_from`; the prior version stays live for in-flight (arrear/retro) periods, and
every artefact routes by its **period**, never by today's date (EV-052).
This is the same effective-dating discipline the wage engine uses for the 50% add-back
(§06.10, "or such other per cent as may be notified" — [Verified]).

---

### 16.2 Tally — accounting export and the migration wedge

Tally is not a peer integration; it is one of **two incumbents with two jobs** — Tally owns
accounting and the statutory artefacts, greytHR owns the HRMS job (K-23, §21). It appears
twice here: as a **one-time migration source**, and as the **ongoing GL export target**
that lets the customer keep Tally as their book of record. **[Reversed]** An earlier
version of this section put the GL journal export in P0. §05.17 PR-13 rules it **P1,
R2**: it is neither a filing nor a payslip, and in R1 a design partner's accountant can
post the month's journal from the payroll register. It stays first in the integration
queue because Tally owns the accounting job (EV-032).

**[Hypothesis]** — **Tally import is the first migration importer (§05.5, item 17), not
because Tally has a good API but because Tally owns the accounting and statutory-artefact
job** (EV-032). How many beachhead firms run Tally *payroll* — as distinct from what it can
do — is unknown (K-23, §20 V-02). **[Reversed]** Earlier text called TallyPrime
"statutorily complete and ₹0-incremental" and concluded that a feature-parity pitch loses.
TallyPrime does ship PF Forms 3A/5/6A/10/12A + ECR, ESI 3/5/6, a PT statement, Form 16,
24Q annexures, 12BA, 27A, NPS and gratuity — but **no state PT slab table** (slabs are
hand-entered), **no LWF engine**, **no leave module**, no leave-encashment calculation,
manual attendance vouchers only, and multi-user access only at Gold, at 3× Silver's price
(EV-032). A search of five TDL add-on catalogues found **no** payroll, PT or LWF add-on
(EV-032). **[Killed]** — the "Payroll Plus ₹5,999" Tally add-on is not evidence of
anything: it is sold on a lookalike domain and cannot be used (K-20). The artefact list is
where we must match; the PT, LWF, leave and attendance gaps are where we win. We win by
making leaving Tally-for-payroll costless while letting the customer keep Tally-for-accounts.

| Facet | Specification |
| --- | --- |
| **Contract** | No live API dependency. TallyPrime's XML gateway is an HTTP server inside the TallyPrime process on port 9000 by default, enabled via F1 > Settings > Advanced Configuration — a LAN endpoint on the customer's machine that a cloud HRMS cannot reach without a local connector (r3/05). The envelope structure (ENVELOPE / HEADER / BODY / TALLYMESSAGE / VOUCHER) is published; only the payroll voucher and ledger payload needs a spike (r3/05). We treat Tally as a **file-and-XML boundary**, not a service. Two flows: (1) **import** — parse a customer's Tally export (masters + vouchers) during onboarding; (2) **export** — emit a payroll journal voucher Tally can import, as a file or through a local connector. |
| **Data exchange — import** | Ingest: ledger masters (employee ledgers, salary/PF/ESI/PT/TDS payable ledgers), cost centres/categories (often used as departments), opening balances, and — where the Tally Payroll module is enabled — pay heads, attendance/production types, and employee masters with PF/ESI/UAN numbers. Format: Tally XML export or CSV per ledger. |
| **Data exchange — export** | Emit a **payroll journal voucher** per pay run: debit salary/wages and employer-contribution expense heads, credit net-pay-payable, PF payable (EE+ER), ESI payable, PT payable, TDS payable, and any recovery ledgers. Delivered as Tally-importable XML with a stable ledger-mapping table the customer confirms once, then reuses. |
| **Failure modes** | (1) **Ledger-name mismatch** — customer's ledger names don't match our mapping → voucher import fails or posts to a suspense ledger. (2) **Duplicate voucher** on re-export → double-counted GL. (3) **Tally release drift** — XML dialect differences between Tally releases, captured by the voucher/ledger-schema spike rather than assumed (r3/05). (4) **Character/encoding** — special characters (`&`, non-ASCII) in employee names corrupt XML unless entity-escaped. (5) **Split company data** — customer runs multiple Tally companies; the request targets the wrong company. (6) **Financial-year boundary** — voucher dated in a year Tally hasn't opened is silently rejected. |
| **Fallback** | Every export is also downloadable as a **CSV/Excel journal** the customer's accountant can post by hand — the same reconciled totals, human-readable. Import failures never block a pay run or a filing; the GL post is downstream of disbursement. A **dry-run diff** shows the voucher before it is emitted. Idempotency: each voucher carries a deterministic `payrun_id` external key (in a voucher reference or narration field confirmed by the schema spike) so re-export updates rather than duplicates. |

**Worked example — the payroll journal voucher (50-employee run).** **[Reversed]** An
earlier version of this example did not balance (debits ₹44,71,100 against credits
₹45,71,100, with a stated total of ₹45,54,200) and its net pay was ₹1,00,000 above gross
less deductions; it is recomputed here. For a monthly run with gross ₹42,00,000 — all 50
members contributing to EPF at the ₹15,000 wage ceiling (EPF wages ₹7,50,000), eight
ESI-covered employees on ₹20,000 each (ESI wages ₹1,60,000), PT ₹200 for 49 employees and
TDS ₹61,700 (both illustrative) — the emitted voucher must balance to the rupee and tie to
§16.3 (rates per §06.2 and §06.3; the EPF admin-charge rate of 0.50% and the nil EDLI
admin charge are the values §06.2 carries as **[Hypothesis]**, and the admin-charge
minimum is the parameter `epf.admin_charge.minimum`, so the ₹7,500 line moves if either
does; the admin charge's wage basis is itself the unsettled parameter
`epf.admin_charge.wage_basis`, but both readings §06.2 names give ₹7,50,000 here, because
every member's EPF wages sit at the ceiling):

| Dr / Cr | Ledger (mapped) | Amount (₹) |
| --- | --- | --- |
| Dr | Salaries & Wages (expense) | 42,00,000 |
| Dr | Employer PF Contribution (expense) — 12% of ₹7,50,000 (EPS ₹62,500 + EPF ₹27,500) | 90,000 |
| Dr | Employer ESI Contribution (expense) — 3.25% of ₹1,60,000 | 5,200 |
| Dr | EDLI + EPF admin charges (expense) — 0.50% + 0.50% of ₹7,50,000 | 7,500 |
| Cr | Net Pay Payable (→ bank batch, §16.3) — 42,00,000 − 90,000 − 1,200 − 9,800 − 61,700 | 40,37,300 |
| Cr | EPF Payable (EE ₹90,000 + ER ₹90,000 + EDLI and admin ₹7,500) | 1,87,500 |
| Cr | ESI Payable (EE ₹1,200 + ER ₹5,200) | 6,400 |
| Cr | Professional Tax Payable | 9,800 |
| Cr | TDS Payable (s.392, ex-s.192) | 61,700 |
| **—** | **Σ Dr = Σ Cr** | **43,02,700** |

`Net Pay Payable ₹40,37,300` must equal the bank disbursement batch total (§16.3) and
Σ payslip net — the three-way tie is checked before the voucher is offered for download.
The EPF payable must also reconcile to the portal's Due Deposit Balance Summary once the
return is approved, including any s.7Q interest the portal computes (EV-036, EV-039).

> **[Hypothesis]** — *Most Tally seats that matter enable the Payroll module.* Kill/validate
> criterion: §20 V-02 (15–25 Tally-partner interviews). If <~5% enable
> payroll, the "import from Tally Payroll" path is low-value and we import from Tally
> *accounts* + a spreadsheet instead; at ~40% the Tally Payroll importer is the single
> highest-leverage onboarding asset. Do not over-build the Payroll-module importer until
> this reports.

> **[Hypothesis]** — *A Tally export carries every field needed to rebuild the year's Form
> 138 salary data.* Kill/validate criterion: §20 V-15 on a design partner's real Tally
> export (§05.5 item 17). If the export omits fields the §16.7 tie-out needs, Tally
> migration degrades to an assisted, services-led import for those heads, and the
> "migration is a product surface" thesis weakens for Tally sources specifically.

**Acceptance criteria (Tally).**

- **AC-TLY-1:** For a 50-employee run, the emitted journal voucher's debits = credits to
  the rupee, and Σ(net-pay-payable) = the bank disbursement total (§16.3) = Σ payslips.
- **AC-TLY-2:** Re-exporting the same `payrun_id` produces zero new vouchers in Tally
  (idempotent by external key), verified against a live TallyPrime instance.
- **AC-TLY-3:** Onboarding import of a real customer Tally export maps ≥95% of employee
  and statutory ledgers automatically (a **[Hypothesis]** target, recalibrated on the first
  §20 V-15 dataset); the residue is surfaced in a mapping UI, never silently dropped.
- **AC-TLY-4:** A ledger-name mismatch routes the line to a named suspense ledger and
  raises a reconciliation exception — it never posts to the wrong head silently.
- **AC-TLY-5:** A voucher dated outside Tally's open financial year is caught pre-emission
  with an actionable message, not left as a silent Tally-side rejection.

---

### 16.3 Banks — salary disbursement and reconciliation

Salary disbursement is on the **pay path**: if it fails, employees are not paid, which is
a same-day escalation. India offers four disbursement mechanisms with materially different
contracts. We support a tiered posture: the file first (universal), an aggregator payout
API or connected banking as the upsell where the tenant qualifies.

Per-rail limits and processing windows differ by provider and by bank, so they are data
(`rail.limits`, `rail.windows`, per provider and bank), never constants (r3/05). The
figures below are one provider's published values, not rail-wide rules.

| Rail | What it is | Published limit and window (RazorpayX, r3/05) | When we use it |
| --- | --- | --- | --- |
| **NEFT** | Batched settlement | Above ₹1 per transaction; processed within 2 hours on working days, in bank-specific windows | Default for bulk salary |
| **RTGS** | Gross settlement for high value | Above ₹2 lakh per transaction; within 30 minutes on working days, in bank-specific windows. Cashfree does not list RTGS (r3/05) | High-value single transfers (e.g. F&F, directors) |
| **IMPS** | Instant | Up to ₹5 lakh per transaction, 24×7 | Off-cycle / urgent single payouts |
| **Connected banking / payout API** | Partner-brokered bank channel, or an aggregator's payout API | Bank or provider SLA | Tenants with a qualifying current account (below) |

**[Verified]** — **The file is the floor; the integration is the upsell** (r3/05). Zoho
Payroll, the closest comparable, ships direct deposit for ICICI, YES Bank, HSBC, Axis and
its own payouts rail, and a downloadable bank advice for every other bank (documentation
read, not executed; r3/05, captured September 2026). We found no Indian bank publishing its salary-file column specification
on a public site — HDFC's ENet pages are marketing copy, and neither the HDFC nor the Axis
developer portal surfaces a bulk-salary API (r3/05). Therefore the **bank file generator is
a per-bank versioned schema** (§16.1), captured from a customer-supplied sample and proven
by a first accepted upload, exactly like the ECR and Form 138 generators.

| Facet | Specification |
| --- | --- |
| **Contract — file** | Per-bank bulk salary upload template: beneficiary account, IFSC, name, amount, narration, debit account, value date, and (for salary-account banks) employee code — the exact columns per bank are captured, not assumed. We ship templates for the banks design partners use, starting with ICICI, HDFC (ENet), Axis, SBI and Kotak (r3/05), and a **configurable generic template builder** (column mapping, delimiter, fixed-width vs CSV, header/trailer, record-count and hash-total checksum) for the long tail so onboarding never blocks on "my bank isn't supported." |
| **Contract — connected banking / payout API** | **Connected banking is partner-brokered, not a public API:** the employer must already hold a corporate current account at that bank, complete document verification through its relationship manager (ICICI may charge a processing fee) and approve activation inside the bank portal; Tally's Connected Banking lists payment initiation for Axis, SBI and Kotak only, ICICI for balance and statement (r3/05). It is a post-launch BD track, not a v1 engineering item. **Payout aggregators:** RazorpayX Payouts requires a current account at a named partner bank (IDFC First, RBL, ICICI, Yes, Axis, Slice) and a mandatory `X-Payout-Idempotency` header; Cashfree Payouts offers API, dashboard and Excel channels without an equivalent partner-bank constraint, with IP allowlisting (at most 25 IPv4 addresses) or a single RSA key (r3/05) — so payout calls run from documented static egress IPs, never from rotating egress. RazorpayX's create-payout call takes the amount in paise (minimum 100), a `reference_id` of at most 40 characters and a `narration` of at most 30 characters drawn from a-z, A-Z, 0-9 and space (r3/05); these are pre-flight rules on the provider's schema object, not code. Credentials stored per §16.12 (secrets vault, per-tenant). **Bank-side maker-checker is a tracked stage:** where the corporate has approval workflows enabled, a payment initiated from the HRMS lands in the bank's own approval queue, so the run shows `pending-bank-approval` naming who must approve in which portal, and an API acknowledgement is never treated as settlement (r3/05). |
| **Data exchange** | Outbound: the disbursement batch (net-pay lines) generated *only* from a LOCKED payroll month (FR-PAY-301 M8; the file itself is §08's FR-PAY-901), and released only by a payment approver distinct from the payroll processor (FR-PAY-904). Inbound: settlement status per line (success / failed / returned) via API status, the bank's downloadable statement in whatever format that bank provides (a per-bank schema object `bank.<bank>.statement_schema`, captured from a customer-supplied sample exactly like the upload template — no statement format is assumed), or manual entry, feeding auto-reconciliation. |
| **Failure modes** | (1) **Invalid IFSC / account** → line rejected or credited wrong (IFSC validated pre-emission against a maintained IFSC directory; account validated through the provider's validation call where one exists, e.g. Cashfree Validate Payout V2, r3/05). (2) **Name-mismatch return** (beneficiary name vs account) — the bank returns the credit later with a reason code. (3) **Partial batch** — some lines settle, some fail; the batch is *not* atomic. (4) **Cut-off missed** — file uploaded after the bank's salary cut-off pays next working day. (5) **Duplicate upload** — same batch uploaded twice → double payment. (6) **Insufficient balance** in the disbursement account → whole batch held. (7) **Holiday/RTGS-NEFT window** and value-date edge cases. (8) **Beneficiary not pre-registered** — a corporate portal may require beneficiary registration or approval before a first credit; whether and for how long is not captured in this PRD's research, so it is recorded per bank at onboarding as `bank.<bank>.beneficiary_registration` and routed to §20, never assumed. (9) **Connection expiry and OTP lockout** — Zoho Payroll's Axis integration expires every 30 days and allows five OTP attempts before it goes inactive and must be set up again (documentation read, r3/05): connection health is tracked, re-authentication is prompted before lapse, a pay run whose bank connection is stale is held before disbursement rather than failing on payday, and OTP entry is never auto-retried. |
| **Fallback** | Universal downloadable bank file is always available even if the API path fails — the customer uploads it in net-banking themselves. **Partial-batch handling is first-class:** each line has an independent status; failed lines are re-queued into a *new* batch without re-paying settled lines (idempotency key per line = `payrun_id + employee_id`). A **pre-flight validation** (IFSC exists, account format, amount > 0, name present, no zero/negative net, batch hash-total matches) blocks a bad batch before it reaches the bank. Reconciliation exceptions (returns, mismatches) open a worklist item, never silently close. |

<!-- DIAGRAM: bank-reconciliation-flow -->

**Worked example — partial-batch return.** A 50-line NEFT batch of ₹40,37,300 (from
§16.2) is uploaded and approved in the bank portal. Settlement status: 48 lines credited,
1 line returned by the beneficiary bank (account closed — reason code captured as the bank
reports it), 1 line failed pre-network (IFSC decommissioned after a bank merger). The run
moves to `disbursed-with-exceptions`. The engine re-queues **exactly the 2 failed lines**
(₹1,54,300 combined) into a new batch keyed on the same `payrun_id + employee_id` pair —
the 48 settled employees cannot be paid twice. The run cannot reach `complete` until
Σ credited (₹40,37,300) = Σ net; the two exceptions carry a reason code and an assignee.
This is the pay-path analogue of "FILED, not SUBMITTED."

**Reconciliation — the load-bearing part.** Disbursement is not "done" when the file
uploads; it is done when **Σ credited = Σ net-pay = Σ payslips** and every exception is
cleared. The reconciliation engine matches bank settlement lines back to pay-run lines by
UTR/reference, flags returns for re-issue, and holds the pay run in a
`disbursed-with-exceptions` state until cleared. This is the integration edge of §08's
FR-PAY-903. The priority conflict an earlier version of this section flagged — §08 rated
FR-PAY-903 **P1** while this section carried reconciliation in P0 — is settled by §05:
credit reconciliation is **P0, R1**, under §05.5 item 33 and capability C-22, because
"paid" is not true until credits reconcile (§05.17 PR-01, routed to the §08 owner to
relabel). The per-line idempotency that stops a re-issue paying anyone twice was never in
conflict (FR-PAY-901 AC-901.3, AC-BNK-2).

**Cut-off awareness (edge cases that cause real incidents).** The engine surfaces the
deadline clock rather than hiding it: a batch scheduled after the tenant bank's salary
cut-off is flagged as "will credit next working day" (Zoho's Axis integration, for
example, documents a 6:45 PM same-day cut-off — documentation read, r3/05; cut-offs are
per-bank data under `rail.windows`, never this figure as a constant); a value date falling on a bank
holiday or outside the rail's processing window is warned pre-emission; a line below the
provider's RTGS minimum is routed to NEFT. None of these silently slip a payday.

**Acceptance criteria (banking).**

- **AC-BNK-1:** Every net-pay line is validated (IFSC in directory, account non-empty,
  amount = payslip net) before the batch is emitted; a single invalid line surfaces as a
  blocking pre-flight error, not a silent drop.
- **AC-BNK-2:** Re-emitting a batch for an already-settled `payrun_id` pays no employee
  twice (per-line idempotency), proven with a returned-line re-issue test.
- **AC-BNK-3:** A partial settlement (e.g. 48/50 lines succeed) leaves the run in
  `disbursed-with-exceptions`, re-queues exactly the 2 failed lines, and the run cannot be
  marked complete until Σ credited = Σ net.
- **AC-BNK-4:** For a supported bank, the generated file imports into that bank's corporate
  net-banking bulk-upload without manual edits (validated per bank release).
- **AC-BNK-5:** A batch whose emitted hash-total / record-count trailer does not match the
  line body is rejected in-product before upload (guards silent truncation).

---

### 16.4 Biometric and attendance devices

Attendance feeds loss-of-pay, overtime and statutory registers (§09), so it is on the pay
path. §09.3 names the device-push receiver **the best-evidenced call in the corpus.**

**[Verified]** — **Build the ADMS/WDMS push receiver in v1** (§09.3, FR-DEV-001). The dominant
device-to-cloud path in India is **outbound**: the terminal HTTP-POSTs punch packets to a
tenant-scoped URL. No on-premise middleware, no static IP, no port-forwarding. eSSL and
ZKTeco both support it; corroborated across four independent sources and unshaken by
hostile re-check (Source: r2/04, via §09.3). The vendor protocol specification itself has
not been captured; it is taken from vendor documentation at the §20 V-11 bench test. The
receiver is R1 capability C-24 (§05.17), whose evidence is that bench result.

<!-- DIAGRAM: device-push-ingest -->

| Facet | Specification |
| --- | --- |
| **Contract — push (P0)** | We expose a **tenant-scoped ingest endpoint** implementing the vendor's push semantics — device handshake, heartbeat, attendance-log upload, command poll (§09.3 FR-DEV-001 AC2). Exact endpoint paths and packet field names come from the vendor protocol documentation at the §20 V-11 bench test; this PRD does not assert them. The logical packet contract every vendor adapter maps onto — handshake, heartbeat, attendance-log upload, command poll, command result and the consent-gated template upload, with the receiver's obligation and failure handling for each — is §09's FR-DEV-008 and is not restated here. The admin enters the endpoint URL + per-device secret into the device's cloud-server config once; punches then flow with no middleware. Device serial → tenant → location mapping is registered at setup. |
| **Contract — pull (P1)** | For devices without ADMS or on segregated plant networks, a **pull path** via the vendor SDK / port-4370 protocol through a lightweight on-prem agent, or a **third-party connector**. **[Verified]** (§09.3 FR-DEV-005; r2/04): a paid connector market exists at ~**$345 one-time to $588/year** — cheap enough that we **partner/buy for the long tail** rather than build for every SDK-bound brand and firmware. |
| **Data exchange** | Inbound punch packet: device serial, user id (device-local), timestamp, punch direction/verify mode. We map device-user-id → employee, dedup, and keep per-day IN and OUT times, because Form IX requires them (EV-055); shift, OT and LOP derive per §09 — OT at not less than twice the ordinary rate against wage-period normal hours (§09.6 FR-OT-001). **[Reversed]** An earlier version cited a 144-hour quarterly OT ceiling here as [Verified]; it is **[Hypothesis]** (K-04) — never confirmed against gazette text, warn-only, never a block, routed to §20 V-17 (§09.6). Outbound (push protocol): user-sync commands queued to the device. Biometric templates never enter business tables — they sit in the separate template keyspace, as an entity separate from the attendance event (Part E-6, §09.2-C); template sync runs only for employees whose written consent is on file, because the SPDI Rules require consent in writing before biometric data is collected (EV-060; enrolment under written consent and the ~May 2027 regime switch are §09.2-B, and who owes that duty is under counsel review, Part D-4, §23); template erasure is two-phase over the command channel, with a documented exception state (§09.3 FR-DEV-007; §09.3-B). |
| **Failure modes** | (1) **Clock drift** on the device → punches land in the wrong day/shift (CERT-In also requires NTP sync, EV-062, §16.12). (2) **Device offline** — punches buffered locally, arrive in a burst on reconnect (must be idempotent). (3) **Duplicate punches** (double-tap, retry). (4) **Unmapped device-user-id** (new joiner enrolled on device but not in HRMS, or vice-versa). (5) **Firmware quirks** on legacy port-4370 — the protocol is undocumented and reverse-engineered, with confirmed enrolment and data-restore limitations (r2/04, [Verified]). (6) **Shared-device identity** — nine in ten people who do not use a phone live in a household that owns one; worker identity ≠ device identity (§09 FR-ATT-013 [Verified]). (7) **Serial spoofing** — an unregistered serial POSTing to the endpoint (mitigated by per-device secret + serial allowlist, §09.3 FR-DEV-001 AC3). |
| **Fallback** | If a device is down or unsupported, attendance falls back to **web/mobile check-in (with GPS/geofence), bulk CSV upload, and manual muster** — none block payroll. Buffered bursts are handled by **idempotent ingest** keyed on `(device_sn, device_user_id, device_timestamp, direction)` + `payload_hash` (§09.3 FR-DEV-001 AC4). Unmapped punches go to an **exceptions worklist** and are held out of pay until mapped, never dropped. A punch that cannot be mapped by pay-run lock is treated per the tenant's configured policy (present-assumed vs LOP), surfaced explicitly. |

**Worked example — buffered burst after reconnect.** A plant terminal (serial
`T-PLANT-01`, an illustrative label, not a vendor serial format) loses WAN for 6 hours across a shift change and buffers 214 punches. On
reconnect it POSTs them in one attendance-log upload. Idempotent ingest keyed on
`(device_sn, device_user_id, device_timestamp, direction)` + `payload_hash` writes each
punch exactly once even though the device retries the POST twice (it did not receive our
first acknowledgement in time). Two punches carry a
device-user-id (`00042`, `00119`) with no HRMS mapping — they land in the exceptions
worklist and are excluded from that day's LOP/OT computation until an admin maps them,
rather than being counted as absent. Net result: 212 attributed, 2 held, 0 duplicated,
0 dropped.

**Highest-leverage cheap artefact (§09.3 FR-DEV-004, carried into this section):** ship a
**public, model-level device compatibility matrix and a self-serve verification tool**
before the first enterprise sales call (P1, §05.5 item 21). It neutralises deal-gating risk, and we are not
aware of any incumbent publishing one as of September 2026. This is an integration
deliverable, not just marketing: it is the self-serve front door to §16.4.

> **[Killed]** — Do not size device work from the retracted "85–98% success / 1-in-7
> devices won't integrate" figure — it was marketing from the vendor selling the fix
> (§09.3; §20.4 banned-numbers table). Device integration effort is **currently
> unsized**; it needs a hardware spike (§20 V-10) before any completion date is committed.

**Acceptance criteria (devices).**

- **AC-DEV-1:** A factory-config eSSL or ZKTeco terminal pointed at the tenant ingest URL
  streams punches with zero on-prem software, mapped to employees within one poll cycle.
- **AC-DEV-2:** A device reconnecting after 6 hours offline delivers its buffered punches
  and produces **no duplicate** attendance rows (idempotent ingest).
- **AC-DEV-3:** An unmapped device-user-id raises an exception and is excluded from LOP/OT
  computation until resolved — it is never silently counted as absent or present.
- **AC-DEV-4:** The public compatibility matrix returns a supported/partner/unsupported
  verdict for a given make+model+firmware, self-serve, before any sales contact.
- **AC-DEV-5:** A POST from an unregistered serial (no per-device secret match) is rejected and
  logged as a security event (§16.12), not silently ingested.

---

### 16.5 Government statutory portals — the filing path

These are the integrations that carry the unit of delivery (§01). They share one brutal
property: **there is no submission API we are aware of** (K-13, §16.1). The
"integration" is *generate a portal-accepted artefact → submit it in an attended session,
by the employer or by our operator under written authority to act (§22) → capture and
reconcile the acknowledgement and receipt.* We are candid about this rather than
pretending an API exists. The operator path (Mode C) is fenced on counsel (Part D-17,
§23; §05.7 A-23; §20 V-25): until it clears, the employer is the one in the session
(Mode A, or Mode B with our operator guiding and never operating the portal, §22
FR-OPS-001), and everything below still holds for that session. In every mode the
statutory payment and any DSC-bound act are the employer's (§16.1).

**[Verified]** — **The corrigendum discipline applies to every file schema here.** Two
adversarial research rounds reached *opposite* conclusions on the Nov-2026 EPF cliff
because one read a notification without checking for a corrigendum (§02.4 standing
rule; the uncorrected S.O. 5319(E) enumeration is still reproduced on indiacode.nic.in —
verifying there alone reproduces the error). Every statutory file schema carries a
gazette/notification source (URL + date), and the statutory-change watcher (§16.12;
§02.4; §13.13; operated by §22's compliance data pipeline) must **catch amendments, not
just new instruments** — a watcher keyed only to new notifications would have missed the
corrigendum that inverted the entire Nov-2026 analysis.

<!-- DIAGRAM: integrations-api-portal-filing-map -->

**The filing lifecycle is §08's filing-instance state machine (FR-PAY-711), not a second
machine here.** **[Reversed]** An earlier version of this section specified its own
lifecycle (draft → validated → file-generated → upload-assisted → submitted →
acknowledged → paid → filed, with a flat five-year retention). It had no REJECTED, REVISED
or SUPPLEMENTARY state and no payment-initiation step, so it could not represent the rule
that a Revised ECR is impossible once payment is initiated (EV-037, Part E-1), and its
retention figure contradicted the per-rule-set wording of EV-054. This section owns only
the portal edge of FR-PAY-711: what the attended session does at VALIDATED → SUBMITTED,
what is captured at SUBMITTED → ACCEPTED or REJECTED, and which receipt closes
PAYMENT_INITIATED → FILED — per portal, in §16.5.1–§16.5.4. Only FILED counts as done;
the statutory verification gate sits immediately before PAYMENT_INITIATED (FR-PAY-301
M10); a stuck state raises the deadline clock, never hides it; and an unpublished format
or unresolved regime short-circuits to BLOCKED with its reason (FR-PAY-711 F2).

#### 16.5.1 EPFO — ECR, UAN, KYC

| Facet | Specification |
| --- | --- |
| **Contract** | Attended upload on the EPFO employer portal — interactive login with a CAPTCHA (r3/05) — by the employer, or by our operator under written authority to act (§22). Primary artefact: the monthly **ECR (Electronic Challan-cum-Return)** return file. Flow: upload → validate → return statement → approve/reject → Due Deposit Balance Summary → challan with TRRN → pay → receipt; return submission is separate from payment, an approved return can never be cancelled, and multiple challans are permitted (EV-036). Return types Regular, Supplementary and Revised, with the EV-037 guards (a Revised return only while no payment is initiated); strict month-wise chronological filing (EV-038); s.7Q interest auto-calculated and mandatory with the contribution (EV-039). **UAN:** since 1 August 2025 the employee allots and activates their own UAN through Aadhaar face authentication in the UMANG app; the employer route survives only for International Workers and citizens of Nepal and Bhutan (EPFO circular of 30.07.2025, r4/04; §10.8 FR-T-O07) — the product prompts, tracks and chases, never collects. What EPF Scheme 2026 para 25 says about Aadhaar, seeded bank account, PAN and UAN is known only from a secondary reproduction (§20 V-24), so no EPF onboarding step is conditioned on it. Supporting: KYC-seeding status, and the EPF forms and registers — whose catalogue under Scheme 2026 is not captured (`epf.form_catalogue`, §06.13), so the legacy Form 3A/6A/5/10/12A labels TallyPrime ships (EV-032) are carried as display names until it is. **Build against the Employees' Provident Funds Scheme, 2026** (12% re-notified retrospective to 21.11.2025 by S.O. 3582(E) — §06.2 [Verified]), not the repealed 1952 scheme. |
| **Data exchange** | Outbound: the ECR return file — UAN, Member Name as per UAN, Gross Wages, EPF Wages, EPS Wages, EDLI Wages, Employee PF Contribution, Employer EPS Contribution, Employer PF Contribution, NCP Days, Refund of Advance (EV-035); the part-payment contribution file is a separate 6-field export (EV-044; R2, §05.7 A-05). A NIL month uses no file: admin and inspection charges are paid through Direct Challan Entry, enabled only when there are no active members, as an attended task (EV-042; FR-PAY-712 AC-712.4). Inbound: the return file ID, return statement and Due Deposit Balance Summary; the **TRRN** at challan; after payment, the **receipt** — captured and stored as the proof-of-filing artefact (EV-036). On a failed upload EPFO returns a downloadable error file whose schema is undocumented and must be captured from a real rejection (r5/02; §20 V-23); until it is, an unmapped error is recorded as SA-PORT-UNMAPPED with the raw file attached and routed to §22 (FR-PAY-713 AC-713.4). |
| **Failure modes** | (1) **Wage-base error** — the 50% add-back (§06.10, §08) mis-computed → wrong EPF wages → wrong challan. (2) **UAN not allotted / KYC incomplete** → the member is flagged before file generation; the default is **exclude-and-flag** with notices to the operator and the employee — never a payroll block, because the product treats Aadhaar as optional everywhere, EPF flows included, and ships no hard-block configuration (Part E-11, Part D-10) — and the member follows on a Supplementary return (Part E-11, EV-037, FR-PAY-701 AC-701.2; final choice with counsel, §23). (3) **Delimiter/format drift** on an EPFO release → upload rejected (the September 2025 revamp did not change the layout, EV-035). (4) **Portal downtime / maintenance windows** near due dates. (5) **Arrears routed into the monthly file** — arrears use a separate File Arrear Return flow whose layout is unpublished and fenced (EV-043); PF liability on arrears dates from the disbursal date (Part E-9). (6) **The cliff:** the one-year saving of the EPF Scheme 1952, EDLI 1976 and EPS 1995 expires on or about 21 Nov 2026; the EPF side has a named successor (Scheme 2026, §06.9), but research captures no EPS or EDLI successor instrument, and we are not aware of one as of September 2026 (§06.13; §20 V-22), so the EPS/EDLI split on post-cliff ECR lines is watched, and any field or form change arrives through the watcher. (7) **NCP-days error** — non-contributory (loss-of-pay) days wrong → contribution mismatch. (8) **Chronology gap** — a skipped month blocks later Regular returns under the M−4 rule, and a wrongly recorded exit date needs a joint declaration (EV-038, EV-041; FR-PAY-712). |
| **Fallback** | The attended session is the primary path; the ECR file is also always downloadable so the employer or their CA can run the session without us — the product never becomes a single point of failure for a statutory deadline. A **pre-upload validator** mirrors EPFO's documented checks at EPFO's own severity — the age-58 EPS rule blocks, the post-01.09.2014 high-earner EPS rule only flags (EV-040) — and adds no block EPFO does not impose. Status runs on FR-PAY-711: FILED needs the approved return's file ID, the TRRN and the payment receipt, and the verification gate sits immediately before payment initiation (EV-037, FR-PAY-301 M10). The challan payment itself is always made by the employer, in every delivery mode (§22 FR-OPS-001). |

**The ECR return-file line layout (the schema object, concretely).** The ECR return file
is a `#~#`-delimited text file — three characters, 10 delimiters per line — with one line
per member, **no header row** and 11 fields; Gross Wages is mandatory (EV-035; Source:
EPFO User Manual ReECR v3.0 p.8, r5/02). Wage Month, Return Type, Contribution Rate and
Remark are portal form controls, never file content (EV-035). The EPFO Help File sample
line is the golden fixture (§06.14 TV16).

| # | Field (EV-035) | Rule / worked value |
| --- | --- | --- |
| 1 | UAN | the member's UAN; EPFO validates UAN and member details and rejects invalid rows before approval (r3/05) |
| 2 | Member Name as per UAN | as held against the UAN |
| 3 | Gross Wages | ₹30,000 |
| 4 | EPF Wages | ₹15,000 (statutory ₹15,000 wage ceiling, §06.2) |
| 5 | EPS Wages | ₹15,000 (EPS wage ceiling ₹15,000) |
| 6 | EDLI Wages | ₹15,000 |
| 7 | Employee PF Contribution | ₹1,800 (12% × 15,000) |
| 8 | Employer EPS Contribution | ₹1,250 (8.33% × 15,000, capped at ₹1,250) |
| 9 | Employer PF Contribution | ₹550 (balance of the employer's 12% after EPS: 1,800 − 1,250) |
| 10 | NCP Days | 0 |
| 11 | Refund of Advance | 0 |

**Worked example — the 50% add-back that drives EPF wages (§06.10 [Verified]).** This is
the hardest single calculation in the build (§06.10), and it is what makes field 4 above
correct. **[Reversed]** An earlier version of this example reached its 60% by treating a
₹10,400 "special allowance" as excluded; special allowance is not an excluded head, and
relabelling universal pay does not move it out of wages (§06.10, *Vivekananda
Vidyamandir*, §06.2). Consider instead an employee at ₹30,000/month structured as Basic
₹12,000, HRA ₹9,000, Conveyance ₹3,000, Commission ₹6,000.

- **Excluded components** (HRA + conveyance + commission, all among the excluded heads
  (a)–(i) of s.2(y)/s.2(88)) = ₹9,000 + ₹3,000 + ₹6,000 = **₹18,000 = 60% of total**.
- The proviso caps exclusions at **50%** of total remuneration = ₹15,000. Excess =
  ₹18,000 − ₹15,000 = **₹3,000 is deemed wages and added back.**
- **Add-back wage base** = (₹30,000 − ₹18,000) + ₹3,000 = ₹12,000 + ₹3,000 = **₹15,000**.
- EPF wages = min(₹15,000 add-back base, ₹15,000 ceiling) = **₹15,000** → fields 4–6.

The engine runs **at least four concurrent wage bases per employee-period** (§06.10); two
of them matter to this file: the add-back base (₹15,000, drives PF/EPS/EDLI/gratuity) and
the equal-pay/payment-of-wages base (₹30,000, includes HRA and conveyance). The rule
version is effective-dated because "50%" is a notified variable, not a constant — an
arrear run recomputes against the version in force for the corrected period, not today's.

**EPF amounts for this member (what the portal's Due Deposit Balance Summary must
reconcile to, and what ties to the Tally voucher, §16.2).** The challan itself is
generated by the portal after the return is approved (EV-036); these are the computed
amounts it is reconciled against, plus any s.7Q interest the portal calculates (EV-039).

| Head | Rate | Amount (₹) |
| --- | --- | --- |
| A/c No. 1 — EPF (employee 12% + employer balance after EPS) | 12% + balance | 1,800 + 550 = 2,350 |
| EPS (employer 8.33%, capped at ₹1,250) | 8.33% × 15,000 | 1,250 |
| EPF admin charges | 0.50% of PF wages **[Hypothesis]**; establishment-level minimum = parameter `epf.admin_charge.minimum` | 75 for this member; the minimum applies once per establishment per wage month |
| EDLI (employer 0.50%) | 0.50% × 15,000 | 75 |
| EDLI admin charges | nil **[Hypothesis]** | 0 |

(EPF, EPS and EDLI rates per §06.2 **[Verified]**. The admin-charge rate and the nil EDLI
admin charge rest on pre-Code EPFO circulars that were not re-verified, and the minimum is
unset data — both are §06.2 **[Hypothesis]** items routed through §06.13 to §20; v0.3's
rupee minimums are not carried. The amount the product reconciles against is always the
portal's own Due Deposit Balance Summary, whose account-head numbering is read, never
hard-coded. Rates re-verify against notification — the watcher owns this.)

#### 16.5.2 ESIC — contribution and IP management

| Facet | Specification |
| --- | --- |
| **Contract** | Attended template upload on the ESIC employer portal (K-13; §22): monthly **contribution upload** → challan generated on the portal → payment by the employer. We are not aware of any published API, file specification or bulk machine interface as of September 2026 (r3/05); whether employer login carries a CAPTCHA is not captured (§20 V-23). IP (Insured Person) registration for new joiners; wage-ceiling gate at ₹21,000 (₹25,000 for a person with disability) (§06.3). |
| **Data exchange** | Outbound: the monthly contribution template. Practitioner sources describe an Excel template of roughly six columns — IP number, IP name, number of days, total monthly wages, reason for zero wages, last working day — but the template itself 404s and the column list is **unconfirmed** from an ESIC primary source (r3/05, low), so the upload file waits on a capture task (§05.7 A-08; fence F-05): the schema object — columns, order, file type, and whether a DSC is needed — is captured from the ESIC portal inside an attended session on a design partner's registration (§20 V-23) and versioned as `esic_mc_template_version` before the generator is written. If the capture finishes before the R1 gate the file ships in R1 (C-12); if not, it moves to R2 by rule (§05.17). Until then ESI is computed and shown as a worksheet the operator keys into the portal's template. EE 0.75% + ER 3.25% (§06.3 [Verified]); the rates and ceiling predate the 8 May 2026 Rules and are re-baselined against them and against the post-cliff position (§05.7 A-07). Inbound: challan + payment confirmation as proof-of-filing. |
| **Failure modes** | (1) **Ceiling-crossing mid-cycle** — an employee crossing ₹21k mid-contribution-period must be handled per the "continue to period end" rule; a naive cutoff mis-files. (2) **IP not registered** → member rejected. (3) **Applicability by area** — ESI applies in notified areas only; a location not in a notified area shouldn't file. (4) **Portal timeout on large files.** (5) **The ESI side of the Nov-2026 cliff is unresolved** — we are not aware of any successor instrument for the ESI rules, regulations and schemes after the one-year saving expires on or about 21 Nov 2026, as of September 2026 (§06.9, where it is an ungraded open item, EV-004, not a [Verified] fact); this is §20 V-08, fence A-09, and a hard dependency. (6) **Incomplete TLS chain** — esic.gov.in serves an incomplete certificate chain, which breaks naive HTTP clients and any automation built against it (r3/05). |
| **Fallback** | Downloadable contribution worksheet — and, once `esic_mc_template_version` is captured, the filled template — for the employer or their CA to upload; pre-validation of ceiling and IP status; area-applicability check per location; **BLOCKED-pending-regime** for post-cliff ESI rather than emitting a guessed file (FR-PAY-711 F2; §08.13 G7 — blocked states are honest). |

**Worked example — the two contribution periods and mid-cycle ceiling crossing.** ESI runs
on fixed contribution periods **April–September** and **October–March**, with benefit
periods lagging (§06.3; Source: ESIC contribution/benefit-period rules). An employee earning
₹20,000 in April gets a raise to ₹23,000 effective July (mid-period). The **"continue to
period end" rule** means: because they were covered at the start of the April–September
period, contribution continues on the *full ₹23,000* until 30 September — they do **not**
drop out on crossing ₹21,000. From the next period (October) they are out of ESI. A naive
"stop at ₹21k the month they cross" cutoff under-files three months and creates a
recoverable default. Contribution at ₹23,000 for July, before rounding: EE 0.75% =
₹172.50 and ER 3.25% = ₹747.50. The rounding of each share is the parameter
`esi.rounding_rule` (§06.3 — v0.3's "round up to the next rupee" is carried, not
re-captured, **[Hypothesis]**, routed through §06.13 to §20); the upload never carries an
assumed ₹173 or ₹748 until that parameter is set from an ESIC source.

#### 16.5.3 TRACES / Income-Tax e-filing — TDS (Form 138 ex-24Q, Form 130 ex-16)

This is the most volatile file schema in the product because the format is a **breaking
layout change on a dual FVU stack** (EV-051, EV-052; §06.5).

| Facet | Specification |
| --- | --- |
| **Contract** | Quarterly TDS statement **Form 138 (ex-24Q)**, governed by Rule 219 of the Income-tax Rules 2026 (EV-049), for **Q1–Q3**. The product generates the statement `.txt`; the **deductor** runs Protean's Java File Validation Utility against it together with the `.csi` file from the TIN Challan Status Inquiry, and uploads the resulting `.fvu` on the income-tax portal — or our operator does so in an attended session under written authority (K-13, §22; r3/05). Two of the four attended-filing questions bite here specifically — whether filing a TDS statement for a deductor engages the e-Return Intermediary route, and how the authorised signatory's personal DSC is handled — and whether a DSC or EVC is needed at `.fvu` upload is itself unconfirmed (r3/05 open question); all are under counsel review (Part D-17, §23), and until they clear the deductor uploads (§05.7 A-23). **Form 130 (ex-Form 16)** is **TRACES-generated only** and has Parts A, B and C; a certificate not generated from TRACES is invalid (EV-048). TRACES builds it from Annexure I (quarterly) and Annexure II (Q4) of Form 138, so the product prepares the Form 138 data and distributes the signed certificate the deductor requests and downloads from TRACES (r5/02; FR-PAY-707). **[Reversed]** An earlier version had us download Part A from TRACES and generate Part B ourselves; that is invalid on both counts. Also: TDS deposit tracking (challan identification captured on payment) and challan-to-deductee mapping; the deposit due dates sit in Rule 218, which has not been read, so deposit timing is judged only once fence F-10 clears (§05.7 A-10; §20 V-20). |
| **Data exchange** | Outbound: the Form 138 statement — ASCII `.txt`, `^`-delimited variable-width fields, every record CRLF-terminated, record types FH / BH / CD / DD, file type `SL1` (EV-051); challan sub-headings remapped to A–K with 303 removed and Annexure I remapped to C–N with 313, 321, 322 and 325 removed; Interest Allocation and Others Allocation added; Surcharge, Education Cess and Penalty/Others removed (EV-051; Source: Protean RPU/FVU 1.2 key features; Q1–Q3 regular format 22 Jul 2026, Q1–Q3 correction format 4 Aug 2026, r5/02). Form 138 has three annexures: Annexure I every quarter; Annexures II and III in Q4 only (EV-047). Tax Year field is six digits (202627 for Tax Year 2026-27), and labels, search and imports accept both vocabularies (EV-050). Inbound: the FVU validation result; the Return Receipt Number (which replaces Token No., EV-051); the TRACES-downloaded, deductor-signed Form 130 for distribution (EV-048). |
| **Failure modes** | (1) **The Q4 regular and correction formats are unpublished** ("Expected to be released soon", no link; re-checked September 2026, EV-046) → Q4 and Tax Year 2026-27 Form 130 preparation are blocked until they land (fence F-01; the release watch is §20 V-19, keyed on Protean's Q4 anchors, never its client-side "Updated As On" footer). (2) **PAN missing or inoperative** → higher-rate deduction (1961-Act s.206AA for FY 2025-26 and earlier; the 2025-Act successor is unmapped, §06.13, FR-PAY-205 AC-205.3) and statement defects. (3) **Challan mismatch** — a deposit not yet reflected in the `.csi` from the TIN Challan Status Inquiry; the TAN and TAN name must match it (r5/02; AC-706.2). (4) **Regime mis-election** (old vs new; the new regime is the default under 1961-Act s.115BAC, its 2025-Act successor unmapped, §06.13) at employee level → wrong TDS. (5) **FVU stack mixing** — RPU 1.2 + FVU 1.2 serve Tax Year 2026-27 onward and RPU 6.0 + FVU 9.5 serve FY 2010-11 to FY 2025-26; mixing them, or replacing only the FVU jar in an old folder, causes rejection (EV-052; r5/02). (6) **Correction filing not yet open** — the Q1–Q3 correction format is published (4 Aug 2026, r5/02) and generation and FVU validation are buildable, but in September 2026 the e-filing portal said Tax Year 2026-27 correction statements "will be enabled shortly" (r3/05), so correction *submission* is held while fence F-02 is open (§05.7 A-12). (7) **Legacy correction layout not held** — a correction to a FY 2025-26 or earlier 24Q statement would go through the legacy RPU 6.0 + FVU 9.5 stack (EV-052), but the legacy correction layout itself is not in this PRD's evidence base, so that artefact is deferred (§05.7 A-28): the product flags it and routes it to the prior vendor or the tenant's CA rather than generating it. |
| **Fallback** | The statement `.txt` is always downloadable for the deductor or their CA to validate through the FVU and upload — the path Zoho Payroll's own documentation describes (r3/05). **Q4 Form 138 (Annexures II and III) and Tax Year 2026-27 Form 130 preparation render BLOCKED-pending-layout** (EV-046; FR-PAY-711 F2), never silently emitted with guessed field mapping, and the legacy 24Q Q4 layout is never used as a proxy (§08.13 G7). The mandatory `.csi` import flags un-reflected challans before generation (AC-706.2). |

**Worked example — the challan-head remap that breaks a hard-coded layout.** **[Reversed]**
An earlier version of this example applied the new layout to a "Q2 FY26" return and
mapped sub-heading 304 to TDS and 305 to surcharge; FY 2025-26 statements stay on the legacy
24Q stack (EV-052), and the published remap sends 304 to C ("Total Interest") and 305 to
D ("Total Fee") (r5/02). Correctly: in October 2026 the same deductor may owe a **Q2
statement for Tax Year 2026-27**, generated as Form 138 — challan sub-headings 301 → A,
302 → B, 303 removed, 304 → C, 305 → D; Surcharge, Education Cess and Penalty/Others gone;
Interest Allocation and Others Allocation added (EV-051) — and a **correction to a Q2
FY 2025-26 statement**, which belongs on the legacy 24Q layout and the RPU 6.0 / FVU 9.5
stack (EV-052). A vendor who hard-coded column ordinals, or who switches layout by today's
date, mis-files one of the two. Our schema object routes by **period**: the Form 138
layout covers Tax Year 2026-27 onward, with the Protean release (22 Jul 2026) recorded as
its source, and the watcher (§16.12) routes each new release to it before any statement
is generated. The FY 2025-26 correction resolves to the legacy stack — and, because the
legacy correction layout is not held, to a deferred artefact that the product flags and
hands to the prior vendor or the tenant's CA (§05.7 A-28), never to the Form 138 writer.

#### 16.5.4 State Professional Tax (PT) and Labour Welfare Fund (LWF)

| Facet | Specification |
| --- | --- |
| **Contract** | Per-state PT return + payment on each state's portal, at a cadence that is per-state data (Maharashtra assigns frequency per registration each financial year and publishes it on MAHAGST — ingested, never derived; Odisha is annual; every other state is not captured, §06.4); per-state LWF contribution on each state's labour-welfare portal at a periodicity that is also data (`lwf.<state>.periodicity`; Karnataka's calendar-year cycle due 15 January is the one verified, §06.8). Each is an attended session on a manual portal — Maharashtra's MAHAGST offers e-Return PT and e-Payment for PTRC/PTEC with no API (r3/05) — so state PT is N portals, not one integration (K-13). These are the most fragmented interfaces in the product — **one schema and cadence per state.** |
| **Data exchange** | Outbound: the state's PT return and LWF remittance, each a per-state schema object — `pt.<state>.return_schema` and `lwf.<state>.remittance_schema` — captured from that state's portal or instrument and published in the state onboarding pack (§22 FR-RULE-017) before the leg ships (§20 V-09). No state's return or remittance field list is captured in this PRD's research, Maharashtra's included (its return format and due day are open, `pt.MH.due_day`; §05.7 A-15), so none is assumed here. Inbound: challan/receipt. **[Reversed]** Earlier text said Frappe HR "already ships PT across 15+ states and LWF across 14, free" and concluded this was parity. That is false from source code: Frappe HR v16's whole India payroll is three files and 549 lines with no Indian state name anywhere in the tree and no PT slabs or LWF (EV-031), and TallyPrime has no state PT slab table and no LWF engine (EV-032). **Multi-state PT and LWF are a genuine differentiator — greenfield in both incumbents** (K-01). |
| **Failure modes** | (1) **Slab drift** — states revise PT slabs and gender variants; a stale slab mis-computes (Maharashtra and Odisha are verified at state primary sources, Karnataka's effect is verified with its instrument not retrieved, every other state is unverified — §06.4). (2) **Registration-not-done** per state/location — MAHAGST runs PTRC (employer deduct-and-remit) and PTEC (the entity's own liability) as separate e-return and e-payment flows (r3/05); the two-registration structure is **[Hypothesis]** as a general rule elsewhere (§06.4). (3) **Cadence confusion** — filing monthly where the state wants annual, or vice-versa. (4) **Portal-per-state** availability and format variance. (5) **Gender/exemption variants** — Maharashtra's threshold for women differs from men's (nil up to ₹25,000, §06.4); every other state's variants are captured per state (§20 V-09), never assumed. |
| **Fallback** | Downloadable per-state file/return; **effective-dated per-state slab tables** with state-primary provenance (a build dependency — the verified PT/LWF dataset for every state is undone work, §20 V-09, maintained by §22's compliance data pipeline). Where a state has no usable portal export, produce the **filled human-readable return** for manual entry. Phasing follows §05.5 and §05.17: in R1 only computation ships, and only for states whose row is state-primary-sourced — Maharashtra at R1 entry (C-16); every PT return leg and every LWF remittance is R2 per design-partner state as its fence ships (A-15, A-16, A-17; PR-03); the all-states dataset is P2 (item 23). |

**Worked example — same salary, four states, one national table cannot represent them.**
An employee earning ₹30,000 gross/month triggers different PT depending on the state of
the place of work, which is why PT must be effective-dated *per state* and never a single
national table (rows per §06.4):

| State | Monthly PT on ₹30,000 | Cadence | Status |
| --- | --- | --- | --- |
| Karnataka | ₹200 (₹300 in February) | Unverified | **[Verified]** effect on the state PT portal — ₹200/month at ₹25,000 or above, ₹300 in February, ₹2,500 a year |
| Maharashtra (man) | ₹200 (₹300 in February) | Assigned per registration each financial year | **[Verified]** at state primary source; PTRC and PTEC are separate MAHAGST flows (r3/05) |
| Odisha | ₹200 for the first 11 months and ₹300 for "the last month" — because the slab tests **annual** income (₹3.6 lakh here, above ₹3 lakh), not the monthly figure | Annual, online only | **[Verified]** at state primary source; which month is "the last month" (February or March) is **[Hypothesis]**, and a reported April 2026 repeal ordinance is unconfirmed (§06.4) |
| West Bengal, Tamil Nadu and every other state | Not captured — parameter `pt.<state>.slabs` (Tamil Nadu: `pt.TN.<local_body>.slabs`, a local-body levy) | Not captured | **[Hypothesis]** — v0.3's figures are not shipped (§06.4) |

**[Reversed]** An earlier version of this table gave West Bengal a slab (₹25,001–40,000 =
₹150) that contradicted its own ₹200 answer at ₹30,000, gave Karnataka no February
top-up, and said only Telangana was verified; its West Bengal ₹200 answer and Tamil Nadu
half-yearly cadence are not captured at any state source (§06.4) and are removed, with
Odisha — verified, and structurally different — in their place. Kill/validate criterion for the
[Hypothesis] rows: each state's slab must be replaced with a state-primary-sourced,
effective-dated entry before that state ships; until then the state renders its PT with a
"slab unverified — confirm before filing" banner rather than emitting a silent figure
(§20 V-09). Evidence status is not ship status: Karnataka and Odisha are [Verified] in
effect above, yet both stay fenced (§05.7 A-16) — Karnataka because its amending
notification was not retrieved, Odisha because a reported repeal from 1 April 2026 is
unconfirmed — and only Maharashtra's computation is in R1 (C-16).

**Master acceptance criteria (statutory portals).**

- **AC-GOV-1:** Every generated statutory file passes an **in-product pre-validator** that
  mirrors the portal's/FVU's documented checks at the portal's own block/flag severity
  (EV-040) and adds no block the portal does not impose, so the modal outcome of an upload
  is acceptance, not rejection.
- **AC-GOV-2:** Filing status runs on the FR-PAY-711 machine: only **FILED** — the
  acknowledgement stored (return file ID and TRRN for the ECR; Return Receipt Number for
  Form 138) and, for a payment-bearing filing, the payment receipt — counts as done; a
  SUBMITTED or ACCEPTED filing is not "done", and a REJECTED one is counted, never hidden
  (§01, §08.13 G5).
- **AC-GOV-3:** Every file schema is a versioned object with a gazette/notification source
  (URL + date); a format change is a data update, not a code deploy (§16.1).
- **AC-GOV-4:** Formats that **are not yet published** (Q4 Form 138 and Tax Year 2026-27
  Form 130 preparation, EV-046; the ECR arrear return, EV-043) and regimes that are
  **unresolved** (post-cliff ESI) render as explicit BLOCKED states, never as
  silently-emitted guessed files.
- **AC-GOV-5:** The statutory-change watcher fires on **amendments/corrigenda**, not only
  new notifications, and routes each hit to the owning schema for review.
- **AC-GOV-6:** The 50% add-back is one of at least four concurrent wage bases per
  employee-period (§06.10), and an arrear/retro run recomputes against the rule version in
  force for the corrected period (§06.10 [Verified]), verified by a retro-recompute test.

> **[Hypothesis]** — *Automation inside the attended session (browser assistance that
> fills and uploads while a named human is present for login, CAPTCHA and OTP) is worth
> building for the top three portals.* It never makes submission unattended: EPFO's
> CAPTCHA on login makes unattended automation impossible by design (r3/05), and no CAPTCHA
> is ever bypassed. Every such session runs under the employer's written authority to act
> and is logged (§22). Whether portal terms of use permit third-party credential use, and
> the other attended-filing questions, are under counsel review (Part D-17, §23) — no
> automation ships before that clears. Kill/validate criterion: if portal anti-automation
> (CAPTCHA, session fingerprinting, terms of use) makes it fragile or non-compliant, drop it
> and stay at generate-file-plus-guided-attended-upload. It is never the *only* path — the
> downloadable file is always available.

---

### 16.6 Accounting systems beyond Tally

For tenants whose book of record is not Tally, the payroll journal must post to their GL.

| Facet | Specification |
| --- | --- |
| **Contract** | Zoho Books, Busy, and generic ERP (SAP/Oracle/MS Dynamics/NetSuite) GL. Zoho Books has a real REST API — OAuth 2.0, an India data centre and a full journals operation set (r3/05); we found no public API or developer documentation for Busy (r3/05); ERP targets are treated as file/DI (data-interchange) until a customer's ERP is scoped. **[Reversed]** QuickBooks India is removed from this list: per Intuit's India page, new sign-ups ended in July 2022 and there has been no access to QuickBooks products in India since 1 July 2023 (r3/05). |
| **Data exchange** | Same payroll journal voucher as §16.2 (debits/credits by expense and payable head), mapped once to the target chart of accounts. Zoho Books: one consolidated create-journal call per pay run (optionally split per department or cost centre, never one call per employee), against the India data centre — Zoho publishes 100 requests per minute per organisation and a daily cap as low as 1,000 requests on its free plan (r3/05), so per-employee posting would breach it. ERP/Busy: emit the DI file (CSV/XML/IDoc-style) to the customer's mapping. |
| **Failure modes** | (1) **Chart-of-accounts mismatch** — target account codes don't match our mapping. (2) **API auth expiry** (OAuth token refresh). (3) **Period locked** in the accounting system (closed month) → post rejected. (4) **Rounding** — GL posts must tie to the payslip and bank totals to the rupee. (5) **Duplicate journal** on retry. (6) **GST/TDS interplay** — a payroll journal must not accidentally touch GST input ledgers. (7) **Rate limit** — HTTP 429 on breach of Zoho's per-minute or daily cap (r3/05) → backoff and retry under the same `payrun_id` key. |
| **Fallback** | Universal downloadable journal (CSV/Excel) for any accounting system; idempotent posts keyed on `payrun_id`; a closed-period rejection opens an exception rather than failing silently. GL posting is downstream of disbursement and filing, so an accounting-integration failure never blocks pay or filing. |

**Acceptance criteria.**

- **AC-ACC-1:** A journal posted to Zoho Books balances and ties to the bank
  disbursement and payslip totals to the rupee.
- **AC-ACC-2:** Token expiry triggers a silent refresh; a hard auth failure raises an
  actionable reconnect prompt, never a lost journal.
- **AC-ACC-3:** A post to a locked accounting period opens an exception with the target
  period surfaced, never a silent drop or a mis-dated re-post.

---

### 16.7 HRIS migration and importers

**[Hypothesis]** — **Migration is a first-class product surface, not a services task**
(§18.9; §20 R-28). Implementation friction is the most-cited churn trigger in the market,
and mid-year cutover is where it concentrates. Importers from Zoho Payroll, Kredily and
Frappe are **acquisition infrastructure, not integrations** — budget them as such; they
are P1, with Tally first among them (§05.5 item 17), behind the universal Excel/CSV
onboarding import, which is P0 in R1 together with the YTD tie-out and the parallel-run
month below (§05.5 item 32; C-05).
The churn-driver claim is not yet validated; kill/validate criterion: §20 V-15 and the
buyer interviews. If implementation friction is not a top-three churn trigger in field
interviews, migration is still worth building but is not the primary GTM wedge.

**The mid-year cutover problem** is the hard part, because a company switching in (say)
August must carry forward: opening balances, YTD earnings and TDS already deducted,
previous-employer income, investment declarations mid-cycle, **certificate continuity
across two systems** (one TRACES-generated Form 130 built from Form 138 data that two
payroll systems prepared, EV-048), EPF UAN and ESI IP continuity, leave balances, and
gratuity accrual (§05.6 Example D; FR-CHR-098, §07.7). It must **not** carry consent:
consent cannot be backfilled, is never imported unless the source held it, and is never
synthesised; every migrated employee goes through the migration consent flow (FR-CHR-102,
Part E-12), and no employee record completes import without a consent-flow status
(§05.5 items 32 and 35).

| Facet | Specification |
| --- | --- |
| **Contract** | One-time import from: **Excel/CSV** (universal), **Zoho Payroll / Kredily / Frappe HR / greytHR** exports (acquisition importers), and Tally (§16.2). Format: guided template + validation. |
| **Data exchange** | Ingest: employee master (with UAN/ESI-IP/PAN/bank), compensation structure and pay heads, **YTD earnings + YTD TDS + YTD statutory** (for mid-year), investment declarations and proof status, leave balances and accrual rules, gratuity/PF opening balances, and org structure. |
| **Failure modes** | (1) **YTD not carried** → wrong TDS projection for the rest of the year and Form 138 data from which TRACES cannot build a continuous Form 130. (2) **UAN/IP discontinuity** → duplicate member accounts at EPFO/ESIC. (3) **Pay-head semantics differ** across source systems (what counts as "basic" for add-back). (4) **Declaration state lost** → employees re-declare mid-year. (5) **Silent data loss** on unmapped columns. (6) **Regime carry-forward** — the employee's old/new regime election must carry, or projected TDS inverts. |
| **Fallback** | A **staged migration** with a mandatory **parallel-run / reconciliation month** for mid-year cutovers: the first live run is diffed against the source system's last run and must reconcile before go-live. Unmapped columns are surfaced, never dropped (§08.13 G9 migration parity). A **YTD import validator** checks that carried-forward TDS + projected TDS is internally consistent, so the year's Form 138 data — and therefore the TRACES-generated Form 130 — is continuous. |

**Worked example — the mid-year TDS continuity check.** An employee joins the new system
in August (month 5 of the Tax Year). Source system YTD (Apr–Jul): taxable ₹4,00,000, TDS deducted
₹18,000. On import, the YTD validator recomputes annualised liability on the *full-year*
projection (₹4,00,000 actual + ₹5,00,000 projected Aug–Mar = ₹9,00,000) under the carried
regime election, subtracts the ₹18,000 already deducted, and spreads the balance over the
remaining 8 months. If the import dropped the ₹18,000-already-deducted figure, the engine
would re-deduct it, over-withholding ~₹2,250/month and producing Form 138 data — and so a
TRACES-generated Form 130 — that does not reconcile to the two systems' combined challans. The validator blocks go-live until
`YTD-carried + YTD-projected` is internally consistent.

**YTD tie-out criteria — the go-live gate for a mid-year cutover.** Internal consistency
is necessary, not sufficient: each carried head is also tied out against an **independent
record** — never against the import file itself. Tolerance per head is the named parameter
`migration.tieout_tolerance.<head>`, shipped at **₹0** for the heads §20 V-15 names (YTD
taxable salary, TDS deducted, statutory contribution totals); any non-zero value is a
tenant-level override with a recorded reason and approver. Zero is the default because
§20 grades a V-15 cutover that only "reconciles within a small, scripted tolerance" as
inconclusive, not as a pass.

| Head carried (per employee unless stated) | Tied out against | Tolerance | On breach |
| --- | --- | --- | --- |
| YTD gross and YTD taxable salary, by month | The source system's payroll register for the same months | ₹0 (V-15) | Go-live blocked for that employee; per-month diff shown |
| YTD TDS deducted, by month | The source register, and the deductee rows of the quarterly statements already filed for those months — Form 138 for Tax Year 2026-27 onward, legacy 24Q for FY 2025-26 and earlier (EV-050, EV-052) | ₹0 (V-15) | Blocked; the TDS projection is not run |
| TDS deposited, per TAN | Challan identification in the `.csi` from the TIN Challan Status Inquiry (AC-706.2) | ₹0 | Blocked; the un-reflected challan is named |
| EPF — employee share, employer EPS and employer EPF, by UAN and wage month | The source's ECR lines, and EPFO's approved return statements and receipts for the months already filed (EV-036) | ₹0 (V-15) | Blocked; those months stay open in the establishment ledger (FR-PAY-712) |
| ESI — employee and employer shares, by IP and month | The source's contribution records and the ESIC challans for the months filed | ₹0 (V-15) | Blocked |
| PT deducted, by state | The source register and the state receipts for periods filed | ₹0 | Blocked for that state; the carried figure feeds the annual ₹2,500 cap check (§06.4) |
| Regime election and previous-employer income and TDS (Form 122, ex-12B, EV-050) | The employee's own declaration captured in the new system | Exact match | Blocked until the employee confirms |
| UAN and ESI IP numbers | The source master, then continuity checks before the first ECR or ESI file (AC-MIG-4) | Exact match | Blocked for that member; never a new UAN or IP |
| Leave balances and gratuity service start date | The source register | Exact (days) | Flagged, not blocked — no filing depends on it at cutover |

<!-- DIAGRAM: integrations-api-ytd-tieout -->

The gate reads the same way for every source system (Tally, Zoho Payroll, Kredily,
Frappe HR, greytHR, Excel). What differs per source is only the importer's field map —
and for Frappe HR, whose repository has no ECR, ESI, 24Q or Form 16 generator (EV-031,
K-01), the "independent record" for EPF, ESI and TDS is the portal-side record the
customer holds (approved returns, challans, receipts), not anything the source system
produced.

**Acceptance criteria.**

- **AC-MIG-1:** A mid-year import produces a first in-product payslip whose YTD figures
  continue the source system's YTD (verified by diff), and year-end Form 138 data from
  which the TRACES-generated Form 130 spans both systems correctly (checked once the Q4
  format is released, EV-046, EV-048).
- **AC-MIG-2:** The Zoho/Kredily/Frappe/greytHR importers map ≥90% of fields automatically
  from a real export (a **[Hypothesis]** target, recalibrated on the first §20 V-15
  dataset); the parallel-run reconciles to the rupee before go-live.
- **AC-MIG-3:** No import silently drops a column; every unmapped field is reported.
- **AC-MIG-4:** UAN/ESI-IP carried from the source are validated for continuity so the
  first ECR/ESI file does not create a duplicate member account.
- **AC-MIG-5:** Go-live for a mid-year cutover is refused while any head in the YTD
  tie-out table is outside `migration.tieout_tolerance.<head>`; the refusal names the
  employee, the head, the month and both figures, and a tolerance override is recorded
  with its reason and approver.

---

### 16.8 Recruiting and job-board integrations

**[Verified, §10.1; r2/08]** — **A new entrant can build recruiting in India, but inbound
only.** Info Edge owns the passive-candidate graph (Resdex, "over 50 million profiles" per
Naukri's own FAQ) and does not licence database search to third-party ATSs; Resdex-in-ATS
is available only through Info Edge's own ATS (Zwayam markets this as exclusive — the
incumbent's own marketing, documentation read, r2/08). We found no published Naukri
developer API, self-serve key or partner documentation as of September 2026 — its
recruiter support corpus has no API or developer folder (r2/08, documentation read).
**Forbid scraping explicitly** — the only working Resdex extraction for a non-partner
replays a live authenticated recruiter session (r2/08), a terms-of-service risk for the
customer and for us; whether it creates further legal exposure is a counsel question
(§23), and the answer does not change the prohibition.

| Facet | Specification |
| --- | --- |
| **Contract** | **Inbound (posting + application sync) only.** Multi-post a requisition to Naukri, LinkedIn, foundit, apna and Indeed against **the customer's own job-board contract** ("bring your own contract"), with application ingest and dedup. **LinkedIn is the one large passive graph with a documented, certifiable partner path** — do it properly and early. |
| **Data exchange** | Outbound: job posting (title, description, location, comp band) to each board on the customer's account. Inbound: applications (candidate profile, resume, source) → dedup → ATS pipeline. No candidate-database *search* against any board (not licensed). |
| **Failure modes** | (1) **No customer contract** on a board → cannot post there. (2) **API/posting-quota limits** per board. (3) **Duplicate candidates** across boards → must dedup on email/phone. (4) **LinkedIn partner-review** gating the integration — the APIs are restricted to LinkedIn-approved developers and need a signed API agreement with data restrictions; Recruiter System Connect requires the Job Posting API to be implemented first, and its real-time features need the customer to hold a Recruiter Corporate or RPS licence (Microsoft Learn LTS docs, page dated 1 April 2026, documentation read, r2/08). (5) **Temptation to scrape** — explicitly architected out and forbidden in sales collateral. |
| **Fallback** | Where a board has no API for a tenant, provide **assisted manual posting** + an email/careers-page application capture (a public application form and an inbound-email parser) so the ATS pipeline is never empty even with zero board integrations. |

> **[Verified] Right-size the moat.** Naukri's "118M" is total resumes (an investor
> metric); Resdex — what recruiters actually buy — is "over 50 million profiles" per
> Naukri's own FAQ (§10.1; r2/08). Do not overstate the graph we cannot reach; compete on
> inbound funnel quality, multi-post ergonomics, and the LinkedIn certified path.

**Acceptance criteria.**

- **AC-REC-1:** One requisition multi-posts to every board where the tenant has a contract,
  and ingests + dedups applications back into one pipeline.
- **AC-REC-2:** No code path performs candidate-database search or scraping against any job
  board; this is enforced architecturally and asserted in sales collateral.

---

### 16.9 Communication channels

Payslip delivery and workflow notifications ride these; e-sign carries the
prescribed-format appointment letter. **[Reversed]** Earlier text implied that letter is
owed from employee one; the OSH Code s.6(1)(f) duty attaches to an "establishment" of 10
or more workers, and the form is prescribed by the appropriate Government — state-sphere,
so the template is configuration per state (K-18, EV-057; §05.5).

| Channel | Contract & use | Failure modes | Fallback |
| --- | --- | --- | --- |
| **Email (SMTP/API)** | Transactional email (payslips, filing confirmations, approvals) via a provider (SES/SendGrid-class) with per-tenant sender domain (SPF/DKIM/DMARC). | Bounce, spam-foldering, domain not verified. | In-app inbox + downloadable payslip; delivery status tracked. |
| **SMS (DLT-registered)** | OTP and critical alerts via a **TRAI DLT-registered** sender header + pre-approved template. The DLT header-and-template registration requirement is not captured in this PRD's research; its instrument and current text are to be confirmed before customer use (routed to §20). | Template not DLT-approved → blocked/scrubbed; carrier delay; header mismatch. | Email/WhatsApp/in-app fallback for the same alert. |
| **WhatsApp Business (P1)** | Frontline/deskless reach (§09). **[Verified]** A new WhatsApp business portfolio reaches only **250 unique users / rolling 24h** (Source: Meta WhatsApp Business Platform messaging-limit tiers, r2/04), so a 5,000-worker site cannot be push-onboarded day one; design **worker-initiated**, not employer-push. Meta charges per message since 1 July 2025, and employee-initiated conversations are free inside the 24-hour window (EV-088). | Tier limits; template rejection; **WABA billing** — an India WABA must migrate to INR billing by 31 Dec 2026, or Meta stops delivering its messages from 1 Jan 2027 (EV-088); **[Killed]** the "Meta charges for service messages in India from 1 Oct 2026" claim is false (applies to nine other markets — §20.4); **Meta's India rate card is unresolved** — BSP sources disagree (marketing ₹0.8631 vs ₹0.95, utility ₹0.1150 vs ₹0.15), leaving the marketing-to-utility multiple a 6.3–7.5× range (r2/04; §20 V-12) — download the rate card before committing any per-worker price. | Ramp within the 250/24h tier; fall back to SMS/IVR/email; never gate a payslip on WhatsApp. |
| **E-sign (P1)** | Appointment letters, policy acknowledgements via **Aadhaar eSign through a licensed eSign Service Provider** or a DSC/DocuSign-class provider. The statutory basis of each signature type is not captured in this PRD's research: capturing the instruments is routed to §20, and any "legally valid signature" statement is a customer-facing legal claim that needs counsel clearance and a named owner before use (Part D-20, §23) — counsel required. Aadhaar eSign is never the only path: Aadhaar is optional everywhere, and no signature, letter or benefit is conditional on it (Part E-11, Part D-10). | Aadhaar OTP failure; ESP downtime; consent capture; name-in-Aadhaar mismatch. | A non-Aadhaar signature path (DSC-class provider) or a downloadable PDF for wet-signature; signature status tracked as an exception until complete. |

**Acceptance criteria.**

- **AC-COM-1:** Payslip delivery is tracked to a per-employee delivery status; a bounce
  opens the in-app copy, never a silent non-delivery.
- **AC-COM-2:** SMS uses only DLT-approved headers + templates; WhatsApp onboarding respects
  the 250/24h new-portfolio cap and degrades to SMS/email.
- **AC-COM-3:** No per-worker WhatsApp price is hard-committed until the Meta India rate
  card is downloaded (§20 V-12).

---

### 16.10 Identity, SSO and provisioning

**Phase: P2** (§05.5 item 24; FR-CHR-092 — deferred to the bands where procurement
expects it). Until then login runs on the local-credential path with MFA that the
fallback row below already requires. Which identity provider 20–200
employee firms actually use was not established by desk research (r3/05) — whether plain
Google Workspace or Microsoft Entra ID sign-in is pulled forward ahead of SAML and SCIM is
a customer-discovery question, not a decision this section takes. When built, one SCIM 2.0
server serves both Entra ID and Okta; Entra's gallery listing and Okta's Integration
Network are separate third-party review gates (r3/05).

| Facet | Specification |
| --- | --- |
| **Contract** | Employee/admin login via **Google Workspace and Microsoft Entra ID** (OIDC), enterprise **SAML 2.0** for larger tenants, and **SCIM 2.0** for automated user provisioning/deprovisioning. |
| **Data exchange** | Inbound identity assertions (OIDC/SAML) and user lifecycle events (SCIM create/update/deactivate → HRMS user, but **HRMS remains the system of record for employee master**; SCIM governs *login accounts*, not employment records). |
| **Failure modes** | (1) **IdP mis-mapping** — SSO identity ≠ employee record. (2) **Orphaned accounts** on deprovision failure. (3) **SAML clock-skew / cert-rotation** breaking login. (4) **SCIM loop** if HRMS also pushes to the IdP. |
| **Fallback** | Local password login (with MFA) remains available as a break-glass for admins so an IdP outage never locks out payroll on a due date. Clear precedence: employee master is authoritative; SSO/SCIM never mutates statutory fields (UAN, PAN, bank). |

**Acceptance criteria.** SSO login maps deterministically to an employee/admin record; a
deprovision event disables the login without deleting the employment record (retention per
EV-054 and §14.7; §16.12); an IdP outage does not lock out the payroll admin; SCIM never
overwrites UAN/PAN/bank.

---

### 16.11 Public API posture, webhooks and MCP

The platform interface. The strategic frame (§12.7): **own the data and the
tools the assistant calls, not the assistant itself.**

**REST API.**

| Facet | Specification |
| --- | --- |
| **Contract** | Versioned REST API (`/v1`), OAuth2 client-credentials + scoped API keys per tenant, **ACL-inheriting** (an API caller can never exceed the granting user's permissions). Documented, self-serve keys — consistent with §18's "publish the price card / be evaluable without a demo" posture. |
| **Surface** | Read: employees, attendance, leave, pay-run summaries, filing status, documents. Write: **idempotent, audited, approval-gated** (create employee, submit declaration, initiate approvals). No write endpoint ever emits a statutory figure the engine didn't compute. |
| **Failure modes** | Auth/scoping errors, rate-limit breaches, schema-version drift for consumers, partial writes. |
| **Fallback / guarantees** | Idempotency keys on all writes; `Retry-After` on 429; deprecation policy (N-version support, sunset headers); no breaking change without a version bump. |

**Webhooks.** Event delivery (pay-run locked, filing accepted, disbursement settled,
device offline, filing-due-approaching) with signed payloads (HMAC), at-least-once
delivery, consumer-side idempotency (event id), exponential-backoff retry, and a
dead-letter + replay console.

**Rate limits (P0 even before the public API, per §13.7 [Verified]).** Per-tenant
**and** per-user limits are P0 because the product is priced per employee but consumed per
user — one heavy user can exceed the ARPU for that seat; even Microsoft Copilot Studio
disables agents at 125% of prepaid capacity (Source: §12.1 P5, §13.7 [Verified]; r2/03). Budget, meter, and
**degrade gracefully** (throttle, don't error-storm).

**MCP server.** Phasing has two parts. The tool layer the in-product assistant calls
ships in v1 as read and draft tools, with approval-gated write tools in v2 (§12 layer
table). The server exposed to *external* assistants matures at **P3** (§05.5 item 30) —
never on the critical path. Either way it is split three ways per §12.7:

1. **ACL-inheriting read tools** — the assistant sees only what the calling user may see.
2. **Idempotent, audited, approval-gated write tools** — a write proposes an action into
   the same approval workflow a human uses; it never bypasses segregation of duties (§08.13 G8).
3. **Per-tenant admin controls** to disable specific tools per assistant — a tenant can
   turn off, say, "initiate disbursement" for any external assistant. Write tools default
   off for external assistants, and AI features default off for RBI-, SEBI- and
   IRDAI-regulated tenants (§12.7, §12.8; Part E-7).

> **[Killed, §12.7; §20.4]** — **No revenue forecast may depend on the MCP server.** We are
> not aware of any evidence, as of September 2026, that shipping an MCP server has changed a
> buying decision, and the round-one MCP
> adoption stats are banned (§20.4). Keka already advertises a "Keka MCP Server" (EV-090,
> claim posture, not tested), so external-assistant access is an expected feature rather than
> a differentiator. We build it because if enterprise assistants converge on
> Copilot/Glean, we want to be the **governed data-and-tools source**, not because it sells.
> Design it to own the data and the tools; assume we do **not** own the chat surface.

**Acceptance criteria (API/MCP).**

- **AC-API-1:** Every write is idempotent (same key ⇒ one effect) and audited (who/what/when).
- **AC-API-2:** API and MCP callers can never exceed the granting user's ACL; a scope test
  proves an under-privileged token cannot read another user's payslip.
- **AC-API-3:** Per-tenant and per-user rate limits are enforced from v1 and degrade
  gracefully (429 + Retry-After), not with data loss.
- **AC-API-4:** A tenant admin can disable a named MCP write tool for an external assistant,
  and the disablement takes effect without a deploy.
- **AC-API-5:** A webhook consumer that is down receives buffered events on recovery
  (dead-letter replay) with no duplicate side-effects (consumer idempotency on event id).

---

### 16.12 Cross-cutting: reliability, idempotency, DPDP/CERT-In, residency

The properties every integration above must share. Stated once, enforced everywhere.

<!-- DIAGRAM: failure-taxonomy -->

**Failure taxonomy and response (applies to all N integrations).**

| Failure class | Response |
| --- | --- |
| **Transient** (timeout, 5xx, portal maintenance) | Exponential backoff with jitter, bounded retries, then queue for later — the deadline clock is surfaced, not hidden. |
| **Permanent** (bad data, rejected file, invalid IFSC/PAN/UAN) | Pre-flight validation catches it before emission; if it slips through, it opens an **exception worklist** item — never a silent failure. |
| **Partial** (batch settles some lines; an ECR filed without members flagged under exclude-and-flag, who follow on a Supplementary return — EV-037, Part E-11) | Line-level status; re-queue only the failures with a per-line idempotency key; the parent object stays in a `*-with-exceptions` state until cleared. |
| **Schema drift** (bank release, FVU version, EPFO layout, PT slab) | Versioned schema object updated as data; the watcher (below) flags the change; old and new versions coexist for in-flight periods. |
| **External unavailable** (device offline, IdP down, portal down near due date) | Fallback path (manual upload / web check-in / break-glass login); the primary is never a single point of failure for pay or filing. |

These five classes describe **how an exchange failed**; they are not a second statutory
error scheme. Any failure that lands on a statutory artefact also carries exactly one
§08 family code — SA-FMT, SA-VER, SA-ID, SA-RULE, SA-REC, SA-SEQ, SA-PORT or SA-CALC
(FR-PAY-713) — so a rejected ECR upload is recorded as *Permanent* + *SA-PORT*, and a
portal outage the day before a due date as *External unavailable* with no SA code until
an artefact is affected.

**Idempotency is universal.** Every outbound artefact — bank batch line, GL journal, ECR
member row, webhook event — carries a **deterministic external key** so re-sends update
rather than duplicate. This is the single most important reliability property: in a
statutory/money system, a duplicate is worse than a miss.

| Artefact | Idempotency key |
| --- | --- |
| Bank NEFT line | `payrun_id + employee_id` |
| Tally / GL journal | `payrun_id` (voucher external key) |
| ECR member row | `establishment + wage_month + return_type + UAN` — a Supplementary return accepts only UANs absent from every prior return for the month; a Revised return supersedes the prior return's rows (EV-037) |
| Device punch | `device_sn + device_user_id + device_timestamp + direction` + `payload_hash` (§09.3 FR-DEV-001 AC4) |
| Webhook event | `event_id` (consumer-side dedup) |
| API write | client-supplied `Idempotency-Key` header |

**Data protection on integrations — what binds today, and what binds from ~May 2027.**
The legal analysis is §23's; this block states only what it means at the integration
boundary.

- **[Reversed]** Earlier text stated DPDP s.7(i) — "employers need no employee consent to
  process employee data for employment purposes" — as current law. It is **not in force**:
  DPDP's substantive provisions, s.7(i) included, commence on or about 13 May 2027
  (EV-058). **Today** the SPDI Rules 2011 require **consent in writing before collecting
  sensitive personal data** (r.5(1)), and r.3 lists biometric information and financial
  information as sensitive (EV-060) — which reaches the device integration (templates,
  §16.4) and the bank-account and payout integrations (financial information, §16.3). Who owes that duty is under counsel review; written-consent capture is built
  either way (Part D-4, §23; FR-CHR-102). When s.7(i) commences it disapplies consent and
  notice for employment purposes only; it does not disapply the s.8 duties (K-03). DPDP
  itself creates no sensitive category (s.2(t), EV-059) — but the SPDI Rules do, and they
  are live (K-06). Both consent regimes run concurrently across ~May 2027 (Part E-6).
- **Onward transfer to a sub-processor** (a BSP for WhatsApp, a payout aggregator, an
  e-sign ESP, an AI provider): SPDI r.7 restricts cross-border transfer of sensitive data
  today (EV-060); for regulated tenants, sub-contractor consent and contract terms bind
  through the customer — RBI para 16(r) where the arrangement is material for that entity
  (EV-087; materiality is a counsel question, Part D-14), SEBI's 20 mandatory contract terms
  (EV-085), IRDAI's regulator-access undertaking reaching sub-contractors where the
  arrangement is outsourcing (EV-086); and
  DPDP s.8(2) will require a "valid contract" with any processor once it commences
  (EV-058; r4/01). The product therefore keeps a **data processing agreement with every
  sub-processor and a maintained sub-processor register, wired to the sub-processor-change
  gate** (§12.8; Part E-7) — a product control, not a claim about which statute imposes it.
- **Data minimisation at the boundary:** each integration sends only the fields it needs
  (a job board does not need bank/UAN; a device ingest does not need PAN). Enforced as a
  per-integration allowed-field allowlist, not a convention. Three structural rules sit
  on top of the allowlist:
  - **No integration payload carries an Aadhaar number.** Business tables hold only an
    opaque token (Part E-6, §07). Where a portal flow asks for Aadhaar, the employer
    enters it from the token store under §07's access controls; whether that makes the
    employer a "requesting entity" is under counsel review (Part D-7, §23). Every
    transmission of it is encrypted (reg 6(4), EV-068).
  - **Every outbound model call passes the redaction chokepoint** — default-deny on
    Aadhaar, PAN, bank account and IFSC, and biometric templates — which is structural in
    the call graph, not a per-integration choice (Part E-7, §12.8.3).
  - **Bank-account details are SPDI "financial information"** (r.3(ii), EV-060; §05.5
    item 35), so every integration whose payload carries them — the bank file, the payout
    API, any journal that names an account — inherits the written-consent capture and the
    r.7 transfer constraint above.
- **Retention & deletion** propagate to integrations: a deprovisioned/erased employee's
  data must be removable from downstream caches, subject to statutory retention on
  registers and filings — per each rule-set's own wording, not a flat five years (EV-054).
  State-sphere periods are unknown and go to counsel (Part D-11, §23); neither immediate
  purge nor a one-year suppression is hard-coded (Part D-9); which classes are erasable,
  and what replay returns after an erasure, are §14.7's (Part E-2).

**CERT-In on integrations (binds from day one, not at enterprise scale — EV-062; §17.6
[Verified]).**

- **6-hour incident reporting** — an integration incident of a type listed in Annexure I
  is reportable within six hours of becoming aware (EV-062); whether a given event (a
  leaked bank-API credential, say) falls in a listed type is a triage decision inside the
  §17 pipeline, made against the clock, not after it. A **CERT-In point of contact** is
  designated and registered before the first paying customer (direction (iii), r4/02;
  §17.6) (Source: CERT-In Directions No. 20(3)/2022-CERT-In, 28.04.2022, EV-062).
- **180 days of ICT logs retained within Indian jurisdiction** — integration call logs,
  file-transfer logs, webhook delivery logs, and LLM prompt and completion logs (kept in
  India, Part E-7, §15) are in scope (EV-062).
- **The device ingest enters the same triage** — Annexure I covers IoT devices (item
  (xiii), EV-062), so an incident on the §16.4 ingest path (a spoofed-serial flood, say,
  AC-DEV-5) is triaged as a possible IoT-class incident. The terminals belong to the
  customer, so whose report it is — ours, the customer's, or both — is decided in triage
  and, where unclear, by counsel (§23).
- **Clock sync to NIC/NPL NTP** — the same NTP requirement that fixes device clock-drift
  (§16.4) is a CERT-In obligation; one control, two problems.
- **Attacks on AI/ML systems are an explicitly reportable class** (Annexure I item (xx),
  EV-062) — the MCP/AI integration surface *enlarges* the reportable perimeter; its
  incidents enter the same six-hour pipeline as an AI/ML incident class (Part E-8, §17).

**Residency and provider abstraction (segment-specific gate — §17.7; legal analysis §23).**

- **Neither a blanket localisation mandate nor none** (K-08). DPDP's cross-border rule is
  a negative list that is empty and not in force; the live constraints are CERT-In's 180
  days of ICT logs in India (EV-062), SPDI r.7's limits on cross-border transfer of
  sensitive data (EV-060), and sectoral rules for RBI, SEBI and IRDAI customers
  (EV-085–087).
- **RBI:** the Outsourcing of IT Services Directions (effective 1 October 2023) carry data
  localisation, a right to audit including by RBI, sub-contractor consent (para 16(r)) and
  regulator inspection (para 16(o)) — **materiality-gated, determined entity by entity**
  (EV-087, [Verified — mirror]; pull from the primary source before customer use).
  **[Reversed]** Earlier text said these bind any SaaS vendor with "no turnover threshold"
  (K-22). Whether our arrangement is material outsourcing for a given RBI entity is a
  counsel question (Part D-14, §23). Silently adding an LLM vendor can put a bank customer
  in breach of its own obligations (EV-087) — hence the sub-processor gate.
- **SEBI:** data must reside and be processed within India, and FAQ Q47/Q50 impose the
  MeitY-empanelled-infrastructure rule on PaaS/SaaS providers (EV-085).
- **IRDAI:** **[Reversed]** Earlier text said IRDAI "mandates records in Indian data
  centres". The IRDAI Information and Cyber Security Guidelines 2023 carry no localisation,
  MeitY or STQC requirement; IRDAI localisation exists only for policy records, and its
  outsourcing definition captures managed payroll but not a self-service licence (EV-086).
- **Procurement can be stricter than regulation:** SBI's HRMS RFP requires DC, DR and HA
  zones in India only and all data functions and processing within India (r2/06). Every
  integration touching a regulated tenant follows that tenant's sectoral profile (§17)
  and is exit-able.
- **At least three interchangeable backends with residency selectable per tenant** — this
  is the same abstraction the AI model-router needs for cost (§13.5), so it is one piece
  of work serving two constraints. Residency is a **per-provider matrix**, and data-at-rest
  residency ≠ in-country inference — track both per provider (§13.10: OpenAI offers India
  data-at-rest, while its first-party inference defaults to the US and in-country
  inference for its models runs through Amazon Bedrock; Anthropic's first-party API offers
  neither; Vertex has an India region; for a SEBI tenant no candidate backend is yet
  confirmed to meet the MeitY-empanelled-infrastructure rule — re-verify per provider,
  §20 V-13; do not rely on Sarvam hosting until verified).

**The statutory-change watcher (integration-facing).** Every file-schema integration
(§16.5, bank formats, PT/LWF slabs) subscribes to the watcher. **[Verified, §02.4]**
It must **catch amendments and corrigenda, not only new instruments** — the Nov-2026
inversion was a corrigendum, and a new-notifications-only watcher would have missed it.
Each hit routes to the owning schema object with its gazette source (URL + date) for a
review-and-version step before any period is filed against it. The watcher is not just a
product feature; it is the operating-model consequence (§05.15) — the company is a
**compliance-maintenance operation with a permanent statutory team**, and the watcher
(§13.13) is the tooling of §22's compliance data pipeline.

---

### 16.13 Integration phasing

Mapped to the module sequencing (§05.5) and to §05.17's closed R1 capability list, which
is the only place "P0" lives: P0 means R1, a fenced leg carries its fence and release
instead of a priority, and anything not on the R1 list is not in R1 whatever this section
calls it (§05.17 lint L1, L2, L5). Only what a beachhead tenant (20–200, §05) needs to
run its first correct filing is P0; the platform surface follows. All three segments are
the *vision*, but v1 ships the beachhead — the register above is deliberately not all P0.

<!-- DIAGRAM: integration-phasing-timeline -->

| Phase | Integrations | Rationale |
| --- | --- | --- |
| **P0 (R1) — first correct filing + first correct payslip** | Per-bank salary file (design-partner banks + generic template), release by a separate approver and credit reconciliation (§05.5 item 33; C-22; PR-01); **ADMS device-push receiver** (C-24); EPFO ECR Regular, Supplementary and Revised returns and the per-establishment ledger, with each statutory payment figure reconciled to the portal's challan (A-01 to A-04; C-09, C-10, C-23); ESIC contribution computation (C-11), and the upload file only if the template capture finishes before the gate (A-08; C-12); Form 138 Q1–Q3 regular and correction generation and FVU validation, with correction submission held while F-02 is open (A-11, A-12; C-14); Form 130 distribution (A-14; C-15); PT computation for each state whose row is state-primary-sourced — Maharashtra at R1 entry (A-15; C-16); the per-state PT and LWF machinery, switched on state by state without a deploy (§05.5 items 5 and 7); Excel/CSV onboarding import with the YTD tie-out and parallel-run month (§05.5 item 32; C-05); email and DLT-SMS as infrastructure under C-31 (PR-14); per-tenant/per-user rate limits (§05.5 item 13). Every statutory artefact ships **portal-ready for the employer to submit** in Mode A or B (C-21). | These carry the unit of delivery and the pay path. Nothing ships without them. |
| **R2 fenced legs (a release and a blocker, not a priority)** | Operator-attended submission, per portal, on counsel clearance (A-23, F-08); PT return legs, Maharashtra's included, and LWF remittance, per design-partner state as F-06 and F-07 ship (A-15, A-16, A-17; PR-03); the ESIC upload file if its capture slipped (A-08); the ECR part-payment file (A-05). Q4 Form 138 and Tax Year 2026-27 Form 130 are R3 on F-01 (A-13, A-14); the ECR arrear return is fenced on F-03 (A-06). | Each leg enters when its blocker clears; none is promised by date. |
| **P1 — reach, breadth, platform** | Tally GL journal export, first in the integration queue (R2; §05.17 PR-13); named-source migration importers — Tally first, then Zoho Payroll/Kredily/Frappe/greytHR (§05.5 item 17), gated by the §16.7 tie-out; device pull-path via third-party connectors; the public device compatibility matrix (§05.5 item 21); Zoho Books journal API and ERP GL files; recruiting job-board posting (LinkedIn certified path first, §05.5 item 19); WhatsApp Business; e-sign; public REST API + webhooks; payout aggregator API (Cashfree/RazorpayX); direct connected banking as a BD track (r3/05). | Widen device coverage and accounting reach, and open the platform. |
| **P2 — v2 surface** | SSO/SAML/SCIM (§05.5 item 24; FR-CHR-092); the all-states PT/LWF dataset (§05.5 item 23); automation inside the attended session (subject to the §16.5 kill criterion and counsel, Part D-17); deeper ERP connectors; benefits/insurer endorsement APIs (data model built in v1 per §11.1, monetisation deferred); approval-gated write tools in the in-product tool layer (§12). | Only after the core filing engine and platform API are proven and the validation programme (§20) has reported. |
| **P3 — vision** | The MCP server for external assistants, matured as a data-and-tools source (§05.5 item 30). | Never on the critical path; no revenue depends on it (§16.11). |

**What P0 explicitly excludes (and why that is a decision, not an omission).** The Tally
GL journal export (P1, R2 — §05.17 PR-13; the accountant posts from the payroll register
in R1); named-source migration importers (P1 — §05.5, with Tally first; how many
beachhead firms run Tally payroll is unknown, §20 V-02); every PT return leg and every
LWF remittance (R2 per state, fenced — A-15 to A-17); the public REST API (P1 — internal-first, rate limits ship
P0 as infra); SSO/SAML/SCIM (P2 — §05.5 item 24); the external MCP server (P3 — no revenue
may depend on it, §16.11 [Killed]); automation inside the attended session (P2 and
conditional on its kill criterion and counsel); benefits endorsement APIs (P2 — data
model only in v1 per §11.1); and operator-attended submission itself until counsel
clears it (§05.7 A-23). **[Reversed]** An earlier version excluded LWF from P0 as "low
value". The reason was wrong: multi-state PT and LWF are a differentiator, not a footnote
(K-01), and LWF's per-state machinery is built in R1 under a P0 module (§05.5 item 7).
But no state's LWF row is sourced (EV-015), so no LWF remittance ships in R1; each state
follows in R2 as its fence ships (§05.17 PR-03, A-17). An earlier version also placed
SSO/SCIM in P1, the MCP server at P2 GA and the Tally GL export in P0, against §05.5's
items 24 and 30 and §05.17 PR-13; all three now follow §05. Committing the exclusions to P0
would dilute the one thing that must be perfect at launch: the filing lands and the
salary credits.

---

### 16.14 Section acceptance summary — the integration guarantees

Eleven guarantees that any integration in this section must satisfy to be called "done."
These are the §16 analogue of the payroll engine's G1–G13 (§08.13).

| # | Guarantee | Enforced by |
| --- | --- | --- |
| **IG1** | **Filing/pay is never single-point-dependent** on an external system — every filing-path and pay-path integration has a working manual/file fallback | §16.2–16.5 fallbacks; §16.12 |
| **IG2** | **Idempotency everywhere** — every outbound artefact (bank line, ECR row, GL journal, webhook, MCP write) has a deterministic external key; re-send never duplicates | §16.3, 16.6, 16.11, 16.12 (key table) |
| **IG3** | **Pre-flight validation** — files are validated against the portal's/bank's known checks before emission; the modal upload outcome is acceptance | AC-BNK-1, AC-GOV-1 |
| **IG4** | **FILED, not submission, is the completion state** — a filing is done only when its acknowledgement and, where payment-bearing, its receipt are captured (FR-PAY-711); a disbursement is done only when settlement is reconciled, never on an API acknowledgement | AC-GOV-2, AC-BNK-3, §08.13 G5 |
| **IG5** | **Schema-driven, versioned, gazette-sourced** — every file format is data with a source (URL + date), not code; amendments are data updates | §16.1, AC-GOV-3, §16.12 watcher |
| **IG6** | **Blocked states are honest** — unpublished formats (Q4 Form 138 and Tax Year 2026-27 Form 130 preparation, EV-046; the ECR arrear return, EV-043) and unresolved regimes (post-cliff ESI) render BLOCKED, never guessed | AC-GOV-4, §08.13 G7 |
| **IG7** | **No model-generated figure crosses a boundary** — the engine computes; the assistant explains, drafts, routes | §12.1 P1 [Verified], §08.13 G4; §16 framing rules |
| **IG8** | **ACL-inheriting, audited, approval-gated writes** — no external caller (API/MCP) exceeds the granting user or bypasses segregation of duties | AC-API-1/2, §16.11 |
| **IG9** | **Data protection and CERT-In at the boundary** — written consent for SPDI-sensitive data today (EV-060), sub-processor register + DPA wired to the sub-processor gate, data minimisation per integration, 6-hour incident path, 180-day logs in India, NTP sync (EV-062) | §16.12 |
| **IG10** | **Residency selectable per tenant across ≥3 backends** — each regulated tenant gets its sectoral profile (RBI materiality-gated, SEBI in-India with MeitY-empanelled infrastructure, IRDAI policy records only — EV-085–087), and the vendor is exit-able | §16.12, §17.7 |
| **IG11** | **Attended, never autonomous, submission** — every statutory submission is an attended portal session by the employer or by our operator under written authority to act, logged; the statutory payment and any DSC-bound act are always the employer's; the employer's and deductor's liability stays with them (K-13); the operator path (Mode C) does not launch until counsel clears Part D-17 (§05.7 A-23; §20 V-25) | §16.1, §16.5, §08.13 G13, §22 FR-OPS-001, §23 |

**Bottom line for the integration layer.** In this market the integration layer is where
the product differs from what Tally and Frappe ship today (no state PT slab table and no
LWF engine in either — EV-031, EV-032) and from what any vendor in the six-vendor set
claims (none claims to submit a filing — EV-030) — not because our APIs are cleverer,
but because **the government gives no submission API we are aware of, and we invest in
the attended path and the fallback anyway.** The device-push receiver (§16.4),
the reconciled bank file (§16.3), the portal-accepted statutory files submitted in
attended sessions with captured acknowledgements (§16.5), and the honest blocked states
where a format is not yet published are the concrete expression of this PRD's thesis
(§01): **the filing, not the payslip, is the unit of delivery — and the integration is
judged by whether that filing reaches FILED, not by whether an API returned 200.**
