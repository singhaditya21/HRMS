## 14. Data Model, Entities & Retention

The data model is where this product's central thesis becomes a schema. If **the filing, not the payslip, is the unit of delivery** (§04, §08 **[Verified]**), then `Filing` is a first-class entity with its own lifecycle, acknowledgement and evidence — not a report generated off a pay run and forgotten. If the 50% wage add-back (Code on Wages s.2(y) / Code on Social Security s.2(88)) creates **multiple concurrent wage bases on one payslip** (§06.10 **[Verified]**), then the schema cannot carry a single `wage` column. And if state rules under the four Labour Codes commence unevenly across states (§06.9 **[Verified]**), then rate/slab/definition storage must be **effective-dated and per-jurisdiction from v1** — with the jurisdiction read from the work location, never from the employee (Part E-5) — not retrofitted when the first multi-state customer complains.

This section specifies the conceptual and logical data model — entities, relationships, keys, cardinality — plus the three things a payroll data model in India lives or dies on: **bitemporal storage, scoped by entity class** (§14.6.1a), **multi-state rule storage**, and a **data-classification / retention / deletion regime that reconciles erasure duties — the Aadhaar purpose-bound retention ceiling today (EV-068), DPDP s.8(7) from on or about 13 May 2027 (EV-058) — against statutory retention duties.** It is a logical model, not a physical schema (no DDL, per the PRD-only constraint); §15 (System Architecture) maps it onto tenancy and storage.

Three conventions used throughout:

- **Entity names** are `PascalCase`; **fields** are `snake_case`; identifiers ending `_id` are internal surrogate keys, identifiers ending `_no` / `_code` are **external government-issued keys with their own format rules** (UAN, PAN, ESI IP, TAN, PF code) that a filing will reject if malformed (see §14.9).
- **Bitemporal** means the row carries `effective_from` / `effective_to` (business-time validity) *and* `recorded_at` / `superseded_at` (system-time / knowledge-time). Only the entity classes listed in §14.6.1a are bitemporal; the erasable classes carry `recorded_at` and an erasure state instead. The distinction is not academic — see §14.6.
- **Acceptance criteria** are stated in `Given / When / Then` form and numbered `AC-DM-nn`; they are the testable contract a physical schema and its access layer must satisfy. They are gathered per-entity where they bite, and are the hooks §20 (Validation Plan) will exercise.

---

### 14.1 Design principles (the invariants the schema must not violate)

These generalise the payroll-engine invariants (§08.1) to the whole data model. Every entity below is designed to these; they are stated once here rather than repeated per-entity.

| # | Principle | Why it is a schema-level invariant, not a feature | Source |
| --- | --- | --- | --- |
| D1 | **Filing is a first-class entity with lifecycle and evidence** | The product's headline metric is "return filed on time and accepted." A filing must persist its generated artefact, portal acknowledgement, challan/UTR, rejection reasons and the exact input snapshot it was built from. The deliverable is a portal-accepted artefact plus attended, assisted filing under written authority to act — never an automated submission — and the employer's statutory liability stays non-delegable, so the entity records who acted and under what authority (§14.4.5; K-13; EV-030). | §04, §08 **[Verified]** |
| D2 | **Bitemporal where replay needs it** — business-time and knowledge-time are separate axes for rules, salary structures, assignments and statutory attributes; the erasable classes are not bitemporal | A March correction filed in September must recompute against March's rules (business time) while recording *when we learned* of the correction (knowledge time). Single-date effective-dating cannot represent "what did we believe in April about March." Punches, rendered documents, biometric templates and consent artefacts must be able to forget, so they sit outside the bitemporal set (§14.6.1a). **[Reversed]** v0.3 made every attribute bitemporal, which contradicted purpose-bound retention and template erasure (K-24). | §06.10 **[Verified]**; Part E-2 |
| D3 | **Rules are data, not code** — every rate, slab, ceiling, definition is a row in `EffectiveDatedRule`, keyed by jurisdiction + effective date | 50% add-back is "or such other per cent as may be notified"; ₹15,000 PF ceiling, ₹21,000 ESI ceiling, state PT slabs, LWF schedules all change by notification. A code deploy per notification is an operating-model failure (§06). | §06.10, §06 **[Verified]** |
| D4 | **Every monetary/statutory field has an immutable audit lineage** — (input × rule_version × formula) → output, with actor, timestamp (NTP-synced), and checker | Required for the six employer registers plus the wage slip (EV-053), retained per each rule-set's own wording (EV-054), for CA read-only audit, and for dispute defence. A wrong payroll number is a legal problem. | §06.9, §07, §17 **[Verified]** |
| D5 | **Tenant is the top partition key on every business row** | Multi-tenant SaaS serving regulated buyers — RBI's IT-outsourcing obligations are materiality-gated, entity by entity (EV-087), and SEBI's cloud framework reaches the provider and its sub-contractors (EV-085) — means tenant isolation is a data-model property, not only an app-layer check. | §17, §15 **[Verified]** |
| D6 | **External government keys are validated to source format at write time, and their linkage state is stored, not just the value** | UAN *seeding status* decides whether a member's line can enter the ECR — an EPFO administrative rule handled by exclude-and-flag, never a payroll block (§07 FR-CHR-005, FR-CHR-101); PAN *availability* drives the higher-rate TDS floor, held as the rule parameter `no_pan_tds_floor` with no shipped default (v0.3's 1961-Act s.206AA wording is carried, not stated as law; 2025-Act mapping pending, §07.1.1); bank *verification status* gates disbursal. The state is as load-bearing as the value. | §07.1.1, §14.9 |
| D7 | **PII/sensitive/regulated fields carry a classification tag that drives encryption, masking, access, residency and retention** | The SPDI Rules 2011 (live — EV-060), the Aadhaar regulations (EV-068), CERT-In (EV-062), sectoral overlays (EV-085–087) and, from on or about 13 May 2027, DPDP (EV-058) differ by field. Classification cannot be a wiki page; it must be attached to the field so policy is enforceable and auditable. | §14.5, §17 **[Verified]** |
| D8 | **Delete is a policy engine, not a `DELETE` statement** — erasure duties, statutory minimum-retention and litigation-hold contend for the same row | Erasure duties — Aadhaar reg 6(5)'s purpose-bound ceiling today (EV-068), DPDP s.8(7) from on or about 13 May 2027 (EV-058) — collide with statutory retention. DPDP s.8(7) is by its text subject to retention "necessary for compliance with any law" (r5/04 finding 40); how the Aadhaar ceiling interacts with a statutory register that names an Aadhaar field is a counsel question (§14.10 item 3). The Codes' registers carry five-year floors (EV-054); other statutory floors are counsel-set parameters (Part D-11). The winner is per-field and time-dependent. | §14.7 |
| D9 | **Money-of-record and attach/benefit money are two ledgers that never blend** | A benefit wallet, insurance endorsement or interchange event must never silently alter a filed statutory figure. The "two lines never blended" GTM rule (§11 **[Verified]**) is enforced structurally, not just in the P&L slide. | §11 **[Verified]** |

**AC-DM-01** — *Given* any business row (Ring 1–3), *When* it is read or written through any interface (app, API, MCP tool, migration importer, admin console), *Then* the query must be scoped by `tenant_id` and a cross-tenant read must be structurally impossible, not merely filtered (D5).

**AC-DM-02** — *Given* any monetary or statutory field on a `PayrollResult` or `Filing`, *When* its value is inspected, *Then* the exact `(input rows, rule_id versions, formula id, actor, checker, NTP timestamp)` that produced it must be resolvable without recomputation (D4).

---

### 14.2 Entity catalogue

The model has **four rings**: (1) tenancy & org, (2) people & the compliance master, (3) the operating record (comp, attendance, pay, filing), and (4) the cross-cutting spine (rules, documents, audit, consent). Ring 4 entities are referenced by almost everything. Two **segregated stores** — the Aadhaar token vault and the biometric template keyspace — sit outside the rings by construction (Part E-6; §14.4.15). The rings are a dependency ordering, not just a grouping: a Ring-3 row is meaningless without its Ring-1/2 parents and its Ring-4 lineage, which is why migration (§14.4.10) imports **outside-in**.

<!-- DIAGRAM: data-model-rings -->

| Entity | Ring | Purpose | Owns / keyed by |
| --- | --- | --- | --- |
| **Tenant** | 1 | The paying customer account; top isolation boundary — one employer establishment group (§15.3.2). | `tenant_id` |
| **Group** | 1 | The corporate group inside a tenant: the node that owns the tenant's legal entities, group-level reporting and (v2) cross-entity transfer policy (§07 FR-CHR-026). Exactly one per tenant. | `group_id` |
| **Employer (LegalEntity)** | 1 | A registered legal employer (company/LLP/firm) under one PAN. Holds TAN(s), GSTIN(s), CIN and the per-state PT enrolment (PTEC) (§07.2a). A Group may hold several. | `employer_id`, `pan` |
| **Registration** | 1 | One statutory registration — EPF code, ESIC code or sub-code, PTRC or PTEC per state, LWF, S&E, LIN, TAN — with its issuer, state, validity range and status. The key every filing instance is raised against (§08 FR-PAY-711). Owned by the establishment, or by the legal entity for TAN and PTEC (§07 FR-CHR-104). | `registration_id`, (`scheme`, `number`) |
| **Establishment** | 1 | A registered place/unit of employment — the unit EPF/ESI/PT/S&E registrations attach to. Per-state, per-code. | `establishment_id`; its registrations via `Registration` |
| **WorkLocation** | 1 | A place where work is performed — an establishment's premises, or a remote worker's own location. Carries the jurisdiction every state rule resolves against: `state_code`, `sphere` (whether the central or the state Government is the appropriate Government) and, per Code, the date that state's Code-era rules commenced (§06.9). Jurisdiction is never an attribute of the employee (Part E-5). | `work_location_id` |
| **Department / CostCentre / Grade** | 1 | Management-hierarchy dimensions; no statutory effect (§07.2). | `*_id` |
| **Employee (Person)** | 2 | Canonical, immutable-lineage person record across rehire/transfer. | `employee_id` (internal, immutable) |
| **Employment (Engagement)** | 2 | A single employment instance: DOJ→DOL, type, establishment mapping. One Person → many Employments (rehire, inter-entity transfer). | `employment_id` |
| **StatutoryIdentifier** | 2 | Typed external IDs with linkage state (UAN+seeding, PAN, ESI IP, PRAN, bank+penny-drop), each at exactly one owning level (§07 FR-CHR-104): person-level for PAN, UAN and ESI IP; PF Member ID on the establishment mapping. Aadhaar is not one of them: it appears in business rows only as an opaque vault token (§14.4.15). | `stat_id_id`, (`type`, `value`) |
| **EligibilityState** | 2 | Effective-dated *derived* flags (PF/ESI/PT/LWF/gratuity applicability). Computed, never typed. | `eligibility_id` |
| **ServiceRecord** | 2 | The continuous-service ledger a person accrues across employments with one legal entity — counted days per twelve-month window, breaks and their treatment, and the gratuity clock (§07 FR-CHR-016). Derived from employments, assignments and attendance; never typed. | `service_record_id`, (`person_id`, `employer_id`) |
| **CompensationStructure** | 3 | A template of ordered `PayComponent`s. | `structure_id` |
| **PayComponent** | 3 | One earning/deduction/reimbursement/statutory/employer-cost line with basis + statutory-inclusion flags (pf/esi/gratuity/pow). | `component_id` |
| **CompensationAssignment** | 3 | Effective-dated binding of an Employment to a structure + component values (CTC revision = new version). | `comp_assign_id` |
| **Punch / DayStatus / FormIXRow** | 3 | The raw source-tagged punch (erasable); the derived day projection; and the Form IX register row carrying per-day IN and OUT timestamps — a present/absent or day-total model is non-compliant (EV-055). Field shapes per §09.1-A. | `punch_id`; (`employment_id`, `date`); (`establishment_id`, `employment_id`, `month`) |
| **LeavePolicy / LeaveBalance / LeaveTransaction** | 3 | Policy, running balance, and the ledger that moves it. | `*_id` |
| **PayRun** | 3 | A period's payroll execution for an Establishment (regular / off-cycle / arrears / bonus / FnF). | `payrun_id` |
| **PayrollResult** | 3 | Per-employee-per-run computed facts, each stamped with the `rule_version` that produced it. | `result_id` |
| **Payslip** | 3 | The rendered artefact off a `PayrollResult` (a document, not the source of truth). | `payslip_id` |
| **Filing** | 3 | **The unit of delivery.** A statutory obligation instance — one registration × obligation × period (ECR, ESI contribution, PT return, Form 138, Form 130 distribution, LWF, register) — with its lifecycle (§08 FR-PAY-711), attempts, acknowledgement and evidence. | `filing_id` |
| **Challan / Payment** | 3 | The money-movement leg of a filing (PF/ESI/PT/TDS challan, EPF TRRN, TDS CRN, UTR, bank NEFT file). | `challan_id` |
| **EffectiveDatedRule** | 4 | Rates/slabs/ceilings/definitions per jurisdiction per effective window. Rules-as-data. | `rule_id`, (`rule_type`, `jurisdiction`, `effective_from`) |
| **Jurisdiction** | 4 | Central + each State/UT (+ a sub-state local body where a state levies at that level). | `jurisdiction_id` |
| **Document** | 4 | Any stored file (appointment letter, TRACES-issued Form 130, proofs, register export) with classification + retention class. An erasable class (§14.6.1a). | `document_id` |
| **ConsentRecord / DataPrincipalRequest** | 4 | A versioned consent artefact per purpose and regime — SPDI r.5(1) written consent today (EV-060), Aadhaar Sharing Reg 5 (EV-068), DPDP once in force (EV-058) — stating whose artefact it is; and the request workflow for access/correction/erasure/grievance/nomination (statutory basis under counsel review, §14.7.3). | `consent_id` (+ `version`), `dpr_id` |
| **AuditEvent** | 4 | Immutable who/what/when/before/after/authority/rule_version for every statutory or monetary change. | `audit_id` |
| **RetentionHold** | 4 | Litigation / investigation / dispute hold that suspends deletion on named rows. | `hold_id` |
| **AadhaarTokenVault** | segregated | Any Aadhaar number an employee chooses to provide, in a separately encrypted, separately access-controlled store; business rows hold only an opaque token (Part E-6; §14.4.15). | `aadhaar_token` |
| **BiometricTemplate / DeviceEnrolment** | segregated | The template in its own keyspace, never referenced by a punch; the per-device enrolment and erasure ledger (Part E-6; §09 FR-DEV-007). | `template_id`; (`employment_id`, `device_sn`) |

<!-- DIAGRAM: data-model-erd -->

---

### 14.3 The ER model — relationships and cardinality

The ERD above renders the entity-relationship model. The relationships that are non-obvious or that people get wrong are called out here, because getting cardinality wrong here is a filing-rejection bug later.

| Relationship | Cardinality | Why it is this and not the naive version |
| --- | --- | --- |
| Tenant → Group → Employer | 1 : 1 : N | A group of related legal entities is one tenant (§15.3.2); billing is at Tenant, filing is at Registration. A CA or bureau does not pool its clients' legal entities into one tenant: each client is its own tenant, and the CA is a cross-tenant actor with read-only access to money-of-record (§15.3.6; AC-DM-30). **[Reversed]** v0.3 described "a CA-run tenant" holding its clients' legal entities, which would have put several unrelated employers inside one isolation boundary. |
| Employer → Establishment | 1 : N | **This is the multi-state pivot.** EPF/ESI/PT/S&E registrations attach to Establishment, not Employer; TAN stays on the legal entity (§07.2). A single PAN with offices in MH, KA, TS has ≥3 PT registrations and possibly ≥3 ESI sub-codes. |
| Person → Employment | 1 : N | Rehire and inter-entity transfer create new Employments under one immutable `employee_id`, preserving gratuity/continuous-service lineage (§07 FR-CHR-001). |
| Employment → Establishment | N : 1 (effective-dated) | The statutory mapping — which PF code, ESI code and registrations the employment files under (§07.2a `establishment_mapping`). A transfer re-points it with an effective date; the prior establishment's returns for the pre-transfer portion are untouched (§07.2). |
| Employment → WorkLocation | N : 1 (effective-dated) | Where the work is performed, and so the source of the jurisdiction — state, sphere, Code-regime commencement — for PT, LWF, S&E and every state rule (Part E-5). Usually the establishment's premises; for a remote employee, their own location. PT follows the work location, never residence or HQ; PT situs for fully remote employees is itself unsettled (§06.13), so the tenant's remote-PT policy is recorded on the assignment. |
| Person → AadhaarTokenVault | 1 : 0..1 (via opaque token) | Optional; absence is a normal state, never an error, and nothing gates on it (§07 FR-CHR-101). |
| Employment → BiometricTemplate | 1 : 0..N | Separate keyspace. A `Punch` never references a template, so destroying one leaves every attendance record valid (Part E-6). |
| Person → ConsentRecord | 1 : N (versioned) | One per purpose × regime; SPDI-regime and DPDP-regime records coexist across on or about 13 May 2027 (Part E-6; EV-058). |
| Person → StatutoryIdentifier | 1 : N | PAN, UAN and ESI IP live on the person, so they survive rehire and exit; a UAN stored per employment would fork on rehire (§07 FR-CHR-104). A person may declare **more than one UAN**: all are recorded, exactly one is `active_for_filing` per period, the rest are `declared_additional` and flagged `MULTIPLE_UAN_DECLARED`; the product never generates, merges or retires a UAN. |
| EstablishmentMapping → PF Member ID | 1 : 1 | PF Member ID is scoped to the establishment code, so an inter-establishment move opens a new one under the same UAN. Modelling PF Member ID as an attribute of Person — or of Employment alone — is a bug. |
| Employment → CompensationAssignment | 1 : N (effective-dated) | Every CTC revision, promotion, or component re-tag is a new version; the current one is `effective_to IS NULL`. |
| CompensationStructure → PayComponent | 1 : N (ordered) | Order matters: "special allowance as balance figure = CTC − Σ(other components)" must evaluate last (§08 FR-PAY-101). |
| PayRun → PayrollResult | 1 : N | One per included employee. |
| PayrollResult → Payslip | 1 : 1 | Payslip is a derived render; regenerating it must reproduce byte-identical output from the same result + template (D4). The rendered file is an erasable class; a re-render is marked as one (§14.6.1a; §08 I4). |
| PayRun → Filing | 1 : N | One monthly regular run feeds **multiple** filings (an ECR per EPF code, an ESI contribution per ESI code, a PT return per state registration, LWF where due). This 1:N is the whole product. |
| Filing → Challan/Payment | 1 : 0..N | An approved ECR return is followed by one or more challans, each with a TRRN — multiple challans are permitted (EV-036). A NIL EPF month has no return file; admin and inspection charges are paid by Direct Challan Entry, enabled only when there are no active members (EV-042). |
| Filing → Document | 1 : N | The generated file, the portal acknowledgement PDF, the challan receipt — all evidence, each retained per its retention class, with the artefact hash kept on the Filing (§14.7.1). |
| Filing → PayrollResult | N : M (via snapshot) | A filing references the exact result rows it was built from; a **retro/arrears filing** references corrections spanning multiple prior runs. This is captured by an input-snapshot, not a live join, so re-opening a later period cannot silently mutate a filed artefact (D2). |
| EffectiveDatedRule → Jurisdiction | N : 1 | Every rule is scoped to Central or a State/UT (or a sub-state local body for certain PT/LWF cases). |
| PayrollResult → EffectiveDatedRule | N : M (recorded) | Each computed figure records which rule version(s) produced it — the audit lineage in D4. |
| AuditEvent → (any entity) | N : 1 (polymorphic) | Every statutory/monetary write emits one. |
| RetentionHold → (any entity) | N : M | A hold can pin an employee, a pay run, or a whole establishment's records. |
| DataPrincipalRequest → Person | N : 1 | Requests attach to the natural person, spanning all their Employments (statutory basis under counsel review, §14.7.3). |

#### 14.3.1 The statutory hierarchy and its temporal constraints

Six levels carry every statutory fact the product files: **Group → Legal entity → Registration → Establishment → Assignment → Service record.** Filing obligations key on the *registration*; a person's pay and deductions key on the *assignment* in force for the period; entitlements that outlive a single employment — gratuity above all — key on the *service record*. Each level has a validity range, and the ranges nest. A cardinality error here is a filing-rejection bug; a temporal error is a wrong month filed under the right code.

<!-- DIAGRAM: data-model-statutory-hierarchy -->

| Level | Entity | Parent · cardinality | Temporal class (§14.6.1a) | Validity range | What reads it |
| --- | --- | --- | --- | --- | --- |
| 1 | `Group` | Tenant 1 : 1 | B (bitemporal) | `valid_from` at onboarding; name and reporting attributes versioned | Consolidated reporting; v2 cross-entity transfer policy (§07 FR-CHR-026) |
| 2 | `LegalEntity` | Group 1 : N | B | `valid_from` (onboarded or incorporated) to `valid_to` (ceased or offboarded) | PAN, TAN(s), GSTIN(s), CIN, PTEC per state (§07.2a); Form 138 series per TAN |
| 3 | `Registration` | Owned by an Establishment (EPF code, ESIC code, PTRC, LWF, S&E, LIN) or by the LegalEntity (TAN, PTEC) · 1 : N | B | `valid_from` (the registration's effective date as issued) to `valid_to` (surrender, cancellation or closure); `status ∈ {applied, active, suspended, surrendered, cancelled}` | Filing instances (§08 FR-PAY-711); the ECR ledger (§08 FR-PAY-712); the calendar (§06.11) |
| 4 | `Establishment` | LegalEntity 1 : N; optional `parent_establishment_id` for sub-code and extension rows (§07 FR-CHR-021) | B | `opened_on` to `closed_on`; premises as a `WorkLocation` | Headcount per counting unit (§14.4.1); register instances (EV-053) |
| 5 | Assignments — `EstablishmentMapping`, `WorkLocationAssignment`, `OrgAssignment`, `CompensationAssignment`, deductor-TAN assignment | Employment 1 : N each | B | Closed-open `[from, to)` inside the employment's `[DOJ, DOL]` | Rule resolution (§14.6.3); ECR routing; PT state; pay (§08) |
| 6 | `ServiceRecord` | (Person × LegalEntity) 1 : 1 | R (records of fact) — derived, never typed | From the first employment's DOJ (or the migrated `gratuity_clock_start`, §14.4.10) to the last DOL | Gratuity eligibility and payout (§07 FR-CHR-016; §14.4.4 FnF); EPS service tests (§06.2) |

**Registration coverage.** An establishment does not always hold its own code for every scheme: §07.2's worked manufacturer runs a Bengaluru sales office "same PF code or a sub-code" as its Pune plant. The model therefore separates *ownership* from *coverage*. `RegistrationCoverage (establishment_id, registration_id, scheme, [from, to))` says which registration an establishment files each scheme under on each date — its own, or one owned by an ancestor establishment of the same legal entity. A sub-code that ESIC or EPFO allots separately is its own `Establishment` row with its own `Registration` (§07 FR-CHR-021), never a coverage row.

**Temporal constraints (the invariants a physical schema must hold).**

| # | Constraint | Enforced at | Failure it prevents |
| --- | --- | --- | --- |
| T1 | **Nesting.** A child's validity lies inside its parent's at every level: registration inside its owner; establishment inside its legal entity; every assignment inside its employment; an `EstablishmentMapping` inside the mapped establishment's range | Write time; a violating write is refused with the conflicting range | A mapping to a closed establishment; a registration outliving its entity |
| T2 | **Coverage.** For every date on which an employment is mapped to an establishment and eligible for scheme S (derived `EligibilityState`), exactly one covering registration for S is active — or the gap is an explicit `registration_pending` exception | Readiness check before `INPUTS_CLOSED` (§08 FR-PAY-301) and at filing-instance creation | A deduction with no registration to remit it under — the silent under-remittance §14.4.1 names |
| T3 | **No gaps, no overlaps** in any assignment type within an employment, closed-open (§07.2a) | Write time; concurrent edits to one range serialised (§07.2a) | Two establishments claiming one employee-day; a day with no PT state |
| T4 | **Uniqueness.** At most one active registration per (owner, scheme, state) on any date; one (scheme, number) never belongs to two owners in a tenant; uniqueness is never checked across tenants (§07 FR-CHR-104) | Write time | Two PTRC rows for one state; a cross-tenant disclosure |
| T5 | **Closure never deletes.** Surrender, cancellation or closure sets `valid_to`. No filing instance can be created for a period wholly after `valid_to`; every due period up to it stays in the ledger until filed or explicitly resolved — a closing registration cannot silently abandon a month (Part E-10; EV-038) | Filing-instance creation; the FR-PAY-712 ledger | A final month nobody files; an obligation that vanishes with the code |
| T6 | **Late knowledge is a new row.** A registration obtained with a back-dated effective date is recorded as a new knowledge-time version; `registration_pending` liabilities for the covered dates are re-pointed to it through a correction path, never by editing a filed artefact | Registration write; the correction-run machinery (§14.4.4) | Rewriting history when a PT certificate arrives three months late |
| T7 | **Straddled periods are surfaced, not assumed.** A period that straddles a registration's `valid_from` or `valid_to` resolves per sub-period (§14.6.3 step 1) and is flagged for operator review; how each portal treats a part-period is a rule-row question routed to §20, never a schema assumption | Readiness check | A guessed part-month split on a surrendered code |
| T8 | **The service record is derived only.** It is recomputed from employments, assignments and the counted days frozen at each period lock; a break's treatment (bridged or breaking) is an audited decision with a basis and an actor; nothing writes a service total by hand | Derivation job; maker-checker on break treatment | A hand-edited gratuity clock |

**The service record, precisely.** `ServiceRecord` holds `segments[]` (one per employment with the legal entity, each `[DOJ, DOL]`), `counted_days` per twelve-month window (the CoSS s.54 day count, §06.6 **[Verified]** — lay-off, paid earned leave, temporary disablement from employment injury and maternity leave up to 26 weeks counted), `breaks[]` with `break_treatment ∈ {bridged, breaks_service}` plus `basis` and `decided_by`, `clock_start`, and a reference to the eligibility-test rule version (`gratuity.four_years_240_days_rule`, §07 FR-CHR-016 **[Hypothesis]**). It is keyed to the legal entity because the employer is the unit the gratuity obligation binds (§06.6), and how service carries across legal entities in a group is the v2 group-transfer decision (§07 FR-CHR-026), so v1 never bridges two entities automatically — a carry-over is an explicit `break_treatment` with its basis recorded. Counted days are read from the input snapshot frozen at each `INPUTS_CLOSED`, never from punches, so erasing punches changes no service total (§14.6.1a).

**Worked example — one transfer, three levels moving.** The §07.2 manufacturer: one legal entity; a Pune plant owning the EPF code, the ESIC code and the Maharashtra PTRC; a Bengaluru sales office owning the Karnataka PTRC and covered for EPF by the Pune code; a remote engineer working from Assam, where the entity holds no PT registration. A salesperson moves from Pune to Bengaluru on 16 September.

- *Assignments:* her `EstablishmentMapping` closes at `[…, 16-Sep)` on Pune and opens `[16-Sep, …)` on Bengaluru; her `WorkLocationAssignment` moves from Maharashtra to Karnataka on the same date; her `OrgAssignment` need not move at all (§07.2).
- *Registrations:* September's PT resolves per sub-period (§14.6.3) against the Maharashtra row for 1–15 September and the Karnataka row for 16–30 September. Whether she belongs on the Maharashtra PTRC return, the Karnataka one, or both for September depends on each state's part-month treatment, which this PRD has not captured — so the month is flagged for operator review and nothing is guessed (T7; §14.10 item 12). Her EPF line stays in the single ECR under the Pune code, because Bengaluru's EPF coverage row points at it.
- *Service record:* unchanged and unbroken — same legal entity, same `ServiceRecord`, one continuous segment.
- *The Assam engineer:* T2 fails for PT if the tenant's remote-PT policy follows the work location, so the readiness report shows `registration_pending` for Assam rather than a zero line (§14.4.1).

**AC-DM-37** — *Given* an establishment whose `closed_on` is 31 March, *When* an `EstablishmentMapping` starting 1 April is written against it, *Then* the write is refused with the conflicting range (T1), and no filing instance for April or later can be created against that establishment's registrations (T5).

**AC-DM-38** — *Given* an employment mapped to an establishment that has no active covering registration for a scheme the employment is eligible for, *When* the readiness check runs before `INPUTS_CLOSED`, *Then* the gap surfaces as `registration_pending` with the scheme, state and dates, the liability is computed and held, and payroll is not blocked (T2).

**AC-DM-39** — *Given* a PTRC surrendered with `valid_to` = 30 June, *When* the filing ledger is read in September, *Then* every due period up to 30 June is present with its own status — filed, or flagged as missed — and none after it is created; the ledger cannot report the registration as clean while a due period is unfiled (T5; Part E-10).

**AC-DM-40** — *Given* a person rehired by the same legal entity after a break, and separately employed by a second legal entity in the same tenant, *When* gratuity eligibility is evaluated, *Then* the first legal entity's `ServiceRecord` carries both segments with the break's recorded treatment and basis, the second legal entity's `ServiceRecord` is separate, and no service is carried between the two entities without an explicit, audited `break_treatment` (T8; §07 FR-CHR-026).

**AC-DM-41** — *Given* a locked period whose punches are later erased, *When* the `ServiceRecord` is recomputed, *Then* its counted days are unchanged, because they are read from the frozen input snapshot and never from punches (T8; §14.6.1a).

---

### 14.4 Entity deep-dives (the load-bearing ones)

Only the entities whose *field-level* shape is non-obvious or India-specific are expanded. Identity/master fields are specified in §07.1 and not repeated; here we specify the fields that exist *because of a statute or a filing format*.

#### 14.4.1 Establishment — the registration hub

The naive model attaches PF/ESI/PT to the company. In India they attach to the **establishment/registration**, and one company routinely holds many. This entity is the reason multi-state "just works" or doesn't.

| Field | Notes | Source |
| --- | --- | --- |
| `epf_code` | Establishment code allotted by EPFO — region/office/establishment code with an optional extension or sub-code, each extension a separate establishment row (§07 FR-CHR-021). The ECR is filed per code. The mask is the versioned validation rule `id_format.epf_code`, carried and desk-verified before GA (§07.1.1). **[Reversed]** v0.3 gave a digit-count example here as Verified; no research round captured EPFO's own specification. | EPFO establishment registration; mask **[Hypothesis — carried, not re-captured]** |
| `esi_code` | ESI employer code; **sub-codes** per state/branch office are common, each a separate establishment row that files separately (§07 FR-CHR-021). The 17-digit length is carried in `id_format.esic_code`. | ESIC registration; length **[Hypothesis — carried, not re-captured]** (§07.2) |
| `pt_reg_no` (PTRC) | The state PT employer registration — the establishment as deductor — held per state; an establishment with staff in two PT-levying states holds two. There is no per-employee PT enrolment; the employee-level fact is the derived PT eligibility (§07 FR-CHR-104). The entity's own PT enrolment (PTEC), which also covers each director's PT, sits on the `LegalEntity`, not here (§07 FR-CHR-022; r1/06 finding 30). Maharashtra assigns the PTRC return frequency per registration each year, so frequency is ingested, never derived (§06.4). **[Reversed]** v0.3 put both certificates on the establishment. | State PT Acts; §07.2 |
| `lwf_reg_no` | State LWF registration where the state runs an LWF. Which states levy, the amounts and the periodicity are compilation-sourced; the one verified periodicity is Karnataka's calendar-year cycle with a 15 January due date (§06.8). | State LWF Acts; periodicity **[Hypothesis]** outside Karnataka (§06.8) |
| `se_reg_no`, `se_state` | Shops & Establishments registration — per-state; the register, leave and hours rules and the threshold are set by each state Act. | State S&E Acts; thresholds **[Hypothesis]** (§07.2, §06.1) |
| `tan` (reference) | The legal entity's TAN, referenced rather than owned: TAN sits on the legal entity, PF/ESI/PT/LWF codes on the establishment (§07.2). Form 138 (ex-24Q — EV-050) is filed per TAN. A company may run multiple TANs; each runs its own Form 138 series, and the employee's deductor TAN is an effective-dated assignment (§07 FR-CHR-104). | §07.2; the 1961-Act s.203A citation is carried and its 2025-Act successor is unmapped (§06.13) |
| `gstin` (reference) | The legal entity's GSTIN for this establishment's state, held on the `LegalEntity` (§07.2a) and referenced here; not a payroll key, used for invoicing and reconciliation. | CGST Act; §07.2 |
| `lin` | Labour Identification Number — the "Registration Number of the establishment" on the Form I register header (r5/04 finding 16) and a column of the principal employer's annual return (r5/04 finding 20). | §07 FR-CHR-022 **[Verified]** |
| `premises_work_location_id` | The establishment's own premises as a `WorkLocation` (state, sphere, Code-regime commencement). Rule resolution reads the jurisdiction from each employment's work-location assignment for the period — this location for on-premises staff, the employee's own location for remote staff (§14.6.3). **[Reversed]** v0.3 put a single `jurisdiction_id` on the establishment, which mis-resolves remote staff (Part E-5). | Part E-5 |
| `nic_code`, `hazardous_flag` | Drives Second-Schedule employee-compensation applicability and the docks/mines/construction health-check confinement (§06.1). | CoSS Second Schedule; notified Rules **[Verified]** |
| `headcount_tracked[counting_unit]` | A running count per **counting unit** — employees, persons, workers, contract labour — because the statutes count different populations and one establishment can be above one line and below another on the same day (EV-057). Holds the latched value where the obligation's wording latches (§06.1). Drives the 10/20/50/100/300 obligation gates so a threshold crossing arms the right filings automatically. | EV-057; §06.1 **[Verified — central sphere]** |

**Edge case — new-state operation without registration.** An employee physically working in a state where the employer has *no* PT registration yet (new market entry, remote hire): the model stores the derived PT liability with a `registration_pending` state so the readiness report flags "PT due, no registration" rather than silently under-remitting — a common source of interest/penalty.

**Edge case — the obligation latch.** The 10-employee gratuity and maternity tests read "employed, or were employed, on any day of the preceding twelve months," so they **latch once crossed** and do not un-arm when headcount dips (§06.1 **[Verified]**). ESI's and EPF's Code-era latch wording is unconfirmed (§06.13), so latching is a per-obligation rule attribute (`latch_rule`), not a schema assumption. `headcount_tracked` stores the *peak-in-trailing-12-months* per counting unit where the rule latches, and `EligibilityState` transitions are driven off the rule, never off a spot count.

**AC-DM-03** — *Given* a legal entity with establishments in MH, KA and TS, *When* the September payroll month is LOCKED, *Then* the readiness report lists exactly three distinct PT `Filing` obligations keyed to three `pt_reg_no`s, and any work-location state lacking a `pt_reg_no` surfaces as `registration_pending`, never as a zero-liability line.

**AC-DM-04** — *Given* an establishment that employed 10 employees on a single day in the trailing twelve months, *When* headcount later falls to 8, *Then* gratuity and maternity applicability in `EligibilityState` remain armed (latch, §06.1), EPF and ESI follow their rule rows' `latch_rule` (Code-era wording unconfirmed, §06.13), and disabling any latched obligation requires an explicit, audited administrative action with a statutory basis, not an automatic de-arm.

#### 14.4.2 Employee, Employment, StatutoryIdentifier

`Person` is immutable-identity; `Employment` is the instance. `StatutoryIdentifier` is modelled as a **typed, effective-dated, linkage-stateful** child rather than columns on Employee, because the *state* of each ID is what gates filings. Each identifier sits at exactly one owning level (§07 FR-CHR-104), and every value mask is a versioned validation rule `id_format.<identifier>` — most carried from v0.3 and desk-verified against the issuer's specification before GA (§07.1.1):

| ID type | Owning level | Value format | Linkage state stored (the load-bearing part) | Gates |
| --- | --- | --- | --- | --- |
| UAN | `Person` | 12 numeric (length carried, `id_format.uan`); field 1 of the ECR file (EV-035) | `seeding_status` (pending / seeded / mismatch), `transfer_status`, `filing_role` (`active_for_filing` / `declared_additional`) | Whether the member's line can enter the ECR — unseeded is exclude-and-flag, never a payroll block (§07 FR-CHR-101); a second declared UAN raises `MULTIPLE_UAN_DECLARED` |
| PAN | `Person` | `AAAAA9999A` (mask carried, `id_format.pan`) | `availability` (present / not-available → the `no_pan_tds_floor` parameter, §07.1.1), `verification_status`, `holder_type` (4th char) | TDS rate, Form 138 data behind Form 130 |
| ESI IP | `Person` | 10 numeric (`id_format.esi_ip` — **[Hypothesis]**, practitioner descriptions only, §07.1.1) | `registration_status` (registered / pending); Aadhaar seeding at IP registration is optional (§07 FR-CHR-042) | ESI contribution filing |
| Aadhaar (optional) | `AadhaarTokenVault`, referenced from `Person` by token | 12 numeric with a Verhoeff checksum (carried, `id_format.aadhaar`) — validated at the vault boundary; the number is held only in the vault (§14.4.15) | The business row holds `aadhaar_token` (opaque, not derived from the number, never a hash) and `vault_state` (none / held / deleted) | Nothing gates on it; UAN seeding is the employee's own UMANG action (§07 FR-CHR-041); never a filing key |
| PRAN | `Person` | 12 numeric (carried, `id_format.pran`) | corporate-NPS subscription state | Employer NPS contribution treatment in TDS |
| Bank account + IFSC | `Person` holds verified accounts; `Employment` holds the disbursal instruction | account + IFSC (mask carried, `id_format.ifsc`) + name; captured only once a written-consent record exists (SPDI r.5(1), EV-060; §07 FR-CHR-006) | `verification_status` (penny-drop / name-match) — **disbursal-blocking** | Salary/FnF payout |
| PF Member ID | `EstablishmentMapping` (employment × establishment code) | establishment-code-scoped | **a new one on every inter-establishment move**, under the same UAN | ECR routing, EPF claims |

**Statutory-identifier linkage state is a small state machine, not a flag.** The gating decisions (can the member's line enter the ECR? does the `no_pan_tds_floor` parameter apply? can we disburse?) are transitions, not truth values, so each identifier carries an explicit lifecycle.

<!-- DIAGRAM: statutory-identifier-linkage-states -->

**Aadhaar rule (Part E-6; §07 FR-CHR-005, FR-CHR-099):** the number is written only to the `AadhaarTokenVault` — separately encrypted, separately access-controlled — and business tables hold an opaque token, never the number and never a hash of it. Display is at most the last four digits, served by the vault. That masking rests on the reg 6(2) security duty and on risk; it is not presented as a statutory display duty on a plain employer (Part D-5). The Verhoeff checksum is validated at the vault boundary, so a mistyped number is rejected before anything is stored. **[Reversed]** v0.3 stored the number, encrypted and masked, on the identifier row.

`EligibilityState` is a separate effective-dated child so that **crossings are handled by rule, not by a checkbox.** The two crossings that generate the most support tickets:

- **ESI ceiling crossing mid-period.** An ESI-covered employee revised above ₹21,000 gross in July keeps coverage to 30 Sep (end of the Apr–Sep contribution period) and drops from 1 Oct — **two effective-dated rows, both visible in history** (Source: the ESI contribution-period rule as it stood before the Code-era rules **[Verified]**; the ESI (Central) Rules 1950 are saved only until the cliff (§06.9) — v0.3's statement that the Social Security (Central) Rules 2026 already supersede them is carried, not re-captured, and the Code-era citation is unmapped (§06.13) — and ESI after on or about 21 November 2026 is fenced, §06.9). ESI contribution periods are Apr–Sep and Oct–Mar; corresponding benefit periods are Jan–Jun and Jul–Dec. The model stores the contribution-period boundary, not the salary-revision date, as the coverage-end.
- **Gratuity eligibility crossing.** The continuous-service test (5 years, with 240 days actually worked in a twelve-month period counting as continuous service; the 5-year condition does not apply on death, disablement or fixed-term expiry — CoSS ss.53–54, §06.6 **[Verified]**) is a derived `EligibilityState` computed off the `ServiceRecord` (§14.3.1), so a rehire under the same `employee_id` bridges or breaks continuous service according to the recorded break treatment.

**AC-DM-05** — *Given* an employee whose gross rises above ₹21,000 on 12-Jul, *When* the July, August and September runs execute, *Then* ESI is deducted through September on actual gross — the ₹21,000 is a coverage gate, not a contribution cap (§06.3) — and stops from 1-Oct, producing exactly two `EligibilityState` rows (`covered` → `not_covered` effective 01-Oct), and the historical rows remain queryable.

**AC-DM-06** — *Given* an employee rehired under an existing `employee_id` after a 3-month gap, *When* gratuity eligibility is evaluated, *Then* continuous-service is computed from the `ServiceRecord` per the recorded break treatment, a PF Member ID is recorded on the new `EstablishmentMapping` (establishment-scoped), and the person-level UAN and ESI IP are unchanged because they never left the `Person`.

**International workers (IW) — a distinct PF sub-regime.** `Employment` carries an `iw_flag` (§07 FR-CHR-007), and `EligibilityState` reads it because an IW is carried as having **no ₹15,000 PF wage ceiling** — contribution on full PF wages. That rule is **[Hypothesis]**: the paragraph references (EPF Scheme para 83, EPS para 43A) and the court history are carried, not re-captured; as carried, a High Court is reported to have struck down the IW special provisions and the matter is under challenge — the court and year v0.3 named trace to no research round and are not stated here (§06.2). The IW PF basis is therefore the parameter `epf.iw_wage_basis`, confirmed before any uncapped IW contribution is applied (§06.13). **[Reversed]** v0.3 marked the IW rule Verified. Where the worker is from a country with a Social Security Agreement (SSA) with India, a **Certificate of Coverage / detachment certificate** may exempt or cap contribution; the model stores this as a `Document` (C1) linked to the `Employment` with a validity window, and `EligibilityState` reflects the exemption for that window. This is the one case where the `pf_wage_ceiling` rule row is deliberately *not applied*, driven by the identifier flag, not a code branch.

**Employment type and contract labour.** `Employment.type ∈ {permanent, fixed_term, contract, apprentice, trainee, consultant, gig_platform}` matters because obligations differ: the 5-year condition does not apply on fixed-term expiry and fixed-term employees are paid gratuity **pro rata** (CoSS s.53, §06.6 **[Verified]**), while the reading that they qualify after one year of service rests on professional commentary, not the Code's text (**[Hypothesis]**, §06.6); contract labour under a principal employer may sit on the *contractor's* PF/ESI code rather than the principal's (§07 FR-CHR-028); and gig/platform workers fall under the Code on Social Security's separate aggregator regime, whose operational status we have not established as of September 2026 (routed to §20). Modelling `type` on `Employment` (not `Person`) lets one person hold a consultant engagement and later a permanent one with correctly different statutory treatment.

#### 14.4.3 CompensationStructure / PayComponent / CompensationAssignment — where the two wage bases live

The 50% add-back forces the schema to compute *several* bases from one component set. Each `PayComponent` therefore carries independent boolean inclusion flags, not a single "statutory" flag:

| Flag on PayComponent | Feeds |
| --- | --- |
| `pf_wage` | PF/EPS/EDLI + gratuity add-back base (excludes HRA, conveyance, overtime, award settlements) |
| `esi_wage` | ESI gross base (**includes** HRA/conveyance/overtime) |
| `gratuity_wage` | Gratuity accrual base (add-back rules) |
| `pow_wage` | Payment-of-wages / equal-remuneration base (broadest) |
| `taxable`, `tax_section` | TDS under s.392 (ex-s.192 — EV-050); exemption section (1961-Act numbering such as HRA s.10(13A), mapped per §06.13) |
| `perquisite_flag`, `fbp_flag` | Form 123 (ex-12BA — EV-050) perquisite valuation; flexible-benefit wallet |
| `component_kind` | earning / deduction / reimbursement / statutory-employer-cost / employer-cost (CTC-only, non-payable) |
| `basis` | fixed / percent-of (basic, CTC or gross) / balance-figure / slab / attendance-prorated |

**Worked example (why one `wage` column is wrong).** Employee CTC ₹9,00,000/yr. Structure: Basic ₹3,00,000, HRA ₹1,50,000, Conveyance ₹19,200, Special Allowance ₹4,30,800 (balance figure). Basic alone = ₹25,000/month; total monthly remuneration = ₹75,000.

- **Excluded-component test (the add-back).** Only the excluded heads enter the test (§06.10). Here they are HRA + Conveyance = (₹1,50,000 + ₹19,200)/12 = ₹14,100/month, i.e. **18.8% of the ₹75,000 total remuneration** — below one-half, so **no add-back arises**. The s.2(y) wage for PF and gratuity is total remuneration less the excluded heads: Basic ₹25,000 + Special ₹35,900 = **₹60,900/month**. The special allowance stays in wages because it is not an excluded head, and relabelling universal pay does not move it out (§06.10). Had the excluded heads exceeded one-half, the excess would be deemed wages and added back — the §06.10 illustration, with the arithmetic fixed by AC-DM-07 (Source: Code on Wages s.2(y) / CoSS s.2(88); final Central Rules notified 8 May 2026 **[Verified]**). **[Reversed]** v0.3's version of this example treated the special allowance as excluded and derived a ₹12,500 add-back; §06.10 withdrew that reading.
- **PF ceiling interaction.** PF/EPS statutory basis is capped at ₹15,000/month unless the employer opts to contribute on actual wages. If the employer restricts to the ceiling, employee EPF = 12% × ₹15,000 = ₹1,800; employer split: EPS = 8.33% × ₹15,000 = ₹1,250 (EPS wage capped at ₹15,000), employer EPF = the remainder, ₹550 — the 1,800 / 1,250 / 550 split is EPFO's own Help File fixture (EV-035; §06.2 **[Verified]**); EDLI = 0.5% × ₹15,000 = ₹75 (**[Verified]**, §06.2). Admin charges at 0.5% × ₹15,000 = ₹75 rest on pre-Code EPFO circulars not re-verified, and the establishment-level minimum is the parameter `epf.admin_charge.minimum`, applied once per establishment per wage month (**[Hypothesis]**, §06.2). **[Reversed]** v0.3 stated the admin rate and a ₹500 minimum as Verified. The s.2(y) wage of ₹60,900 still matters: it is the base if the employer contributes on actual wages, and it is the gratuity base, which has no ceiling (§06.10).
- **ESI gross base** = full gross (Basic + HRA + Conveyance + Special) = ₹75,000 — but this employee is **above the ₹21,000 ESI ceiling** (₹25,000 for a disabled IP), so **not ESI-covered**.
- **POW base** = full gross ₹75,000, for minimum-wage and equal-remuneration tests.

Three different numbers — ₹15,000 (ceiling-restricted PF), ₹60,900 (s.2(y) wages and gratuity), ₹75,000 (ESI gross and POW) — one payslip, one component set. The model stores components + flags; the engine (§08) computes bases against the `EffectiveDatedRule` add-back percentage in force for the period. `CompensationAssignment` versions the whole binding so a mid-year CTC revision recomputes correctly for open/retro periods only.

**Balance-figure ordering.** `PayComponent.basis = balance-figure` (special allowance = CTC − Σ others) must evaluate **last** in the ordered structure; a percent-of-CTC component and a balance-figure component in the same structure form a resolution order that the structure's `component_order` encodes (§08 FR-PAY-101). Where a balance figure feeds the add-back test that re-bases it, the node is a bounded fixed-point node — iterated to convergence under a maximum iteration count and a tolerance — not a one-pass topological step (§08 I7, FR-PAY-211).

**AC-DM-07** — *Given* a structure whose excluded components exceed 50% of total remuneration, *When* the PF/gratuity base is computed, *Then* the deemed-wages add-back equals `excluded − addback_percent × total_remuneration` (50% today, a notified variable), the figure is stamped with the `addback_percent` rule version used, and changing the CTC mid-year re-runs this only for open and explicitly-reopened periods, never for a LOCKED or later month except through a correction run.

**AC-DM-08** — *Given* a structure containing both a percent-of-CTC component and a balance-figure special allowance, *When* the structure is evaluated, *Then* the balance figure resolves after all other components and the sum of all `component_kind ∈ {earning, statutory-employer-cost, employer-cost}` equals CTC to the paisa.

#### 14.4.4 PayRun / PayrollResult / Payslip

`PayRun.type ∈ {regular, off_cycle, arrears, bonus, reimbursement, fnf}`; its state is the payroll-month machine of §08 FR-PAY-301. `PayrollResult` holds every computed figure **with its rule lineage** (D4): each amount references the `rule_version` rows used, so the run is **replayable** (same input snapshot + rule versions + evaluation context → byte-identical, §08 I4/I6) and **recomputable** (retro against the period's versions). Replay reads only the snapshot and the bitemporal classes, never an erasable input such as a punch (§14.6.1a). `Payslip` is a rendered `Document`, never a source of truth — regeneration must reproduce the original from result + template version.

**Payroll-month states — what each freezes in the data model.** The machine itself — event, guard, side effect, who may trigger — is specified as a transition table in §08 FR-PAY-301 (Part E-1): `OPEN → INPUTS_CLOSED → PROCESSED → APPROVED → LOCKED → DISBURSED → PAYMENT_INITIATED → FILED`, reversible before `LOCKED`, with the statutory verification gate immediately before `PAYMENT_INITIATED` (EV-037). This table is its data-model consequence. Each transition emits an `AuditEvent`. **[Reversed]** v0.3 specified `draft → inputs_locked → computed → reviewed → approved → disbursed → filed → closed`, with approval as the point of no return and no payment-initiation state, so the one irreversibility line the revamped ECR creates had nowhere to live (Part E-1).

<!-- DIAGRAM: payrun-lifecycle-state-machine -->

| State (§08 FR-PAY-301) | Becomes immutable in the data model | A later change goes to |
| --- | --- | --- |
| `OPEN` | Nothing; the period's rule-set versions resolve and filing instances are created as `SCHEDULED` | Direct edit |
| `INPUTS_CLOSED` | The input snapshot — attendance-derived paid days, LOP, NCP days and OT hours by band; variable pay; declarations; joins, exits and revisions. Replay reads this, never punches | Reopen to `OPEN`; the superseded snapshot is kept |
| `PROCESSED` | A `PayrollResult` version per employee, stamped with rule versions and the evaluation context (§08 I6); repeatable | Reprocess — a new version, prior versions kept for diff |
| `APPROVED` | The approval artefact; the planned disbursal date in the evaluation context | Return to `PROCESSED` (approval voided, reason kept) |
| `LOCKED` | Every result; payslips rendered; bank file generated; filing artefacts may be generated from the locked snapshot | A correction run only — a diff against the locked snapshot (§08 FR-PAY-306) |
| `DISBURSED` | The actual disbursal date, recorded (it keys PF liability on arrears — Part E-9), and UTRs | Correction run |
| `PAYMENT_INITIATED` | Statutory challans with TRRN; the verification gate has passed — no downward ECR correction is possible from here (EV-037) | Correction run, routed to a Supplementary return or the fenced arrear flow (EV-037, EV-043) |
| `FILED` | Every monthly filing instance `FILED`, with acknowledgement and receipt | Correction run |

**Retro/arrears modelling:** an arrears run does not overwrite a LOCKED month. It creates new `PayrollResult` rows tagged `applies_to_period = March, run_in_period = September`, computed against **March's** rule versions (D2), with the statutory liability date for PF taken from the arrears run's disbursal date, not the wage month (Part E-9). The March filing artefact remains immutable; the delta goes to whichever filing path the guards allow — a Revised or Supplementary return within EV-037, the arrear flow (fenced — no layout is published, EV-043), or the next Form 138 statement or correction statement (§08 FR-PAY-708). This is the schema expression of §08's I3. LOP-reversal, retro-CTC-revision, and corrigendum-driven recompute all use this same shape — there is exactly one mechanism for "change a locked month," and it is additive: a diff, never a mutation (Part E-1).

**Full-and-final settlement (FnF) — a distinct run type, not a special payslip.** `PayRun.type = fnf` composes components that never co-occur in a regular run: **leave encashment** (reads the derived `LeaveBalance`, §14.4.7), **gratuity payout** where eligibility is met ((15/26) × last-drawn monthly wages × completed years, with service in excess of six months in the final year counting as a full year — CoSS s.53, §06.6 **[Verified]**). The payable ceiling is "such amount as may be notified" under CoSS s.53(3) and no Code-era notification has been located, so it is the parameter `gratuity.payable_ceiling`; the familiar ₹20 lakh is a legacy of the repealed Act (**[Hypothesis]**, §06.6). It never shares a field with the lifetime tax-exemption ceiling, `tax.gratuity_exemption_ceiling`. **[Reversed]** v0.3 stated a ₹20L cap as Verified. **notice-period recovery** (a negative earning), **pending reimbursements**, and a **TDS true-up** against the full-year projection now that the exit date is known. FnF is where retention (§14.7) and the gratuity claim-tail begin: the run's outputs seed the post-exit retention clock. An FnF run can itself be reopened as an arrears run if a gratuity dispute later revalues service — again additive, never in-place.

**AC-DM-09** — *Given* a LOCKED March month, *When* a September arrears run corrects a March input, *Then* new `PayrollResult` rows are created with `applies_to_period=March, run_in_period=September` computed against March-effective rule versions, the March `PayrollResult` and `Payslip` remain byte-identical, the PF liability date is the arrears disbursal date (Part E-9), and the delta is routed only to a filing path the EV-037 guards allow — never into an edit of the March return.

**AC-DM-10** — *Given* a LOCKED month and its `PayrollResult`, *When* the run is replayed from the recorded input snapshot, rule versions and evaluation context, *Then* every figure reproduces byte-for-byte; the `Payslip` verifies against its stored `sha256` while its rendered file is retained, and once that file is erased under its retention class it is re-rendered from snapshot and template version and marked as a re-rendering (§08 I4). A divergence in any figure is a lineage defect that blocks release.

#### 14.4.5 Filing — the unit of delivery

Because the whole product is "did the return go out and get accepted," `Filing` is the most instrumented entity in the model.

| Field | Purpose |
| --- | --- |
| `filing_type` | ECR, ESI_CONTRIB, PT_RETURN, LWF, TDS_138 (Form 138, ex-24Q), FORM_130 (Form 130, ex-Form 16 — distribution of the TRACES-generated certificate), STAT_REGISTER, etc. Labels, search and imports accept both vocabularies (EV-050). |
| `registration_id` (+ the registration row's knowledge-time version), `establishment_id`, `jurisdiction_id`, `period` | What/where/when this covers: one registration × obligation × period (§08 FR-PAY-711; §14.3.1). The jurisdiction is the registration's state, resolved from its work location (Part E-5). |
| `return_type` | For the ECR: `regular`, `supplementary` (needs an approved Regular; only members absent from every prior return for the month) or `revised` (needs an approved Regular, no other return in process, **no payment initiated**) — EV-037. |
| `format_version` | The government file-format version used. Form 138 replaces 24Q with a breaking layout (EV-051); the Q1–Q3 regular format was published 22 July 2026 and the Q1–Q3 correction format 4 August 2026 (§06.5); the **Q4 regular and correction formats are not released**, re-checked September 2026, so the Q4 generator and Form 130 Part B are fenced (EV-046). The FVU stack is chosen by the period — RPU 1.2 + FVU 1.2 from Tax Year 2026-27, RPU 6.0 + FVU 9.5 for FY 2010-11 to FY 2025-26 — and mixing them is rejected (EV-052). The model stores which format each attempt was built against. **[Verified]** |
| `input_snapshot_ref` | Immutable snapshot of the exact `PayrollResult`/master rows the artefact was built from (the N:M-via-snapshot in §14.3). |
| `generated_document_id`, `artefact_sha256` | The file/return artefact (Document) and its hash. The hash lives on the Filing, so it outlives the erasable Document (§14.6.1a). |
| `state` | The §08 FR-PAY-711 states: `SCHEDULED, BLOCKED, GENERATED, VALIDATED, SUBMITTED, REJECTED, ACCEPTED, REVISED, SUPPLEMENTARY, PAYMENT_INITIATED, FILED` (Part E-1), with `blocked_reason`, owner and unblocking trigger when `BLOCKED`. |
| `submitted_by`, `submission_mode`, `authority_to_act_document_id`, `portal_session_log_ref` | Every statutory portal is an attended surface. `submission_mode ∈ {employer, operator_under_written_authority}`; the session log records who acted, on whose credentials, when, and which file (§22). The employer's statutory liability is non-delegable (K-13). The operator mode is a product capability whose statutory basis is under counsel review — acting on portals under employer credentials, portal terms of use, the e-Return Intermediary question for TDS, and the authorised signatory's DSC (Part D-17; §23) — so `employer` is always available and the schema never assumes the operator mode is lawful. |
| `ack_ref`, `ack_document_id`, `submitted_at` | Portal acknowledgement — the return file ID and, at challan, the TRRN for the ECR (EV-036); the Return Receipt Number for Form 138 (EV-051). The proof of on-time filing, the headline metric's evidence. |
| `rejection_reasons[]` | Structured, replayable rejection codes (e.g. name mismatch against UAN, negative wage, IFSC invalid) so the fix loop is guided, not manual. |
| `challan_id` | The money leg (§14.4.6). |
| `due_date`, `filed_date`, `on_time` | Computed against the statutory calendar for that filing_type + jurisdiction. |
| `corrects_filing_id`, `attempt_no` | The Regular or accepted return that a Revised, Supplementary or correction attempt diffs against, and the attempt sequence. The prior return and attempt are never overwritten — a correction is a diff (Part E-1). |
| `nil_status` | A NIL period is a ledger entry, never a gap. For EPF a NIL month uses no file; admin and inspection charges go through Direct Challan Entry, enabled only when there are no active members (EV-042). |

**Filing lifecycle.** The canonical machine — transition table and guards — is §08 FR-PAY-711; the diagram below shows its data consequences: every attempt is a new record linked to the prior one, every artefact is bound to the locked snapshot and a format version, and a correction after acceptance is a new linked return. **[Reversed]** v0.3's lifecycle had no `BLOCKED`, `SUPPLEMENTARY` or `PAYMENT_INITIATED` state and allowed a revision of any accepted return, with no guard for payment initiation (Part E-1; EV-037).

<!-- DIAGRAM: filing-lifecycle-state-machine -->

**Filing-type catalogue with statutory calendar** (due dates drive `due_date`/`on_time`; all are `EffectiveDatedRule`-backed, since due dates themselves change by notification):

| `filing_type` | Covers | Typical due date | Source | Confidence |
| --- | --- | --- | --- | --- |
| `ECR` (EPF) | Electronic Challan-cum-Return | **15th** of following month | EPFO ECR procedure | **[Verified]** |
| `ESI_CONTRIB` | ESI contribution | **15th** of following month | ESI regime as it stood before the Code-era rules; post-cliff regime fenced (§06.9) | **[Verified]** to on or about 21 November 2026 |
| `PT_RETURN` | State PT return | **Per state, per registration** — monthly/annual; e.g. Maharashtra assigns the frequency per registration each year (§06.11) | State PT Acts | **[Hypothesis]** exact per-state dates — per-state verification status is kept in §06.4 and §06.13, not restated here |
| `TDS_138` | Quarterly TDS statement, Form 138 (ex-24Q) | **Q1 31 July, Q2 31 October, Q3 31 January, Q4 31 May of the year following the Tax Year** | Income-tax Rules 2026 r.219 (EV-049) | **[Verified]** dates; Q4 generator fenced — format not released (EV-046) |
| `FORM_130` | Annual salary certificate, Form 130 (ex-Form 16) — **TRACES-generated only**; a certificate not generated from TRACES is invalid (EV-048). The product distributes it, never generates it | **15 June** of the year following the Tax Year (§08) | Income-tax Rules 2026 r.215 | **[Verified]**; blocked for Tax Year 2026-27 behind the missing Q4 Annexure II (EV-046, EV-047) |
| `LWF` | State LWF | **Per state** — monthly/half-yearly/annual | State LWF Acts | **[Hypothesis]** per-state dates/rates — kill/confirm: gazette per state, §14.10 item 8. **[Reversed]** v0.3 called multi-state LWF parity with Frappe HR "across 14 states"; Frappe HR v16 has no LWF and no Indian state name in its source (EV-031), and TallyPrime has no LWF engine (EV-032), so it is a differentiator (K-01) |
| `STAT_REGISTER` | **Six employer registers plus a wage slip**, across three rule-sets, kept as one canonical set (EV-053) | Maintained current; retention per the governing rule-set's wording (EV-054, §14.7.1) | Wages r.51(1), OSH r.72, SS r.53(1)(a) — central sphere; form numbers per state | **[Verified — central sphere]** |

`STAT_REGISTER` covers Wages Rules r.51(1) Forms I, IV and IX with the Form V wage slip; OSH Forms XIII, XIV, XV, XIX and XX with the Form XVI wage slip; and SS r.53(1)(a) Form XXII, the Register of Women Employees. The non-duplication provisions (OSH r.72(3); SS r.53(1)(a) proviso) make them one canonical set with code-specific views, and form numbers are configurable per state because state rules prescribe different forms (EV-053). Form IX needs per-day IN and OUT timestamps; Form I has 36 numbered fields, including specimen signature or thumb impression (EV-055). Each register instance is a record with a retention class keyed to its rule-set's wording (§14.7.1). **[Reversed]** v0.3 described "four consolidated registers" with a flat five-year retention.

**Why `PayrollResult` carries the fields it does — the ECR is the forcing function.** The EPFO ECR is a member-wise text file — `#~#`-delimited, no header row, **11 fields in a fixed order** (EV-035) — and each field must be reproducible from a `PayrollResult` row plus the member's identifiers. Wage month, return type, contribution rate and remark are portal form controls, not file content (EV-035), so they live on the `Filing`, not the result. This mapping is why the result cannot be a single net-pay number:

| # | ECR field (EV-035) | Sourced from | Note |
| --- | --- | --- | --- |
| 1 | UAN | `StatutoryIdentifier` (UAN, `seeding_status`) | An unseeded member is excluded and flagged before generation (§07 FR-CHR-101) |
| 2 | Member Name as per UAN | `Person.name_as_per_uan` (§07 FR-CHR-009a) | Never the display name |
| 3 | Gross Wages | `PayrollResult` POW/gross base | The broadest base |
| 4 | EPF Wages | `PayrollResult` PF base (s.2(y) wages, ceiling-applied unless contributing on actuals) | Distinct from gross — the §14.4.3 example |
| 5 | EPS Wages | min(EPF wages, ₹15,000); zero for a non-EPS member | EPFO hard-blocks only the age-58 EPS rule and merely flags a post-01.09.2014 above-ceiling joiner (EV-040), so the derivation is the control (§07 FR-CHR-012) |
| 6 | EDLI Wages | min(EPF wages, ₹15,000) | Capped separately |
| 7 | Employee PF Contribution | `PayrollResult` employee share | Stamped with rate `rule_id` |
| 8 | Employer EPS Contribution | `PayrollResult` employer EPS share | Stamped with rate `rule_id` |
| 9 | Employer PF Contribution | `PayrollResult` employer EPF share | Stamped with rate `rule_id` |
| 10 | NCP Days | The run's input snapshot (derived at `INPUTS_CLOSED` from `DayStatus`) | Never recomputed from punches (§14.6.1a) |
| 11 | Refund of Advance | ledger | Where applicable |

A single `wage` column cannot regenerate this file — which is the schema-level proof of §14.4.3's argument, expressed as a filing format.

**Exception-loop worked example.** Before generation, the pre-ECR readiness check (§07 FR-CHR-097) finds one member's UAN at `seeding_status = pending`. The default is exclude-and-flag (§07 FR-CHR-101): the member is paid in the same run, the member's line is left out of the Regular return, and an exception row `{code: AADHAAR_UAN_UNSEEDED, uan: …, member_id: …}` routes to exactly that member's identifier state, with an operator task and an employee notice. Once the employee has seeded the UAN, the product prepares a **Supplementary** return for that wage month — permitted because the member is absent from every prior return for the month (EV-037) — as a new attempt linked by `corrects_filing_id`, built **from the same locked snapshot** (the wage data did not change, only the identifier state), with the portal-calculated s.7Q interest shown, since it is mandatory (EV-039). A portal rejection for another reason follows the same shape: `REJECTED → GENERATED`, a new attempt, the fix made through identifier state or a correction run and never by editing the snapshot (§08 FR-PAY-711 F8).

**AC-DM-11** — *Given* a payroll month for a multi-state employer, *When* it reaches `LOCKED`, *Then* filing instances exist for one `ECR` per EPF establishment code, one `ESI_CONTRIB` per ESI code, one `PT_RETURN` per PT registration, `LWF` where due and `TDS_138` at quarter-end, each with its own `due_date`, state and reference to the locked snapshot.

**AC-DM-12** — *Given* a return from which a member was excluded, or a `REJECTED` attempt, *When* the identifier state is corrected and a new attempt is generated, *Then* the new attempt is a separate record linked to the prior one, built from the same snapshot if no wage figure changed, and both attempts keep their own timestamps so that §19 computes on-time status by its own definition. Whether a portal treats a corrected resubmission as on-time is not established in this PRD's evidence and is not assumed (§20).

**AC-DM-13** — *Given* an EPF establishment with no contribution due for a wage month, *When* the ledger is evaluated, *Then* the month carries an explicit status — NIL with its Direct Challan Entry receipt where there are no active members (EV-042), or the return the rules otherwise require — and an unfiled due month is flagged as a missed obligation, never suppressed (§08 FR-PAY-712).

#### 14.4.6 Challan / Payment

Separates the *return* (what is owed and to whom) from the *payment* (money moved). Holds PF/ESI/PT/TDS challan numbers, the EPF TRRN (EV-036), CRN (TDS Challan Reference Number), bank UTR, NEFT/host-to-host file reference, amount — with the s.7Q interest component carried separately, because it is mandatory, auto-calculated and payable with the contribution (EV-039) — and reconciliation state (`initiated → debited → reconciled → failed`). A NIL EPF month has a Direct Challan Entry payment and no return file (EV-042); a challan can fail after a return is accepted, so the two lifecycles are **independent**.

**Why independent lifecycles matter (edge case).** For EPF, return submission is separated from payment: upload → validate → return statement → approve → Due Deposit Balance Summary → challan with TRRN → pay → receipt, and several challans may follow one return (EV-036). For TDS, the challan (CRN via the e-Pay Tax / TIN 2.0 flow) is often paid *before* the quarterly return is filed and is then *quoted* inside the return. So the model cannot assume a fixed ordering between Filing and Challan; it links them and reconciles, rather than nesting one inside the other. A `Challan` in `failed` after its `Filing` is `ACCEPTED` raises a reconciliation exception, not a re-filing.

**AC-DM-14** — *Given* an accepted TDS return quoting a challan CRN, *When* the bank later reports that challan as failed/reversed, *Then* the system raises a reconciliation exception linking Filing and Challan, and does not silently mark the period compliant.

#### 14.4.7 Punch, DayStatus, FormIXRow / Leave

The attendance entities follow §09.1-A. A `Punch` is source-tagged (`source ∈ {device_adms, geo, mobile, kiosk, manual, import}`) because device-pushed punches (the ADMS/WDMS receiver, §09.3 **[Verified]**) arrive with a device serial and raw packet that must be retained for dispute. Ingestion is idempotent on `(device_sn, device_user_id, device_timestamp, direction)` plus `payload_hash` (§09.3 AC4), so a device retrying a POST does not double-count a punch. A `Punch` is an **erasable** class and never references a biometric template (§14.6.1a, §14.4.15). `DayStatus` is a derived projection. `FormIXRow` is the statutory record: a monthly sheet with **per-day IN and OUT timestamps**, materialised at period lock — a present/absent or day-total model cannot produce it (EV-055) — and retained per EV-054, so it survives the erasure of the punches behind it.

Overtime is paid at **not less than twice the ordinary rate of wages**, against normal hours of 8 a day where the wage period is daily and 48 a week otherwise (§09.6 FR-OT-001 **[Verified]**), so the OT rate and hours are `EffectiveDatedRule` rows, not constants, with state overlays possible. A **quarterly ceiling of 144 OT hours** is reported only by secondary summaries, has never been confirmed against gazette text, and may sit in the OSH rules — **[Hypothesis]** (K-04). It is the parameter `ot_quarterly_ceiling_hours`: the product may **warn** on it and must **never block** a punch, roster, OT approval, pay run or filing; the figure is routed to §20. **[Reversed]** v0.3 marked the 144-hour ceiling Verified and flagged excess hours against it as a statutory breach.

**OT worked example.** A worker on ₹26/hour normal rate logs 30 OT hours in a month; the running quarter total is already 130 hours. OT pay = 30 × (2 × ₹26) = ₹1,560, and every hour worked is paid. The model adds the 30 hours to the quarterly total (160) and compares it with `ot_quarterly_ceiling_hours` (hypothesised 144): crossing the configured threshold raises an **advisory** warning to the site admin — nothing is blocked, nothing is withheld, and the register records hours actually worked.

`LeaveBalance` is a *derived* running total; `LeaveTransaction` is the immutable ledger that moves it (`accrual, availment, encashment, lapse, carry_forward, opening_balance, adjustment`), so a balance can always be reconstructed and a mid-year policy change is a new effective-dated `LeavePolicy` version.

**Leave-ledger worked example (why balance is derived).** Employee opens FY with 6 days (imported as an `opening_balance` transaction, §14.4.10). Monthly accrual 1.5 days, posted at each month end; takes 3 days in June; a new `LeavePolicy` version from September changes the carry-forward cap, which bites only at year end. Balance at any date = Σ transactions ≤ that date — 6 + (6 × 1.5) − 3 = 12 days on 30-Sep — so an auditor reconstructs "how did we get 12 days on 30-Sep" without trusting a mutable counter, and the September policy change adds a `lapse` transaction only when the cap is applied. Encashment at exit reads the derived balance and posts an `encashment` transaction feeding FnF.

**AC-DM-15** — *Given* a worker whose quarterly OT would exceed `ot_quarterly_ceiling_hours`, *When* the run computes OT, *Then* every hour worked is paid at the `EffectiveDatedRule` rate in force for the period, an advisory warning is raised, and no punch, roster, approval, pay run or filing is blocked (K-04).

**AC-DM-16** — *Given* a leave balance on any date, *When* it is queried, *Then* it equals the sum of `LeaveTransaction` rows up to that date, and no direct write to `LeaveBalance` is possible outside a transaction.

#### 14.4.8 Document

Every stored file carries `classification` (§14.5) and `retention_class` (§14.7), plus `sha256` (tamper-evidence for filed artefacts), `storage_region` (residency, §14.8) and `linked_entity`. Document types include the appointment letter — in the form the appropriate Government prescribes where the establishment has 10 or more workers (OSH Code s.6(1)(f)), which makes the template state-sphere and configured per state (EV-057; §07 FR-CHR-043) — wage slip, the TRACES-generated Form 130 stored as downloaded (EV-048), Form 124 (ex-12BB) proofs, KYC documents, and register exports. Any Aadhaar document lives only in the `AadhaarTokenVault`, never in the Document store (§14.4.15). **[Reversed]** v0.3 treated the prescribed-format letter as universal from 21 Nov 2025 (K-18). A `Document` that is a filed artefact is **write-once**: its `sha256` is recorded at generation and any later read verifies against it, so a filed return cannot be silently swapped. Documents are an erasable class (§14.6.1a): when a retention class expires the file is erased and a tombstone remains, while the `Filing` keeps the hash.

#### 14.4.9 Benefits / FBP entities (build the model now, defer monetisation)

Per §11, the benefits *data model* is v1 even though monetisation is deferred — retrofitting these into a shipped payroll engine is expensive, and they are the option value on the entire attach business. The entities:

| Entity | Purpose | India-specific note |
| --- | --- | --- |
| `FbpDeclaration` | Employee's flexible-benefit-plan allocation across components (meal, LTA, telephone, books, fuel) per Tax Year | Meal perquisite limit ₹200/meal and gift/voucher ₹15,000 per tax year from 1 Apr 2026 (was ₹50 / ₹5,000) — **[Hypothesis]** (EV-019; §11); these limits are `EffectiveDatedRule` rows, not hardcoded. The meal exemption applies **only** to food provided during working hours at office or factory premises, or through non-transferable vouchers usable only at eating outlets; without those conditions the perquisite is taxable, payslips under-deduct, and the demand plus interest lands on the employer. The conditions are engine constraints on the component (`meal_delivery_mode`, voucher attestations — §11 BEN-62), and the 2026-Rules citation is routed to §20 (K-19). |
| `WalletConfig` / `WalletTransaction` | Wallet setup and spend ledger | Kept as a *ledger* so proof-of-spend and endorsement reconcile. |
| `ProofOfSpend` | Bill/proof against a wallet or exemption (HRA, LTA) | A `Document` (C2) with verification state; feeds Form 124 (ex-12BB) proof state (§07 FR-CHR-017). |
| `Dependant` | Dependant records (spouse/children/parents) for group health + ESI dependant benefit | C2; drives ESI dependant eligibility and insurance endorsement. |
| `InsurancePolicy` / `Endorsement` | Group health/GPA/GTL policy + add/delete endorsement history | Model software PEPM and attach revenue as **two lines never blended** (§11 **[Verified]**); the schema keeps them structurally separate. |
| `NpsSubscription` | Corporate NPS (PRAN), employer/employee contribution | Feeds the employer-contribution deduction in TDS (1961-Act s.80CCD(2); 2025-Act mapping per §06.13). |

**Design rule (D9 applied):** attach entities reference `Employment` and carry classification/retention like any other C1/C2 data, but they are **isolated from the payroll `PayrollResult` money-of-record** — a benefit wallet or an insurance endorsement never silently alters a filed statutory figure. This keeps the "two lines never blended" discipline enforceable at the schema level, not just in reporting.

**AC-DM-17** — *Given* a `WalletTransaction` or `Endorsement`, *When* it posts, *Then* it can adjust taxable-perquisite inputs for the *next* TDS computation via an explicit, audited feed, but it can never mutate an already-filed `PayrollResult` or `Filing` (D9).

#### 14.4.10 Migration / opening-balance entities (mid-year cutover is first-class)

Migration is **a first-class product surface, not a services task** (§18.9, §16.7 **[Hypothesis]** — the churn-driver claim is not yet validated), and mid-year cutover is where churn-inducing friction concentrates. The data model therefore has dedicated entities so an imported employee lands *fileable*, not merely *stored*:

| Entity | Carries | Why it must exist as data |
| --- | --- | --- |
| `MigrationBatch` | Source system (Tally/Zoho Payroll/Kredily/Frappe/spreadsheet), cutover date, mapping profile, validation report | Importers from Zoho/Kredily/Frappe are *acquisition infrastructure* (§18.9, §16.7); the Tally import is the wedge. A batch never creates a `ConsentRecord` — consent cannot be backfilled; imported written-consent evidence attaches with its original date and provenance, and the onboarding consent flow is §07 FR-CHR-102 (Part E-12). Source biometric templates are never imported. |
| `OpeningBalance` | YTD earnings, YTD TDS already deducted, PF/ESI contributions YTD, leave balances, gratuity accrual clock start | Without YTD-TDS-deducted, the first in-house Form 138 statement is wrong and so is the TRACES-generated Form 130 built from it; without gratuity clock start, continuous-service is wrong. |
| `PreviousEmployerIncome` | Form 122 (ex-12B — EV-050) income + TDS from a mid-year joiner's prior employer | Required for correct annual TDS aggregation (§07 FR-CHR-018). |
| `CertificateContinuity` | Link from prior-system Form 16/130 and prior UAN/ESI IP continuity | UAN/ESI IP are portable; the migration must *continue* them, not mint new ones. |

**Cutover edge cases the model handles:**

1. **Mid-cycle investment declaration.** An employee whose investment declaration was in-flight in the old system — `FbpDeclaration` + `PreviousEmployerIncome` reconcile so proofs already submitted aren't re-demanded.
2. **YTD TDS already deducted.** Flows into `OpeningBalance` so the remaining-year TDS spreads correctly across the balance months and the TRACES-generated Form 130 reflects one continuous year across two systems. **Worked (illustrative figures — the liability comes from whatever slab, standard-deduction, rebate and cess rows are in force for the Tax Year, §06.5):** an employee migrated on 1-Oct with ₹12,00,000 income and ₹1,40,000 TDS already deducted Apr–Sep, projected full-year income ₹24,00,000, and a full-year liability the engine computes from the rule rows — say ₹2,90,000. The engine subtracts the ₹1,40,000 `OpeningBalance` already withheld → ₹1,50,000 remaining, spread over Oct–Mar = ₹25,000/month. It does **not** restart the year at ₹2,90,000/6 ≈ ₹48,333/month, which would over-withhold by ₹1,40,000 across the six months. **[Reversed]** v0.3's version used a ₹9,00,000 income with a ₹95,000 new-regime liability, which the rebate figures in §06.5 contradict. A mid-year joiner from another employer instead brings `PreviousEmployerIncome` (Form 122, ex-12B), which the engine *aggregates* into projected income before computing liability — a different path from `OpeningBalance` (same-employer continuity vs prior-employer aggregation), and conflating the two mis-states the year's withholding.
3. **Leave balances** import as an opening `LeaveTransaction` so the derived `LeaveBalance` is auditable from day one.
4. **Gratuity clock.** `OpeningBalance.gratuity_clock_start` carries the original DOJ so continuous-service is not reset to the migration date — a silent reset here would understate a future gratuity claim.

**AC-DM-18** — *Given* a mid-year `MigrationBatch` with `OpeningBalance.ytd_tds_deducted`, *When* the first in-house run computes TDS, *Then* the annual liability is reduced by the opening YTD figure and spread over remaining months, and the Q4 salary annexure (Annexure II — generator fenced until the format is released, EV-046, EV-047) carries full-year figures including the opening YTD, so the TRACES-generated Form 130 (EV-048) reflects one continuous year across both systems.

**AC-DM-19** — *Given* an imported employee with a prior `UAN`/`ESI IP`, *When* migration completes, *Then* the existing identifiers are continued (linkage state carried forward) and no new UAN/ESI IP is minted; a duplicate mint is a release-blocking migration defect.

#### 14.4.11 EffectiveDatedRule + Jurisdiction

Covered in depth in §14.6 — it is the entity that makes multi-state + retrospective payroll tractable.

#### 14.4.12 AuditEvent, ConsentRecord / DataPrincipalRequest, RetentionHold

`AuditEvent` is append-only, NTP-synced (NIC/NPL, per CERT-In — EV-062 **[Verified]**), retained **at least 180 days within Indian jurisdiction** as ICT logs (EV-062; longer where a statutory register or dispute requires). It records `actor, role, action, entity, before, after, authority (statutory basis or approval), rule_version, ts_ntp`. Because a wrong payroll number is a legal problem (§08 **[Verified]**), every statutory/monetary write path emits exactly one `AuditEvent` and cannot commit without it.

`ConsentRecord` is **load-bearing today**. SPDI r.5(1) requires consent in writing before collecting sensitive personal data — biometric and financial information, including bank details (EV-060) — and an Aadhaar number enters the vault only on a Sharing Regulation 5 consent (EV-068). The record's shape — versioned, per purpose and regime, stating whose artefact it is — is specified in §14.4.15. **[Reversed]** v0.3 said DPDP s.7(i) already exempts employment processing from consent and confined consent to optional purposes; s.7(i) is not in force until on or about 13 May 2027, and when it commences it disapplies consent and notice for employment purposes only, not the s.8 duties (EV-058; K-03).

`DataPrincipalRequest` (the DPR) is a small workflow entity: `type ∈ {access, correction, erasure, grievance, nomination}`, `raised_at`, `regime`, `sla_due_at`, `status`, `reasoned_response_document_id`, `decision_basis`. The types mirror DPDP Chapter III (EV-066), which is not in force until on or about 13 May 2027 (EV-058). Its lifecycle is `received → verified_identity → evaluated → responded (with reasoned response) → closed`; erasure requests fork into the §14.7 deletion engine. The machinery is built now; its statutory basis is under counsel review (§14.7.3).

`RetentionHold` is the override that pins rows against deletion during litigation/investigation/tax scrutiny: `scope (employee|payrun|establishment|tenant), reason, authority, placed_at, released_at`. While active it beats every erasure and every retention ceiling.

**AC-DM-20** — *Given* any write to a statutory or monetary field, *When* the transaction commits, *Then* exactly one `AuditEvent` with a valid NTP timestamp and stated `authority` is committed atomically with it; a write without its audit row is impossible.

#### 14.4.13 What the model deliberately does not store (the anti-patterns)

A data model is defined as much by its refusals as its tables. Each refusal below traces to a specific §PRD finding, and is a schema-level prohibition, not a guideline:

| Refusal | Why | Source |
| --- | --- | --- |
| **No model-generated statutory or monetary figure** is ever persisted as truth | "No statutory or monetary figure may ever be model-generated" — a wrong payroll number is a legal problem. AI output is stored only as C3 draft/explanation, structurally separated from `PayrollResult`. | §08 **[Verified]** |
| **No biometric image anywhere, and no template outside the biometric keyspace** — no image column, no image bucket | Enrolment images are deleted after template extraction; a template lives only in its separate keyspace; a `Punch` never references a template, so the attendance record survives template destruction. **[Reversed]** v0.3 deferred this to "final DPDP Rules"; the design now follows Part E-6, and nothing here rests on a DPDP sensitive category, which does not exist (EV-059). | Part E-6; §14.4.15; §09 FR-DEV-007 |
| **No Aadhaar number, or hash of one, in any business table, log, export, analytics store or model call** — and Aadhaar is never a filing key | Business rows hold an opaque vault token only; UAN/ESI IP are the filing keys. | Part E-6; §07 FR-CHR-099; EV-068 |
| **No single `wage` column** | At least four concurrent wage computations exist per employee per period (§06.10; §14.4.3). | §06.10 **[Verified]** |
| **No `current PT slab` reference on a computed result** | Results cite a *versioned* `rule_id`, so re-opening a later period cannot mutate a filed artefact. | §14.6, D2 **[Verified]** |
| **No hard `DELETE` from the app** | Deletion is the §14.7 policy engine's reasoned decision, executed by crypto-shredding or tombstone (§14.6.1a). | D8 **[Verified]** |
| **No blending of software money-of-record and attach/interchange money** | "Two lines never blended." | §11, D9 **[Verified]** |
| **No PF Member ID on `Person`**, and no identifier at more than one level | PF Member ID is establishment-code-scoped and a new one opens on every inter-establishment move; it lives on the `EstablishmentMapping`. PAN, UAN and ESI IP live only on `Person`; TAN and PTEC only on `LegalEntity` (§07 FR-CHR-104). | §07 FR-CHR-104; §14.9 |
| **No per-employee PT enrolment** | PT registrations belong to the establishment (PTRC) and the legal entity (PTEC); the employee-level fact is derived eligibility. | §07 FR-CHR-104 |

These refusals are the mirror image of §20: the product declines to build hardware, a premium AI SKU, or interchange-monetised free HRMS at the *business* layer; the data model declines the corresponding *schema* shortcuts that would quietly re-open those doors.

#### 14.4.14 Cardinality / volume shape (a hint for §15 storage)

Rough per-tenant magnitudes at the top of the 20–200-employee beachhead, to inform partitioning and hot/cold placement (§15) — order-of-magnitude, not commitments:

| Entity | Growth driver | Shape |
| --- | --- | --- |
| `Punch` | employees × working-days × punches | **Highest-volume** row; ~200 emp × ~25 days × 2 punches ≈ 10k rows/month; erasable, while the `FormIXRow`s derived from it carry the register retention |
| `AuditEvent` | every statutory/monetary write | High-volume, append-only, at least 180 days kept within India (EV-062), then cold |
| `PayrollResult` | employees × runs (regular + off-cycle + arrears) | ~200–400 rows/month; hot for open + reopenable periods |
| `Filing` | ~4–8 per establishment per month | Low-volume, high-value, never cold (evidence) |
| `EffectiveDatedRule` | notifications, not tenant activity | Small, shared, reference; C4; cached |
| `LeaveTransaction` | accruals + events | Medium; append-only ledger |
| `Document` | filings + KYC + slips | Object-store; `storage_region` + `retention_class` drive lifecycle |

The design consequence: the two append-only high-volume ledgers (`Punch`, `AuditEvent`) dominate storage but are cheap to tier; the low-volume high-value entities (`Filing`, `PayrollResult` lineage, `EffectiveDatedRule`) are what must never be lost or mutated. Storage economics and integrity requirements therefore point in *opposite* directions across the model — which §15 must resolve, not average away.

#### 14.4.15 Segregated identity stores — Aadhaar token vault, biometric template, consent record (Part E-6)

Three kinds of data are kept out of the rings by construction, because retrofitting any of them means a migration across every module and an audit of every query. §07 (FR-CHR-099–103) owns the capture behaviour and §09 (FR-ATT-017, FR-DEV-007) owns biometric capture and the device protocol; this subsection fixes the entity shapes and the invariants a physical schema must hold.

| Entity | Fields | Store and keys | End of life |
| --- | --- | --- | --- |
| `AadhaarTokenVault` | `aadhaar_token` (opaque and random — not derived from the number), `aadhaar_number` (ciphertext), `consent_id` (Sharing Regulation 5 consent — EV-068), `purpose`, `purpose_spent_at`, `deleted_at` | Separate store, separate encryption keys, separate access control; encrypted transmission, a legal requirement (reg 6(4), EV-068); excluded by default from support tooling, analytics, exports, sub-processors and every model call (§07 FR-CHR-099). Hosting outside India is a counsel question (Part D-15), so the vault is India-only | Deleted once the consented purpose is spent — reg 6(5) sets a ceiling, not a floor (EV-068). The business-row token then resolves to a tombstone |
| `BiometricTemplate` | `template_id`, `employment_id`, `modality`, `consent_id`, `key_ref` (biometric keyspace), `enrolled_at`, `erased_at` | Separate keyspace, independently access-controlled and logged. No image column and no image bucket: enrolment images are deleted after template extraction | Key destruction plus two-phase device-side erasure (§09 FR-DEV-007), on exit, consent withdrawal or a switch to the non-biometric path |
| `DeviceEnrolment` | (`employment_id`, `device_sn`), `enrolled_at`, `erase_cmd_id`, `ack_at`, `exception_state`, `attested_by` | The per-device enrolment and erasure ledger, with a retry queue for offline devices | `erased-confirmed` on the device's acknowledgement, or `closed-by-attestation` through the documented exception state (an admin attests decommission or loss) |
| `ConsentRecord` | `consent_id`, `version`, `data_principal_id`, `purpose`, `data_classes`, `regime` (SPDI r.5(1) / Aadhaar Sharing Reg 5 / DPDP), `notice_text_version`, `capture_form` (written wherever the regime requires it), `artefact_owner` (employer / vendor / both — who owes the SPDI duty is under counsel review, Part D-4), `granted_at`, `withdrawn_at`, `provenance` (captured / imported evidence) | Append-only and versioned; a withdrawal is a new version, never an edit | Erasable class (§14.6.1a), kept as evidence for the counsel-set parameter `retention.consent_evidence` |

**Invariants.**

1. **No Aadhaar number, and no hash of one, in any business table, log, export, analytics store or model payload.** Business rows carry `aadhaar_token` only.
2. **The attendance record survives template destruction.** A `Punch` carries employee id and timestamp and never a template reference, so erasing a template leaves every punch, `DayStatus` and `FormIXRow` valid (§09.1-A).
3. **Two consent regimes run concurrently.** Every `ConsentRecord` carries its regime. At the switch on or about 13 May 2027 (EV-058) nothing is rewritten, re-dated or discarded: SPDI-regime records stay as captured and DPDP-regime records begin alongside them. Whether the SPDI Rules survive the omission of IT Act s.43A is a counsel question (Part D-12).
4. **Consent is never backfilled.** No import or job synthesises a `ConsentRecord`; imported evidence keeps its original date and provenance (§07 FR-CHR-102).
5. **Neither Aadhaar nor biometric enrolment is ever a condition** of employment, payroll or any benefit, and no tenant configuration can make it one (Part D-10; §07 FR-CHR-101).
6. **The vault is named for its function, not for a UIDAI regime.** `AadhaarTokenVault` is this product's own segregated store. Whether UIDAI's Aadhaar Data Vault and HSM regime binds a non-requesting entity is under counsel review (Part D-6; §23), and so is whether an employer entering Aadhaar into EPFO or ESIC portals becomes a "requesting entity" (Part D-7). This PRD asserts neither, and the store's separate keys and access control are specified so that the answer changes key custody, not the schema.

**AC-DM-31** — *Given* every business table, audit record, log line, export, analytics store and model-call payload, *When* the build-time schema and egress test runs, *Then* no Aadhaar number and no hash of one is found; the only Aadhaar-related value outside the vault is the opaque token.

**AC-DM-32** — *Given* an employee enrolled on three terminals who exits, *When* erasure runs, *Then* the template key is destroyed, a delete command is queued per device, the erasure shows complete only when each device has acknowledged or has been closed by attestation (shown as `closed-by-attestation`, never `erased-confirmed`), and every punch and Form IX row for the employee remains readable.

**AC-DM-33** — *Given* a `ConsentRecord` captured under SPDI r.5(1) before on or about 13 May 2027, *When* the DPDP regime commences, *Then* the record is unchanged and still resolvable as evidence of what was captured under it, and any DPDP-regime record for the same purpose is a new record alongside it.

---

### 14.5 Data classification

Every field and document carries one of four classifications. The tag is not documentation — it **drives** encryption, masking, access scope, residency and retention, and it is enforced in code and auditable (D7).

| Class | Definition | Examples in this model | Controls the tag enforces |
| --- | --- | --- | --- |
| **C1 · Regulated-Sensitive** | Data whose handling is dictated by a specific statute/regulator, or whose leak is a reportable incident. Includes the SPDI r.3 sensitive set — biometric information and financial information — which needs consent in writing before collection today (SPDI r.5(1), EV-060) | Bank account, PAN, salary/comp, PF/ESI contributions, TDS, biometric templates (in their own keyspace — §14.4.15), health/disability status, ICT logs. The Aadhaar number is not held in any C1 business store — only in the vault | Encryption at rest + in transit; field-level masking; access confined to named functions + audited; India-region storage by default (§14.8); CERT-In-reportable on breach within six hours (EV-062); retention class |
| **C2 · Personal — elevated harm** | Personal data whose exposure causes material harm. An internal handling class, not a statutory category: DPDP defines personal data with no sensitive sub-category (EV-059) | DOB, address, personal email/mobile, dependant records, nominee, marital/gender where used for statutory variance | Encryption; role-scoped access; masking in support views; access and correction requests serviced (§14.7.3) |
| **C3 · Internal-Personal** | Ordinary personal/employment data | Name, designation, department, DOJ, employment type, org mappings | Tenant-isolated; role-based access; audited on statutory-impacting change |
| **C4 · Operational / Reference** | Non-personal config and reference | `EffectiveDatedRule` rows, `Jurisdiction`, structure templates, holiday calendars, device registry | Standard access controls; changes to rules are audited (they move money) |

**India-specific classification notes:**

- **Aadhaar lives in its own store, not in any class of business data.** The number exists only in the `AadhaarTokenVault` (§14.4.15; Part E-6); business rows hold an opaque token — never the number, never a hash. Masking to the last four digits is built as a reg 6(2) security and risk control, not presented as a statutory display duty on a plain employer (Part D-5); encrypted transmission is a legal requirement (reg 6(4), EV-068). UAN/ESI IP are the filing keys; Aadhaar is never one. **[Reversed]** v0.3 said the Aadhaar Act and regulations restrict storage and display, and kept the masked number on the identifier row.
- **Salary and statutory contributions are C1**, not C3, because they are personal data *and* the substance of regulated filings, and bank details are SPDI financial information (EV-060); a comp leak is both a privacy and a competitive event.
- **DPDP has no sensitive category; the SPDI Rules do.** DPDP creates no special or sensitive category of personal data (s.2(t), EV-059) — **and** the SPDI Rules 2011 are live and classify biometric and financial information as sensitive, requiring consent in writing before collection (r.3, r.5(1), EV-060). Nothing in this model is labelled sensitive "under DPDP" (Part D-19). Biometric templates are C1 and live in a separate keyspace, never referenced by an attendance event (§14.4.15). **[Reversed]** v0.3 said DPDP pushed biometrics to the strictest class and deferred template storage to "final DPDP Rules" (K-06).
- **Consent is live today; s.7(i) is not.** DPDP s.7(i) is not in force until on or about 13 May 2027 (EV-058). Today SPDI r.5(1) requires written consent before collecting the sensitive set (EV-060), so `ConsentRecord` is a primary control now, alongside the classification and retention regime. When s.7(i) commences it disapplies consent and notice for employment purposes only; the s.8 duties still apply (EV-058). Who owes the SPDI written-consent duty — employer or vendor — is under counsel review (Part D-4), so every record states whose artefact it is. **[Reversed]** v0.3 stated s.7(i) as current law and called it a structural advantage over GDPR-bound designs (K-03).
- **CERT-In-reportable classes are tagged.** Attacks on AI/ML systems are an expressly reportable incident class — Annexure I item (xx) of the CERT-In Directions (EV-062); C1 fields touched by any AI egress path additionally carry `ai_egress_class` (§14.8) so the reportable surface is enumerable, not guessed, at incident time — the report is due within six hours of becoming aware (EV-062).

#### 14.5.1 Access, roles & maker-checker (the schema side of D4)

Classification decides *what* is protected; the role model decides *who* touches it and *under what control*. The maker-checker separation (D4) is a data constraint — the checker on a `PayrollResult` or `Filing` transition must be a distinct actor from the maker — enforced in the transition, not left to process discipline.

| Role | Reads | Writes | Constraint |
| --- | --- | --- | --- |
| **Payroll maker** | C1–C3 within scope | proposes run inputs, computes | Cannot approve own run |
| **Payroll checker / approver** | C1–C3 within scope | approves `PROCESSED → APPROVED` and `APPROVED → LOCKED` (§08 FR-PAY-301) | Must ≠ maker on the same run (segregation) |
| **HR admin** | C2–C3 | master data, structures | Comp writes are statutory-impacting → audited |
| **Employee (self-service)** | own C1–C3 (masked where C1) | own declarations, proofs, consents, DPRs | No cross-employee read |
| **CA / bureau (console)** | **read-only** across assigned clients | none on money-of-record | Read-only audit access (§18.7 **[Hypothesis]**); switching clients is tenant-scoped |
| **Data-request handler** | DPR queue + processing summary | reasoned responses | A named role; distinct from the CERT-In point of contact, which is named before the first paying customer (§17.6) |
| **Support** | masked views only | none on statutory fields | No vault access: the Aadhaar vault is excluded from support tooling by default (§07 FR-CHR-099) |

**AC-DM-29** — *Given* a run at `PROCESSED`, *When* an actor attempts to approve it, *Then* the approval is rejected if that actor is the run's maker (maker ≠ checker), and the rejection is auditable; segregation-of-duties cannot be bypassed by role stacking on one account without an explicit, logged override.

**AC-DM-30** — *Given* a CA console user assigned to a set of client tenants, *When* they open any client, *Then* all money-of-record entities are read-only, the view is scoped to exactly the assigned tenants, and no write to a `PayrollResult`/`Filing`/`Challan` is possible from the console.

---

### 14.6 Effective-dated & multi-state rule storage (the hardest schema)

Two problems collapse into one entity here: **rules change over time** (retrospective payroll) and **rules differ by place** (multi-state). `EffectiveDatedRule` solves both by being keyed on (`rule_type`, `jurisdiction_id`, `effective_from`) with bitemporal columns.

#### 14.6.1 Why bitemporal, not just effective-dated

A single `effective_from` answers "what rule applied to March." It cannot answer "what did we *believe* in April about March" — which is exactly what you need when a **corrigendum** amends a notification retrospectively. The PRD's own cautionary tale is the November 2026 EPF cliff, where corrigendum S.O. 5936(E) of 19.12.2025 substituted the S.O. 5319(E) entries and inverted an earlier reading of when the EPF Act repeal commenced; verifying against the uncorrected S.O. 5319(E) reproduces the wrong answer (§06.9, §02.4 **[Verified]**). The EPF Scheme 2026, with 12% re-notified retrospectively to 21.11.2025 by S.O. 3582(E), is a separate instrument (§06.9). A bitemporal store lets us record the corrected rule *and* preserve what we filed under the old belief, with a clean recompute path.

| Column | Axis | Meaning |
| --- | --- | --- |
| `effective_from`, `effective_to` | **Business time** | The period the rule legally governs. `effective_to = NULL` = still in force. |
| `recorded_at`, `superseded_at` | **Knowledge time** | When *we* recorded/replaced this belief. A corrigendum inserts a new row that supersedes the old belief without deleting it. |
| `source_ref`, `source_url`, `source_captured_at` | Provenance | Gazette/notification citation with URL + capture timestamp — enforces the PRD standing rule that no compliance claim ships without a captured source, and the "check for a corrigendum" step. **[Verified]** (Source: §02) |
| `corrigendum_of` | Lineage | Links a corrected rule to the notification it amends (the amendment-watcher, not just new-instrument-watcher, §06). |

#### 14.6.1a Scope: which entity classes are bitemporal, and how the erasable classes forget (Part E-2)

A bitemporal store never forgets; purpose-bound retention (EV-068) and template erasure (Part E-6) require forgetting. The model resolves the conflict by entity class, not by exception. **[Reversed]** v0.3 declared every attribute bitemporal, with universal never-forget replay (K-24).

| Class | Entities | Time axes | How a change lands | End of life |
| --- | --- | --- | --- | --- |
| **B · Bitemporal** — never overwritten, replayable | Rules: `EffectiveDatedRule`, `Jurisdiction`, format versions. Salary structures: `CompensationStructure`, `PayComponent`. Assignments: `CompensationAssignment`, the establishment and work-location assignments. Statutory attributes: `StatutoryIdentifier` linkage state, `EligibilityState`. The statutory hierarchy: `Group`, `LegalEntity`, `Establishment`, `Registration`, `RegistrationCoverage` (§14.3.1) | Business (`effective_from/to`) + knowledge (`recorded_at/superseded_at`) | A new row supersedes; nothing is overwritten | Rules and other non-personal rows are kept. Person-linked rows keep their personal fields under the subject key and fall to the retention engine (§14.7) when their class expires |
| **R · Records of fact** — append-only | Input snapshots, `PayrollResult`, `Filing` and its attempts, `Challan`, `LeaveTransaction`, `FormIXRow`, `ServiceRecord` (derived from frozen inputs, §14.3.1 T8), `AuditEvent`, `RetentionHold` | Business period (`applies_to_period`) + `recorded_at` | A correction is a new linked record — a diff, never a mutation (Part E-1) | Retention engine, at floor and ceiling (§14.7) |
| **E · Erasable** — not bitemporal | `Punch`; rendered `Document`s (payslip PDFs, generated artefacts, register exports, letters); `BiometricTemplate`; `ConsentRecord`; `AadhaarTokenVault` entries | `recorded_at` + erasure state | Append-only while held; `ConsentRecord` versions forward | Erased on its lawful trigger — retention expiry, purpose spent, exit, consent withdrawal |

**Erasure mechanism.** Two mechanisms, chosen per record:

- **Crypto-shredding per subject key.** Each data principal has a subject data key inside the tenant key hierarchy (§17.4); the biometric keyspace and the Aadhaar vault hold their own. Erasable payloads about a subject, and the personal fields of B- and R-class rows, are encrypted under it. Destroying the key makes every copy unreadable, backups included — which holds only if the key itself cannot be restored from those backups, so subject keys are kept outside the backed-up data stores and no key-store restore resurrects a destroyed key (§17.14).
- **Tombstone.** A record that is not encrypted per subject — a multi-subject register export, a tenant-level document — has its payload replaced by a tombstone: record id, class, dates, erasure basis and actor (§07.2a).

Every erasure writes an `AuditEvent` naming the mechanism, basis and actor; the audit event never contains the erased content.

**What replay returns after an erasure.**

1. **Payroll figures reproduce.** Evaluation reads the run's input snapshot, the B-class rows and the evaluation context (§08 I4, I6). Punches are never evaluation inputs — the snapshot holds what the run consumed (paid days, LOP days, NCP days, OT hours by band) — so erasing punches changes no replayed figure.
2. **Attendance replays from the lock-time record.** A period whose punches have been erased returns the `FormIXRow`s and day summary frozen at lock, flagged `source-erased`; it never recomputes from punches that no longer exist (§09 FR-ATT-001).
3. **Rendered documents re-render, and say so.** A payslip or artefact erased under its retention class is re-rendered from the snapshot and template version and marked as a re-rendering; for a filed artefact the `Filing` keeps the original `sha256`, so the re-render is checked against it (§08 I4).
4. **An erased record returns its tombstone**, never a reconstruction (§07.2a).
5. **After a subject key is shredded**, figures remain against surrogate ids (`employment_id`), personal fields return `ERASED`, and a re-render that would need those fields is refused with the tombstone rather than produced with gaps.

**AC-DM-34** — *Given* a LOCKED, filed month whose punches are later erased, *When* the month's payroll is replayed, *Then* every figure reproduces byte-identical from the snapshot, rule versions and evaluation context, and the attendance view returns the lock-time Form IX rows flagged `source-erased`.

**AC-DM-35** — *Given* a data principal whose subject key has been destroyed, *When* any store, or any restored backup, is queried for that principal's records, *Then* only tombstones, ciphertext and surrogate-keyed figures are returned, and no restore path recovers the key.

#### 14.6.1b The rule object — the complete schema

`EffectiveDatedRule` is the rule object. §14.6.1 gives its two time axes; this is the whole object, field by field. §22.8.2 (FR-RULE-002) specifies how the compliance pipeline fills the workflow fields and §15.4 how rule packs ship; the field names below are the ones both sections use.

| Group | Fields | Constraint in the data model |
| --- | --- | --- |
| **Identity** | `rule_id` (one per version), `rule_key` (stable across versions: `rule_type` + jurisdiction + scope qualifiers), `rule_type`, `version`, `rule_pack_id` | `rule_id` is immutable and never reused; `version` is monotonic per `rule_key` |
| **Jurisdiction scope** | `jurisdiction_id` (Central, a state or UT, or a local body where the levy is local — Tamil Nadu and Kerala PT, §06.4), `applies_to_sphere` (all, central, state), `regime` (legacy or Code-era, per the state's commencement date, §14.6.3), `registration_type` (the scheme it binds — PTRC, PTEC, EPF code…), `establishment_class` (e.g. the classes on the reduced PF rate, §06.2), and for `threshold` rows `counting_unit` and `latch_rule` (EV-057) | Jurisdiction is read from the work location at resolution, never from the employee (Part E-5) |
| **Effective range** (business time) | `effective_from`, `effective_to` (`NULL` = in force), `retro_effective` (the instrument is dated after `effective_from`) | Closed-open; `retro_effective = true` enqueues impact analysis on publish (§22 FR-RULE-009) |
| **Decision-time range** (knowledge time) | `recorded_at`, `superseded_at` | `recorded_at` is the instant the version became resolvable — publication, or staging for a tenant in the canary cohort (§22 FR-RULE-013) — not when an analyst began typing; `superseded_at` is the only field ever written after that instant |
| **Payload** | `payload` typed per `rule_type` under a `payload_schema_version`, with units; `rounding_method`, or the named parameter that stands in for an unstated one; `enforcement_mode` (`enforce` or `warn_only`) | A payload that does not validate against its schema cannot leave drafting; no guessed rounding (§15.4.6) |
| **Citation and capture** | `source_ref` (instrument number, date, clause), `source_url`, `source_captured_at`, `capture_method` (raw, rendered, transcribed from an image-only scan), `archive_hash`, `legacy_citation` and `successor_citation` side by side (EV-050), `corrigendum_of`, `last_corrigendum_check_at`, `evidence_status` (`[Verified]`, `[Verified — mirror]`, `[Hypothesis]`) | A version with an incomplete citation or no recorded corrigendum check cannot reach review (§22 AC-RULE-002.3) |
| **Author and reviewer** | `change_request_id`, `author`, `reviewer`, `certification_ref` | `reviewer ≠ author`, enforced as a data constraint, not a UI check (§22 AC-RULE-003.2) |
| **Publish state** | `publish_state` — the §22 FR-RULE-003 states (DETECTED … DRAFTING, IN_REVIEW, CERTIFYING, STAGED, PUBLISHED, SUPERSEDED, ROLLED_BACK, WITHDRAWN); `canary_cohort`; `published_at` | See RO1–RO3 |

**Invariants of the rule object.**

- **RO1 · Only published knowledge resolves.** The resolvable set is every version that has reached PUBLISHED, plus STAGED versions for tenants in the canary cohort. Drafts, versions in review and withdrawn versions never resolve for any tenant.
- **RO2 · Nothing is edited after it resolves.** Any change to any field is a new version. Publication of the next version, or a rollback, writes `superseded_at` on the prior one; no other post-publication write exists.
- **RO3 · Superseded and rolled-back versions stay resolvable in their own window.** A replay at a knowledge time `T` inside a version's `[recorded_at, superseded_at)` window resolves it, so "what did we believe then" is always answerable — including for a version later rolled back, which also lists every output that used it (§22 FR-RULE-014).
- **RO4 · No two current versions overlap.** For one `rule_key`, the versions current at any knowledge time `T` have non-overlapping effective ranges. A corrigendum that changes a range therefore supersedes every version it overlaps in one publication.
- **RO5 · A hypothesis never blocks.** `evidence_status = [Hypothesis]` forces `enforcement_mode = warn_only` (§22 AC-RULE-002.1); the overtime ceiling is the standing example (§14.4.7; K-04).
- **RO6 · A `[Verified — mirror]` version carries its flag** and an open pull-from-primary task, and is never quoted in customer-facing copy until the task closes (Part A-1).

**Worked example — two Karnataka rows, two enforcement modes.** §06.4 records Karnataka PT as ₹200 a month at a monthly salary of ₹25,000 or above, ₹300 in February, nil below — ₹2,500 a year — effective 1 April 2025 under Notification DPAL 08 SHASANA 2025 of 15 April 2025, with the effect verified on the state PT portal and the instrument text not retrieved; the filing frequency is unverified.

| Field | `pt_slab` · Karnataka | `filing_due_date` · Karnataka PTRC |
| --- | --- | --- |
| `rule_key` | `pt_slab` · KA · PTRC | `filing_due_date` · KA · PT_RETURN |
| `effective_from` · `retro_effective` | 01.04.2025 · `true` (instrument dated 15.04.2025) | — not captured |
| `payload` | Base monthly salary; below ₹25,000 → nil; ₹25,000 or above → ₹200, February ₹300; annual total ₹2,500 | `pt.KA.filing_frequency` and due day — no shipped value |
| `source_ref` · `capture_method` | DPAL 08 SHASANA 2025, 15.04.2025 · rendered state PT portal; instrument text not retrieved | — |
| `evidence_status` · `enforcement_mode` | `[Verified]` (§06.4) · `enforce` | `[Hypothesis]` · `warn_only` — the calendar shows the obligation with an unconfirmed due date and never blocks a run |

The slab row can deduct; the frequency row can only warn. A reviewer who is not the author signs each, and neither resolves until published.

**AC-DM-42** — *Given* a rule version in DRAFTING, IN_REVIEW or CERTIFYING, *When* any tenant's run resolves its `rule_type` for a covered period, *Then* the version is not selected; and *given* a STAGED version, *Then* it is selected only for tenants in its canary cohort (RO1).

**AC-DM-43** — *Given* a published rule version, *When* any field other than `superseded_at` is written, *Then* the write is refused and the change is routed to a new version (RO2); and *given* a version whose `author` equals its `reviewer`, *Then* it cannot be stored in any state past IN_REVIEW.

**AC-DM-44** — *Given* a version with `evidence_status = [Hypothesis]`, *When* its `enforcement_mode` is set to `enforce`, *Then* the write is refused (RO5).

**AC-DM-45** — *Given* a version rolled back after it produced figures in two tenants' runs, *When* those runs are replayed at their original knowledge time, *Then* the rolled-back version resolves and reproduces the original figures, and the version lists both runs as consumers (RO3).

#### 14.6.2 What lives as a rule row (not code)

| `rule_type` | Jurisdiction | Example values / variance |
| --- | --- | --- |
| `pf_wage_ceiling` | Central | ₹15,000 (basis cap), re-fixed by S.O. 2702(E) of 29.05.2026 — **[Verified — mirror]**: read through a professional alert quoting it, not the gazette; pull from the primary source before customer use, and the row carries the RO6 flag until then (§06.2); the IW basis is `epf.iw_wage_basis` — "no ceiling" as carried, **[Hypothesis]** while para 83's enforceability is under challenge (§06.2, §06.13) |
| `pf_rate`, `eps_rate`, `edli_rate`, `admin_charges` | Central | 12% employee, re-notified by S.O. 3582(E); employer split EPS 8.33% (capped at ₹15,000 → ₹1,250) / EPF balance; EDLI 0.5% (§06.2 **[Verified]**). Admin 0.5% and `epf.admin_charge.minimum` are **[Hypothesis]** — pre-Code circulars, not re-verified (§06.2). The reduced 10% rate is a per-establishment-class row (§06.2) |
| `addback_percent` | Central | 50%, "or such other per cent as may be notified" — the standing variable that alone justifies this entity (Source: Code on Wages s.2(y) **[Verified]**) |
| `esi_wage_ceiling`, `esi_rate_ee`, `esi_rate_er` | Central | ₹21,000 (₹25,000 disabled); 0.75% / 3.25% (Source: ESIC contribution rates **[Verified]**, §06.3); rows after on or about 21 November 2026 fenced until a successor instrument is found (§06.9) |
| `esi_contribution_period` | Central | Apr–Sep, Oct–Mar; drives the mid-period ceiling-crossing rule (§14.4.2) (Source: pre-Code ESI contribution-period rule **[Verified]**; Code-era citation unmapped, §06.13) |
| `pt_slab` | **Per state**, or **per local body** where the levy is local (Tamil Nadu, Kerala — §06.4) | Each levying state its own table, with a slab base that differs in kind — monthly salary (Maharashtra, Karnataka) or annual income (Odisha); **gender variants** (Maharashtra's women's slab, §06.4); a February or last-month top-up that engineers the ₹2,500 Article 276 ceiling. Maharashtra, Karnataka and Odisha are captured at state sources; Telangana, Tamil Nadu, West Bengal, Gujarat and the rest are `pt.<state>.slabs` parameters with no shipped values (§06.4). **[Hypothesis]** full all-state PT dataset — per-state verification status is kept in §06.4 and §06.13, and aggregator tables are disputed. **Validate/kill:** gazette-sourced dataset per state (levy y/n, slabs, gender, periodicity, dates) before a state drives a deduction; ship beachhead states in v1, all-states in v2 (§07 FR-CHR-014, §20). |
| `lwf_schedule` | **Per state** | Levy y/n, employee/employer share, periodicity (monthly/half-yearly/annual), due months. **[Reversed]** v0.3 called this parity with Frappe HR "across 14 states, free". Frappe HR v16 has no LWF and no Indian state name anywhere in its source (EV-031), and TallyPrime has no LWF engine and no state PT slab table (EV-032): multi-state LWF and PT are a genuine differentiator, greenfield in both Frappe HR and TallyPrime (K-01). |
| `ot_rate`, `ot_quarterly_ceiling_hours`, `normal_hours` | Central + state overlays | Not less than 2× the ordinary rate; 8 hours a day for a daily wage period, 48 a week otherwise (§09.6 **[Verified]**). `ot_quarterly_ceiling_hours` (hypothesised 144) is **[Hypothesis]**, warn-only, never blocking (K-04). State overlays possible. |
| `code_regime` | **Per state × Code** | The date each state's Code-era rules commenced; before it, that state's pre-existing rules and forms govern state-sphere matters (per-state dual regime — §06.9). Resolution reads it from the work location (§14.6.3; Part E-5). Dates are loaded from the state instrument, never assumed. |
| `threshold` | Central + state | Each obligation line with its **counting unit** (employees / persons / workers / contract labour), **sphere** and `latch_rule` as schema fields (EV-057; §06.1). |
| `tds_slab`, `regime_params`, `surcharge`, `cess`, `standard_deduction`, `rebate_87a` | Central | Both regimes computed per employee; the new regime is the default where the employee states no preference (§06.5). The FY 2025-26 slab and rebate figures in §06.5 are a worked base, **[Hypothesis]** for Tax Year 2026-27 until verified against the rates in force; the standard deduction is `tds.standard_deduction.<regime>` (§06.5). Values are `EffectiveDatedRule` rows, so a Budget is a data load, not a deploy. |
| `gratuity_params` | Central | 15/26 formula; 5-year condition with the 240-day continuous-service count; the death, disablement and fixed-term exceptions (CoSS ss.53–54, §06.6 **[Verified]**). `gratuity.payable_ceiling` — the amount notified under CoSS s.53(3), none located, the legacy ₹20 lakh **[Hypothesis]**; `gratuity.four_years_240_days_rule` **[Hypothesis]** (§07 FR-CHR-016). The tax-exemption ceiling is a separate row (`tax.gratuity_exemption_ceiling`, §06.6). |
| `meal_perq_limit`, `gift_voucher_limit` | Central | ₹200/meal, ₹15,000 per tax year from 1 Apr 2026 (was ₹50 / ₹5,000) — **[Hypothesis]** (EV-019: two dated professional sources, rule text not read; §11), shipped as effective-dated parameters, never as a customer-facing citation, until §20 reports. The meal row carries its qualifying conditions as engine constraints — premises meals during working hours, or non-transferable vouchers usable only at eating outlets — without which the perquisite is taxable (K-19; §11 BEN-62). The 2026-Rules citation is unconfirmed and routed to §20. |
| `filing_due_date` | Central + state | Per `filing_type` + jurisdiction; drives `Filing.due_date`/`on_time` (§14.4.5). |
| `statutory_register_spec` | Central + state | The six employer registers plus wage slip (EV-053): per-state form numbers, field lists (Form IX per-day IN/OUT; Form I's 36 fields — EV-055) and the retention wording of the governing rule-set (EV-054). **[Verified — central sphere]** |

#### 14.6.3 Rule resolution algorithm (deterministic)

For any computation of `rule_type R` for employment `M` in `period P`, as-known-at time `T`:

1. Resolve the `WorkLocation` in force for `M` during `P` from its effective-dated assignment → state `J`, sphere `S`, and for each Code the state's regime commencement date `C` (Part E-5). Never from the employee's residence, the employer's HQ or the registered office. Where the work location changes inside `P`, resolve per sub-period.
2. Select rows where `rule_type = R AND jurisdiction ∈ {J, Central} AND applies_to_sphere ∈ {all, S}`; for a state-sphere Code rule type, `regime = legacy` for dates before `C` and `code` from `C`; AND `effective_from ≤ P.end AND (effective_to IS NULL OR effective_to ≥ P.start)` AND `recorded_at ≤ T AND (superseded_at IS NULL OR superseded_at > T)`, over the resolvable set only — published versions, plus staged versions for a tenant in the canary cohort (§14.6.1b RO1).
3. Prefer the **most specific jurisdiction** (state overrides Central where both exist and the state legislates the field, e.g. PT/LWF); Central applies where no state row exists.
4. Record the selected `rule_id`(s), the `work_location_id` and the regime used on the `PayrollResult` lineage (D4).
5. A **retro run** sets `T = now` but `P = the corrected period`, so it picks up corrigenda (latest knowledge) applied to the historical business period — the desired behaviour.

<!-- DIAGRAM: rule-resolution-flow -->

**Worked multi-state example.** A tenant with staff in Maharashtra, Karnataka and a new remote hire working from Assam. For September PT: the MH row (its slab, whose ₹300 February instalment engineers the ₹2,500 annual total — §06.4), the KA row (its slab), and Assam — the hire's work location. PT situs for fully remote employees is unsettled (§06.13), so the tenant's remote-PT policy recorded on the assignment decides; where it follows the work location and the employer has no Assam PT registration, resolution returns the liability with `registration_pending`, surfacing "PT due, no registration" on the readiness report rather than filing wrong. Central rules (PF/ESI/TDS) resolve identically for all three; PT, LWF, S&E and the state-sphere Code rules (register forms, working-hours overlays) diverge — which is why those rule types are state-scoped and carry a regime flag (§06.9).

**AC-DM-21** — *Given* a computation of `pt_slab` for an employment whose work location is in a PT-levying state, and of `pf_rate` for the same employment, *When* rule resolution runs, *Then* `pt_slab` resolves to the row for the work location's state (most-specific-jurisdiction wins), `pf_rate` resolves to the Central row, both `rule_id`s and the `work_location_id` are recorded on the result lineage, and a change to the employee's residence address changes neither.

**AC-DM-36** — *Given* a state whose Code-era rules commence on date `C` inside a pay period, *When* a state-sphere rule type is resolved for a work location in that state, *Then* dates before `C` resolve to the legacy row and dates from `C` to the Code row, and the lineage records the regime used for each figure.

#### 14.6.4 Worked bitemporal timeline — the corrigendum case

This is the scenario the whole bitemporal design exists for. Suppose the add-back percentage for wage months from 21 November 2025 (the Codes' commencement, §06.9) is believed to be 50%, then a corrigendum on 15-Sep-2026 amends it retrospectively (illustrative — the *mechanism*, not a real notification; the 47% below is invented for the example):

| Event (knowledge time) | `EffectiveDatedRule` rows for `addback_percent` | What a March pay run computes |
| --- | --- | --- |
| Apr-2026: March run executed | Row A: 50%, `effective_from`=21-Nov-2025, `effective_to`=NULL, `recorded_at`=Apr-2026 | 50% — filed under Row A; `PayrollResult` lineage cites Row A |
| Sep-2026: corrigendum recorded | Row A: `superseded_at`=15-Sep-2026; **Row B**: 47% (illustrative), `effective_from`=21-Nov-2025, `recorded_at`=15-Sep-2026, `corrigendum_of`=Row A | — (existing March filing untouched) |
| Sep-2026: retro run for March, `T=now` | Resolution picks **Row B** (latest knowledge, historical business period) | 47% — an arrears/correction `PayrollResult` (`applies_to_period`=March, `run_in_period`=Sep) and a **correction filing attempt** linked by `corrects_filing_id` to the original March filing, routed within the EV-037 guards. A paid March ECR cannot take a Revised return (payment initiated), so an upward EPF delta goes to the arrear flow, which is fenced (EV-043) |

<!-- DIAGRAM: bitemporal-timeline -->

The original March artefact is preserved exactly as filed (what we believed then); the correction is a new, linked artefact (what we know now) — a diff, never a mutation (Part E-1). A watcher keyed only to *new notifications* would miss the corrigendum — the model requires `corrigendum_of` and an **amendment**-watcher, per §06 **[Verified]**.

**AC-DM-22** — *Given* Row A (50%) recorded in April and Row B (47%, `corrigendum_of`=A) recorded in September, *When* the original March filing is read as-known-in-April and a September retro run is executed, *Then* the April read returns 50% and cites Row A, the September retro returns 47% and cites Row B, and both are simultaneously reproducible from the store.

#### 14.6.5 Text ER cardinality summary (for readers reconstructing the schema)

```
Tenant 1─1 Group 1─N Employer(LegalEntity) 1─N Establishment N─1 WorkLocation(premises) N─1 Jurisdiction 1─N EffectiveDatedRule
Employer 1─N Registration (TAN, PTEC)  ;  Establishment 1─N Registration (EPF, ESIC, PTRC, LWF, S&E, LIN)
Establishment N─M Registration via RegistrationCoverage (effective-dated; one per scheme per date)
Person(Employee) 1─N Employment 1─N EstablishmentMapping N─1 Establishment   (effective-dated statutory mapping; holds PF Member ID)
Employment 1─N WorkLocationAssignment N─1 WorkLocation   (effective-dated; the jurisdiction source, Part E-5)
Person 1─N StatutoryIdentifier (PAN, UAN, ESI IP, PRAN)  ;  Person × Employer 1─1 ServiceRecord (derived)
Employment 1─N EligibilityState        (effective-dated)
Employment 1─N CompensationAssignment  (effective-dated) N─1 CompensationStructure 1─N PayComponent
Establishment 1─N PayRun 1─N PayrollResult 1─1 Payslip(Document)
PayrollResult N─M EffectiveDatedRule   (lineage / recorded)
PayRun 1─N Filing N─1 Registration  ;  Filing 1─0..N Challan/Payment
Filing N─M PayrollResult (via input_snapshot)  ;  Filing 1─N Document  ;  Filing ─self corrects (attempts, diffs)
Employment 1─N Punch  ;  Employment 1─N FormIXRow  ;  Employment 1─N LeaveTransaction ─derives─ LeaveBalance
Person 1─0..1 AadhaarTokenVault (opaque token)  ;  Employment 1─N BiometricTemplate  ;  Person 1─N ConsentRecord (versioned)
Employment 1─N FbpDeclaration / Dependant / NpsSubscription / InsuranceEndorsement
MigrationBatch 1─N OpeningBalance / PreviousEmployerIncome ─→ Employment
AuditEvent N─1 (polymorphic)  ;  RetentionHold N─M (polymorphic)  ;  DataPrincipalRequest N─1 Person
```

---

### 14.7 Retention & deletion (reconciling erasure vs statutory retention)

This is the entity model's hardest *policy* problem: erasure duties — Aadhaar reg 6(5)'s purpose-bound ceiling today (EV-068), and DPDP s.8(7) from on or about 13 May 2027 (EV-058) — meet statutory retention of the very same records. DPDP s.8(7) is by its text subject to retention "necessary for compliance with any law" (r5/04 finding 40); the Aadhaar ceiling carries no such words in this PRD's evidence, and its collision with a register that names an Aadhaar field is a counsel question (§14.10 item 3). DPDP s.8(7) will reach employment processing too: s.7(i) disapplies consent and notice, not the s.8 duties (EV-058). Deletion is therefore a policy engine (D8), evaluated per-field, per-record, at request time.

#### 14.7.1 Statutory retention floors (deletion cannot go below these)

Only the central-sphere register periods (EV-054) are stated as figures. Every other period is a **named configurable parameter** whose value is set only on counsel sign-off, with the statutory basis under counsel review (Part D-11) — routed to §23's counsel register and §20. Research round five located candidate provisions for several of them (r5/04 findings 32–37, 45–46); counsel reviews those rather than this PRD asserting them. State-sphere periods are unknown and are per-state configuration (EV-054).

| `retention_class` | Floor | Clock | Basis | Confidence |
| --- | --- | --- | --- | --- |
| `REG_WAGES` — Forms I, IV, IX and the Form V wage slip | Five years | After the date of last entry in the register | Wages (Central) Rules 2026 r.51(4) (EV-054) | **[Verified — central sphere]** |
| `REG_OSH` — Forms XIII, XIV, XV, XIX, XX | Five **calendar** years; OSH r.76(2) further bars destroying the r.76 register (leave with wages, §06.9) even after five years unless it has been transferred to a new register | From the date of last entry | OSH (Central) Rules 2026 r.72(1)(vii), r.76(2) (EV-054) | **[Verified — central sphere]** |
| `REG_SS` — Form XXII and "all the registers and other records" under the SS Rules, which reach EPF and ESI employer records (r5/04 finding 22) | Five **calendar** years | From the date of last entry | SS (Central) Rules 2026 r.53(1)(e) (EV-054) | **[Verified — central sphere]**; whether the SS Code inquiry window extends the practical need is a counsel question (`retention.epf_esi_extension`) |
| `REG_IR` — records under the IR Rules | Electronic maintenance compulsory; **no period set** | — | IR (Central) Rules 2026 r.47(1)–(2) (EV-054) | **[Verified]** gap → parameter `retention.ir_records`, counsel |
| State-sphere registers and forms | Per state | Per state | State rules under the Codes | Unknown → parameter per state, counsel (EV-054) |
| `TAX_TDS` — Form 138 data, challans, Form 124 (ex-12BB) proofs, TRACES-issued Form 130 | `retention.tax_tds` | Counsel | Income-tax Act 2025 / Income-tax Rules 2026 candidates (r5/04) | Counsel (Part D-11) |
| `BOOKS_COMPANY` — payroll records forming part of a company's books of account | `retention.books` | Counsel | Companies Act 2013 books-of-account candidate (r5/04); whether a payroll artefact is part of the books is fact-specific | Counsel (Part D-11) |
| `GRATUITY_SERVICE` — `ServiceRecord` (§14.3.1) and gratuity records | `retention.gratuity_tail` | From exit | A gratuity claim can arise years after exit; the limitation reading is not in evidence | Counsel (Part D-11) |
| `ICT_LOGS` — `AuditEvent` and ICT logs | At least 180 days, within Indian jurisdiction — a maintenance duty, not a ceiling | From creation | CERT-In Directions 28.04.2022 (EV-062) | **[Verified]** |
| `DPDP_PROCESSING_LOGS` | `retention.dpdp_r8_3`, effective on or about 13 May 2027; neither immediate purge nor a one-year suppression is hard-coded | Counsel | DPDP Rules 2025 r.8(3), not in force (EV-058) | Counsel (Part D-9) |
| `AADHAAR_VAULT` — a **ceiling**, not a floor | Delete once the consented purpose is spent | Purpose spent | Aadhaar Sharing Regulations reg 6(5) (EV-068) | **[Verified]** |
| `BIOMETRIC_TEMPLATE` — a ceiling | Erase on exit, consent withdrawal or a switch to the non-biometric path | Trigger event | Product rule (Part E-6; §09 FR-DEV-007) | — |
| `CONSENT_EVIDENCE` | `retention.consent_evidence` | From withdrawal or expiry | Counsel | Counsel |

The labour-code clocks run from the date of last entry *in the register*, not per employee (EV-054 wording), so the model scopes each register instance by period — Form IX is a monthly sheet (EV-055) — to give every instance a determinable last entry (r5/04 finding 44, an inference). Registers also carry custody constraints (EV-054): OSH r.72(4) and SS r.53(3) impose a three-kilometre physical-location constraint, differently worded; the SS maternity Schedule para 11(a)(2) requires the women's register "in ink", contradicting r.53(1)(b)'s electronic permission. The model keeps the register electronically and flags the contradiction to counsel (§23); it does not resolve it. **[Reversed]** v0.3 stated income-tax, EPF, ESI, gratuity and Companies Act periods as figures, and a flat five years for "four consolidated registers".

**Rule of thumb the model encodes:** each `retention_class` stores `min_retention` (the statutory floor above) and `max_retention` (the ceiling — a purpose-bound limit such as reg 6(5) today, and DPDP s.8(7) from its commencement). Deletion is permitted only in the window after `min_retention` elapses, and *required* once `max_retention` elapses **unless** a `RetentionHold` is active. Where two floors overlap (e.g. a wage figure that is both TDS evidence and register data), the **longer floor wins** — the standing "default to the longer of overlapping floors" rule (§14.10 item 1). A floor parameter with no counsel-set value blocks automatic erasure of that class and raises an unresolved-retention flag; it never defaults to zero.

#### 14.7.2 The deletion decision engine

For a given row/field at time `T`, deletion is evaluated as:

1. **Is there an active `RetentionHold`?** (litigation, investigation, unresolved dispute, tax scrutiny) → **retain**, log the hold as the reason.
2. **Has the statutory `min_retention` for its `retention_class` elapsed?** If not, or if the floor is a counsel-set parameter not yet set → **retain**. The erasure is *deferred*, not refused, and the requester is told the basis and the date the class becomes erasable, or that the date is under confirmation.
3. **Is there a live processing purpose?** (active employment, open pay run, pending filing) → **retain**.
4. Else → **erase or anonymise**, by crypto-shredding the subject key or by tombstone (§14.6.1a). Prefer **anonymisation/aggregation** for analytics-relevant rows (strip direct + quasi identifiers, keep de-identified facts for headcount/cost trends) over erasure, where lawful.
5. Every branch writes an `AuditEvent` with the decision, basis and mechanism; a request is closed by a *reasoned response*, not necessarily a deletion.

Which erasure duties bind depends on the date. Today: the Aadhaar purpose ceiling (EV-068), the product's own template erase-on-exit (Part E-6), and the employer's policy. From on or about 13 May 2027: DPDP s.8(7) as well (EV-058). Whether an employee holds a DPDP erasure *right* against processing under s.7(i) is under counsel review in both directions (EV-066; Part D-1), so the engine runs identically for a request and for a scheduled sweep and never asserts a statutory right in its response.

<!-- DIAGRAM: deletion-decision-engine -->

**Worked example — post-exit employee erasure request.** An employee resigns March 2026, FnF settled, and asks in June 2026 for her data to be erased. The engine:

- Erases data held only on a consent she has withdrawn or whose purpose is spent (no statutory floor).
- **Retains** register data under EV-054's floors — each Form IX sheet for her months stays until the longest applicable register floor for that sheet has run (the rule-sets' wordings differ; the longer reading wins) — and payroll, PF/ESI, TDS and gratuity records under their retention classes, whose periods are counsel-set parameters (Part D-11). The response gives each class's basis and, where the parameter is set, its erasable date; otherwise it says the date is under confirmation.
- Finds her Aadhaar number, if she provided one, already deleted from the vault when its consented purpose was spent (reg 6(5), EV-068); business rows hold only a token that resolves to a tombstone, and EPF records are keyed on UAN, never Aadhaar. **[Reversed]** v0.3 kept a masked Aadhaar as a "seeding key" on retained EPF records.
- Finds her biometric template, if she was enrolled, already erased on exit through the two-phase device erasure (§09 FR-DEV-007); her punches and Form IX rows are unaffected (§14.4.15).
- Sets a scheduled re-evaluation at each floor's expiry so retention does not silently become indefinite.

**Worked example — litigation hold beats an expired floor.** A wage register row hits its 5-yr floor while an ESI dispute over that period is open. A `RetentionHold` scoped to (establishment, period) is active, so branch 1 retains the row and logs the hold as the reason; the row becomes erasable only after the hold is `released_at` *and* the floor has elapsed.

**AC-DM-23** — *Given* a post-exit erasure request against an employee with retained TDS records, *When* the deletion engine evaluates each field, *Then* data held only on a withdrawn or spent consent is erased, statutory records are retained with a per-class erasable date (or "under confirmation" where the floor parameter is unset), and the requester receives a single reasoned response enumerating the basis for each retained class within the tenant-configured request SLA — without any deletion of records below their floor.

**AC-DM-24** — *Given* a row whose `min_retention` has elapsed but that is under an active `RetentionHold`, *When* the deletion engine runs, *Then* the row is retained, the hold is logged as the decision basis, and erasure is re-scheduled for hold-release; a deletion of a held row is impossible.

#### 14.7.3 Data-principal request handling (the entity `DataPrincipalRequest`)

Supports **access** (what we hold + processing summary), **correction** (write path is the same maker-checker audited flow as any statutory-field change), **erasure** (engine above), **grievance** (routed to the named data-request handler; the CERT-In point of contact is a separate role, §17.6), and **nomination**. Each request carries its `regime`, an SLA timer and a reasoned-response record. The five types mirror DPDP Chapter III — access (s.11), correction and erasure (s.12), grievance (s.13), nomination (s.14) — which contains no right against automated decisions, no right to explanation and no right to human review (EV-066), and which is not in force until on or about 13 May 2027 (EV-058). Whether ss.11–12 reach employment processing under s.7(i) is a counsel question, and both directions are dangerous (EV-066; Part D-1; §23), so the machinery is built now and described as a product capability with its statutory basis under counsel review. Because statutory floors cover most employment records, most requests resolve to *access + correction + reasoned retention*, not deletion — the model is built to answer, not merely to delete. **[Reversed]** v0.3 grounded this in s.7(i) as current law (K-03).

**AC-DM-25** — *Given* a correction DPR against a statutory field (e.g. a wrong PAN), *When* it is actioned, *Then* it flows through the identical maker-checker audited write path as any other statutory-field change (not a privileged side-door), emits an `AuditEvent`, and triggers re-validation of any pending Filing that referenced the old value.

---

### 14.8 Data residency & storage placement

Residency is a **segment-specific procurement gate**, not a general differentiator (§13.10, §17.7), but the data model must make placement a first-class property so the gate can be met per tenant without re-architecture.

- Every `Document` and every C1/C2 store carries `storage_region`; the default is an **India region**. That is a product default, not a claim that Indian law mandates localisation — and not a claim that it has none. The live constraints the tag must satisfy are: CERT-In's 180 days of ICT logs within Indian jurisdiction (EV-062); SPDI r.7's restriction on cross-border transfer of sensitive personal data (EV-060); for SEBI-regulated customers, data resident and processed in India, the MeitY-empanelled-infrastructure rule reaching SaaS providers, and audit and search-and-seizure rights over the provider and its sub-contractors (EV-085); for RBI-regulated customers, the IT-outsourcing directions' localisation, audit (including by RBI), sub-contractor consent and inspection terms, **materiality-gated** entity by entity (EV-087 — whether a given arrangement is material is counsel's question, Part D-14); for IRDAI-regulated customers, no localisation in the 2023 cyber guidelines, with localisation only for policy records (EV-086). DPDP's transfer regime is a negative list, empty and not in force (K-08). Hosting Aadhaar outside India is a counsel question (Part D-15), so the vault is India-only. A further candidate constraint sits outside the ledger: research round five reads Income-tax Rules 2026 r.46(8) as requiring electronically maintained books of account to remain accessible in India, with daily backups on servers physically located in India (r5/04 finding 34). Whether a customer's payroll records form part of its books is fact-specific (r5/04 finding 45), so this is a counsel question (§23); the tag must be able to express "primary and backup both in India" per tenant so the answer is a configuration, not a migration. The per-tenant guarantees built on this tag are specified in §17.1 and the legal analysis sits in §23. **[Reversed]** v0.3 applied RBI's directions "with no turnover threshold" and said IRDAI mandates records in Indian data centres (K-22, K-08).
- **Data-at-rest residency ≠ in-country inference.** The model tags fields that may be sent to an AI provider (`ai_egress_class`) so the router (§12.14, §13) can enforce a per-tenant provider matrix. Aadhaar, PAN, bank account and IFSC, and biometric templates are default-deny at the mandatory redaction chokepoint on every outbound model call and never leave in clear (Part E-7; §12.8); other C1 fields leave only where the tenant's matrix allows a provider with India data-at-rest and in-country inference. LLM prompt and completion logs are kept in India, and AI features default off for RBI-, SEBI- and IRDAI-regulated tenants (Part E-7). This is one abstraction serving both cost (router) and residency (compliance) — the same "at least three interchangeable backends, residency selectable per tenant" abstraction §13 and §17 require (§17.7 NFR-RES-702).
- **No statutory or monetary figure is ever model-generated** (§08 **[Verified]**), so the highest-sensitivity numeric fields never need to leave the deterministic engine; AI egress is largely C3/de-identified text, which narrows the residency surface.

**AC-DM-26** — *Given* a tenant with a residency requirement, *When* any field would be sent to an AI provider, *Then* a default-deny field (Aadhaar, PAN, bank account/IFSC, biometric template) is tokenised at the chokepoint and never sent in clear; any other C1 field is checked against the tenant's provider matrix via `ai_egress_class` and blocked unless the provider offers both India data-at-rest and in-country inference; every block and every allow is auditable.

---

### 14.9 Keys, referential integrity & external-format validation

External keys are validated to their **source format at write time** (§07 FR-CHR-002..006) so rejections surface at data entry, not at expensive filing time. Format validation is cheap insurance against a filing-day rejection loop. Every mask below is a versioned validation rule, parameter `id_format.<key>`, so a mask change is a rule-version change and never a code edit. Most masks were carried from v0.3 without any research round capturing the issuer's own specification; they are desk-verified against that specification before v1 GA (§07.1.1, §20). **[Reversed]** v0.3 marked every row below Verified.

| Key | Format (validated at write) | India-specific validation | Confidence |
| --- | --- | --- | --- |
| PAN | `[A-Z]{5}[0-9]{4}[A-Z]` (10 char) | 4th char = holder type (`P` individual, `C` company, `F` firm, `H` HUF, `T` trust…); 5th char = first letter of surname/entity name; mismatch drives correction before Form 138/130 | **[Hypothesis — carried, not re-captured]** (`id_format.pan`, §07.1.1) |
| TAN | `[A-Z]{4}[0-9]{5}[A-Z]` (10 char) | First 4 alpha (4th = deductor initial), 5 numeric, 1 alpha; the TDS filing key | **[Hypothesis — carried, not re-captured]** (`id_format.tan`) |
| Aadhaar (optional) | 12 numeric, **Verhoeff checksum** | Validated at the vault boundary; stored only in the `AadhaarTokenVault`, never in a business table; business rows hold the opaque token (§14.4.15) | **[Hypothesis — carried, not re-captured]** the checksum rule (`id_format.aadhaar`, §07.1.1) |
| UAN | 12 numeric | No published checksum; validity via seeding status, not digit rule | **[Verified]** field position in the ECR (EV-035); length carried (`id_format.uan`) |
| ESI IP | 10 numeric | Registration status gates ESI filing | **[Hypothesis]** — practitioner descriptions of ESIC's upload template only (`id_format.esi_ip`, §07.1.1) |
| IFSC | `[A-Z]{4}0[A-Z0-9]{6}` (11 char) | **5th char is `0`** (reserved); validated + optionally checked against the RBI IFSC master; feeds penny-drop | **[Hypothesis — carried, not re-captured]** (`id_format.ifsc`, §07.1.1) |
| Bank account | numeric, bank-variable length | No universal checksum; verified by **penny-drop / name-match** (disbursal-blocking) | Product rule (§07 FR-CHR-006) |
| EPF establishment code | region/office/establishment code + optional extension | Region/office codes from the EPFO master | **[Hypothesis — carried, not re-captured]** (`id_format.epf_code`, §07.2) |
| ESIC employer code | 17 digits as carried | Sub-codes are separate establishment rows | **[Hypothesis — carried, not re-captured]** (`id_format.esic_code`, §07.2) |
| GSTIN | 15 char (`\d{2}[A-Z0-9]{13}`) | First 2 = state code (must match establishment state); 15th = checksum | **[Hypothesis — carried, not re-captured]** (`id_format.gstin`) |

| Concern | Model rule |
| --- | --- |
| **Internal vs external keys** | Internal surrogate `_id`s are the join keys; external government keys are validated to source format **at write time** so rejections surface at entry, not at expensive filing time. |
| **Immutable lineage** | `employee_id` never changes across rehire/transfer; `Employment`, the assignments and `CompensationAssignment` carry the churn, and person-level identifiers stay on `Person`. PF Member ID is establishment-scoped and *does* change on transfer — modelled on the `EstablishmentMapping`, not Person. |
| **Registration keys on filings** | A filing instance references the `registration_id` and the knowledge-time version of the registration row it was raised against, so a later correction to a registration number never rewrites which code an artefact was filed under (§14.3.1 T6). |
| **Referential integrity across effective-dated rows** | A `PayrollResult` references a *specific version* (`rule_id` + knowledge-time) — not "the current PT slab" — so re-opening a later period cannot mutate a filed artefact (D2). |
| **Snapshot isolation for filings** | `Filing.input_snapshot_ref` freezes the exact rows used; corrections create new attempts linked by `corrects_filing_id`, never in-place edits. |
| **Idempotency** | Device punches (`device_sn`, `device_user_id`, `device_timestamp`, `direction` + `payload_hash` — §09.3), bank files (batch id) and portal submissions (return file ID; TRRN; challan CRN; acknowledgement reference) carry natural idempotency keys so retries do not double-count. |
| **Soft-delete only** | Business rows are never hard-deleted by the app; deletion is the §14.7 engine's decision, executed as anonymisation, crypto-shredding or tombstone (§14.6.1a) with an audit record. |

**AC-DM-27** — *Given* a malformed PAN, TAN, IFSC (5th char ≠ `0`), or a failed Aadhaar Verhoeff checksum, *When* it is entered, *Then* it is rejected at write time with a specific reason — the Aadhaar at the vault boundary, before anything is stored — and before any Filing that would quote the key is generated.

**AC-DM-28** — *Given* a device that re-POSTs a punch it already sent (same `device_sn`, `device_user_id`, `device_timestamp`, `direction` and `payload_hash`), *When* the ADMS receiver ingests it, *Then* the punch is deduplicated and attendance is not double-counted.

---

### 14.10 Open questions, hypotheses & validation gates

Carried forward so nothing here is mistaken for settled fact. Each hypothesis has a kill/confirm method.

| # | Open item | Confidence | Validation / kill criterion |
| --- | --- | --- | --- |
| 1 | Every retention period other than EV-054's central-sphere register figures — income-tax/TDS, company books, EPF/ESI beyond SS r.53(1)(e), gratuity tail, IR records, consent evidence, and every state-sphere period | Counsel (Part D-11) | Counsel sets each `retention.*` parameter (§14.7.1), starting from the r5/04 candidate provisions; tracked in §23's counsel register; build-blocking desk work in §20. Default to the **longer** of overlapping floors; an unset floor blocks automatic erasure. |
| 2 | Whether biometric attendance capture is authorised by s.7(i) once in force, and who owes the SPDI written-consent duty today | Counsel (Part D-2, D-4) | Build consent capture either way (§14.4.15); the non-biometric path is always available (§09). |
| 3 | Whether a rendered Form I register (field 24, Aadhaar No.) may carry the full number, given the reg 6(5) purpose ceiling on the vault; and whether the Form I photo and thumb-impression fields (EV-055) are SPDI biometric information needing written consent | Counsel (§23) | Until answered, registers render Aadhaar from the vault only at generation (§07 FR-CHR-045-onb), and register images never come from a biometric enrolment image or template. |
| 4 | Full all-state PT/LWF slab dataset for `EffectiveDatedRule` | **[Hypothesis]** | Per-state status in §06.4 and §06.13. Gazette-source each state before claiming coverage; v1 = beachhead states, v2 = all states. |
| 5 | Form 138 Q4 regular and correction formats → Form 130 Part B | **[Verified]** not released, re-checked September 2026 (EV-046) | Watch the release; the Q4 generator is fenced and `Filing.format_version` absorbs the format when it lands. |
| 6 | ESI regime after the one-year saving under CoSS s.164(2)(b) lapses on or about 21 November 2026 | Open — we are not aware of a successor instrument as of September 2026 (§06.9) | Primary-source watch on ESIC/MoLE (§22 FR-RULE-006); §06 time-critical item. ESI rule rows after the date stay fenced until a successor is published through §22. |
| 7 | Whether the add-back percentage stays 50% | **[Verified]** it is a notified variable | `addback_percent` is a rule row, not a constant — no schema change needed if it moves. |
| 8 | Per-state filing due dates for `filing_due_date` rows (PT, LWF) | **[Hypothesis]** | Gazette-source per state alongside item 4; `Filing.due_date`/`on_time` are rule-backed so a date change is a data load. |
| 9 | Whether DPDP ss.11–12 rights reach employment processing under s.7(i); the scope of the DPDP r.8(3) retention floor | Counsel (Part D-1, D-9) | `DataPrincipalRequest` and `retention.dpdp_r8_3` are built as machinery; neither immediate purge nor one-year suppression is hard-coded. |
| 10 | Whether the SPDI Rules survive the omission of IT Act s.43A on or about 13 May 2027 | Counsel (Part D-12) | `ConsentRecord.regime` keeps SPDI-regime records intact across the switch whatever the answer (§14.4.15). |
| 11 | Whether Income-tax Rules 2026 r.46(8)'s in-India accessibility and daily in-India backup condition reaches payroll records a customer keeps in the product (r5/04 findings 34, 45) | Counsel (§23) | `storage_region` expresses primary and backup placement per tenant (§14.8); the answer sets a tenant default, never a schema change. |
| 12 | Each state's part-period treatment when a registration starts, ends or changes inside a filing period, and on a mid-period transfer | **[Hypothesis]** | Read per state alongside item 4; until read, straddled periods are flagged for operator review (§14.3.1 T7), never split by assumption. |
| 13 | Every `id_format.*` mask carried from v0.3 (PAN, TAN, Aadhaar checksum, ESI IP, IFSC, EPF and ESIC codes, GSTIN, PRAN) | **[Hypothesis — carried]** | Desk-verify against each issuer's published specification before v1 GA (§07.1.1, §20); a mask change ships as a rule version. |

The single most important property of this model is that **items 4–8, 12 and 13 are absorbed as data, not code, and items 1–3 and 9–11 as parameters and regimes rather than schema changes**: a corrigendum, a new state slab, a changed add-back percentage, a shifted due date or a new file format is a row in `EffectiveDatedRule` / a `format_version` bump — not a migration and a deploy. That is what makes "statutory maintenance as the operating model" (§06) affordable rather than fatal.

---

### 14.11 Acceptance-criteria index

The `AC-DM-nn` criteria above are the testable contract §20 exercises. Grouped by the invariant they defend:

| Invariant | Acceptance criteria |
| --- | --- |
| D2 · bitemporal / retro, scoped by class | AC-DM-09, AC-DM-10, AC-DM-22, AC-DM-34, AC-DM-35 |
| D3 · rules-as-data; jurisdiction on the work location | AC-DM-07, AC-DM-21, AC-DM-36 |
| D3 · the rule object (§14.6.1b) | AC-DM-42, AC-DM-43, AC-DM-44, AC-DM-45 |
| Statutory hierarchy and temporal constraints (§14.3.1) | AC-DM-37, AC-DM-38, AC-DM-39, AC-DM-40, AC-DM-41 |
| D4 · audit lineage / maker-checker | AC-DM-02, AC-DM-08, AC-DM-20, AC-DM-25, AC-DM-29 |
| D5 · tenant isolation | AC-DM-01, AC-DM-30 |
| D6 / §14.9 · external-key state & format | AC-DM-05, AC-DM-06, AC-DM-19, AC-DM-27, AC-DM-28 |
| D7 / §14.8 · classification & residency | AC-DM-26 |
| Segregated identity stores (Part E-6) | AC-DM-31, AC-DM-32, AC-DM-33 |
| D8 · deletion engine | AC-DM-23, AC-DM-24, AC-DM-35 |
| D9 · money-of-record isolation | AC-DM-17 |
| Filing-as-delivery (D1) | AC-DM-03, AC-DM-11, AC-DM-12, AC-DM-13, AC-DM-14 |
| Obligation latch / eligibility | AC-DM-04, AC-DM-05 |
| Attendance / leave ledgers | AC-DM-15, AC-DM-16 |
| Migration correctness | AC-DM-18, AC-DM-19 |

Every criterion is falsifiable and maps to at least one entity above; a failing `AC-DM-nn` is, by construction, either a filing-rejection bug or a compliance exposure — which is why they live in the data-model section and not only in the test plan.
