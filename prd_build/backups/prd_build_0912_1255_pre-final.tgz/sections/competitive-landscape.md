## 21. Competitive Landscape & Parity

This section is the PRD's canonical competitive record. It holds the corrected Frappe/Tally parity table, the rate-card evidence behind the priced-vendor comparison and the 50-seat floor, Keka in full, the freemium paywall, the finding that no vendor claims to submit a filing, packaging, the AI claim-posture comparison, the enterprise adjacency, the competitive-response scenarios, and the rule that governs every competitor claim that leaves the building. Other sections draw on it and do not restate it: §04.4 keeps only what sizing and the wedge depend on; §18.11 and §18.12 turn this evidence into battle cards and a list-price comparison; §12 and §13 own AI governance and AI cost; §16.2 and §16.7 own the importers; §22 owns the attended-filing operation; §23 owns the law. Where another section states a competitor fact differently, this section's capture record governs the fact, and the other section's owner governs what is done with it.

Three things are true of every line below. They are what make the section usable in a hostile review.

1. **Nothing was executed.** No competitor product was installed, trialled or run in any research round. Every capability statement is *declared capability* — read from a vendor page, product documentation or a source repository — never *observed behaviour*. Where a row says "absent", it means absent from the artefact that was read, on the date it was read (r3/01, r5/03).
2. **Every fact carries a capture.** Pricing and packaging captures are dated 4–5 September 2026 unless a row says otherwise (r1/08, r5/03). The Frappe HR and ERPNext source trees were read at v16 stable, tag v16.17.1 (r3/01). TallyPrime was read from its own help documentation, FAQ and buy page (r3/01, r5/01). Keka's withdrawn card is an archived capture of Keka's own page dated 1 August 2024 (EV-022). Round-one and round-two captures that no later round re-checked carry the §02.3 discount — treat them as roughly 70–75% reliable — and are tagged with their round wherever they appear.
3. **No row is a sales claim until it clears §21.12.** A fact that is safe to build on is not automatically safe to say to a prospect. The clearance rule in §21.12 is the gate, which is why this section is written as "the artefact read shows" rather than "the competitor cannot".

### 21.1 Scope, vocabulary and the evidence posture

#### Five groups that earlier drafts conflated

Earlier drafts used "the incumbent" for three different things. That confusion produced two errors this revision reverses (K-01, K-23). This section uses five terms and keeps them apart.

| Term | Members | What the term is for | Source |
| --- | --- | --- | --- |
| **The two incumbents** | TallyPrime (with the CA who operates it) and greytHR | Who holds each *job* the beachhead buyer already pays to have done: Tally the accounting and statutory-artefact job, greytHR the HRMS job | K-23; EV-032; EV-091 |
| **The zero-price parity comparators** | Frappe HR v16 and TallyPrime | The bake-off a prospect with a free or sunk-cost alternative actually runs. The corrected parity table (§21.3) is written against these two | EV-031; EV-032 |
| **The six-vendor priced set** | greytHR, Qandle, Pocket HRMS, Zimyo, HROne, Keka | The published-card SaaS field at the beachhead. The seat-floor finding and the common-point price table are scoped to exactly these six | EV-026; EV-027 |
| **The freemium players** | Kredily; Zoho Payroll and Zoho People | Where computation is priced at zero and outputs are charged | EV-029 |
| **Enterprise adjacency** | Ramco and ZingHR, with Darwinbox and PeopleStrong as enterprise suites | Vendors kept out of the competitive set because they sell into enterprise procurement, not into the beachhead | EV-033 |

Tally appears in two rows on purpose: it is an incumbent for the job it does and a parity comparator in the bake-off. greytHR appears in two rows for the mirror reason.

**The sentence "multi-state PT and LWF is greenfield in both incumbents" (K-01) is about the parity comparators, Frappe and Tally.** It is not a statement about greytHR, whose payroll page says "PT with all state-specific rules built-in" (r5/03, captured 5 Sep 2026); nor about Zoho Payroll, whose free tier lists "Statewise PT, LWF" (r2/01); nor about Keka, whose entry tier lists pre-built "PF, ESI, LWF, TDS" statutory reports (r5/03). Against those three the state layer is *claimed parity*. Our differentiation there is maintenance under contract, jurisdiction resolved on the work location, and attended submission — not presence. §21.3 sets out what "greenfield" does and does not license. Sections that write "both incumbents" in this context mean Frappe and Tally, and should say so.

#### The competitive set register

One row per entity the research examined. "Executed" is "No" throughout: no product was run.

| Entity | Class | In the set? | Why | Evidence held | Captured | Executed |
| --- | --- | --- | --- | --- | --- | --- |
| TallyPrime | Incumbent (job 1); parity comparator | In | Owns the statutory-artefact job; payroll ships inside the licence (EV-032) | Help docs and FAQ; buy page; five TDL catalogues | r3, r5 (Sep 2026) | No |
| greytHR | Incumbent (job 2); priced set | In | Claims "30,000+ companies" (EV-091); full published card (EV-027) | Pricing, payroll, partner and press pages | r1 (4 Sep 2026), r3, r5 (5 Sep 2026) | No |
| Frappe HR v16 | Parity comparator | In | Free open-source alternative with genuinely strong gross-to-net (EV-031) | Source trees (hrms v16.17.1, erpnext v16, india-compliance); docs; product and pricing pages | r2, r3 (Sep 2026) | No |
| Kredily | Freemium | In | ₹0 computation at unlimited headcount; outputs charged (EV-029) | Pricing page | r1 (4 Sep 2026), r2, r3 | No |
| Zoho Payroll, Zoho People | Freemium | In | ₹0 to 10 employees (Payroll) and 5 users (People); the credible commercial floor (r2/01) | Pricing pages, pricing JSON, dated changelog | r1 (4 Sep 2026), r2 | No |
| Keka | Priced set | In | Best-capitalised pure-play in the band (§04.4); live card suppressed (EV-021) | Raw HTML with comment scan, archive, terms of service, AI page | r1 (4 Sep 2026), r5 (5 Sep 2026) | No |
| Qandle (MYND) | Priced set; nearest occupant of the filing corner | In | Four-tier card recovered from its own pricing config file (r5/03); inside a payroll-outsourcing group since April 2025 (EV-034) | Pricing config file; rendered page | r5 | No |
| Pocket HRMS | Priced set | In | Published card with a hard 50-employee floor (r5/03) | Pricing page | r1, r5 | No |
| Zimyo | Priced set | In | Per-user card with "Minimum billing for 50 Users" (r5/03) | Rendered page (returns HTTP 403 to a non-browser fetch) | r1, r5 | No |
| HROne | Priced set | In | Published block card; an unpriced programme for companies under 50 (r5/03) | Pricing page | r1, r5 | No |
| factoHR | Beachhead-adjacent | Watch | Published card including a free tier to 20 employees (r1/08); filed revenue in §04.4 | Pricing page | r1 (4 Sep 2026) — not re-checked since | No |
| RazorpayX Payroll | Beachhead-adjacent, fintech parent | Watch | Flat plan to 20 employees; mid plan capped at 100 (r1/08) | Pricing page | r1 (4 Sep 2026) | No |
| 247HRM | Beachhead-adjacent | Watch | Base block for 50; usage-billed AI credits from a prepaid wallet (r1/08) | Pricing page | r1 (4 Sep 2026) | No |
| sumHR | Fintech-owned HRMS | Watch | Per-user tiers billed annually (r1/01; r1/08); owned by the neobank Jupiter (r2/02) | Pricing page; trade press | r1, r2 | No |
| MYND Integrated Solutions | Services layer, owns Qandle | Watch | The only bundle pairing self-serve HRMS with an outsourced filing operation — unpriced, demo-sold (EV-030, EV-034) | Acquirer announcement; trade press | r5 | No |
| Ramco | Enterprise adjacency | Out | Enterprise multi-country payroll; no published price (EV-033, EV-092) | Audited annual report FY2025-26 | r5 | No |
| ZingHR | Enterprise adjacency | Out | Titled "Enterprise HCM"; no price; its pricing URL returns 404 (r5/03) | Homepage | r5 | No |
| Darwinbox, PeopleStrong | Enterprise suites | Out at launch | No public price (r1/08); enterprise is closed to a new entrant for roughly three years (§05.2) | Pricing-URL status checks; filings | r1 | No |
| HONO | Enterprise, agentic positioning | Out at launch | Positions as a "headless HRMS"; enterprise logo list (r2/07) | Homepage; aggregator record | r2 | No |
| CAs and payroll bureaus | Services layer | Not a competitor — channel and price anchor | The budget line the product redirects (§18.7) | Indicative fee band, unvalidated (§20 V-01) | r2 | n/a |
| Aparajitha / Simpliance | Services layer (compliance operations) | Partner or acquisition candidate, not a competitor | 1,500+ staff across 25 states; software includes a payroll/remittance product; no AI claim anywhere on its site (r2/07) | Company site; acquisition release | r2 | No |
| TeamLease, Quess | Staffing majors | Not product competitors | TeamLease impaired its HR-technology subsidiary by ₹6.4 Cr in FY26 (r2/07) | Audited results | r2 | n/a |
| Odoo | ERP with an HR module | Out | India is not an official Odoo payroll localisation; four third-party India payroll modules (r2/01) | Documentation; app store | r2 | No |
| Alight | — | Removed | Sold its payroll business (§20.4) | — | — | — |
| Ascent HR | — | Not defunct | An earlier exit inference rested on a mistyped domain (§20.4) | — | — | — |

The register is not claimed to be complete. Round five found that greytHR — the largest vendor by claimed customer count — had been missing from the mid-market pricing dimension's prior round, and reached it only because a competitor's FAQ named it (r5/03); round one's market dimension had separately captured greytHR's card on 4 September 2026 (r1/08). A vendor can be present in one research dimension and absent from another, so the completeness question is asked per dimension. A vendor set is re-swept before any comparative claim is made (§21.13), and "is anyone missing?" is a standing question on that sweep.

#### Evidence classes and what each can support

| Evidence class | Used for | Strength | Known failure mode | Example in this section |
| --- | --- | --- | --- | --- |
| Source repository, stable branch | Frappe HR / ERPNext capability | Strongest evidence of *absence* inside the trees read; silent about artefacts outside them | A product page may describe an artefact outside the trees read | EV-031; the Frappe product-page item in §21.3 |
| Vendor product documentation | TallyPrime capability | Strong for documented features; weak for undocumented ones and for currency against the latest Finance Act | Search-engine summaries misquote the page — a summary claims Tally lets you "choose the state and slab" for PT; Tally's own page says the opposite (r5/01) | EV-032 |
| Vendor page, raw fetch with a comment-node scan | Suppressed prices and suppressed features | The only method that sees commented-out content | A rendered read cannot see it | EV-021; EV-028 |
| Vendor page, rendered read | Client-rendered prices | Needed where the page injects prices with JavaScript | A raw fetch shows empty spans | Qandle, Zimyo (r5/03) |
| Vendor pricing config file | JavaScript-injected prices | The strongest price source where it exists | Unrendered config values are not published prices and must not be quoted (r5/03) | Qandle (r5/03) |
| Archive snapshot of the vendor's own page | Withdrawn cards and deleted terms | Frozen and historical | Not a current price | EV-022; the deleted Keka FAQ (EV-025) |
| Vendor terms of service | Renewal, refund, lock-in | Contractual text | Clause numbering drifts between versions | EV-025 |
| Filed financials | Scale | Audited or ROC-filed | Filing lag; segment aggregation | EV-033; EV-092 |
| Vendor marketing claims — counts, AI, launch dates | Positioning only | Weakest | Internally inconsistent on the same day | EV-091; Keka's 12,500+ against 10,000+ (r5/03) |
| Another vendor's comparison page | Never | — | Disagrees with the named vendor's own page | Pocket HRMS's pricing FAQ gives greytHR's minimum paid plan as ₹3,495 a month; greytHR's own page shows ₹2,495 (r1/08; r5/03) |

The capture method for every row follows §02.5's dual-capture rule. This section adds one competitive-specific requirement: a row's *executed* status is recorded as a field, not implied. The two values are **declared capability** (pages, documentation or source read) and **observed in product** (executed, with the build or tenant date). No row in this revision is observed.

#### What this revision reverses or kills in the competitive record

| v0.3 statement | Status | Replacement | Evidence |
| --- | --- | --- | --- |
| "Frappe HR is free and open-source with PT across 15+ states and LWF across 14" — and the conclusion that multi-state PT/LWF is not a differentiator | **[Reversed]** (K-01) | The Frappe source trees read contain no Indian state name, no PT slab table and no LWF logic; TallyPrime has no state PT slab table and no LWF engine. Multi-state PT and LWF is greenfield in both parity comparators | EV-031; EV-032; EV-K12 |
| "TallyPrime is the real incumbent, statutorily complete at ₹0 incremental" | **[Reversed]** (K-23) | Two incumbents, two jobs. Tally ships the central artefacts but not the state layer, leave or encashment; its payroll *adoption* is unknown | EV-032; EV-K34 |
| "Keka's INR tiers are TLS-blocked and unverified; treat every Keka pricing claim as provisional" | **[Reversed]** (K-10) | Obtained: commented-out live rates, the archived card, the live small-business floor. The block was one fetch tool's failure, not the site's | EV-021–EV-025; EV-K21 |
| "Keka is the competitor that matters for the beachhead" | **[Reversed]** | greytHR holds the HRMS job (K-23). Keka is the top of the price band and the published-price opening | EV-024; EV-027; EV-091 |
| "greytHR = 34,000 customers / 4.4% share ceiling", undated | **[Reversed]** (K-16) | greytHR currently claims "30,000+ companies"; its own pages have shown several counts on one day. Every share figure carries a capture date | EV-091; EV-016; EV-K27 |
| "Keka renewal rates run below list" | **[Killed]** (K-17) | Keka's terms of service, clause 15: renewal fees "subject to an increase" | EV-025; EV-K28 |
| "The effective price ceiling at 50 employees is roughly ₹45–50 PEPM" | **[Reversed]** (K-09) | Two anchors: a value floor near ₹50 PEPM and a mid-market clearing band of ₹80–200 PEPM | EV-027; EV-006; EV-K20 |
| The "Payroll Plus ₹5,999" Tally add-on as evidence of an ecosystem fix | **[Killed]** (K-20) | Sold on a lookalike domain; five TDL catalogues show no payroll, PT or LWF add-on | EV-032; EV-K31 |
| "Every quote-only vendor spot-checked — greytHR, Keka, Darwinbox, PeopleStrong" | **[Reversed]** | greytHR, Qandle, Pocket HRMS, Zimyo and HROne publish full cards; Keka suppresses; the enterprise suites publish nothing | EV-027; r1/08 |
| Any implication that competitors bill actual headcount from employee one | **[Killed]** (K-25) | Six of six priced vendors bill a 50-employee minimum block on their published cards (Keka's archived block: 100) | EV-026; EV-K36 |
| "Tally is statutorily complete but has no filing service, no employee app" | **[Reversed]** in part | Tally ESS is *contested* — its marketing site describes a self-service portal; its help documentation has no ESS topic. Assert nothing either way | EV-032 (unresolved cell) |
| "Nobody has shipped HR AI at scale in India" | **[Reversed]** in part | greytHR presents NAVOS as generally available on every paid plan since 3 June 2026 and Zoho logs Zia in a dated changelog — claim posture, not tested. The monetisation half survives: no one in the set charges for it | EV-090; r1/04 |

Three research-round readings are also superseded here, although no earlier PRD draft adopted them as conclusions: "Qandle is the price floor of the entire set" (greytHR undercuts it on monthly billing — r5/03); "Frappe's India Payroll covers PT, LWF, ECR and ESI returns", read from a Frappe product page in round two and not reproduced in the source trees read in round three (§21.3); and round two's reading of the strings "Form 130" and "Form 138" on Zoho's India pages as CMS corruption — under the Income-tax Act 2025 mapping they are the successor numbers of Form 16 and Form 24Q (EV-050), so Zoho's copy is simply in the new vocabulary.

### 21.2 Two incumbents, two jobs

The beachhead buyer is already paying to have two different jobs done, and different vendors hold them (K-23). Round three surfaced the split and did not reconcile it: the parity work was a Frappe-versus-Tally bake-off while the vertical and channel work called greytHR "the volume incumbent at this band" (r3 critic). They are different fights. They need different displacement arguments, different migration tooling, different battle cards and a different channel posture, and this subsection states each.

**Job 1 — accounting and the statutory artefacts: TallyPrime plus the CA who runs it.** TallyPrime ships the central statutory artefacts inside the licence — PF Forms 3A/5/6A/10/12A and the ECR, ESI Forms 3/5/6, a PT statement, Form 16 (now Form 130 — EV-050), the 24Q (now Form 138) annexures, Form 12BA (now 123), Form 27A, NPS and gratuity — but no state PT slab table, no LWF engine, no leave module and no leave-encashment calculation (EV-032). Once the licence is paid the payroll module costs nothing extra: TallyPrime Silver is ₹22,500 as a lifetime licence or ₹750 a month and runs on a single PC; Gold, which adds multi-user access over a LAN, is ₹67,500 lifetime or ₹2,250 a month, both plus 18% GST (r3/01, Tally's buy page). The CA carries submission and the relationship. Tally's integration surface is XML or JSON over HTTP into a *running local instance*, or ODBC — a LAN endpoint, not a cloud API — which is why the Tally importer needs a file path or a local connector (r3/01; §16.2). **What is not known is adoption:** how many Tally businesses actually run Tally *payroll*, as distinct from owning the capability, is the open question §20 V-02 exists to answer (EV-032).

**Job 2 — the HRMS: greytHR.** greytHR claims "30,000+ companies" (captured September 2026, EV-091) — about 3.9% of the 7,66,254 contributing establishments, the dated share ceiling §04 works from (EV-016). The ratio divides a vendor's count of *companies* by a count of *contributing establishments*, a unit mismatch that travels with the figure (§02.15). It publishes a full card — Essential ₹2,495 a month including 50 employees plus ₹45 per additional employee (EV-027) — and states that "every plan includes complete payroll, leave management, and employee self-service" (EV-028; r5/03). Its statutory language is generation only: ECR generation, ESI challans, Form 24Q generation "with automatic FVU validation", Form 16 generation; the words "filing", "TRACES" and "EPFO" do not appear on its payroll page (EV-030; r5/03). Its assistant NAVOS is "included in every plan" (EV-090). Two distribution assets matter more than any feature. Its Alliance Partner track is overwhelmingly banks and payment networks — ICICI Bank, HSBC, IDFC First Bank, AU Small Finance Bank, Bank of Baroda, Kotak Mahindra Bank, Visa and Mastercard, alongside AWS, Google, Zoho, Jio and Godrej Nirmaan — a channel no other vendor in the set displays (r3/03). And it runs a Payroll Service Provider landing page, "greytHR for PSPs: Multi-Client Payroll Management", which calls greytHR "the trusted Payroll Partner for 1000+ Payroll Service Providers" and lists multi-client tooling (r1/08). Round three re-read the same page and classed it as a demo-capture page rather than a programme page with published terms; no CA-specific programme page was found (r3/03). The later reading governs: this section treats the PSP offer as a page and its tooling, not as a programme whose terms are known. Its pricing FAQ states no cancellation fee or lock-in on any plan (r1/08). Its operating company filed FY25 revenue of ₹125.22 Cr, up 29% — the input to the ~₹52 realised-PEPM point (EV-006) — and its profitability is not public (r2/09). Its own pages carry more than one customer count, including "around 20,000+ paying businesses in India and GCC countries" on its About page, which is why every greytHR count travels with its capture date (r2/09; EV-016; K-16).

**Beneath both — the spreadsheet and the CA.** For some share of the band the working status quo is a spreadsheet for payroll, Tally for accounts and a CA for the portals. That share is unknown and is the same measurement as Tally payroll adoption (§20 V-02). If adoption proves low, the displacement target in job 1 is the spreadsheet, not Tally payroll, and the importer and channel priorities shift toward greytHR (§01 validation table).

<!-- DIAGRAM: competitive-landscape-two-jobs -->

#### The two jobs compared

| Dimension | Job 1 — TallyPrime + CA | Job 2 — greytHR | Consequence for us |
| --- | --- | --- | --- |
| What the buyer is paying for | Books of account, the statutory artefacts and someone to put them on the portals | An HR system of record with payroll, leave and self-service | We sell the filing carried to portal acceptance into both, from different doors |
| What the incumbent holds | The accounting relationship and the CA's monthly routine | The employee record, leave history and the employee's login | Job 1: attach, keep Tally for accounts. Job 2: migrate the system of record |
| Price the buyer sees for payroll | ₹0 incremental once the licence is sunk (r3/01) | ₹2,495 a month for up to 50 employees on Essential (EV-027) | Job 1: we are an added cost justified by work removed. Job 2: we must beat a 50-seat block on structure (§21.4) |
| Who submits the return | The CA, on portals, under the employer's credentials | The customer — greytHR publishes generation language only (EV-030) | Attended, assisted submission is new in both (K-13; §22) |
| State PT and LWF | PT slabs hand-entered per pay head; LWF not a statutory pay type (EV-032; r5/01) | "PT with all state-specific rules built-in" (r5/03) — a claim, not tested | Job 1: coverage is the argument. Job 2: maintenance under contract, work-location scoping and submission are the argument, never coverage |
| Leave and attendance | No leave module; attendance by manual voucher (EV-032) | Included; attendance is the first upsell from Essential to Growth (r1/08) | Job 1: leave-to-payroll is a real gap. Job 2: parity |
| Employee surface | Contested — assert nothing (EV-032) | Self-service on every plan (EV-028) | Job 1: do not claim. Job 2: parity |
| AI | None in the evidence | NAVOS in every plan (EV-090) | AI is parity at best in job 2 (§21.9) |
| Distribution | Four-grade partner channel; its public locator listed 1,257 partners; a separate CA Community (r3/03) | Bank alliances and a PSP landing page with multi-client tooling (r3/03; r1/08) | Job 1: never sell against the partner's licence revenue (§18.8). Job 2: compete directly |
| Switching cost | YTD inside Tally and the CA's habits | HR history, YTD and the employee's app | Both: mid-year YTD tie-out is the gate (§18.9) |
| Migration path | Tally importer — first in the importer set (§16.2, §16.7) | A greytHR export importer is named in §16.7, sequenced after Tally among the named-source importers | Sequence open: CQ-12 (§21.14) |
| Never say | "Switch off Tally" — kills the partner channel (§18.8) | "greytHR can't do multi-state PT" — its page claims it does | Both enforced by §21.12 |

#### Which job we take, by the prospect's current stack

A decision table for the first sales conversation. It names the job displaced, the argument, the migration path and what is conceded. Every competitor fact in a cell is subject to §21.12 before it is said aloud.

| # | Prospect's current stack | Job we take | Lead argument | Migration path | What we concede |
| --- | --- | --- | --- | --- | --- |
| 1 | TallyPrime with payroll enabled, CA submits, single state | Payroll inside job 1 | Leave-to-payroll (PAR-24), attended submission with status visibility; the state layer as the firm grows. Nothing is said about Tally's employee surface while that cell is open (CLR-15) | Tally importer (§16.2) | Central-artefact parity; Tally stays the book of record |
| 2 | TallyPrime for accounts, payroll on a spreadsheet, CA submits | The spreadsheet | One record from attendance to the filed return; attended submission; the CA armed, not replaced | Spreadsheet importer (§18.9) | The CA's advisory relationship |
| 3 | TallyPrime, establishments in two or more states | Payroll inside job 1 | Multi-state PT and LWF, which Tally does not ship (EV-032), maintained under contract | Tally importer | Tally's granular multi-user permissions (r3/01) |
| 4 | greytHR Essential, 20–49 employees | Job 2 | No seat floor — the firm pays for 50 (EV-026, EV-027); attended submission (EV-030). Never "cheaper" without the headcount-specific computation (§04.4 AC-17) | greytHR importer (§16.7) | Artefact generation, FVU validation and AI are parity |
| 5 | greytHR, 50–200 employees, several states or entities | Job 2 | Maintained multi-state rules, the registration model and attended submission; the registration allowance is priced openly (§18.3) | greytHR importer (§16.7) | Sticker price: greytHR Essential at ₹49.90 PEPM is the value floor (EV-027) |
| 6 | Kredily or Zoho Payroll free, approaching 20 employees | The free tier | The EPF moment: outputs and attended submission arrive when the filing surface jumps (§18.2 P1, P2) | Kredily / Zoho importer (§18.9) | Computation is free there and parity here |
| 7 | Frappe HR self-hosted or partner-run | Parity comparator | The statutory layer and its maintenance under contract; attended submission | Frappe importer (§18.9) | Gross-to-net — the bake-off will not be won there (EV-031) |
| 8 | Keka | Priced set | A published, all-in card with no seat floor; attended submission | None named | Suite breadth |
| 9 | CA or bureau only, no software | Services layer | A fixed monthly price and visibility the retainer never gave; the CA keeps the relationship (§18.7) | CA console (§18.7) | The CA's standing with the employer |

### 21.3 The corrected Frappe / Tally parity table

This is the bake-off a prospect with a free or sunk-cost alternative runs. It has one conclusion that must never be lost: **the bake-off will not be won on gross-to-net.** Frappe HR's salary engine is genuinely strong (EV-031), and a feature-by-feature pitch on calculation loses to something free. What the table shows instead is that the *statutory* layer — the rate tables, the state dimension, the artefacts, the maintenance obligation and the submission — is where the two parity comparators diverge from each other and from us.

**[Reversed]** (K-01). Earlier drafts said Frappe ships PT for 15+ states and LWF for 14, and concluded that multi-state PT and LWF was table stakes. The source says otherwise. Frappe HR v16's entire India payroll layer is three files and 549 lines — `setup.py` (285), `utils.py` (221) and `data/salary_components.json` (43) — and India overrides exactly three functions, two for HRA exemption and one for marginal relief; the regional-deductions hook has an empty default body and India does not override it. No Indian state name appears anywhere in the v16 tree. ERPNext v16 has no India regional module and removed payroll; the `india-compliance` app covers GST, income-tax (vendor TDS), VAT and audit trail only (EV-031; r3/01). TallyPrime, for its part, has no state PT slab table and no LWF engine (EV-032). Multi-state PT and LWF is therefore **greenfield in both parity comparators** and a genuine differentiator against them.

#### What Frappe's India layer does contain

A parity reading that lists only absences overstates the gap. The three files are not empty, and the bake-off concedes what they do.

| Artefact in the India layer | What it does | Source |
| --- | --- | --- |
| Three regional overrides in the hooks file | Annual eligible HRA exemption; HRA exemption for a period; tax with marginal relief | r3/01 |
| `utils.py` | The three-case HRA minimum, with rent-date overlap validation | r3/01 |
| `setup.py` — component types | Adds "Provident Fund", "Additional Provident Fund", "Provident Fund Loan" and "Professional Tax" as salary-component types a user tags; no rates attach to them | r3/01 |
| `setup.py` — declaration fields | Adds HRA fields to the tax-exemption declaration and proof-submission doctypes | r3/01 |
| `setup.py` — gratuity | Creates an "Indian Standard Gratuity Rule": a five-year minimum, rounded work experience, a 15/26 slab | r3/01 |
| `salary_components.json` | Seeds components, including Leave Encashment | r3/01 |
| Two reports | "Provident Fund Deductions" sums whatever was tagged PF; "Professional Tax Deductions" lists what was tagged PT | r3/01 |
| Outside the India layer | Income-tax slabs and taxable-salary slabs in the generic payroll module; the full gross-to-net engine; arrears and payroll correction | r3/01 |

Read together: Frappe gives an Indian employer a strong salary engine, HRA-exemption and marginal-relief logic (read in code, not executed), a gratuity rule and labelled buckets for PF and PT. What the employer must still supply is every statutory rate, every state slab, every return file and the maintenance of all of it (PAR-09 to PAR-23).

#### The full table

Columns: what the Frappe HR v16 source trees show (r3/01, read at tag v16.17.1); what TallyPrime's documentation shows (r3/01, r5/01); our v1 position; and the class the row puts us in. Form names carry both vocabularies (EV-050).

| # | Capability | Frappe HR v16 — source read | TallyPrime — documentation read | Our v1 position | Class |
| --- | --- | --- | --- | --- | --- |
| PAR-01 | Salary structure and gross-to-net | Genuinely strong: `salary_slip.py` is 2,743 lines — formula and statistical components, an employer-contributions table, LWP/PPL from leave or attendance, holiday-aware payment days, timesheet earnings, loans, benefit accruals, CTC and a YTD tax projection | Pay heads and salary structures; six enumerated statutory pay types — PF, ESI, NPS Tier-I, NPS Tier-II, PT, Income Tax (r5/01) | Credible parity (§08.2) | **Concede** — never the axis of the pitch (EV-031) |
| PAR-02 | Arrears and retrospective recomputation | Ships in v16 stable: `arrear`, `payroll_correction` and child doctypes, 13 files, with LWP reversal | Not established in the documentation read | Retro as a diff against the rule version in force for the period (§08.5) | Parity with Frappe; Tally not assessed |
| PAR-03 | The s.2(y) 50% wage add-back | No reference to "labour code", "wage code", "code on wages" or "social security code" anywhere in the repository | No Labour Code wage-definition topic in the payroll documentation index | Dual wage base with bounded fixed-point evaluation (§06.10, §08) | **Differentiator vs both** — we are not aware of either implementing it, as of September 2026 |
| PAR-04 | Gratuity | Computes it: an "Indian Standard Gratuity Rule" with a five-year minimum and a 15/26 slab | Computes it: a slab-based gratuity pay head and a Gratuity Summary of liability | Accrual and settlement (§06.6, §08.9) | Parity |
| PAR-05 | Leave encashment | A first-class doctype, a seeded component and payment-status handling | Its FAQ: the amount "cannot" be calculated in the payroll module, but an amount calculated outside payroll can be carried, with its PF, ESI and PT effects handled (quote both sentences — §21.12) | Computed from the leave ledger (§09.7) | Differentiator vs Tally; parity with Frappe |
| PAR-06 | Investment declaration and proof | The full declaration and proof-submission doctype chain; the three-case HRA minimum with rent-date overlap validation | An Income Tax Declarations master with a "Proof/Eligible Amount" field — operator-entered, no document upload | Form 124 (ex-12BB) workflow with proof upload and a reviewer (§07.5) | Parity with Frappe; narrow differentiator vs Tally (self-submission and upload) |
| PAR-07 | Income-tax computation — regime election, rebate, surcharge, cess | Income Tax Slab, Taxable Salary Slab and marginal relief exist; the computation path was not executed | Documents a "New Tax Regime under Section 115BAC" page | §08.3, on both vocabularies (EV-050) | **Unresolved cell** — Frappe correctness (EV-032) |
| PAR-08 | NPS | Not assessed | NPS Tier-I and Tier-II statutory pay types and NPS reports | §11.8 | Parity with Tally; Frappe not assessed |
| PAR-09 | EPF computation — rates, wage ceiling, EPS split | No rate constants; PF exists only as a component type a user tags; the "Provident Fund Deductions" report sums whatever was tagged | PF computation through the PF statutory pay type | Engine with effective-dated rates (§06.2) | Differentiator vs Frappe; parity with Tally |
| PAR-10 | The ECR file | Zero matches for ECR, EDLI, EPS or UAN | A dedicated E-Challan Return page | The 11-field `#~#` generator — buildable (EV-035) | Differentiator vs Frappe; parity with Tally |
| PAR-11 | PF Forms 3A, 5, 6A, 10, 12A | None | Ships them (EV-032) | Migration-grade register equivalents per §08.13 | Differentiator vs Frappe; parity with Tally |
| PAR-12 | EPF return lifecycle — Regular, Supplementary, Revised; the chronological ledger | None | Not in the documentation read — the lifecycle lives on the portal | Filing ledger with the return types and the M−4 rule (EV-036–EV-038; §08) | Differentiator vs Frappe; Tally not assessed |
| PAR-13 | ESI computation | Absent as a capability: two references in the tree, a code comment and a test fixture | ESI statutory pay type; a monthly contribution statement | Engine (§06.3) | Differentiator vs Frappe; parity with Tally |
| PAR-14 | ESI Forms 3, 5, 6 and the monthly return | None | Ships them (EV-032) | ESIC template; the post-22-Nov-2026 regime is fenced (§05, §06) | Differentiator vs Frappe; parity with Tally |
| PAR-15 | **State PT slab table** | No Indian state name in the tree; PT is a component type; the "Professional Tax Deductions" report is a listing with no slab logic | Slabs hand-entered per pay head ("Amount Greater Than", "Amount Up To", "Value"); no state dropdown, no shipped slab data (r5/01) | Gazette-sourced per-state dataset — PT schedules verified at state primary source for Maharashtra and Odisha, Karnataka's effect only (instrument unretrieved); every other state, Telangana's slab included, unverified (EV-014, EV-015; §20 V-09) | **Differentiator vs both** (K-01) — and a build dependency |
| PAR-16 | PT statement and return | None | A PT statement (EV-032) | State PT returns carried to portal acceptance (§22) | Differentiator vs Frappe; statement parity with Tally |
| PAR-17 | **LWF** | Zero matches for LWF or "Labour Welfare" | Not among the six statutory pay types; absent from the statutory reports archive; Tally's own article tells employers to confirm rates with the State Labour Welfare Board (medium confidence — an inference from an enumerated list, r5/01) | Per-state LWF engine with periodicity (§06.8) | **Differentiator vs both** (K-01) |
| PAR-18 | **State as a payroll dimension** | Multi-company exists; no state dimension anywhere in the payroll model | PT slabs are per-company manual entry; no state dimension documented | Jurisdiction resolved on the work location — state, sphere and Code-regime commencement date (§14) | **Differentiator vs both** |
| PAR-19 | Quarterly TDS return — 24Q, now Form 138 | Zero matches for 24Q | Form 24Q, E-24Q e-Return, Annexures I and II (EV-032) | Form 138 Q1–Q3 on RPU 1.2 + FVU 1.2; Q4 fenced (EV-046, EV-051, EV-052) | Differentiator vs Frappe; parity with Tally **subject to the currency cell** |
| PAR-20 | Annual certificate — Form 16, now Form 130 | None; the nearest artefact is an "Income Tax Computation" report | Form 16 (EV-032) | Data preparation for TRACES issue — Form 130 is valid only if TRACES-generated (EV-048); Part B fenced (EV-046) | Differentiator vs Frappe; parity with Tally subject to the currency cell |
| PAR-21 | Form 12BA, now Form 123 | None | Ships it (EV-032) | §08.8 | Differentiator vs Frappe; parity with Tally |
| PAR-22 | Form 27A | None | Ships it (EV-032) | §08.8; the 2025-Act successor of Form 27A is not mapped in our evidence (EV-050) — CQ-20, routed to §20 | Differentiator vs Frappe; parity with Tally; mapping open |
| PAR-23 | Form 12BB, now Form 124, as a produced output | None | Not in the income-tax reports index | Form 124 declaration output (§07.5) | Small differentiator vs both (r3/01) |
| PAR-24 | Leave management | Sixteen leave doctypes | No leave module; its FAQ defers it to "future releases" | §09.7 | Differentiator vs Tally; parity with Frappe |
| PAR-25 | Attendance device ingestion | A whitelisted check-in API with device and employee-field lookup; no in-product device management | Manual Attendance Vouchers | ADMS/WDMS push receiver (§09.3) | Differentiator vs Tally; narrow vs Frappe |
| PAR-26 | Code-era registers — Wages Forms I, IV, IX; OSH Forms XIII, XIV, XV, XVI, XIX, XX; SS Form XXII (EV-053) | Not assessed | Not assessed | One canonical set, form numbers configurable per state; Form IX with per-day IN and OUT (EV-053, EV-055; §09.10) | **Unassessed** — claim nothing about either |
| PAR-27 | Shift, roster, overtime | Present — shift, roster and overtime doctypes and a roster app | Absent from the payroll documentation index | §09.4, §09.6 | Differentiator vs Tally; parity with Frappe |
| PAR-28 | Full-and-final settlement | Present | Absent | §08.9 | Differentiator vs Tally; parity with Frappe |
| PAR-29 | Recruitment and performance | Present — job openings, applicants, interviews, appraisals, goals, KRAs | Absent | v2 metered recruiting; performance deferred (§10) | Concede vs Frappe in v1 |
| PAR-30 | Employee self-service and mobile | A progressive web app (Ionic/Vue) with push notifications | **Contested**: the marketing site describes a self-service portal for declarations, reimbursements and payslips; the help documentation has no ESS topic; Tally Cloud Access is a hosted virtual desktop sold through partners | ESS and mobile (§07.5) | Parity with Frappe; **unresolved cell** for Tally |
| PAR-31 | Concurrent users and permissions | Framework roles — not assessed in depth | Silver single-PC; multi-user only at Gold, 3× the price; granular security levels per voucher and report — a genuine Tally strength (r3/01) | Permissions matrix with maker-checker (§07.6) | Tally strength on granularity; licence-gated concurrency |
| PAR-32 | Multi-company and registrations | A Company link on slips, structures and payroll entries | Separate Tally companies (§16.2) | Group → legal entity → registration → establishment, with a per-registration filing ledger (§14) | Parity on entity; differentiator on the registration ledger |
| PAR-33 | API | REST over every doctype; 221 whitelisted methods in the HR app alone | XML/JSON over HTTP into a running local instance; ODBC | Hosted API and webhooks (§16.11) | Parity with Frappe; structural advantage vs Tally (cloud-callable) |
| PAR-34 | Bank salary payment files | Generic query reports (bank remittance; salary via ECS with IFSC and MICR) exported as CSV/Excel; no bank template, no fixed-width writer | Not established in the documentation read | Per-bank versioned templates (§16.3) | Differentiator vs Frappe; Tally not assessed |
| PAR-35 | Licence and hosting cost | AGPL-3.0; Frappe Cloud priced per site, not per user — from ₹410, ₹1,800 or ₹5,400 a month (r2/01); implementation labour is the real cost and is unquantified | Silver ₹22,500 / Gold ₹67,500 lifetime, plus 18% GST (r3/01) | Published per-head card (§18) | **Concede** on licence price |
| PAR-36 | Statutory maintenance obligation | None contractual — open source | Ships Finance-Bill payroll updates (an "Updates Supported as per Finance Bill for Payroll" page — r3/01), not a per-tenant SLA | Maintained under a compliance SLA with a capped remedy (§18.3, §22) | **Differentiator vs both** — as a contract, not a feature |
| PAR-37 | Submission on the portal | None | Generates the artefacts; submission stays with the employer or its CA | Portal-accepted artefact plus attended, assisted submission under written authority (K-13; §22) | **Differentiator vs both**; legality under counsel review (§23) |

#### The eight rows that decide a bake-off

Most prospects will not read thirty-seven rows. These eight decide the evaluation, and they reduce to three patterns: Frappe absent and Tally present on the central artefacts; both absent on the state layer and the add-back; Frappe present and Tally absent on leave, encashment, shift and settlement.

| Row | Capability | Frappe HR v16 | TallyPrime | What the row lets us say after §21.12 clearance |
| --- | --- | --- | --- | --- |
| PAR-10 | ECR file | Absent in the source read | Present | Frappe: the source trees read contain no ECR generator. Tally: parity |
| PAR-13/14 | ESI | Absent in the source read | Present | As above |
| PAR-15 | State PT slab table | Absent in the source read | Hand-entered, no shipped table | We ship and maintain per-state slabs; both require the user to supply them |
| PAR-17 | LWF | Absent in the source read | Not a statutory pay type | As above |
| PAR-19 | Quarterly TDS return | Absent in the source read | Present, currency unresolved | Frappe: no 24Q/138 generator in the trees read. Tally: parity; format currency not asserted |
| PAR-20 | Annual certificate | Absent in the source read | Present, currency unresolved | As above; Form 130 is TRACES-generated for everyone (EV-048) |
| PAR-18 | State as a payroll dimension | Absent | Absent | One company, many states, one cycle — on the work location |
| PAR-03 | s.2(y) add-back | Absent | Absent | "We are not aware of either implementing it, as of September 2026" — never "they cannot" |

#### The four cells deliberately left unresolved

These four are unresolved in the evidence (EV-032), and the table stays honest only if they stay visibly open. Each carries the method that would close it, who closes it, what changes either way, and what may be said in the meantime.

| Cell | Why it is open | Method to close | Owner | If resolved one way | If resolved the other | Until closed, say |
| --- | --- | --- | --- | --- | --- | --- |
| **TallyPrime employee self-service** | Tally's marketing site describes a self-service portal; its help documentation has no ESS topic (r3/01) — the round-three researcher named this "the single most likely thing in this report to be wrong" | A partner demonstration or a trial licence, captured with date and build | Research / GTM | Present: our employee-surface argument against Tally narrows to mobile, deskless attendance and attended submission | Absent: the employee surface becomes a documented Tally gap — still said only as "observed in product" once executed | Nothing about Tally ESS in either direction |
| **Frappe income-tax engine correctness** | The doctypes exist; the computation path was never executed (r3/01) | Execute the §06.14 golden vectors on a Frappe v16 instance and record outputs | Statutory engineering | Correct: TDS computation is parity, and the bake-off moves entirely to the statutory artefacts | Incorrect on named cases: a demonstrable row — said only as "observed in product, executed on <date>, build <tag>" | Concede computation |
| **Tally forms' currency with the latest Finance Act** | The documentation lists 24Q and Form 16 in the 1961-Act vocabulary; whether Tally ships Form 138 on RPU/FVU 1.2 for Tax Year 2026-27 is not established (r3/01; EV-050, EV-052) | Read Tally's release notes; confirm on a current build | Research | Current: artefact parity holds | Not current: the SLA's format-break coverage (§18.3) is a live differentiator for Tax Year 2026-27 | Nothing about Tally's form currency |
| **A commercial add-on closing the PT/LWF gap** | Five public TDL catalogues show none; the in-product TallyShop browser needs a licensed install and has never been searched (r5/01) | Browse TallyShop from a licensed install; verify any named product directly | Research | Exists: the moat is maintained multi-state content under SLA, not the absence of a feature | None: unchanged | "We are not aware of any, as of September 2026" |

#### What "greenfield" licenses — and what it does not

K-01's reversal is about Frappe and Tally. It says nothing about the SaaS field, where state PT and LWF are *claimed*. This table keeps the two apart; every cell outside the first two columns is a page claim, not a tested capability.

| Capability | Frappe HR v16 (source) | TallyPrime (docs) | greytHR (page claim) | Zoho Payroll (page claim) | Keka (page claim) | Our basis for differentiation |
| --- | --- | --- | --- | --- | --- | --- |
| State PT slabs | None | Hand-entered | "PT with all state-specific rules built-in" (r5/03) | "Statewise PT" in the free tier (r2/01) | Not in the captured entry-tier text | Coverage vs Frappe and Tally; maintenance, work-location scoping and attended submission vs the SaaS field |
| LWF | None | Not a statutory pay type | Not in the captured payroll-page text | "LWF" in the free tier (r2/01) | Pre-built LWF reports (r5/03) | As above |
| State as a work-location dimension | None | None documented | Not assessed | Not assessed | Not assessed | Architectural (§14) — claim only against Frappe and Tally |
| s.2(y) add-back | None | None documented | Not assessed | Not assessed | Not assessed | "We are not aware of any vendor in the set implementing it", dated |
| Submission on the portal | None | CA | Generation language only (EV-030) | Generates; the customer files (§18.12) | Pre-built reports (EV-030) | Attended, assisted submission (K-13) |
| Maintenance under a per-tenant SLA | None | Updates shipped, no SLA | Not assessed | Not assessed | Not assessed | The SLA is the product (§18.3) |

#### Provenance notes the table depends on

- **The Frappe product page and the source trees disagree, and the disagreement is recorded, not resolved.** A round-two rendered read of Frappe's "India Payroll Version 16" product page captured copy describing PT across 15+ states, LWF across 14 states, ECR and ESI returns and state LWF filings (r2/01) — **[Killed]** as a basis for any conclusion here. Round three read the `hrms` v16 stable tree, the `erpnext` v16 tree and the `india-compliance` app and found none of it; it reports that no companion app closes the gap (r3/01), and Frappe's own documentation has no India statutory content (r3/01). This PRD builds on the source reading (EV-031). What the product page describes — an artefact outside the three trees read, or copy ahead of code — is open (CQ-05). Two consequences: the product decision does not depend on the answer, because the state layer is built and maintained either way; and no external statement may go beyond "the Frappe HR v16, ERPNext v16 and india-compliance source trees, read in September 2026, contain no state PT slab table or LWF logic", and none may say Frappe's page is wrong (§21.12, CLR-02).
- **The Tally PT contamination trap is live.** A search-engine summary reproduced in two rounds says Tally lets the user "choose the state and slab" for PT and attributes it to the Tally help page that says the opposite (r5/01). Any re-check of PAR-15 goes to help.tallysolutions.com, never to a search summary.
- **Quote Tally's leave-encashment FAQ in full.** An earlier round truncated it to its first sentence. The second sentence — that an amount calculated outside payroll can be carried, with its PF, ESI and PT effects managed — materially narrows the gap, and the counsel review listed "TallyPrime cannot calculate leave encashment" among the flat negative assertions it flagged for disparagement exposure (r3/01; r5 counsel review). PAR-05 is stated with both sentences or not at all.
- **The table is written in both form vocabularies** (EV-050). Round three's parity table used the 1961-Act names only (r3 critic). A reader searching "Form 16" or "Form 130", "24Q" or "Form 138" must find the same row.
- **Frappe's arrears capability was upgraded, not assumed.** Arrears and payroll correction were confirmed on the v16 stable branch, not inferred from the development branch (r3/01). The same discipline applies to every "present" cell: read on the release branch the customer would install.

#### The re-verification recipe

EV-031 is re-verified on each Frappe major release and EV-032 on each TallyPrime release. The recipe below is what "re-verify" means, so that the next reader reproduces the reading instead of re-interpreting it. Frappe checks run on the stable branch, with word-boundary searches; Tally checks read the vendor's own help page, never a search summary.

| Rows | Frappe HR check — stable branch | TallyPrime check — help.tallysolutions.com | Result in September 2026 |
| --- | --- | --- | --- |
| PAR-15, PAR-18 | Search the whole tree for Indian state names (for example Maharashtra, Karnataka, Tamil Nadu, West Bengal); inspect the "Professional Tax Deductions" report for slab logic | The Professional Tax deduction pay-head page: are slabs entered by hand, is there a state selector, is slab data shipped? | Zero state names; the report is a listing. Tally: manual slabs, no state selector, no shipped data (r3/01; r5/01) |
| PAR-17 | Search for "LWF" and "Labour Welfare" | The enumerated statutory pay types; the payroll statutory-reports index | Zero matches. Tally: LWF absent from both lists (r3/01; r5/01) |
| PAR-09, PAR-10, PAR-12 | Search for ECR, EDLI, EPS and UAN; look for PF rate constants and the wage ceiling outside tests | The E-Challan Return page; the PF reports pages | Zero matches and no constants. Tally: ECR page and PF Forms present (r3/01) |
| PAR-13, PAR-14 | Search for "ESI"; classify each hit | The ESI reports pages | Two hits — a code comment and a test fixture. Tally: ESI Forms 3, 5, 6 present (r3/01) |
| PAR-19 to PAR-23 | Search for 24Q, 12BB, 12BA, 27A and "Form 16"; repeat with the 2025-Act names 138, 124, 123, 130 (EV-050) | The income-tax reports index; release notes for Form 138 and RPU/FVU 1.2 | Zero matches in the 1961-Act names; the 2025-Act search is owed. Tally: 24Q, Form 16, 12BA and 27A listed; 12BB not listed; currency open (r3/01) |
| PAR-03 | Search for "labour code", "wage code", "code on wages", "social security code" | The payroll documentation index for a wage-definition topic | Zero matches; no topic (r3/01) |
| PAR-01, PAR-02 | Confirm the salary-slip engine and the arrear and payroll-correction doctypes exist on the stable tag | — | Present at tag v16.17.1 (r3/01) |
| India layer as a whole | Count the files and lines under the India regional folder; list the functions India overrides in the hooks file | — | Three files, 549 lines, three overrides (EV-031) |
| Companion apps | Check ERPNext's regional folder for India and its overrides; list the india-compliance app's modules | — | No India module in ERPNext v16; india-compliance covers GST, income tax (vendor TDS), VAT and audit trail (r3/01) |
| PAR-05, PAR-24, PAR-30 | Confirm the leave and leave-encashment doctypes and the PWA front end | The payroll FAQ (leave encashment, leave module); cloud access; any ESS topic | Frappe present. Tally: the two FAQ statements as quoted; no ESS topic; cloud access is a hosted desktop (r3/01) |

A new Frappe or TallyPrime release that changes any "Result" cell updates the parity table, re-opens the affected CLR claims (CLR-11), and is recorded as a new capture in §21.13. The 2025-Act vocabulary search in the Frappe tree was not run in round three; it is owed on the next re-read.

#### The Tally add-on ecosystem

**[Killed]** (K-20): the "Payroll Plus ₹5,999" add-on is sold on a lookalike domain, its detail page returns 404, and even its own copy claims no state PT or LWF capability (r5/01; EV-K31). It is not evidence of anything.

Five independent public catalogues show no payroll, PT or LWF add-on: Tally's official TallyShop (sixteen categories, none for payroll), an authorised 5-Star partner's list of about 300 TDLs (cosmetic payroll-adjacent items only), a 200+ add-on catalogue, a third-party TDL store whose site search for "payroll" returns nothing, and a nine-category add-on catalogue (r5/01; EV-032). Observed add-on prices are low — TallyShop lists at ₹354; one catalogue runs ₹1,180 to ₹3,540; the TDL store's products run ₹999 to ₹4,999 observed, with struck-through list prices to ₹6,999 (r5/01). The "₹18,000" once quoted is the ceiling of a price-filter control, not a product price (r5/01).

The inference that matters: a partner could build a PT or LWF TDL cheaply. The moat against Tally is therefore **maintained multi-state regulatory content under contract**, not the absence of a competing feature. The re-check trigger is specific: if a competitor, partner or prospect names a TDL product for PT or LWF, that product is captured and verified directly; the ecosystem sweep is not re-run on a rumour (r5/01).

#### Cost of the parity comparators, as the buyer sees it

- **Frappe HR:** licence ₹0 under AGPL-3.0; Frappe Cloud priced per site, not per user — at 100 employees the cheapest site plan works out to about ₹4 per employee per month and the server plan to ₹18 (r2/01, arithmetic on ₹410 and ₹1,800). Whether the India payroll layer installs on the cheapest plan was not established (r2/01). The real competing price is implementation and statutory maintenance by a partner, and it is unquantified (CQ-06).
- **TallyPrime:** the payroll module is ₹0 incremental once the licence is paid; the licence itself is ₹22,500 (Silver, single PC) or ₹67,500 (Gold, multi-user) lifetime, plus GST (r3/01). Tally Cloud Access is sold through partners with no public price (r3/01).

In both cases the buyer's comparison is not our price against theirs — it is our price against *their price plus the work they still do by hand*: the slabs they enter, the LWF they compute, the returns their CA submits and the Finance-Act changes nobody is contracted to absorb. That is the frame §18.1 prices against.

#### Running the bake-off — the protocol we offer a prospect

A prospect comparing us with Frappe or Tally should run the comparison on its own establishments and states, and we should make that easy, because the statutory rows are where it is decided. The protocol splits the work cleanly: we run our product; the prospect checks the alternative. We never operate a competitor's product on a prospect's behalf and report its results, and anything we do execute ourselves is recorded under CLR-14 before it is repeated.

| Step | What the prospect brings | What we run on our product | What the prospect checks on the alternative | Evidence we keep |
| --- | --- | --- | --- | --- |
| B1 | Its establishments, their states, and its registrations — PF code, ESI code, PT registration per state, TAN | The registration model, per establishment (§14) | Where the alternative records state and registration (PAR-18, PAR-32) | The setup record |
| B2 | Last month's inputs for a representative slice of employees | A full run: gross-to-net and both wage bases (§06.10) | Its gross-to-net — expect parity (PAR-01) | Run output stamped with rule versions |
| B3 | — | The ECR text file, validated against the 11-field layout (EV-035) | Whether an ECR file is produced (PAR-10) | The file and its validation report |
| B4 | An establishment in a PT state | PT from the maintained slab table, with the rule object's citation and capture date; the PT return artefact | Where the alternative's PT slabs come from — shipped or typed in (PAR-15) | The rule object as applied |
| B5 | An establishment in an LWF state, in a deduction month | LWF on the state's periodicity (§06.8) | Whether LWF is computed at all (PAR-17) | The rule object as applied |
| B6 | Quarter-to-date TDS data | Form 138 for Q1–Q3, validated on the notified FVU version (EV-051, EV-052) | Whether a Form 138 file is produced, and on which RPU/FVU version (PAR-19; the currency cell) | The file and the FVU output |
| B7 | A back-dated revision | Retro as a diff against the period's rule version; PF liability dated from the disbursal date (§08.5) | Its arrears handling — Frappe ships arrears (PAR-02) | The before-and-after diff |
| B8 | A component mix that trips the 50% add-back | The add-back, shown per employee (§06.10) | Whether the add-back is computed (PAR-03) | The worked calculation |
| B9 | — | The attended-submission walkthrough: what our operator does, what the prospect approves, what the audit entry records (§22) | Who submits today (PAR-37) | The walkthrough record |
| B10 | — | The maintenance commitment: SLA terms and the rule-change log (§18.3) | Who is contracted to absorb the next change (PAR-36) | The SLA document |

Two limits keep the protocol honest. **B4 and B5 run only in states whose dataset is verified at the state's own primary source** — today that is PT in Maharashtra and Odisha, with Karnataka's PT effect verified but its amending instrument unretrieved (EV-014); Telangana's slab is not verified (only its employer-registration wording was — EV-014), and no state's LWF dataset is verified (EV-015). In any other state, and for Karnataka until the instrument is retrieved, the bake-off shows the rule object and its verification status, not a number (§20 V-09). And **the prospect's findings about the alternative are the prospect's**: they are never recorded by us as "observed in product", and never repeated to another prospect without clearing §21.12. If a prospect reports parity on a statutory row, we do not dispute it; the conversation moves to maintenance, submission and the SLA (§20.8 R-7).

### 21.4 The six-vendor priced set and the 50-seat floor

This subsection is the evidence form of the priced comparison: the rate cards as captured, the arithmetic that turns them into effective per-employee prices, the structural models behind the arithmetic, and the exact scope of the seat-floor finding. §18.12 is the commercial form of the same data and must stay consistent with it.

#### The rate-card register

As captured from each vendor's own page, ex-GST, per month. "Entry plan" is the lowest paid tier that carries payroll (EV-028).

| Vendor | Entry plan | Billing basis | Base price | Seats in the base | Per additional employee | Higher tiers | Billing and trial | Capture method | Captured |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| greytHR | Essential | Base plus overage | ₹2,495 | 50 | ₹45 | Growth ₹4,495 + ₹85; Premium custom, marketed as "~30% savings vs Growth plan" | Monthly; 7-day trial; no free plan | Rendered read and raw fetch | 4 Sep 2026 (r1); 5 Sep 2026 (r5) |
| Qandle | FOUNDATION | Flat per-employee with a 50-seat minimum (base = 50 × rate) | ₹2,950 monthly / ₹2,450 annual | 50 | ₹59 monthly / ₹49 annual | REGULAR ₹4,950 + ₹99 / ₹3,950 + ₹79; PLUS ₹6,200 + ₹124 / ₹4,950 + ₹99; PREMIUM ₹8,000 + ₹160 / ₹6,450 + ₹129; ENTERPRISE by quote for 1,000+ | Monthly or annual — "Save upto 25 %" advertised; the implied saving is 16.9–20.2%; "Free Trial", length not stated | Vendor pricing config file, confirmed by a rendered read | 5 Sep 2026 (r5) |
| Pocket HRMS | Standard | Approximately flat per-employee with a 50-seat minimum | ₹2,995 (billed annually) | 50 | ₹60 | Professional ₹4,495 + ₹90; Premium by quote with a 100-employee minimum | Annual; "free demo"; trial length not stated | Raw fetch | 4 Sep 2026 (r1); 5 Sep 2026 (r5) |
| Zimyo | Basic | Per user, "Minimum billing for 50 Users" | ₹80 per user | 50 minimum | ₹80 | Standard ₹160; Enterprise ₹240 per user | 14-day trial, no card | Rendered read (the site returns HTTP 403 to a non-browser fetch) | 4 Sep 2026 (r1); 5 Sep 2026 (r5) |
| HROne | Basic | Flat per-employee with a 50-seat minimum (base = 50 × ₹99) | ₹4,950 | 50 | ₹99 | Professional ₹6,500 + ₹130; Enterprise by quote "For 50+ Team"; a startup programme "less than 50 Employees" with no published price | Trial or demo; no trial length on the pricing page | Raw fetch | 4 Sep 2026 (r1); 5 Sep 2026 (r5) |
| Keka | FOUNDATION | Archived: base plus overage. Live: no price on the pricing page | Archived ₹9,999; live small-companies floor "from ₹6,999" | Archived 100; the live floor's block is unknown | ₹90 — present on the live pricing page only inside an HTML comment | Archived STRENGTH ₹12,999 + ₹120; GROWTH ₹15,999 + ₹150; Hiring ₹1,500 and ₹2,500 per recruiter | Plan "Free Trial" links lead to a demo-request form; terms auto-renew | Raw fetch with comment scan; Wayback archive of Keka's own page; terms of service | 5 Sep 2026 (r5); archive 1 Aug 2024 |

(Sources: EV-021–EV-027 and the rate cards read in r5/03; round-one captures in r1/08 agree with round five on every figure both rounds read.)

#### Effective per-employee price by headcount

The 20- and 50-employee columns are the registered figures (EV-027). The other columns are arithmetic on the same verified block prices, assuming the published overage applies linearly above the block — no page says otherwise, and none says so either. The formula column is the definition; any headcount can be recomputed from it.

| Vendor and plan | Effective PEPM for *n* employees | 20 | 25 | 30 | 40 | 50 | 75 | 100 | Model |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Qandle FOUNDATION, annual | ₹2,450 ÷ *n* up to 50; then ₹49 | 122.50 | 98.00 | 81.67 | 61.25 | 49.00 | 49.00 | 49.00 | Flat with minimum |
| Qandle FOUNDATION, monthly | ₹2,950 ÷ *n* up to 50; then ₹59 | 147.50 | 118.00 | 98.33 | 73.75 | 59.00 | 59.00 | 59.00 | Flat with minimum |
| greytHR Essential | ₹2,495 ÷ *n* up to 50; then (₹2,495 + ₹45 × (*n* − 50)) ÷ *n* | 124.75 | 99.80 | 83.17 | 62.38 | 49.90 | 48.27 | 47.45 | Base plus overage — tends toward ₹45 |
| Pocket HRMS Standard | ₹2,995 ÷ *n* up to 50; then (₹2,995 + ₹60 × (*n* − 50)) ÷ *n* | 149.75 | 119.80 | 99.83 | 74.88 | 59.90 | 59.93 | 59.95 | Approximately flat with minimum |
| Zimyo Basic | ₹80 × max(*n*, 50) ÷ *n* | 200.00 | 160.00 | 133.33 | 100.00 | 80.00 | 80.00 | 80.00 | Flat with minimum |
| HROne Basic | ₹4,950 ÷ *n* up to 50; then ₹99 | 247.50 | 198.00 | 165.00 | 123.75 | 99.00 | 99.00 | 99.00 | Flat with minimum |
| Keka FOUNDATION, archived card | ₹9,999 ÷ *n* up to 100; then (₹9,999 + ₹90 × (*n* − 100)) ÷ *n* | 499.95 | 399.96 | 333.30 | 249.98 | 199.98 | 133.32 | 99.99 | Base plus overage — tends toward ₹90 |
| Keka, live small-companies floor | ₹6,999 ÷ *n* while the floor's block covers *n* | 349.95 | — | — | — | 139.98 | — | — | Block size unknown (₹6,999 ÷ ₹90 = 77.8 matches no round number — r5/03) |

(All figures ₹ per employee per month, ex-GST, entry tier, list price. Realised prices are unmeasured for every vendor — §20 V-03.)

<!-- DIAGRAM: competitive-landscape-seat-floor -->

Three readings follow from the arithmetic, and none of them needs a number we do not have:

1. **Below 50 the model inverts.** At 20 employees the six charge ₹122.50 to ₹349.95 per employee — exactly two and a half times each vendor's own 50-employee rate, because the block does not shrink with the firm — and the buyer pays for seats it does not have (EV-026, EV-027). In annual terms a 20-person firm pays ₹29,400 (Qandle, annual billing) to ₹83,988 (Keka's live floor) a year for the entry tier. The 20–50 sub-band is structurally overcharged, which is the basis for §04's beachhead argument and §18.2 P6.
2. **Two structural models hide inside "base plus per-employee".** For Qandle, HROne, Zimyo and — to within ₹5 — Pocket HRMS, the base is exactly 50 times the per-employee rate, so these are flat per-employee prices with a 50-seat minimum and the effective price stops falling at 50. For greytHR (₹2,495 against 50 × ₹45 = ₹2,250) and Keka's archived card (₹9,999 against 100 × ₹90 = ₹9,000) the base exceeds the seats it covers, so the effective price keeps falling with headcount toward the marginal rate (r1/08). Only the second group rewards growth, which matters for the taper above 200 (§18.2 P4).
3. **Above 50 the band is served cheaply.** At 100 employees greytHR Essential is ₹47.45 and Qandle's annual card ₹49.00. The 50–200 sub-band is over-served by cheap product; the argument there is attended submission and maintained rules, never price (§04.4).

#### Worked example — a firm growing from 20 to 60 employees

Annual list cost of each vendor's entry tier as one firm grows, ex-GST. Arithmetic on the verified block prices; the 60-employee figures assume the published overage applies linearly above the block.

| Vendor and plan | Annual at 20 | Annual at 35 | Annual at 60 | PEPM at 35 | PEPM at 60 |
| --- | --- | --- | --- | --- | --- |
| Qandle FOUNDATION, annual billing | ₹29,400 | ₹29,400 | ₹35,280 | ₹70.00 | ₹49.00 |
| greytHR Essential | ₹29,940 | ₹29,940 | ₹35,340 | ₹71.29 | ₹49.08 |
| Pocket HRMS Standard | ₹35,940 | ₹35,940 | ₹43,140 | ₹85.57 | ₹59.92 |
| Zimyo Basic | ₹48,000 | ₹48,000 | ₹57,600 | ₹114.29 | ₹80.00 |
| HROne Basic | ₹59,400 | ₹59,400 | ₹71,280 | ₹141.43 | ₹99.00 |
| Keka FOUNDATION, archived card | ₹1,19,988 | ₹1,19,988 | ₹1,19,988 | ₹285.69 | ₹166.65 |
| Keka, live floor | ₹83,988 | Block unknown | Block unknown | — | — |

The firm's bill does not move between 20 and 50 employees on any of the six: the first thirty hires after the 20th are already paid for. The overcharge is front-loaded into the smallest, most price-sensitive stage — which is also the stage at which EPF switches on at 20 and the firm is most likely to re-evaluate its software (§18.2 P1, P2). That coincidence is what makes the structural wedge strongest exactly where our conversion happens. The wedge is per head, not per bill: against the two value-floor blocks (greytHR ₹2,495, Qandle ₹2,450 annual) a no-floor card anywhere in the ₹80–150 hypothesis is the smaller invoice only up to roughly 16–31 employees, and above that the block is cheaper in absolute rupees even though its effective PEPM is higher — which is why §04.4 AC-17 bars an unqualified "cheaper". Our own figures cannot be put in this table: our price is a **[Hypothesis]** until §20 V-01 and V-03 report, and a comparison against it is made only from our published card (§18.12; CLR-05).

#### Can a 30-person buyer evaluate each vendor without a call?

The price card is only half of evaluability. The other half is whether a buyer who will not sit through a demo can find the number that applies to them, start, and see the terms (§04.4 AC-14).

| Question | greytHR | Qandle | Pocket HRMS | Zimyo | HROne | Keka |
| --- | --- | --- | --- | --- | --- | --- |
| Is a price visible on the site? | Yes | Yes — rendered by JavaScript | Yes | Yes — browser only | Yes | Not on the pricing page; a floor on the small-companies page |
| Can the buyer see what 30 employees cost? | Only as the 50-employee base; the slider starts at 10 | Only as the 50-employee base | Only as the 50-employee base | Only as the 50-user minimum | Only as the 50-user base | No |
| Can the buyer start without sales? | 7-day trial | "Free Trial", length not stated | "free demo"; no trial length on the pricing page | 14-day trial, no card | Trial or demo; no trial length on the pricing page | No — the trial links lead to a demo-request form |
| Can the buyer buy without a call? | No — the pricing page routes to a trial, sales or a demo (r3/03) | Not in the evidence | Not in the evidence | Not in the evidence | Not in the evidence | No (r3/03) |
| Is a setup fee stated? | None advertised | Not in the evidence | Disclosed during the sales discussion | Not in the evidence | None, except possibly for enterprise | Contradictory and unquantified |
| Are lock-in or renewal terms stated? | "No cancellation fee or lock-in period" | Not in the evidence | Not in the evidence | Not in the evidence | "Zero contractual lock-in", two months' notice | Terms: auto-renewal, renewal "subject to an increase" |

(Sources: r5/03; r1/08; r3/03; EV-021–EV-025. Zoho Payroll, outside the six, is the one vendor in the evidence that publishes payment methods for self-serve purchase — r3/03.)

#### The two anchors, restated from the same table

**[Reversed]** (K-09): there is no single price ceiling. The table produces two anchors at 50 employees — a **value floor near ₹50 PEPM** (Qandle ₹49.00 annual, greytHR ₹49.90; Pocket HRMS at ₹59.90 just above it) and a **mid-market clearing band of ₹80–200 PEPM** (Zimyo ₹80.00, HROne ₹99.00, Keka ₹139.98 on its live floor or ₹199.98 on the archived card) (EV-027, EV-006). The earlier ₹80–150 planning anchor survives inside the band. Where our own price sits between the anchors, and why, is §18.3's decision, not this section's.

#### What the 50-seat floor means for each vendor

EV-026 is exact about its scope — six of six *priced* vendors, on their *published* cards — and it has to be used exactly. The table records what "floor" means for each, including the routes that sell below it without a published price.

| Vendor | The floor as published | Routes below the floor | Source |
| --- | --- | --- | --- |
| greytHR | Base price includes 50 employees on Essential and Growth | The pricing slider starts at 10 employees and the feature table says "Number of Employees: Unlimited", so it will quote below 50 — but the base price still buys 50. A "FLEXIBLE START" single-module motion is gated behind sales with no published price | r5/03 |
| Qandle | "upto 50 employees" base block on all four tiers | None published | r5/03 |
| Pocket HRMS | FAQ: "a minimum requirement of at least 50 employees"; Premium "Minimum Subscription- 100+ Employees" | None published | r5/03 |
| Zimyo | "Minimum billing for 50 Users" on every plan | None published | r5/03 |
| HROne | "For 50 Users" base blocks | A startup programme "For Startups (less than 50 Employees)" with no published price | r5/03 |
| Keka | Archived: "(Upto 100 Employees)" | The live small-companies floor of ₹6,999 covers an unknown block | EV-022; EV-023 |

Outside the six the field uses other structures, and none of them is covered by EV-026. They matter because they bound what our own "no seat floor" claim may say (§21.12, CLR-06).

| Vendor | Structure | Source |
| --- | --- | --- |
| Zoho Payroll | Free to 10 employees; Standard ₹1,000 a month (annual billing) including 25 employees, then ₹40 each; a separate payroll licence is required for each legal entity | r2/01; r1/08 |
| Kredily | Free Forever at unlimited headcount, marketed with "no per-seat minimum"; Payroll OS ₹1,249 a month up to 25 employees, then ₹50 each | r2/01; r3/03 |
| Zoho People | Free to 5 users; per user from ₹48 a month on annual billing — core HR, not payroll; People Plus requires at least 5 paid users | r2/01 |
| RazorpayX Payroll | PRIME ₹2,499 a month flat, maximum 20 employees; ELITE ₹5,499 (shown discounted from a ₹8,499 list) for 50 then ₹150 each, maximum 100; above 100 by quote | r1/08 — round one only |
| factoHR | Free to 20 employees (employee data, letters, payslip generation); Core ₹4,999 up to 50 then ₹69, billed quarterly | r1/08 — round one only |
| 247HRM | Professional ₹8,999 base for 50 employees | r1/08 — round one only |
| sumHR | Per user, billed annually: Startup ₹49, Basic ₹69, Advanced ₹119 a month (₹119 is the ₹1,428-a-year figure quoted in r1/08); a one-time setup fee based on employee count; Enterprise from 250 employees; any minimum was not captured | r1/01; r1/08 — round one only |

The honest statement of the finding is therefore narrower than "nobody bills from employee one": **none of the six vendors in the priced set bills below a 50-employee block on its published card, and Keka's archived block was 100** (EV-026). Per-user and per-employee structures exist elsewhere — Zoho People, sumHR — and Kredily markets its free tier as having no per-seat minimum. Our wedge is billing actual headcount from the first paid employee on a *payroll-and-filing* product with a published card (§18.2 P6); the claim is made against the six, dated, and never extended to "the market".

One consistency point for §18: the round-one capture shows factoHR with a free tier to 20 employees (r1/08). §18.4 now records it — the gate position at the EPF line is not unique, and what is ours is the combination at that line (full statutory computation and artefact generation below it, attended submission and the SLA above it), since factoHR's free scope is employee data, letters and payslips. The capture predates the later rounds and was not re-checked; it is routed for re-capture (CQ-15) before either §18.4's statement or this one is used externally.

#### Commercial terms beyond the sticker price

The price table is list price. What a buyer actually signs includes setup fees, lock-in, renewal and refund terms, and GST. The evidence on each:

| Vendor | Setup or implementation fee | Lock-in and cancellation | Renewal | Refunds and other terms | Source |
| --- | --- | --- | --- | --- | --- |
| greytHR | None advertised | "There is no cancellation fee or lock-in period on any of our plans" | Not in the evidence | Unused annual credit is non-refundable on early exit | r1/08 |
| Qandle | Not in the evidence; advisory add-ons (HR Advisory, Payroll Advisory, Compliance Assistance) carry no published price | Not in the evidence | Not in the evidence | — | r5/03 |
| Pocket HRMS | "A nominal one-time implementation fee", disclosed during the sales discussion, varying with company size, customisation and data-migration complexity | Not in the evidence | Not in the evidence | — | r5/03 |
| Zimyo | Not in the evidence | Not in the evidence | Not in the evidence | 14-day trial without a card | r5/03 |
| HROne | None, except a possible implementation cost for enterprise clients | "Zero contractual lock-in"; two months' prior notice before exit | Not in the evidence | — | r5/03; r1/08 |
| Keka | Contradictory on two live pages; unquantified on both (EV-025) | The August 2024 "no lock-in" FAQ has been deleted | Clause 15: auto-renews for equal terms unless 30 days' notice; renewal fees "subject to an increase"; downgrades may be re-priced | Clause 3: fees non-refundable whether or not the platform is used; 1% a month late interest | EV-025; r5/03 |
| Zoho People (outside the six) | "Jumpstart" onboarding ₹50,000 to ₹1,60,000 by edition | Monthly or annual at a flat 20% difference | Not in the evidence | Premium support ₹5,750 a month | r1/08 |
| Kredily (outside the six) | None advertised | Not in the evidence | Not in the evidence | — | r1/08 |

Two further terms distort any naive side-by-side. **GST:** published prices are ex-GST and 18% is added, but disclosure is uneven — Zoho Payroll, RazorpayX and 247HRM say so on the page; greytHR, HROne, factoHR, Kredily and Zimyo do not (r1/08). **Purchase path:** a trial is not a self-serve purchase. greytHR, Keka and Kredily route to a trial, a free plan, sales or a demo; Zoho Payroll is the exception that publishes payment methods (r3/03). Published, quantified, all-in pricing that can be bought without a call is a wedge in its own right, and §18.13 sets our terms.

### 21.5 Keka in full

Keka gets its own subsection for five reasons, and being "the competitor that matters" is not one of them — that framing is **[Reversed]** (§21.1); greytHR holds the HRMS job (K-23). Its filed FY25 revenue, ₹133.86 Cr, sits beside greytHR's ₹125.22 Cr (r2/09; §04.4) — stated as filed figures, not as a ranking (CLR-08). Its own archived page describes it as "Loved by companies with 20 - 20,000 employees", which is our band (r5/03). It sits at the top of the priced set's price range (EV-027). It has withdrawn its price card globally, which is the opening for a published-price competitor (EV-024). And its published AI governance commitments set the table stakes the whole field will be measured against (EV-090).

#### The pricing evidence chain

| # | Finding | Method | Evidence | Captured |
| --- | --- | --- | --- | --- |
| K1 | The India pricing page carries no live price. The raw page (318,005 bytes) holds 60 HTML comments, exactly three of which contain a rupee symbol — ₹90, ₹120 and ₹150 "per additional employee", in FOUNDATION, STRENGTH, GROWTH order by byte offset. With comments stripped, the page contains zero rupee characters | Raw fetch with a comment-node scan | EV-021 | 5 Sep 2026 (r5); the same three spans in a 4 Sep 2026 raw fetch (r1/08) |
| K2 | A rendered read cannot see those prices. The earlier "TLS-blocked" premise was one fetch tool's failure; a plain fetch retrieves every Keka page with HTTP 200 | Method correction | EV-K21; r5/03 | r5 |
| K3 | The withdrawn card: FOUNDATION ₹9,999 a month for up to 100 employees plus ₹90 per additional; STRENGTH ₹12,999 + ₹120; GROWTH ₹15,999 + ₹150. Hiring priced per recruiter: PRO ₹1,500 and ADVANCED ₹2,500 a month | Wayback snapshot of Keka's own page | EV-022 | 1 Aug 2024; corroborated twice in 2026 by third parties, used as corroboration only (r5/03) |
| K4 | The live small-business page publishes a floor: "starts at ₹90 per employee/ month" and "starting at ₹6,999 per month"; its FAQ adds "no setup fees or hidden add-on costs". The word "minimum" does not appear | Raw fetch | EV-023; r5/03 | 5 Sep 2026 |
| K5 | The suppression is global. The US and UAE pricing pages each carry exactly three commented-out price spans and no live figure. Withdrawn US card $9 / $16 / $22 per employee per month (pure per-employee, not block plus overage); UAE $4 / $5 / $6 per additional employee | Raw fetch | EV-024 | 5 Sep 2026 |
| K6 | The per-plan "Free Trial" links lead to a page titled "Sign up for free demo", with no pricing, no plan selector and no seat field | Rendered read | r5/03 | 5 Sep 2026 |
| K7 | The live pricing page carries region toggles (India; USA and European Union; Asia Pacific and GCC) and product toggles (HRMS and Payroll; Hiring; Projects and TimeSheets) — the likeliest reason earlier rendered readings disagreed | Saved-page read | r5/01 | r5 |

<!-- DIAGRAM: competitive-landscape-keka-evidence -->

**What the chain supports:** a dual anchor — the withdrawn card as Keka's own historical list price, and the live small-business floor as its current published entry point — and the reading that Keka moved, company-wide and on every locale at once, to a sales-qualified motion (EV-024). **What it does not support:** the block the ₹6,999 floor buys (₹6,999 ÷ ₹90 = 77.8, which matches no round number); whether India is moving to pure per-employee pricing as the withdrawn US card was; and the date of the suppression, which is bracketed between September 2024 and October 2025 and not pinned — because it was global, one resolvable snapshot on any locale would date it (r5/03). The "₹99 Keka price" that circulated in earlier drafts appears in none of Keka's own captures and stays out of every model and deck (§18.3; §20.4).

#### Terms that hardened between August 2024 and September 2026

| Source | What it says | What it means for a buyer | Evidence |
| --- | --- | --- | --- |
| Pricing-page FAQ | "Yes, a nominal setup fee applies" — for guided payroll configuration, data import, validating past salary records and customisation | A setup fee exists and is not quantified | EV-025 |
| Small-companies page, same day | "no setup fees, surprise add-ons, features locked behind an upsell" | The two live pages contradict each other | EV-025 |
| Terms of service, clause 15 ("Term") | Auto-renews for successive equal terms unless 30 days' written notice; "Upon any renewal, the recurring fees shall be subject to an increase"; a downgrade "may be subject to re-pricing ... regardless of prior Term pricing" | Renewal price risk sits with the customer. **[Killed]** "Keka renewal rates run below list" (K-17) | EV-025; EV-K28 |
| Terms of service, clause 3 | Fees "non-refundable whether or not the Keka Platform is actively being used"; pricing revised on a change of region; overage billed; late payment at 1% a month or the highest lawful rate, whichever is lower | Prepaid fees are sunk | r5/03 |
| Terms of service, clause 5 | No customisations for individual customers | Configuration only | r5/03 |
| Terms of service, clauses 1.7 and 1.8 | "Keka Service Credits" held in a "Keka Wallet", defined as a semi-closed prepaid instrument | A prepaid-wallet construct in the contract | r5/03 |
| August 2024 pricing FAQ (archived) | "You can cancel your Keka account at any time with no fees and there is no lock-in period" | That answer is gone; the current pricing FAQ has three items and none is about lock-in | EV-025 |

The reading is narrow and dated: between the August 2024 archive and the September 2026 capture, Keka's published terms moved from no lock-in towards auto-renewal with non-refundable fees and an upward renewal clause (r5/03). It is a statement about Keka's published documents, not about any customer's negotiated contract.

#### Features suppressed the same way as the prices

The comment mechanism hides features as well as prices (r5/03; EV-028). "Direct Salary Payout" — "disburse salaries directly from Keka Wallet, with a single click", already marked "(additional charges applicable)" in 2024 — sits inside a 477-character HTML comment in the live FOUNDATION block, in the same position where it was live in August 2024. "Timesheets on Mobile App", "Smart Resource Allocation" and a 3,101-character "CLIENT PORTAL (Coming Soon)" section are commented out too. The method warning belongs in the capture discipline: a plain text search finds "Direct Salary Payout" on both the 2024 and the 2026 page and would conclude that nothing changed; the comment boundary is the only discriminating test (r5/03). The product reading is that in-product salary disbursement is being repositioned, which is one more reason to treat payout as a distinct build-or-partner decision rather than an assumed entry-tier capability (§16.3).

#### AI posture — waitlisted, with the most explicit governance commitments in the set

**[Verified — claim posture, not tested]** (EV-090). On 5 September 2026 "Join the waitlist" appeared exactly twice on Keka's AI page and "COMING SOON" three times — beside Payroll, Performance and Employee engagement. Hiring, HRIS, Onboarding, AI helpdesk and Time and attendance carried no badge; the footer's "Live demo available. Start using Keka AI now!" sits directly above a "Join the waitlist" button (r5/03). Round one recorded three delivery surfaces — embedded AI, a copilot inside the web app, and the "Keka MCP Server" for Claude, ChatGPT and other external assistants — all behind the same waitlist, and an AI helpdesk further along with a free-trial call to action (r1/04, round one). The governance commitments, read verbatim: a source citation on every answer — "No citation means no answer"; "No silent writes — Every action requires an explicit human confirmation"; multi-entity awareness by default; role-based access on every AI call; "Your data never trains external models" (r5/03). §12 matches or beats each of these; none is a differentiator for us, and external-assistant access is an expected feature, not a moat (§12.7). The honest caveat stands: a waitlist may mean Keka is more candid, not further behind (r5/03).

#### Scale claims

Keka's pricing and small-companies pages said "12,500+" on 5 September 2026; its sign-up page — reached from the pricing page's own plan links — said "10,000+" on the same day (r5/03). The two are not a time series and no growth reading may be drawn from them. Filed revenue is the only scale figure used for Keka (§04.4).

#### The sales motion behind the suppressed card

Keka's hiring corroborates the sales-qualified reading of EV-024. It advertises business-development roles for the Indian SMB market and the mid-market separately from enterprise account executives — a split motion rather than a full-cycle one — and runs a sales-development-to-account-executive outbound model that it is exporting to the US (r3/03; the India split is medium confidence). Its reseller programme pays partners on the first twelve months of a client's billing and on renewal, and Keka's own team co-sells a new reseller's first five deals (r3/03). A company that routes every price through a conversation and staffs for it is unlikely to answer a 30-person buyer's question about cost on a web page; that is the evaluability gap §21.4 records, and on this evidence it reads as a deliberate motion rather than an oversight — an inference, not a finding.

#### What Keka's position opens for us, and what it does not

| Keka's move | What it opens | What we must do to use it | Never say |
| --- | --- | --- | --- |
| Price withdrawn on every locale (EV-024) | A buyer who will not sit through a demo cannot evaluate Keka | Publish a per-head card with a headcount slider (§18.2 P3) | Keka's withdrawn ₹9,999 card as a current price — it is archived (EV-022) |
| Live floor of ₹6,999 a month (EV-023) | ₹349.95 per employee at 20 employees (EV-027) | Bill actual headcount from the first paid employee (§18.2 P6) | Any block size behind the floor — it is unknown |
| Setup fee confirmed and denied on the same day (EV-025) | The buyer cannot budget year one | Default ₹0 setup, stated on the card (§18.13) | Any rupee figure for Keka's setup fee — the ranges on comparison blogs trace to no primary source (r5/03) |
| Renewal "subject to an increase" (EV-025) | Renewal risk the buyer carries | Publish our own renewal and price-change terms (§18.10) | "Keka renewals run below list" — **[Killed]** (K-17) |
| AI behind a waitlist (EV-090) | Nothing durable — governance parity is table stakes | Match the five commitments (§12) | "Keka has no AI" |
| Direct Salary Payout commented out (EV-028) | Payout is not a settled entry-tier expectation | File-first bank payout templates (§16.3) | "Keka cannot pay salaries" |

The open Keka items — the floor's block size, the setup-fee amount, the suppression date, per-employee migration in India, current Hiring and project-module prices, and AI general availability — are CQ-01 to CQ-04 in §21.14. None blocks the build; each changes what sales may say.

### 21.6 The freemium paywall — computation free, outputs charged

**[Verified]** Both freemium players give away computation and charge for outputs — bank payout files, PF/ESI challans, the annual tax certificate, Form 12BB/124 (EV-029). The paywall is empirically located: it is where two vendors with every incentive to find willingness-to-pay have independently put it. It is consistent with how Indian employers already buy this work: the ICAI recommended fee schedule read in round two carries no payroll-processing line item (EV-017) — but that schedule is pre-GST, a February 2020 revision was not retrieved, and the negative is therefore unverified for the current revision (§02.2 G15). It is corroboration, not a second finding, and it is not used outside the PRD until the revision is read.

#### Where each vendor draws the line

EV-029's list is the union across two vendors. The line sits in a different place for each, and a sales statement that ignores the difference is wrong.

| Vendor | Free tier | First paid tier | What the paywall holds back | Source |
| --- | --- | --- | --- | --- |
| Kredily | "Free Forever", ₹0, unlimited employees: payroll, HR, attendance and leave; PF, ESI, PT and TDS statutory *calculation*; self-service and mobile app. Limits: 250 MB storage, one leave/attendance rule, one salary structure | Payroll OS ₹1,249 a month up to 25 employees, then ₹50 each | Salary payouts ("ICICI Bank & NEFT"); PF/ESI challans; Form 12BB and Form 16. Professional (₹1,749 + ₹70) adds selfie/GPS attendance and expense workflows; Enterprise adds exit settlements and multi-company | r2/01; r3/03; r1/08 |
| Zoho Payroll | ₹0 up to 10 employees: automatic payroll calculation and payslips; "Online salary payments through HSBC"; "Compliance - Income Tax, EPF, ESI, Statewise PT, LWF"; automatic TDS worksheet; reimbursement-proof and investment-proof approval; self-service portal; 40+ reports | Standard ₹1,000 a month on annual billing (₹1,250 monthly) including 25 employees, then ₹40 (₹50) each | Statutory form generation — "Form 130 generation with digital signature", "Form 138, TDS challan recording"; the product page adds Form 12BB and e-signature. A separate licence per legal entity | r2/01; r1/08 |
| Zoho People | ₹0 up to 5 users | Essential HR ₹48 per user a month on annual billing (₹60 monthly), with the Zia AI bot included | Higher HR modules by tier; People Plus bundles from ₹192 per user with a 5-user minimum | r2/01 |
| factoHR | ₹0 up to 20 employees: employee data, letter generation, payslip generation | Core ₹4,999 a month up to 50, then ₹69 | Not established beyond the tier names | r1/08 — round one only |

Three precision points follow, and each is enforced by §21.12:

- **Zoho's free tier includes two things Kredily charges for:** salary payouts through HSBC and the investment-proof approval workflow (r2/01). "The freemium players charge for bank payouts" is true of Kredily and false of Zoho's HSBC route. The claim-safe form is "both give computation away and charge for statutory outputs; which outputs differ by vendor". For the same reason, the declaration-and-proof *workflow* is free on Zoho's free tier, while the Form 12BB *output* is behind Kredily's paywall; §07.5's treatment of Zoho should be read against this table.
- **Zoho's copy is in the new tax vocabulary.** Round two read "Form 130" and "Form 138" on Zoho's India pages as CMS corruption (r2/01). Under the Income-tax Act 2025 mapping they are the successors of Form 16 and Form 24Q (EV-050); the reading is superseded. Two cautions travel with it: Form 130 is valid only when TRACES-generated (EV-048), and the Form 138 Q4 format is unreleased (EV-046). What Zoho's "Form 130 generation" does in the product is not established, and nothing is said about it beyond its page wording (CQ-09).
- **Zoho prices per legal entity.** "You will have to purchase separate payroll licenses for each legal entity" (r1/08). A competitor already charges on an entity unit, not only on headcount — evidence that the market will accept a registration-shaped line like ours (§18.3), and a hidden multiplier in any headline comparison with Zoho for a multi-entity group.

#### The two gate shapes

Zoho gates all three of its India free tiers on a *size* proxy — 5 users (People), 10 employees (Payroll), and ₹25 lakh of annual revenue for Zoho Books — so a customer converts by growing, not by discovering a missing feature (r2/01). Kredily gates on *features* — unlimited headcount, but one salary structure and 250 MB of storage — so there is no conversion trigger at all (r2/01). §18.2 P1 copies Zoho's shape and sets our gate at the EPF line. Zoho's gates also create cliffs — ₹0 to ₹1,000 a month between the 10th and 11th employee; ₹0 to ₹48 a user between the 5th and 6th user — which §18.2 P2 treats as the attack surface and refuses to reproduce (r2/01).

#### Why Zoho is the credible commercial floor

Kredily and Frappe set the nominal floor at ₹0; Zoho sets the credible commercial one. It is the only actor in the evidence with an installed base across accounting and payroll, suite pull-through, a demonstrated pattern of indefinite India free tiers, and an AI bot at the bottom of its paid ladder — so dropping its India HR price is, for Zoho, a transfer between its own products (r2/01). That is an inference from pricing behaviour, not from financials: Zoho's revenue and profitability are not in the evidence, and Kredily's funding figures are aggregator-reported only, so neither is used here (r2/01). The consequence is written into the scenarios: assume Zoho widens its free gates, and do not build a plan that needs it not to (§21.11, CRS-01).

#### What the paywall means for our boundary

The freemium players draw the line between computation and outputs. Our Free tier gives away computation *and* artefact generation (§18.4), and holds back only what neither freemium player sells at any price: attended, assisted submission under written authority, and the compliance SLA (K-13; §18.3). Our line therefore sits one stage further along the filing chain than theirs (§21.7). Against Zoho, calculation and the declaration workflow are parity — **[Killed]** as differentiators in earlier drafts and not revived here (§04.5 claim ledger).

The boundary, stage by stage. Cells for the freemium players are their page claims; cells for us are §18.4's packaging decision, and a dash means §18.4 does not settle the point.

| Stage | Kredily free | Kredily Payroll OS | Zoho Payroll free | Zoho Payroll Standard | Our Free | Our File |
| --- | --- | --- | --- | --- | --- | --- |
| Statutory computation — PF, ESI, PT, TDS | Yes | Yes | Yes, with LWF | Yes | Yes | Yes |
| Investment-proof workflow | Not in the evidence | Not in the evidence | Yes — proof approval | Yes | — | — |
| Salary payout | No | Yes — ICICI Bank and NEFT | Yes — through HSBC | Yes | — | — |
| Statutory artefacts — challans, forms, returns | No | PF/ESI challans; Form 12BB and Form 16 | No | Form generation with digital signature; TDS challan recording | Generated; the customer submits | Generated and carried to portal acceptance |
| Attended, assisted submission | No | No | No | No | No | Yes, under written authority (§22) |
| Compliance SLA with a capped remedy | No | No | No | No | No | Yes (§18.3) |

(Sources: r2/01; r3/03; r1/08; §18.4. Zoho Payroll's tiers are read as cumulative, as its page lists each tier's features as increments on the one below — r2/01.)

### 21.7 No vendor submits a filing — the finding, its scope and its limits

**[Verified]** No vendor in the six-vendor priced set claims to submit any statutory filing. greytHR — the most compliance-forward of them — publishes only generation language, and MYND/Qandle is the only bundle that pairs self-serve HRMS with an outsourced filing operation, unpriced and demo-sold (EV-030). Round five treated this as the weakest null in the prior round and attacked it by adding the vendor most likely to falsify it; the null survived and was upgraded (r5/03).

<!-- DIAGRAM: competitive-landscape-filing-depth -->

#### What was read, and what it shows

| Vendor | Language on the pages read | Stage reached (§21.7 diagram) | Source |
| --- | --- | --- | --- |
| greytHR | "PF calculations with ECR generation"; "ESI computations and challans"; "PT with all state-specific rules built-in"; "Comprehensive TDS (IT) calculations and eTDS returns"; "One-click Form 24Q generation with automatic FVU validation"; "Digitally signed Form 16 and 12BA generation". "Filing", "e-fil", "TRACES" and "EPFO" appear zero times on the payroll page | Generate and validate | r5/03; EV-030 |
| Keka | Pre-built "PF, ESI, LWF, TDS and other mandatory statutory reports" in the entry tier | Generate | r5/03 |
| Qandle | The nearest offer is an unpriced "Compliance Assistance" advisory add-on | Advisory, unpriced | r5/03 |
| MYND / Qandle | An outsourced filing operation inside a finance-and-accounting and HR outsourcing group; unpriced, sold by demo | Services | EV-030; EV-034 |
| Pocket HRMS, Zimyo, HROne | No submission claim on the pages read | Generate | EV-030 |
| TallyPrime | Generates the artefacts; submission stays with the employer or its CA | Generate | EV-032 |
| Zoho Payroll | Form generation with digital signature and TDS challan recording in the paid tier; the customer files | Generate | r2/01; §18.12 |
| Kredily | Challans and certificates behind the paywall | Generate | EV-029 |
| Frappe HR v16 | No Indian statutory artefact in the source trees read | Compute | EV-031 |

#### What the finding does not cover

1. **Documentation and live tenants.** Round five searched pricing, payroll and feature surfaces, not product documentation or a trial account. The absence of a published submission claim is strong evidence of *positioning*, not proof of absent *capability* (EV-030). Whether any India HRMS actually submits is "the load-bearing unknown" and is settled only by documentation or a tenant (r5/03; CQ-07).
2. **The services layer.** CAs and payroll bureaus submit returns today; MYND runs an outsourced filing operation; Aparajitha's 1,500+ staff across 25 states deliver compliance services that include payroll compliance (r2/07); staffing majors sell compliance services. They are the budget line we redirect (§18.7), not SaaS features we out-build. Their economics are a warning as much as a benchmark: TeamLease's "Other HR Services" segment — regulatory compliance, training, a job portal, EdTech and SaaS compliance — returned a ₹2.62 Cr segment result on ₹196.52 Cr of revenue in FY25, a 1.33% margin (r2/07). Filing done by people is a services business at services margins, which is why supervised filing is the dominant and unsized line in our own cost stack and why its automation target is a build requirement (EV-088; §13, §22).
3. **The portals themselves.** Every statutory surface is an attended portal — EPFO's interactive login with a CAPTCHA; the TDS return, where the employer runs the FVU utility and uploads; ESIC's template upload; state PT across separate portals — so no vendor can "submit" through an API that does not exist (K-13; EV-035–EV-038). The deliverable that follows is a portal-accepted artefact plus attended, assisted submission under written authority to act, with the employer's and deductor's statutory liability non-delegable throughout (K-13). Whether our operator may act on those portals under employer credentials is under counsel review (§23), and the operation itself is §22's.

#### Who does the submission step today, filing by filing

The table below reads each competitor's position onto the portals themselves. Where a vendor publishes generation language only, "the customer" is an inference from that language (EV-030), not an observed fact.

| Filing | What the submission step involves | TallyPrime + CA | greytHR | Zoho Payroll (paid) | Kredily (paid) | MYND / Qandle | Us |
| --- | --- | --- | --- | --- | --- | --- | --- |
| EPF ECR | EPFO interactive login with a CAPTCHA; upload, validate, approve, generate the challan with its TRRN, pay (EV-036) | The CA | The customer | The customer | The customer | Outsourced operation, unpriced | Attended, assisted, under written authority (§22) |
| ESI contribution | ESIC template upload (K-13) | The CA | The customer | The customer | The customer | Outsourced operation | As above |
| State PT | Separate state portals (K-13) | The CA | The customer | The customer | The customer | Outsourced operation | As above, per state |
| TDS return — Form 138 | The deductor runs the FVU utility and uploads (K-13) | The CA | The customer, after greytHR's FVU validation | The customer | The customer | Outsourced operation | As above; Q1–Q3 only while Q4 is fenced (EV-046) |
| Annual certificate — Form 130 | Generated by TRACES only (EV-048) | Via TRACES | Via TRACES | Via TRACES | Via TRACES | Not in the evidence | Data prepared for TRACES; Part B fenced (EV-046) |

The last row is the reason no vendor — us included — can issue a valid annual certificate outside TRACES, and why our own copy says "prepared for TRACES issue", never "generated" (EV-048).

#### Saying it safely

| Say | Never say | Why |
| --- | --- | --- |
| "No vendor in our six-vendor priced set claims, on its pricing, payroll or feature pages as read in September 2026, to submit a statutory return" | "No one else files" / "We are the only product that files" | The services layer files; documentation and tenants were not read (EV-030) |
| "We carry the return through attended, assisted submission under your written authority; the statutory liability stays with you" | "We file for you" / "We take on your liability" | **[Killed]** (K-13); the liability is non-delegable. Usable only once counsel has cleared attended filing — the four Part D-17 questions (§23; §20.8 R-32) |
| "greytHR's payroll page describes ECR generation and Form 24Q generation with FVU validation" | "greytHR can't file" | A capability claim about a product we did not run |
| "MYND/Qandle pairs an HRMS with an outsourced filing operation, sold by demo" | Any price or scope for MYND's filing operation | Unpriced and demo-sold (EV-030) |

The corner this finding opens is **thin, not empty** (§04.4). MYND's operation sits next to it, and a priced vendor adding submission, or MYND pricing and self-serving its operation, would occupy it; both are scenarios in §21.11 (CRS-06, CRS-07), with observable triggers in the capture schedule (§21.13).

### 21.8 Packaging — payroll sits in the entry tier everywhere

**[Verified]** Payroll sits in the entry tier for every vendor that publishes tiers; what is gated upward is performance, recruitment, engagement, analytics and workflow (EV-028). Payroll therefore cannot be an upsell in our packaging either, and §18.4 does not make it one.

| Vendor | Entry tier contains | Gated upward or sold as an add-on | Published add-on prices | Source |
| --- | --- | --- | --- | --- |
| greytHR | Essential: payroll, leave, core HR; "Every plan includes complete payroll, leave management, and employee self-service"; NAVOS included | Attendance and shift management move from Essential to Growth; performance is an add-on (free in Premium) | Performance ₹35–45 per user a month; Timesheets ₹35; Expense ₹35; GPS Live Tracking ₹140 per user a month; Recruit ₹2,500 per recruiter a month; Alumni Portal ₹20. Unpriced: GeoMark+, Visage, SSO/API, multi-company, manpower planning | r5/03; r1/04; r1/08 |
| Keka | FOUNDATION: payroll automation, statutory compliance, accounting integration, loans and salary advances, expense management, employee tax management, gratuity management | Hiring is a separate product; "Direct Salary Payout" commented out of the live entry block | Archived Hiring PRO ₹1,500 and ADVANCED ₹2,500 per recruiter a month | r5/03; EV-022; EV-028 |
| HROne | Basic includes payroll | Recruitment, performance and engagement are Enterprise-only; add-ons include payroll outsourcing, WhatsApp and Teams bots, business intelligence and workforce planning | None published in the evidence | r5/03; r1/08 |
| Qandle | FOUNDATION's core-HR block includes payroll | Strategic HR and analytics by tier; HR Advisory, Payroll Advisory and Compliance Assistance as unpriced add-ons | Remote Screen Tracking ₹50 per employee a month — identical on monthly and annual billing in India, unlike every other country Qandle prices | r5/03 |
| Pocket HRMS | Standard includes payroll processing | Higher tiers | None published in the evidence | r5/03 |
| Zimyo | Basic ₹80 per user | Standard and Enterprise tiers | Recruit ₹4,000 per recruiter a month; HR Analytics ₹20,000 per licence a month; Timesheet, Learn and Trip Management ₹40 per user a month each | r5/03 |
| Zoho People (outside the six) | Essential HR: onboarding and offboarding, employee database, documents, leave, reports, Zia AI bot | Higher HR modules by tier | Recruit ₹3,000 per recruiter a month; LMS ₹86 per user; engagement ₹30 per user; API access ₹37,500 a month | r2/01; r1/08 |

Five packaging readings, each with the section that acts on it:

1. **Payroll is never an upsell.** Computation and artefact generation sit in our Free tier; attended submission and the SLA sit in File, the first paid tier; no payroll capability is held back for Scale (§18.4).
2. **The market already accepts non-headcount units.** Recruiting is priced per recruiter by greytHR, Zimyo, Zoho People and Keka's archived card; location tracking per tracked user, at ₹140 against greytHR's ₹45 marginal seat — 3.1 times (r5/03). §18.5 prices recruiting and location as separable add-ons on that evidence. Location tracking carries a legal question the evidence has not answered: the counsel review noted that geolocation receives none of the proportionality analysis applied to biometrics (r5 counsel review). Pricing it is §18's decision; whether and how it may be offered is §23's.
3. **Attendance is greytHR's first upsell, and it is in our Free tier.** greytHR moves attendance and shift management from Essential to Growth (r1/08); our Free tier includes attendance because a Form IX-compliant time record feeds the filing (§18.4; EV-055). That is a packaging contrast that may be stated, dated, after §21.12 clearance.
4. **Implementation fees are the hidden line.** Zoho is the only vendor in the evidence publishing a hard number — "Jumpstart" onboarding from ₹50,000 to ₹1,60,000 by edition — which for a 100-seat Professional customer is roughly 70% of year-one licence value (r1/08, arithmetic on Zoho's published figures). Keka's fee is confirmed and unquantified (EV-025); Pocket HRMS discloses one during the sales conversation; HROne charges one only to enterprise clients; greytHR, factoHR and Kredily advertise none; 247HRM includes managed implementation (r1/08). §18.13 defaults ours to ₹0 because migration is acquisition infrastructure (§18.9).
5. **Salary payout is bank-specific across the field.** Kredily's paid payout is "ICICI Bank & NEFT" (r3/03); Zoho's free payout runs "through HSBC" (r2/01); Keka has commented its wallet-based payout out of the live entry block (EV-028). None is bank-neutral in the evidence. §16.3's per-bank, versioned, file-first templates are the neutral alternative, and the bank-side maker-checker stays with the customer.

### 21.9 AI posture — a comparison of claims, not capabilities

**[Verified — claim posture, not tested]** greytHR's NAVOS "included in every plan" is the only packaging-level AI commitment in the priced set; Keka's AI is waitlisted; Keka publishes AI governance commitments and a "Keka MCP Server" that become table stakes to match (EV-090). Nothing in this subsection was tested inside a product. "Shipped" means "presented as available".

| Vendor | What is claimed | Availability as labelled | Packaging | Governance claimed | Evidence and date |
| --- | --- | --- | --- | --- | --- |
| greytHR | NAVOS, an agentic assistant across payroll, core HR, leave and attendance, performance and recruitment; homepage: "No AI add-on fees" | "Available across all paid greytHR plans ... requires no additional setup or purchase"; launched 3 June 2026 | Included in Essential, Growth and Premium — the only packaging-level commitment | Respects existing roles and permissions | Press release and pricing page (r1/04; r5/03) |
| Keka | Keka AI — embedded AI, a copilot, an MCP server for external assistants | Waitlist; Payroll, Performance and Employee engagement "COMING SOON"; the AI helpdesk offers a trial | Keka AI is not itemised in any pricing tier; the only AI items in its tiers were two recruiting features (r1/04) | Citation on every answer; no silent writes; multi-entity awareness; role-based access on every call; no training of external models | AI page, raw fetch (r5/03; r1/04) |
| Zoho People | "Zia AI bot" in the Essential HR tier; twelve named Zia functions; dated changelog entries in May and July 2026 | No beta or early-access tags; dated changelog entries — second only to a packaging commitment on the ladder below | Bundled from the entry paid tier (₹48); no AI-credit metering published | Role-based retrieval; a choice of Zoho's own LLM in Zoho data centres or bring-your-own-key third-party models — the only model-choice option in the set | Pricing page, Zia page, changelog (r1/04; r2/01) |
| HROne | "One AI Suite", voice-led for employees; on payroll, anomaly detection only | Presented as live; the April 2025 launch date traces to the vendor alone | Not itemised on the pricing page | Not in the evidence | Vendor blog and wire (r1/04) |
| 247HRM | "11 AI features, live" | Presented as live | The only usage-metered model in the evidence — AI credits and WhatsApp messages billed from a prepaid wallet | Not in the evidence | Pricing page (r1/08, round one) |
| Darwinbox (enterprise) | Cortex, an AI-native platform; an MCP server announced September 2025 | Cortex early access since 4 August 2026; its two named design partners are not India-headquartered; MCP availability not stated | No public price | Identity and permissions preserved | Newsroom and analyst note (r1/04) |
| PeopleStrong, ZingHR (enterprise) | Multiple named agents | No dates, no availability labels | No public price | Inline source citations (PeopleStrong's ER agent) | Product pages (r1/04) |
| Frappe HR, Kredily | No AI claims found | — | — | — | r2/01 |
| Aparajitha / Simpliance | No reference to AI, machine learning or algorithmic decision-making anywhere on the site — a verified negative | — | — | — | r2/07 |

AI claims in this market come in six strengths, and a claim is only as strong as its class. The ladder orders claims, not capability — nothing on it was tested.

| Evidence class for an AI claim | What it establishes | Example |
| --- | --- | --- |
| A packaging commitment on a published price card | That the vendor has committed commercially to including it | greytHR's "NAVOS included" on every plan (EV-090) |
| A dated public changelog entry | That the vendor recorded it as shipped on a date | Zoho People's May and July 2026 entries (r1/04) |
| A press release with an explicit availability statement | A dated claim of availability | greytHR's NAVOS release of 3 June 2026 (r1/04) |
| A product page with no dates or availability labels | Presence in marketing only | HROne, PeopleStrong, ZingHR (r1/04) |
| Early access | Not generally available | Darwinbox Cortex (r1/04) |
| A waitlist | Not generally available | Keka AI (EV-090) |

Four structural findings survive across the set, all from round one's verified reading (r1/04):

- **Payroll is the least-shipped AI surface.** Keka marks payroll AI "COMING SOON"; NAVOS claims it can initiate payroll processes without claiming statutory reasoning; HROne lists anomaly detection; Zoho's 2026 changelog entries are about onboarding, files, learning and analytics. On the pages read in round one, no vendor in the set publishes AI capability specifically for PF, ESI, PT, LWF, TDS or the Labour Codes — we are not aware of any, as of September 2026.
- **Every AI outcome metric is vendor-claimed.** Figures exist — Keka's AI helpdesk page claims classification accuracy "above 85%" against the customer's own ticket history; PeopleStrong's ER agent page claims resolution and ticket-reduction percentages — but on the pages read none carries an evaluation methodology, a sample size or third-party verification (r1/04).
- **Governance language has converged.** Role-based access, source citation and audit logging are claimed by nearly every vendor; only Keka's "no silent writes" and "no citation means no answer" are distinctive phrasings, and they describe an unreleased product.
- **Agent naming has converged** on "<Function> Agent"; neither naming nor agent count differentiates.

What this means for us, and what it does not:

- **AI cannot be the revenue line.** The market price of HR AI is zero (§13.1). Inference is the smallest of four cost lines and the earlier inference-margin claim is withdrawn (K-02; EV-088); the metered AI SKUs carry a kill criterion (§18.5; §20 V-07).
- **Governance parity is table stakes.** §12 matches Keka's five commitments and adds the structural controls the market does not publish — the redaction chokepoint and the per-employee AI disclosure record. Those controls are described to customers as what the product does, never as a comparison with a named vendor's internals.
- **[Hypothesis]** The one AI position no vendor in the evidence occupies is statutory reasoning that cites the rule version and its capture — an answer about a PT slab or an ECR rejection grounded in the effective-dated rule object (§14) rather than in a policy document. Kill/validate: extend §20 V-07's instrument to ask which assistant capability buyers would pay for or prefer; if statutory reasoning is not preferred over a general HR assistant, it stays a product feature and is never a positioning claim.

### 21.10 Enterprise adjacency and the services layer

#### Enterprise adjacency — outside the set, and why

| Vendor | What the evidence shows | Why it is outside the competitive set | Where it re-enters | Source |
| --- | --- | --- | --- | --- |
| Ramco | HR & Payroll business-unit revenue ₹2,976.15 Mn in FY2025-26, up 30.8%; India revenue across *all* business units ₹1,329.96 Mn; the standalone Indian entity's India-geography revenue ₹1,127.51 Mn. A single Ind AS 108 operating segment, so India HR revenue is not separable. 500+ payroll customers globally and 18 new enterprise customers in the year; "15–20 country go-lives per quarter" (quote the range) | Enterprise multi-country payroll; no published price; "Let's Talk" calls to action | A calibration row for sizing (§04.4); an expansion-band and v3 competitor (§05.10) | EV-033; EV-092; r5/03 |
| ZingHR | Titled "Enterprise HCM for the End of Transactional HR"; no rupee character on its homepage; its pricing URL returns 404; claims 1,200+ enterprises; an AI brand, GHROWTH | Enterprise, sold by vertical, no price | §04.4's filed-revenue scoreboard; the 1,000+ band (§05.10) | EV-033; r5/03 |
| Darwinbox | No public price (pricing URLs return 404); majority of revenue from outside India as of March 2025; targets companies of 3,000+ employees; Cortex in early access | Enterprise procurement is closed to a new entrant for about three years (§05.2) | The 1,000+ band and v3 | r1/08; r1/04 — round one |
| PeopleStrong | No public price; enterprise; a controlling stake reported acquired by Goldman Sachs' alternatives arm in April 2025 | As above | As above | r1/08 — round one |
| HONO | "The world's first headless HRMS - run your people operations on a single conversation"; named agents; an enterprise logo list; aggregator-reported revenue band only | Enterprise; occupies the agentic narrative, not our band | Watch — AI positioning only | r2/07 |

Enterprise adjacency is not ignored; it is sequenced. These vendors set the documentary bar — certifications, references, residency — that §05.2 says a new entrant cannot clear for roughly three years, and they are the competitors when a tenant graduates past 1,000 employees (§05.10). None of their figures is used in a beachhead comparison.

#### MYND and Qandle — the nearest occupant of the filing corner

MYND Integrated Solutions acquired Qandle in April 2025; MYND's own announcement is dated 17 April 2025 and Qandle's site footer now reads "Copyright@ 2026 MYND" (EV-034; r5/03). MYND describes itself as a finance-and-accounting and HR outsourcing provider (r5/03). The result is the only bundle in the evidence that pairs a self-serve HRMS with an outsourced filing operation — and the operation is unpriced and sold by demo (EV-030). Qandle's own card shows the join: its advisory add-ons, including "Compliance Assistance" and "Payroll Advisory" (which describes outsourced verification of proofs and "complete payroll processing"), carry no published price (r5/03).

Three observable changes would move MYND from adjacency into the corner, and each is a capture trigger (§21.13): a priced filing or compliance add-on on Qandle's published card; MYND marketing a filing service to employers of 20–200; or Qandle's config file acquiring values for the advisory add-ons that then render on the page. Unrendered config values do not count — the file already holds some that never render, and they must not be quoted as prices (r5/03).

#### The services layer — channel, benchmark, partner

| Actor | What it does today | How we treat it | Source |
| --- | --- | --- | --- |
| CAs and payroll bureaus | Prepare and submit returns for employers; the monthly retainer is the budget line | A channel and a price anchor, never a target to displace (§18.7); indicative fee band unvalidated (§20 V-01) | r2/05; §18.1 |
| MYND | Outsourced payroll and compliance operations, now with Qandle | Watch — see above | EV-034 |
| Aparajitha / Simpliance | A compliance organisation with 1,500+ staff, 1,700+ clients and presence in 25 states, fused with Simpliance's software (labour-law compliance, regulatory compliance management, vendor compliance, audit, and a payroll/remittance product); SOC 2 Type 2 and ISO/IEC 27001:2022; no AI claim anywhere on its site. It bought 76% of Simpliance at an enterprise value of ₹120 crore — dated 2022 on the release's own internal evidence | Partner or acquisition candidate, not a competitor. The open question that decides a partnership is whether Simpliance exposes a usable API (CQ-14) | r2/07 |
| TeamLease | Staffing and compliance services; its HCM business manages over 3.5 lakh monthly employee records; it impaired its own HR-technology subsidiary by ₹6.4 crore in FY26 | Evidence, not a competitor: distribution, capital and compliance depth did not suffice to build HR software; and compliance services run at low single-digit segment margins (§21.7) | r2/07 |

#### Competitors in the channel — who else courts the CA and the partner

Our go-to-market leans on the CA and partner channel (§18.7, §18.8), and so do most competitors. The CA console is **not** an unmatched wedge: Kredily runs a dedicated CA programme on a multi-company console, and greytHR runs multi-client tooling for payroll service providers. What remains distinct is what the console *does* — carry filings to portal acceptance under the client's written authority — not that a console exists.

| Vendor | Channel programmes | Multi-client console for CAs or PSPs | Commission published? | Source |
| --- | --- | --- | --- | --- |
| Kredily | Two separate accountant-side programmes: a Partner Program for payroll service providers, with white-label; a CA Program for chartered accountants managing compliance for their client book | Yes — "Run payroll for every client, from one dashboard": one login across clients, per-client roles, a compliance command centre tracking PF, ESI, PT and TDS across all clients "with Form 16 & 24Q generated", a role-gated AI copilot, delivery under the practice's brand | No — clients land on the free plan and monetise when they need payouts, challans or Form 16 | r3/03 |
| greytHR | Reseller and Alliance tracks (the alliance track mostly banks and card networks); a Payroll Service Provider landing page claiming "1000+ Payroll Service Providers", which round three classed as a demo-capture page, not a programme page; a login-gated partner portal whose partner types could not be read | Yes — PSP tooling with single-click logins across client accounts, centralised control, audit trails, role-based access and MFA | No | r3/03; r1/08 |
| Keka | Reseller, Referral, Integration and Solution tracks; the programme is titled for HR and payroll consultants | Not in the evidence | No — resellers are paid on the first 12 months of billing and on renewal; Keka co-sells a new reseller's first five deals | r3/03; r1/08 |
| Zimyo | Two referral tiers; recruits freelancers, HR professionals, payroll specialists, tax consultants and financial advisors by name | Not in the evidence | Yes — "upto 20%" and "upto 30%" by monthly referrals, the only Indian HRMS vendor found publishing a rate | r3/03 |
| Zoho | Affiliate programme; Consulting Partner and reseller tracks; a Payroll Partnership Program | Not in the evidence | Affiliate only — 15% for the first 12 months at the standard tier, rising to 18% and 20%; consulting and reseller margins unpublished | r3/03; r1/08 |
| factoHR | Six partner categories, including CA/tax consultants and Tally/CRM/ERP resellers | Not in the evidence | No | r3/03 |
| HROne | Alliance Partner and Business Partner tracks | Not in the evidence | No | r3/03 |
| TallyPrime | Four partner grades; the public locator listed 1,257 partners; a separate CA Community | Not applicable — the CA works inside each client's Tally | No margins or terms published | r3/03 |
| Darwinbox | Technology and marketplace partnering only | Not in the evidence | No | r3/03 |

Three consequences. First, **the CA channel is contested, and one competitor already reaches it on a zero-price land model** — Kredily's CA programme puts every client on the free plan and monetises on outputs, which is exactly where a CA's clients cross from calculation into filing. Our console competes on the stage Kredily's does not reach: attended submission with the employer's approval inside it (§21.7). Second, **none of the programmes read publishes the economics that would tell us what a CA expects**, except Zimyo's referral percentages and Zoho's affiliate rates (r3/03); §20 V-05 exists to find out, and no figure here is a benchmark for our own terms. Third, **greytHR's bank alliances are a channel we cannot match and should not try to** — the response is bank-neutral payout files and partnership, not a rival alliance programme (CRS-05). The review-marketplace channel has also consolidated: G2 acquired Capterra, GetApp and Software Advice, closing on 5 February 2026 (r3/03) — one counterparty where there were four, which §18 prices as a channel, not this section.

#### Also outside the set

- **Odoo** is not a price floor for Indian payroll: India is not an official Odoo payroll localisation, and Indian payroll on Odoo means one of four third-party modules from single publishers across different Odoo versions, sold for one-time fees, with no statutory-maintenance obligation (r2/01). For a buyer that is a compliance liability, not a cheap substitute — and a migration source if one appears.
- **Rippling** is scaling in India as an engineering presence, not as a domestic HRMS go-to-market (r1/08 — round one).
- **Employer-of-record providers** solve a different problem — employing people in India on a foreign company's behalf — and are out of scope.

### 21.11 Competitive-response scenarios

The field will not hold still, and the moment a competitor moves is the wrong moment to decide what to do about it. Each scenario below has an observable trigger that a named person can watch for, the evidence that makes it plausible, what it breaks and what survives, a pre-agreed response, and what we will not do. Probabilities are deliberately not assigned — the evidence supports plausibility, not likelihood, and an invented percentage would be the fabricated precision this PRD exists to avoid. Each scenario's §20.8 risk row is given in its heading; the reconciliation with §20 is the table at the end of this subsection.

#### CRS-01 — Zoho widens its free gates (§20.8 R-1)

| Element | Content |
| --- | --- |
| Trigger | Zoho Payroll's pricing page raises its free ceiling above 10 employees, or its Standard tier's included seats above 25; or Zoho People raises its free cap above 5 users |
| Why plausible | Zoho already runs three size-gated India free tiers — Payroll to 10 employees, People to 5 users, and Books below ₹25 lakh of revenue, indefinitely — bundles AI from its ₹48 tier, and sells a suite bundle; dropping HR prices is a transfer between its own products (r2/01 — an inference from pricing behaviour) |
| What it breaks | The bottom of the beachhead gets zero-priced computation *and* Zoho's free declaration and HSBC-payout features; the "structurally overcharged 20–50" argument no longer applies against Zoho, though it still applies against the six; the paid band re-centres on 50–200 (§04.4) |
| What survives | Attended submission and the SLA, which Zoho does not sell; the CA console; maintained multi-state rules; the registration model priced openly (§18.3) — Zoho licenses payroll per legal entity (r1/08), so an honest multi-entity comparison counts Zoho's licences, not its headline; the Zoho importer as a switching path |
| Pre-agreed response | Move the commercial floor to 50 (§18.10, H-P8); lean on attended submission and the CA console (§20.8 R-1); keep our Free tier generous and gated at the EPF line |
| We will not | Follow Zoho to ₹0 on the File tier; claim feature advantage over Zoho on computation — **[Killed]** as a differentiator (§04.5) |
| Owner | GTM |

#### CRS-02 — Zoho adds submission or a compliance guarantee (§20.8 R-35)

| Element | Content |
| --- | --- |
| Trigger | Zoho Payroll's pages add submission, e-filing or an SLA or remedy term; its payroll partner programme markets filing as a service |
| Why plausible | Zoho already occupies artefact generation — form generation with a digital signature and TDS challan recording at ₹1,000 a month (r2/01) — and publishes a payroll partner programme (r1/08). Submission is one stage further along the same chain (§21.7) |
| What it breaks | Attended submission stops being unmatched against Zoho, the one actor in the evidence with an installed base across accounting and payroll (§21.6); the argument against Zoho narrows to maintenance quality and the channel |
| What survives | The CA console; maintained multi-state rules under a per-tenant SLA; a registration allowance priced openly on the card (§18.3) against Zoho's per-entity licences (r1/08); deskless attendance and the Form IX time model (§09) |
| Pre-agreed response | Compete on measured execution — the on-time accepted filing metric and its published definition (§19.1) — and on CA-channel depth; bring forward the SLA evidence pack |
| We will not | Claim Zoho's submission is inferior without an executed, dated comparison that has cleared §21.12 |
| Owner | Founder / GTM |

#### CRS-03 — Keka re-publishes a price, cuts it, or moves India to per-employee pricing (§20.8 R-9)

| Element | Content |
| --- | --- |
| Trigger | The commented-out spans on Keka's pricing page become live; its small-companies floor changes; an India card appears in the per-employee shape of its withdrawn US card |
| Why plausible | The withdrawn US card was pure per-employee (EV-024); the live small-business page already quotes "₹90 per employee/month" (EV-023); whether India is migrating is open (r5/03) |
| What it breaks | "Keka does not publish a price" stops being true; if the new card has no block, the 20-employee overcharge against Keka disappears |
| What survives | Attended submission; maintained multi-state rules; published renewal and setup terms of our own (§18.13); the 50-seat floor argument against the other five |
| Pre-agreed response | Re-capture within the capture window; re-run the §21.4 tables; withdraw any collateral built on Keka's opacity (CLR-11); keep the argument on structure and submission |
| We will not | Chase Keka's level; quote the archived card as current |
| Owner | Research, then GTM |

#### CRS-04 — Keka AI, or payroll AI anywhere in the set, becomes generally available

| Element | Content |
| --- | --- |
| Trigger | "Join the waitlist" disappears from Keka's AI page; the "COMING SOON" badge leaves Payroll; any vendor publishes AI for PF, ESI, PT, LWF or TDS |
| Why plausible | Keka has published its surfaces and governance commitments already (EV-090); payroll AI is the least-shipped surface in the set (r1/04) |
| What it breaks | Nothing in the revenue plan — AI is cost, not the revenue line (§13.1). The claim-posture table (§21.9) changes |
| What survives | Everything — no wedge rests on AI presence |
| Pre-agreed response | Re-capture; re-confirm governance parity (§12); if a vendor ships statutory AI, test the §21.9 hypothesis against it before any positioning |
| We will not | Position on AI presence or agent count |
| Owner | Product |

#### CRS-05 — A fintech subsidises an HRMS to win the payroll-to-bank flow (§20.8 R-6)

| Element | Content |
| --- | --- |
| Trigger | A neobank, card issuer or payments company acquires an HRMS or launches a zero-priced payroll product with salary payout as the funnel; or a bank bundles an HRMS free with salary accounts |
| Why plausible | Jupiter acquired sumHR to source salary accounts — the deal date is unsettled in the evidence: round two gives February 2023, while round one read the February 2023 report as describing an acquisition "last year", i.e. 2022 (r2/02; r1/01), and CQ-19 carries it; a consideration of ₹7.5 crore for 100% is reported second-hand from reporting on Jupiter's FY23 filings and is not confirmed against MCA (r2/02 — low confidence). RazorpayX Payroll sits inside a payments company (r1/08). greytHR's alliance partners are mostly banks and card networks (r3/03). Zaggle, whose platform fees are about 2% of its gross revenue, is buying software businesses for their margin (r2/02) |
| What it breaks | Price as an argument at the bottom of the band; bank-bundled payout convenience |
| What survives | Attended submission, maintained rules, multi-state coverage, the switching cost of a filing-critical system, and bank-neutral payout files (§16.3) |
| Pre-agreed response | Defend on submission, the SLA and switching cost; stay bank-neutral and partner with banks on payout rather than compete for the account; treat the precedent's cheap valuation as an option on partnership, not a plan (r2/02) |
| We will not | Offer a free HRMS monetised on interchange or float (§18.17) |
| Owner | Founder |

#### CRS-06 — greytHR, or another priced vendor, adds submission (§20.8 R-36)

| Element | Content |
| --- | --- |
| Trigger | greytHR's payroll page adds submission or filing language; its Payroll Service Provider page markets filing to employers; any of the six adds a filing SKU |
| Why plausible | greytHR is the most compliance-forward of the six — Form 24Q generation with FVU validation (EV-030) — and already has PSP multi-client tooling and bank alliances (r1/08; r3/03) |
| What it breaks | EV-030's null: attended submission is no longer unmatched in the priced set |
| What survives | No seat floor (greytHR's base buys 50); maintained multi-state rules under contract; published all-in terms. The CA console survives only where it out-performs greytHR's existing PSP tooling — to be earned, not assumed (§21.10) |
| Pre-agreed response | The wedge narrows to execution quality, no seat floor and CA-channel depth — the "single falsifiable risk" §04.4 names. Publish measured on-time acceptance (§19.1) as the proof |
| We will not | Dispute the competitor's submission capability without an executed, dated comparison |
| Owner | GTM |

#### CRS-07 — MYND prices and self-serves its filing operation for 20–200 (§20.8 R-37)

| Element | Content |
| --- | --- |
| Trigger | A priced filing or compliance add-on appears on Qandle's published card; MYND markets a filing service to employers of 20–200 |
| Why plausible | MYND owns Qandle and runs payroll and compliance outsourcing (EV-034); Qandle already lists "Compliance Assistance" and "Payroll Advisory" as unpriced add-ons (r5/03) |
| What it breaks | The corner is occupied by a bundle, not a service beside an HRMS |
| What survives | No seat floor (Qandle's base buys 50); a product-led submission workflow with the employer's approval inside it, against an outsourced service; maintained multi-state rules; the CA console |
| Pre-agreed response | As CRS-06 |
| We will not | Characterise MYND's service quality |
| Owner | GTM |

#### CRS-08 — The Tally ecosystem closes the PT/LWF gap (§20.8 R-38)

| Element | Content |
| --- | --- |
| Trigger | A named TDL add-on for state PT or LWF; or a TallyPrime release note adding a state slab table or an LWF engine |
| Why plausible | Add-ons are cheap to build and sell — observed prices run from ₹354 to ₹4,999 (r5/01) |
| What it breaks | PAR-15 and PAR-17 become parity against Tally |
| What survives | Maintained content under SLA; attended submission; leave-to-payroll; multi-user access without a Gold licence; the employee surface only if the open Tally ESS cell closes as a gap (CLR-15) |
| Pre-agreed response | Verify the named product directly — never re-run the sweep on a rumour (r5/01); move the Tally conversation to maintenance and submission; keep "attach, never replace" |
| We will not | Sell against the partner's licence revenue (§18.8) |
| Owner | Research, then GTM |

#### CRS-09 — Frappe, or a Frappe partner app, ships the Indian statutory layer (§20.8 R-7)

| Element | Content |
| --- | --- |
| Trigger | A Frappe HR release, a marketplace app or the resolution of CQ-05 shows state PT, LWF, ECR or 24Q/138 logic in code |
| Why plausible | Frappe's own product page already describes such a layer (r2/01 — unreconciled with the source trees, §21.3); it has a partner channel (vendor-reported) and a low-burn funding history that puts it under no pressure to raise prices (r2/01) |
| What it breaks | PAR-10, PAR-15, PAR-17 and PAR-19 move to parity against Frappe at a ₹0 licence |
| What survives | The maintenance obligation under contract, attended submission and a support SLA — the things an open-source project does not contract to provide (§20.8 R-7) |
| Pre-agreed response | Re-read the release branch the customer would install; the bake-off moves entirely to maintenance, submission and the SLA |
| We will not | Claim "more complete India compliance" (§20.8 R-7) |
| Owner | Research, then GTM |

#### CRS-10 — A priced vendor drops its 50-seat block (§20.8 R-39)

| Element | Content |
| --- | --- |
| Trigger | Any of the six changes its base block, or publishes a price for a sub-50 route — HROne's startup programme or greytHR's FLEXIBLE START |
| Why plausible | Both routes already exist unpriced (r5/03); greytHR's slider already quotes from 10 employees (r5/03) |
| What it breaks | The no-seat-floor wedge against that vendor (§18.2 P6) |
| What survives | A published, all-in card; attended submission; maintained multi-state rules |
| Pre-agreed response | Re-capture; withdraw seat-floor claims for that vendor inside the withdrawal window (CLR-11); watch H-P14 (§18.16) for whether 20–50 stays winnable |
| We will not | Keep using the claim after the card changes |
| Owner | Research, then GTM |

#### CRS-11 — greytHR cuts its price or widens the seats its base includes (§20.8 R-40)

| Element | Content |
| --- | --- |
| Trigger | greytHR Essential's base falls below ₹2,495 a month, its per-employee rate below ₹45, or its base covers more than 50 employees |
| Why plausible | greytHR already sets the value floor at 50 employees with Qandle (EV-027), already quotes below 50 on its slider (r5/03), and holds a bank-alliance and PSP channel that lowers its acquisition cost (r3/03; r1/08) |
| What it breaks | The value-floor anchor moves down, and the distance between the floor and our target inside the clearing band widens (§18.3) |
| What survives | Attended submission, maintained multi-state rules and the SLA; the no-seat-floor wedge unless the base shrinks below 50 (then CRS-10 applies) |
| Pre-agreed response | Re-run §21.4; revisit where our price sits between the anchors only on realised-price evidence (§20 V-03), never on a competitor's list move alone |
| We will not | Match a list-price cut; describe a greytHR price change as a sign of distress |
| Owner | GTM |

#### CRS-12 — A vendor publishes a free tier that reaches 20 employees or more (§20.8 R-41)

| Element | Content |
| --- | --- |
| Trigger | Any vendor's published card offers a free tier with statutory computation at 20 employees or above |
| Why plausible | factoHR published a free tier to 20 employees in the round-one capture (r1/08); Zoho's free payroll tier stops at 10 and could widen (CRS-01) |
| What it breaks | Our Free-to-File boundary at the EPF line is no longer the only free boundary there; conversion at 20 meets a free alternative |
| What survives | Attended submission and the SLA — nobody in the evidence gives either away; maintained multi-state rules. A free tier with a CA console already exists (Kredily, §21.10), so the console is not a survivor on its own |
| Pre-agreed response | Keep File's value on submission and the SLA; do not move our gate below the EPF line; re-capture factoHR's tier (CQ-15) and, if its scope has widened to statutory computation, re-state §18.4's "combination at the line" claim against it |
| We will not | Extend our Free tier to include attended submission |
| Owner | GTM |

#### Which wedges survive which move

The matrix reads across: for each scenario, whether each of our wedges holds, narrows, or is lost against the vendor that moved. "Lost" is always *against that vendor*, never against the field.

| Scenario | No seat floor | Published all-in card | Attended submission | Multi-state PT/LWF maintained | CA console | Importers | Format-break coverage (SLA) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CRS-01 Zoho widens free gates | Narrows | Holds | Holds | Holds | Holds | Holds | Holds |
| CRS-02 Zoho adds submission | Holds | Holds | Narrows | Holds on maintenance | Holds | Holds | Narrows if it adds a guarantee |
| CRS-03 Keka re-prices | Narrows vs Keka | Narrows vs Keka | Holds | Holds | Holds | Holds | Holds |
| CRS-04 AI goes GA | Holds | Holds | Holds | Holds | Holds | Holds | Holds |
| CRS-05 Fintech subsidy | Narrows | Narrows | Holds | Holds | Holds | Holds | Holds |
| CRS-06 greytHR submits | Holds | Holds | Lost vs greytHR | Holds on maintenance | Narrows — greytHR already has PSP tooling | Holds | Holds unless it adds one |
| CRS-07 MYND self-serves | Holds | Holds | Narrows | Holds | Holds | Holds | Holds |
| CRS-08 Tally TDL closes PT/LWF | Holds | Holds | Holds | Narrows vs Tally | Holds | Holds | Holds |
| CRS-09 Frappe ships the layer | Holds | Holds | Holds | Lost vs Frappe on coverage | Holds | Holds | Holds |
| CRS-10 Seat block dropped | Lost vs that vendor | Holds | Holds | Holds | Holds | Holds | Holds |
| CRS-11 greytHR cuts price | Holds, unless the base shrinks | Holds | Holds | Holds | Holds | Holds | Holds |
| CRS-12 Free tier reaches 20 | Narrows | Holds | Holds | Holds | Holds | Holds | Holds |

CRS-11 leaves every wedge standing and still matters, because it moves the value floor that §18.3 positions against; price level is not a wedge, but it is the frame the wedges are sold inside.

The CA-console column reads "Holds" against the vendor that moves, not against the field: Kredily's CA programme and greytHR's PSP tooling are already multi-client consoles (§21.10), so the console is a contested surface whose distinct part is the attended submission it carries.

Two readings. First, **attended submission is the most robust wedge** — only a competitor adding submission touches it — and the CA console is robust only to the extent that it carries submission; as a multi-client dashboard it is matched today (r3/03; r1/08). Second, **the dangerous case is a combination, not a single move**: one vendor that publishes a per-head card with no floor (CRS-10) *and* adds submission (CRS-06 or CRS-07) occupies the target corner outright, and the wedge collapses to execution quality alone. That combination is a whole-thesis review trigger under §20.11.

#### Watching for the triggers

The triggers are only useful if something watches them. The competitive watch is an operating capability of the research function, specified here so that it can be staffed and audited:

| Signal | Source watched | Detection method | Why this method |
| --- | --- | --- | --- |
| Price or feature change on a comment-suppressing page (Keka) | Pricing, small-companies, US and UAE pricing pages | Hash the raw page twice — with and without HTML comments — and alert on either change | Keka's material changes happen inside comments; a rendered or comment-stripped hash would miss them (EV-021, EV-028) |
| Price change on a JS-injected page (Qandle) | The vendor's pricing config file | Hash the config file; confirm by a rendered read | Raw HTML shows empty spans (r5/03) |
| Price change on a rendered page (Zimyo, Zoho) | Pricing page and, for Zoho, the pricing JSON | Rendered read; JSON hash | The page returns 403 to a non-browser fetch (Zimyo) or injects prices client-side (Zoho) |
| Terms change | Keka terms of service; pricing FAQs | Clause-level diff | Renewal and refund terms moved once already (EV-025) |
| Submission language | Payroll pages of the six, Zoho and Kredily | Term search for filing, submission, e-filing, TRACES, EPFO and SLA terms | EV-030 was established by the absence of these terms |
| AI availability | AI pages and changelogs | Waitlist and badge detection; changelog entries | EV-090 is a claim-posture record |
| Frappe statutory layer | Frappe HR and ERPNext release tags; the Frappe product page; the app marketplace | Re-run the §21.3 greps on each stable release | EV-031's re-verify trigger is each Frappe major release |
| Tally state layer | TallyPrime release notes; named TDL products | Read on each release; verify any named add-on | EV-032's re-verify trigger is each TallyPrime release |
| Acquisitions and fintech moves | Trade press and acquirer announcements | Manual watch | CRS-05 and CRS-07 turn on corporate events |

Every alert is triaged by the research owner within `competitive_alert_triage_days`, and any cleared claim it touches enters the withdrawal path (CLR-11). Both parameters are unsized and routed to §20 with the other §21 parameters (§21.14).

#### Routing to the §20 risk register

Every scenario except CRS-04 now has a §20.8 risk row: four pre-dated this section and were updated from it, and seven were registered from it (R-35 to R-41). §20 owns the register; this table is the hand-off and its reconciliation. Where a §20 row's wording and this section's differ, the scenario here governs the competitor fact and §20 governs the risk rating.

| Scenario | §20.8 row | Status of the hand-off |
| --- | --- | --- |
| CRS-01 Zoho widens its free gates | R-1 | Updated in §20: the per-entity licence point is in the response, and the residual notes that the CA console survives against Zoho only — Kredily and greytHR both run multi-client consoles (§21.10) |
| CRS-02 Zoho adds submission or a guarantee | R-35 | Registered. Open: R-35's residual describes Zoho as "the best-capitalised software competitor"; Zoho's financials are not in the evidence (§21.6), so that wording is routed back to §20 for removal (CLR-08) |
| CRS-03 Keka re-prices or moves to per-employee pricing | R-9 | Updated in §20: re-keyed off the completed V-06 capture (EV-021–EV-025) |
| CRS-04 AI goes generally available | None | Watch item only — no wedge depends on it |
| CRS-05 Fintech subsidy | R-6 | Updated in §20: the ₹7.5 crore consideration is marked second-hand and unconfirmed (r2/02; CQ-19). Open: the deal date (CQ-19) |
| CRS-06 greytHR or another priced vendor adds submission | R-36 | Registered — it removes EV-030's null |
| CRS-07 MYND self-serves its filing operation | R-37 | Registered |
| CRS-08 The Tally ecosystem closes the PT/LWF gap | R-38 | Registered, with the verify-the-named-product trigger (r5/01) |
| CRS-09 Frappe ships the statutory layer | R-7 | Updated in §20: the trigger is tied to CQ-05 and a release-branch re-read |
| CRS-10 A priced vendor drops its 50-seat block | R-39 | Registered, linked to H-P14 (§18.16) |
| CRS-11 greytHR cuts its price | R-40 | Registered |
| CRS-12 A free tier reaches 20 employees | R-41 | Registered, linked to CQ-15 |
| CRS-10 with CRS-06 or CRS-07 for one vendor | R-39 with R-36 or R-37 | Registered in §20.11 as a whole-thesis review trigger |

### 21.12 The competitor-claim clearance rule

This is the canonical statement of the rule that §01, §02.5, §04.4 and §18 each cite. **No competitor claim leaves the building without legal clearance, a dated capture of its source, and a note of whether the competitor's product was executed or only its pages, documentation or code were read** (r5 synthesis, item 18(c); r5 counsel review; §01 standing rule). The rest of this subsection makes that sentence operable.

**How legal clearance is operated.** Counsel clears at two levels, and no claim reaches a reader without one of them. First, counsel clears, once and in writing, a **phrasing template** for each claim class in the table below — the label, the scoping words and the never-say list for that class — and re-clears it whenever the template changes. Second, a named claim owner clears each *instance* against its class's counsel-cleared template. An instance that fits no cleared template, and every instance in a class the table marks "counsel", goes to counsel individually. Until counsel has cleared a class's template, every claim in that class goes to counsel individually. The template mechanism is an operating proposal of this PRD, not counsel's; whether it satisfies the clearance counsel asked for is itself a §23 item.

**Why it exists.** Round five's counsel review found flat negative assertions about named competitors framed for sales use — that a vendor's compliance calendar was wrong, that "the incumbents' own published compliance data is wrong", that TallyPrime "cannot calculate leave encashment" — sitting a few rows from the admission that neither product had been run. It identified disparagement exposure in that pattern, citing the Trade Marks Act 1999 s.29(8) read with s.30(1) and ASCI's comparative-advertising provisions for collateral (r5 counsel review). Whether and how comparative claims may be used at all is §23's analysis; statutory basis under counsel review. This section's job is to make sure no claim reaches that question uncaptured, unscoped or unowned.

**What "leaving the building" means.** Any artefact seen by someone outside the company: the website and price card, decks, battle cards, sales emails and call scripts, proposals and RFP responses, contracts and order forms, partner enablement for CAs and Tally partners, analyst and press briefings, support macros, and social posts. Extracts of this PRD shared outside the company are external artefacts — the counsel review called the PRD itself "the artefact most likely to be forwarded" (r5 counsel review).

#### The rules

| ID | Rule | Why | How a reviewer checks it |
| --- | --- | --- | --- |
| CLR-01 | Every competitor claim has a register entry: vendor, statement, claim class, evidence class, capture date, capture method, executed-or-declared label, evidence reference (EV-ID or research file), owner, expiry | Without the entry the claim cannot be re-verified or withdrawn | The artefact cites a register ID; the entry has no empty field |
| CLR-02 | Never assert that a competitor's page, documentation, data or product is "wrong", "false", "misleading" or "non-compliant". Describe what our product does and cite dated evidence | §04.4 AC-13; the disparagement exposure above | Search for the listed words next to a vendor name |
| CLR-03 | A negative claim is scoped to the artefact read ("the source trees read contain no …") or written as "we are not aware of any … as of <date>". Never "cannot", "does not support" or "has no" | Absence was read, not proven; unprovable negatives are a §23 item | Every negative claim names its artefact or its date |
| CLR-04 | Quote a vendor's own qualifier in full; never truncate it | The truncated Tally leave-encashment FAQ is the worked failure (§21.3) | Quotes match the capture verbatim, including the following sentence where it qualifies |
| CLR-05 | Prices come only from the vendor's own page — raw, rendered, and its config file where prices are injected — or, labelled "archived", from an archive of that page. State the normalisation: headcount, tier, billing cadence, ex-GST, list not realised. Never take a price from another vendor's comparison page. A claim that we are "cheaper" computes both monthly bills at the stated headcount from the dated cards and is made only where ours is lower (§04.4 AC-17) | Pocket HRMS's FAQ gives greytHR's entry price as ₹3,495 against greytHR's own ₹2,495 (r1/08; r5/03); list is not realised (§20 V-03) | The price cites its normalisation and capture; no third-party source |
| CLR-06 | Scope every claim to the set it was measured on. The seat-floor finding and the submission null are statements about the six-vendor priced set. Never generalise to "the market", "no one", "only us" or "first" | Per-user and per-employee structures exist outside the six (§21.4); the services layer files (§21.7) | No universal quantifier without a named set |
| CLR-07 | AI claims are claim posture only. Never state a competitor's AI capability or its absence as fact; never position on AI presence | EV-090 is claim posture, not tested | AI statements carry "as presented on <page>, <date>" |
| CLR-08 | Financial facts are filed figures with entity and period only — no evaluative adjectives ("barely", "burning", "loss-making giant") | The counsel review flagged characterisations of named private companies' financials (r5 counsel review) | Adjectives next to a financial figure are removed |
| CLR-09 | Customer counts appear only as "claims", with the capture date, and never as a share figure without that date | K-16; counts are inconsistent on the same vendor's own pages (EV-091; r5/03) | Count, "claims" and date travel together |
| CLR-10 | A claim is used externally only if its capture is younger than `competitor_claim_max_capture_age_days`, and it is re-captured before its first external use | Captures decay; pages change | The capture date is inside the window on the day of use |
| CLR-11 | When a source changes or a capture expires, the claim is withdrawn or re-cleared within `competitor_claim_withdrawal_window_days`, everywhere it appears | One register entry, many artefacts | The register lists every artefact carrying the claim |
| CLR-12 | Tally claims are framed as complementary — the layer we add, never "switch off Tally" | Channel conflict with Tally partners (§18.8) | Tally copy passes the §18.8 channel check |
| CLR-13 | Every claim carries legal clearance — through its class's counsel-cleared template or individually. Any claim that a competitor's output is legally deficient, and any comparative advertisement, is cleared by counsel individually before use | Legal claims are product surface with a named owner (§23) | Counsel's clearance is recorded on the entry |
| CLR-14 | An "observed in product" claim needs an execution record — build or tenant, date, steps, the person who ran it and the captured output — and still passes CLR-02 and CLR-03 | Executed evidence is stronger, not exempt | The record is attached to the entry |
| CLR-15 | The four unresolved cells (§21.3) are never stated in either direction until closed | EV-032 | No artefact asserts Tally ESS, Tally form currency, Frappe tax correctness or a Tally PT/LWF add-on |
| CLR-16 | Killed and banned figures never appear — the ~₹99 "Keka price", "Keka renews below list", the ₹45–50 ceiling, Frappe's state coverage | §20.4; EV-K20, EV-K28 | The §20.4 list is run against the artefact |

#### Claim classes

| Class | Example | Allowed evidence | Label it must carry | Clearance | Re-capture trigger |
| --- | --- | --- | --- | --- | --- |
| Price | "greytHR Essential is ₹2,495 a month including 50 employees" | The vendor's own page | "List price, ex-GST, captured <date>" | Claim owner, on the counsel-cleared template | Any change on the page; the capture window |
| Price structure | "None of the six vendors in our priced set bills below a 50-employee block on its published card" | The six rate cards | "Published cards, captured <date>" | Claim owner, on the counsel-cleared template | Any rate-card change among the six |
| Capability present | "TallyPrime ships Form 24Q annexures" | Product documentation | "Per TallyPrime documentation, read <date>" | Claim owner, on the counsel-cleared template | Each TallyPrime release |
| Capability absent | "The Frappe HR v16 source trees read contain no ECR generator" | Source repository | "Source read at tag <tag>, <date>" | Counsel, per instance | Each Frappe major release |
| Commercial terms | "Keka's terms of service, clause 15, say renewal fees are subject to an increase" | The vendor's terms | "Clause <n>, captured <date>" | Counsel, per instance | Any change to the terms |
| AI | "greytHR includes NAVOS in every plan" | Pricing or product page | "Claim posture, not tested, <date>" | Claim owner, on the counsel-cleared template | The capture window |
| Financial | A vendor's filed revenue | MCA/ROC filing or audited report | "Filed, <entity>, <period>" | Claim owner, on the counsel-cleared template | The next filing |
| Legal-comparative | "Vendor X's calendar shows the wrong due date" | — | Not permitted | — | — |

#### Worked examples

| Draft statement | Verdict | Cleared form |
| --- | --- | --- |
| "Frappe has no PT." | Fails CLR-03 | "The Frappe HR v16, ERPNext v16 and india-compliance source trees, read in September 2026, contain no state PT slab table. We ship and maintain one per state." |
| "Frappe's website is wrong about its state coverage." | Fails CLR-02 | Not said, in any form |
| "Tally can't calculate leave encashment." | Fails CLR-04 | "TallyPrime's FAQ says the leave-encashment amount cannot be calculated in its payroll module, and that an amount calculated outside payroll can be carried, with its PF, ESI and PT effects managed. We compute it from the leave ledger." |
| "Nobody else files your returns." | Fails CLR-06 | "No vendor in our six-vendor priced set claims, on its pages as read in September 2026, to submit a statutory return. We carry yours through attended, assisted submission under your written authority; the liability stays with you." — the second sentence only after counsel clears attended filing (§23) |
| "We're cheaper than greytHR." | Fails CLR-05 and §04.4 AC-17 — whether it is true depends on our unpublished card and the headcount; on §04.4's arithmetic a no-floor card anywhere in the ₹80–150 hypothesis undercuts greytHR's block only up to roughly 16–31 employees | "At 20 employees, greytHR's published Essential card (captured <date>) bills a base of ₹2,495 a month covering 50 employees; we bill your actual headcount." — usable only with our own card published |
| "Keka renews below list." | **[Killed]** (K-17) | Not said |
| "Keka has no AI." | Fails CLR-07 | Omit; if asked: "Keka's AI page showed a waitlist when we captured it on <date>." |
| "Zoho charges for salary payouts." | False for Zoho's HSBC route (r2/01) | "Zoho Payroll's free tier lists salary payments through HSBC; its statutory form generation is in the paid tier (captured <date>)." |
| "No HRMS bills from employee one." | Fails CLR-06 | "None of the six vendors in our priced set bills below a 50-employee block on its published card." |
| "greytHR has 34,000 customers." | **[Killed]** (K-16) — superseded and undated | "greytHR claims 30,000+ companies (captured <date>)." |
| "Keka is loss-making and burning cash." | Fails CLR-08 | Filed figures with entity and period, or omit |
| "Tally has no employee self-service." | Fails CLR-15 | Not said until the cell is closed |
| "Keka's price is ₹99 per employee." | Banned (§20.4) | Not said |

#### The §18.11 battle cards, traced to their evidence

Every battle card in §18.11 rests on competitor facts held here. None may be used until each fact it carries has a register entry (CLR-01) and has cleared.

| §18.11 card | Competitor facts the response uses | Evidence | Claim classes | Open point before use |
| --- | --- | --- | --- | --- |
| "Kredily is free forever." | Free at unlimited headcount; payouts, PF/ESI challans, Form 12BB/124 and Form 16/130 are paid | EV-029; CAP-17 | Price; capability present | None beyond clearance |
| "Zoho does all this for ~₹2,000." | Zoho Payroll at 50 employees is about ₹2,000 a month at list (₹1,000 including 25, plus 25 × ₹40); calculation parity | r2/01; CAP-15 | Price | State the normalisation (annual billing, ex-GST) and, for multi-entity groups, the per-entity licence (CLR-05) |
| "Frappe is free and open-source." | Gross-to-net genuinely strong; statutory artefacts absent from the trees read | EV-031; CAP-18 | Capability present; capability absent | Negative claims need counsel (claim-class table); CQ-05 must be noted internally |
| "We already own Tally." | Tally ships the central artefacts; no state PT slab table, no LWF engine, no leave module | EV-032; CAP-21 | Capability present; capability absent | Frame as complementary (CLR-12); the currency cell stays silent (CLR-15) |
| "Keka starts at ₹90." | The small-companies floor; no live price on the pricing page; ₹349.95 effective at 20 employees | EV-021; EV-023; EV-027 | Price | State that the block behind ₹6,999 is unknown (CQ-01) |
| "Our CA already handles all this." | None — no competitor fact | — | — | — |

<!-- DIAGRAM: competitive-landscape-claim-clearance -->

#### The claim register — lifecycle

The register is the single place a claim is created, cleared, used and withdrawn. It is an internal operating record, not a product feature. Each entry moves through five states.

| From | Event | Guard | Side effect | Who may trigger |
| --- | --- | --- | --- | --- |
| — | Draft | Statement, vendor and intended artefact recorded | Entry created in DRAFT | Any author |
| DRAFT | Captured | Capture meets §02.5 and CLR-05; executed-or-declared label set | Evidence attached; state CAPTURED | Research |
| CAPTURED | Cleared | CLR-02 to CLR-09 and CLR-12 to CLR-16 pass; the instance fits a counsel-cleared template for its class, or counsel's individual clearance is recorded (always for CLR-13 and counsel-per-instance classes) | Expiry computed from `competitor_claim_max_capture_age_days`; state CLEARED | Named claim owner against a counsel-cleared template; counsel for everything else |
| CLEARED | Published | Capture still inside its window on the day of use | Artefact linked to the entry; state PUBLISHED | Author, with the owner's clearance on record |
| PUBLISHED | Source changed or expired | A watch alert (§21.11) or the expiry date | Every linked artefact flagged; state WITHDRAWN until re-cleared | Research, or automatically on expiry |
| WITHDRAWN | Re-cleared | Fresh capture; the rules re-run; the class template is still counsel-cleared, or counsel re-clears the instance | State CLEARED; artefacts may be re-published | Named claim owner, or counsel as on first clearance |

A claim is never deleted — a withdrawn claim and the reason it was withdrawn are kept, for the same reason the PRD keeps its [Killed] rows: so the claim cannot quietly return.

#### Who does what

The rule names roles, not people; §20 and the org plan (§22) assign the people. One person may hold two roles except where the table says otherwise — the same dual-control logic §02.5 applies to grading.

| Role | Responsibility | May not |
| --- | --- | --- |
| Author | Drafts the claim for a named artefact; links the artefact to the register entry | Clear their own claim |
| Capture researcher | Captures the source under §02.5 and CLR-05; sets the executed-or-declared label; runs the §21.11 watch | Clear a claim they captured |
| Claim owner | A named individual per claim class who applies CLR-02 to CLR-16 and clears or rejects instances against the class's counsel-cleared template | Clear an instance that fits no cleared template, or any counsel-per-instance class |
| Counsel | Clears the phrasing template for every claim class; clears individually every CLR-13 claim, every capability-absent and commercial-terms claim, and every instance outside a template; owns the comparative-advertising question (§23) | — |
| Auditor | Runs the periodic sample (`competitor_claim_audit_sample_size`) and reports gaps | Audit claims they authored or cleared |

#### Acceptance tests for the rule

- **Given** a battle-card row whose capture is older than `competitor_claim_max_capture_age_days`, **when** it is exported for a customer conversation, **then** the export is blocked and the row is routed for re-capture.
- **Given** a watch alert on a vendor page (§21.11), **when** it is triaged as a material change, **then** every published artefact carrying an affected claim is flagged within the withdrawal window, and the claim returns to WITHDRAWN.
- **Given** a draft containing "only", "no one", "first" or "the market" next to a competitor fact, **when** it is submitted for clearance, **then** it fails CLR-06 until the set is named.
- **Given** a comparative price, **when** it lacks headcount, tier, billing cadence, GST treatment or the list-versus-realised label, **then** it fails CLR-05.
- **Given** a claim in a class whose phrasing template counsel has not cleared, **when** a claim owner attempts to clear it, **then** the clearance is refused and the claim is routed to counsel individually.
- **Given** a periodic audit, **when** `competitor_claim_audit_sample_size` published claims are sampled, **then** each has a complete register entry and a capture inside its window.

### 21.13 Capture log and re-verification schedule

The capture log is the audit trail behind every competitor fact in this section. Each row names the artefact, the method that read it, the round and date, and what forces a re-read. "Declared" means pages, documentation or source read; no row is "observed in product".

| ID | What was captured | Vendor | Evidence | Artefact handle | Method | Captured | Status | Re-verify trigger |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CAP-01 | Live pricing page — three commented price spans, zero live prices | Keka | EV-021 | keka.com/pricing | Raw fetch with comment-node scan | 5 Sep 2026 (r5); 4 Sep 2026 (r1) | Declared | Any change, hashed with and without comments |
| CAP-02 | Withdrawn India card and Hiring prices | Keka | EV-022 | Wayback snapshot of keka.com/pricing, 1 Aug 2024 | Archive, parsed | r5 | Declared, frozen | None — historical |
| CAP-03 | Small-business floor and FAQ | Keka | EV-023 | keka.com/small-companies | Raw fetch | 5 Sep 2026 | Declared | Any change |
| CAP-04 | US and UAE suppression and withdrawn cards | Keka | EV-024 | keka.com/us/pricing; keka.com/ae/pricing | Raw fetch | 5 Sep 2026 | Declared | Any change |
| CAP-05 | Setup-fee contradiction; terms clauses 1.7, 1.8, 3, 5, 15; deleted FAQ | Keka | EV-025 | keka.com/pricing; /small-companies; /terms-of-services; 2024 archive | Raw fetch; archive | 5 Sep 2026 | Declared | Any change to the terms or FAQ |
| CAP-06 | Suppressed feature blocks, including Direct Salary Payout | Keka | EV-028 | keka.com/pricing | Raw fetch with comment-boundary test | 5 Sep 2026 | Declared | Any change |
| CAP-07 | AI waitlist, badges, surfaces and governance commitments | Keka | EV-090 | keka.com/keka-ai | Raw fetch | 5 Sep 2026 (r5); Sep 2026 (r1) | Claim posture | Waitlist or badge change |
| CAP-08 | Rate card, add-on prices, NAVOS inclusion, customer claim | greytHR | EV-027; EV-090; EV-091 | greythr.com/pricing | Rendered read and raw fetch | 4 Sep 2026 (r1); 5 Sep 2026 (r5) | Declared | Any rate-card change; carry the customer-count date on every use |
| CAP-09 | Payroll-page statutory language | greytHR | EV-030 | greythr.com/payroll-software | Rendered read; term search | 5 Sep 2026 | Declared | Biannual; any change |
| CAP-10 | Alliance partner track; PSP landing page (a demo-capture page, r3/03) | greytHR | r3/03; r1/08 | Alliance-partner page data; PSP page | Raw page-data JSON | r3; 4 Sep 2026 (r1) | Declared | Biannual |
| CAP-11 | Four-tier card, monthly and annual; Remote Screen Tracking; unpriced advisory add-ons | Qandle | EV-027 | Qandle's pricing config script and transparent-pricing page | Config file, confirmed by a rendered read | 5 Sep 2026 | Declared | Config-file hash change |
| CAP-12 | Rate card, 50-employee minimum, implementation-fee FAQ | Pocket HRMS | EV-026; EV-027 | pockethrms.com/pricing | Raw fetch | 4 Sep 2026 (r1); 5 Sep 2026 (r5) | Declared | Any change |
| CAP-13 | Rate card, minimum billing, trial | Zimyo | EV-026; EV-027 | zimyo.com/pricing | Rendered read (HTTP 403 to non-browser fetch) | 4 Sep 2026 (r1); 5 Sep 2026 (r5) | Declared | Any change |
| CAP-14 | Rate card, lock-in and setup FAQ, startup programme | HROne | EV-026; EV-027 | hrone.cloud/pricing | Raw fetch | 4 Sep 2026 (r1); 5 Sep 2026 (r5) | Declared | Any change |
| CAP-15 | Payroll tiers, free-tier features, per-entity licensing | Zoho Payroll | EV-029; r2/01; r1/08 | zoho.com/in/payroll/pricing | Rendered read and raw fetch | 4 Sep 2026 (r1); r2 | Declared | Any change to the free ceiling or included seats (CRS-01) |
| CAP-16 | People tiers, free cap, Zia inclusion, implementation fees | Zoho People | r2/01; r1/08 | zoho.com/people/zohopeople-pricing.html; Zoho's pricing JSON | Rendered read; JSON | r2; 4 Sep 2026 (r1) | Declared | Any change |
| CAP-17 | Free and paid tiers and their paywall | Kredily | EV-029 | kredily.com/pricing | Raw fetch | 4 Sep 2026 (r1); r2; r3 | Declared | Any change |
| CAP-18 | India payroll layer, state names, statutory artefacts | Frappe HR / ERPNext | EV-031 | frappe/hrms at version-16 (tag v16.17.1); frappe/erpnext version-16; resilient-tech/india-compliance | Source read and word-boundary search | r3 (Sep 2026) | Declared | Each Frappe major release |
| CAP-19 | "India Payroll Version 16" product page | Frappe | r2/01 | frappe.io/hr/india-payroll | Rendered read | r2 | Declared; unreconciled (CQ-05) | Before any use; on CQ-05 |
| CAP-20 | Cloud hosting prices, per site | Frappe | r2/01 | frappe.io/hr/pricing | Rendered read | r2 | Declared | Before any use |
| CAP-21 | PT pay head, statutory pay types, statutory reports, income-tax reports, FAQ, ECR, declarations, cloud access, integration | TallyPrime | EV-032 | help.tallysolutions.com (named pages) | Documentation read — never a search summary | r3; r5 | Declared | Each TallyPrime release |
| CAP-22 | Silver and Gold prices | TallyPrime | r3/01 | tallysolutions.com/buy-tally | Page read | r3 | Declared | Any change |
| CAP-23 | Five TDL catalogues — no payroll, PT or LWF add-on | Tally ecosystem | EV-032 | TallyShop; a 5-Star partner list; three independent catalogues | Catalogue read; site search | r5 | Declared, null | A named product (CRS-08) |
| CAP-24 | HR & Payroll and India revenue; single operating segment | Ramco | EV-033; EV-092 | Audited annual report FY2025-26 | PDF text extraction | r5 | Declared | Next annual report |
| CAP-25 | No price; enterprise positioning | ZingHR | EV-033 | zinghr.com | Raw fetch; pricing URL status | r5 | Declared | Biannual |
| CAP-26 | Acquisition of Qandle; Qandle footer | MYND / Qandle | EV-034 | MYND announcement dated 17 Apr 2025; trade press; qandle.com | Page read | r5 | Declared, event | None — frozen; watch CRS-07 |
| CAP-27 | Rate cards outside the six — factoHR, RazorpayX Payroll, 247HRM, sumHR | Various | r1/08 | Vendor pricing pages | Raw fetch | 4 Sep 2026 (r1) only | Declared, round one | Re-capture before any use (CQ-15, CQ-17) |
| CAP-28 | AI posture — NAVOS, Zia, One AI, Cortex, others | Various | EV-090; r1/04 | Press releases, changelogs, product pages | Page read | Sep 2026 (r1) | Claim posture | Biannual; CRS-04 |

**Schedule.** Three kinds of re-read, in order of precedence. A **forced re-read** happens before any first external use of a claim (CLR-10) and on any watch alert (§21.11). An **event re-read** happens on the triggers in the register — each Frappe major release (EV-031), each TallyPrime release (EV-032), each vendor rate-card change (EV-026, EV-027). A **cadence re-read** sweeps the whole set every `competitive_recapture_cadence_days`, with the EV register's biannual floor for EV-027, EV-030 and EV-090, and asks the standing completeness question — "which vendor has never been searched?" — that found greytHR missing from the mid-market dimension in round five (r5/03).

**Method rules for competitive captures,** on top of §02.5's dual capture: record the fetch tool and network with the capture, because rounds one to four mistook one tool's TLS failure for a site property (EV-K21); treat a page that shows different prices to two captures as a finding, not a tie to break (§02.5); never quote unrendered config values as prices (r5/03); and for any vendor whose material changes happen in HTML comments, keep the comment-included raw page as the evidential copy.

### 21.14 Open competitive questions and the parameters routed to §20

None of these blocks the v1 build. Each changes what sales may say, the priority of an importer, or the size of a wedge. Methods are desk work or sales conversations unless stated; the owner column names a function, and §20 assigns people, cost and elapsed time. §20 registers CQ-01 to CQ-20 as V-28 (CQ-08 as V-02; CQ-12 and CQ-14 as build and partnership decisions), and the five parameters below in §20.13.

| ID | Question | Why it matters | Method | Owner | What changes with the answer | §20 routing |
| --- | --- | --- | --- | --- | --- | --- |
| CQ-01 | What employee block does Keka's live ₹6,999 floor buy? | Precision of every Keka comparison at small headcounts | A sales quote — the plan links lead to a demo form (r5/03) | GTM | The Keka row of §21.4 | Commercial validation |
| CQ-02 | What is Keka's setup or implementation fee? | The all-in comparison | A sales quote | GTM | §21.5 terms table | Commercial validation |
| CQ-03 | When did Keka suppress its prices? | Dates the move to a sales-qualified motion | Archive snapshots on any locale — the change was global (r5/03) | Research | The Keka evidence timeline | Desk, now |
| CQ-04 | Is Keka moving India to per-employee pricing; are its AI surfaces generally available; what are its current Hiring and project-module prices? | CRS-03, CRS-04 | Watch captures; a demo | Research / GTM | §21.5; the §21.11 matrix | Desk and commercial |
| CQ-05 | What does Frappe's "India Payroll Version 16" product page describe — an artefact outside the three trees read, or copy ahead of code? | The only open item on K-01's evidence; decides CRS-09 | Follow the page's install path; search the app marketplace; read any named repository at its stable tag | Research | If code exists, PAR-10/15/17/19 move toward parity against Frappe and the pitch becomes maintenance and submission | Desk, now |
| CQ-06 | What does a Frappe partner charge to build and then maintain the Indian statutory layer? | That, not the ₹0 licence, is the real competing price (r3/01) | Partner interviews | GTM | The Frappe row of §18.1 | Commercial validation |
| CQ-07 | Does any India HRMS actually submit returns, or do all stop at generation? | Decides whether attended submission is unmatched in product or only in positioning (r5/03) | Product documentation and trial tenants for greytHR, Zoho Payroll and Keka | Research | EV-030's scope; CRS-06 | Desk and trial, now |
| CQ-08 | What share of Tally businesses run Tally payroll? | Which job-1 displacement argument and importer lead | §20 V-02 | GTM | §21.2 decision table; importer priority | Existing — V-02 |
| CQ-09 | What does Zoho Payroll's "Form 130 generation" do in the product, and how does per-entity licensing change a multi-entity comparison? | The Zoho parity line; CRS-02 | Zoho documentation; a trial | Research | §21.6 | Desk |
| CQ-10 | The four unresolved cells — Tally ESS; Frappe's income-tax engine; Tally's form currency; a Tally PT/LWF add-on | EV-032 | As set out in §21.3 | Research / statutory engineering | The parity table's four cells | Desk and trial |
| CQ-11 | What does greytHR's "FLEXIBLE START" cost, and does it break the 50-seat floor? | CRS-10 against the HRMS-job incumbent | A sales conversation | GTM | §21.4 floor table | Commercial validation |
| CQ-12 | Where does the greytHR importer sit in the named-source sequence? | §16.7 now names a greytHR export importer and sequences it after Tally; §01 shifts priority toward greytHR if Tally payroll adoption is low | Decide after CQ-08 | Product | §16.7 importer sequence | Build planning |
| CQ-13 | Are the mid-market vendors' AI features generally available in product? | §21.9 is claim posture only | Trial tenants | Research | §21.9 | Desk and trial |
| CQ-14 | Does Simpliance expose a usable API for a third-party HRMS? | Decides whether Aparajitha is a partner (r2/07) | Partner conversation | Founder | §21.10 services table | Partnership |
| CQ-15 | Does factoHR still publish a free tier to 20 employees, and what does it include? | §18.4 and CRS-12 rest on a round-one capture that no later round re-checked | Re-capture | Research | §18.4's combination-at-the-line wording; the §21.4 wider-field table; CRS-12 | Desk, now |
| CQ-16 | Is the vendor set complete? HR add-ons for SAP Business One, Microsoft Dynamics, Busy and Marg were never researched (r2/01) | Busy and Marg have deep Indian SMB accounting penetration; a bundled payroll module would change the job-1 picture | A desk sweep under §02.5 | Research | §21.1 register; §21.2 | Desk, now |
| CQ-17 | Current cards for RazorpayX Payroll, sumHR and 247HRM, and sumHR's minimum | Round-one captures only | Re-capture | Research | §21.4 wider-field table | Desk |
| CQ-18 | Kredily's free-to-paid conversion and financial position | Whether ₹0 is a durable anchor or a temporary land-grab (r2/01) | MCA filings | Research | §21.6 | Desk |
| CQ-19 | Jupiter's consideration for sumHR, the deal date (2022 or February 2023 — r1/01 and r2/02 disagree), and whether the salary-account attach worked | Calibrates CRS-05 (r2/02) | MCA filings; trade press | Research | CRS-05 | Desk |
| CQ-20 | What is the Income-tax Act 2025 successor of Form 27A, if any? | PAR-22 cannot be written in both vocabularies until it is known; the CBDT mapping held in evidence does not list it (EV-050) | Read the CBDT form mapping and the Form 138 file specification; the corrigendum check under §02.4 | Research / statutory engineering | PAR-22's form name; §08.8's artefact label | Desk, now |

#### Parameters this section introduces

Every parameter is unsized. None may be given a value in this document; §20 sizes each and records who set it and why.

| Parameter | Governs | Used in |
| --- | --- | --- |
| `competitor_claim_max_capture_age_days` | The oldest capture a claim may rely on when it is used externally | CLR-10; claim-register lifecycle |
| `competitor_claim_withdrawal_window_days` | How quickly a claim is withdrawn everywhere after its source changes or its capture expires | CLR-11; claim-register lifecycle |
| `competitive_recapture_cadence_days` | The whole-set re-sweep interval, subject to the EV register's biannual floor | §21.13 schedule |
| `competitive_alert_triage_days` | How quickly a watch alert is triaged | §21.11 watch |
| `competitor_claim_audit_sample_size` | How many published claims a periodic audit samples | §21.12 acceptance tests |

### 21.15 What this section commits other sections to

A competitive record is only useful if it changes what gets built and said. Each finding below has an owning section and a concrete consequence there; this section states the finding and its evidence, the owning section states the requirement. Where the owning section's current text and the finding diverge, the divergence is listed as open rather than silently resolved.

| §21 finding | Owning section | What it requires there | Evidence | Status |
| --- | --- | --- | --- | --- |
| Multi-state PT and LWF is greenfield in both parity comparators (PAR-15, PAR-17) | §06, §14, §22 | The gazette-sourced per-state dataset and the pipeline that maintains it; jurisdiction on the work location | EV-031; EV-032; EV-015 | Consistent |
| State PT or LWF is *claimed* by greytHR (PT), Zoho Payroll (PT and LWF) and Keka (LWF reports) | §01, §04, §18 | "Greenfield" used only about Frappe and Tally; the SaaS-field argument is maintenance, scoping and submission | r5/03; r2/01 | Open — several sections write "both incumbents" without naming them |
| The bake-off will not be won on gross-to-net | §08 | Credible parity on salary mechanics, not investment beyond it | EV-031 | Consistent |
| The central artefact set is parity with Tally | §08 | File-level parity is table stakes, not differentiation | EV-032 | Consistent |
| No seat floor — scoped to the six-vendor priced set | §18.2 P6 | Claim wording per CLR-06 | EV-026 | Consistent |
| factoHR's round-one free tier to 20 employees | §18.4 | State that the EPF-line gate is not unique and claim only the combination at that line | r1/08 | Consistent — §18.4 records it; re-capture owed (CQ-15) |
| No vendor in the six claims to submit | §19, §22 | The attended-filing operation and a published, measured on-time acceptance metric | EV-030 | Consistent |
| Filing done by people runs at services margins | §13, §22 | The supervised-minutes automation target | EV-088; r2/07 | Consistent |
| Keka's five AI governance commitments are table stakes | §12 | Match all five | EV-090 | Consistent |
| Salary payout is bank-specific across the field; Keka suppressed its wallet payout | §16.3 | File-first, bank-neutral payout templates | EV-028; r3/03; r2/01 | Consistent |
| Zoho licenses payroll per legal entity | §18.3 | Evidence that a registration-shaped price line is market-acceptable | r1/08 | Consistent |
| The HRMS-job incumbent needs a migration path | §16.7 | A greytHR export importer, with its place in the sequence revisited after §20 V-02 | K-23 | Consistent — named in §16.7; sequence open (CQ-12) |
| Payroll sits in every entry tier | §18.4 | Payroll never an upsell | EV-028 | Consistent |
| Implementation fees are the hidden line | §18.13 | ₹0 setup by default | r1/08; EV-025 | Consistent |
| Zoho's free tier includes the investment-proof workflow and HSBC payouts | §07.5 | Read Zoho's position against §21.6 before calling the declaration workflow a paid output across the freemium players | r2/01; EV-029 | Open |
| Every competitor claim clears §21.12 | §01, §02.5, §04.4, §18, §23 | One rule, one register | r5 counsel review | Consistent |
| Location tracking is monetisable, and legally unexamined | §18.5, §23 | A proportionality view before the add-on is offered | r5/03; r5 counsel review | Open |
| The CA console is contested — Kredily's CA programme and greytHR's PSP tooling are multi-client consoles | §18.7, §20.8 | Position the console on the submission it carries, not on its existence; R-1's "Zoho does not sell" is true only of Zoho | r3/03; r1/08 | Open |
