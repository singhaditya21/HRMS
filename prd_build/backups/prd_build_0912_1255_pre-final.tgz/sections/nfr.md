## 17. Non-Functional Requirements — Security, DPDP, Scale

This section specifies **how well the system must behave**, not what it does. Every
functional requirement in §07–§16 assumes the guarantees below; several would be
incorrect or non-compliant without them. Three facts make this section unusually
load-bearing for an India-first HRMS, and they are not restated per-NFR:

- **CERT-In binds from day one, not at enterprise scale (EV-062, [Verified — CERT-In
  domain]).** Six-hour incident reporting, 180 days of ICT logs retained *within Indian
  jurisdiction*, and clock sync to NIC/NPL NTP servers (CERT-In Directions No.
  20(3)/2022-CERT-In, 28.04.2022) are obligations on *every* body corporate — they apply
  to the 20-employee first customer, not only to the 2,000-seat prospect. Six hours is the
  live Indian breach clock; DPDP's timelines are not in force (K-07). Days of work now; a
  painful, un-fundable migration later if deferred.
- **The live data-protection regime is the SPDI Rules 2011, not DPDP (EV-058, EV-060).**
  DPDP's substantive provisions commence on or about 13 May 2027 (EV-058 **[Verified —
  mirror]** — pull G.S.R. 843(E) from the primary source before customer use). Until then
  the SPDI Rules require consent in writing before biometric or financial information is
  collected (r.5(1)) and restrict its cross-border transfer (r.7) (EV-060 **[Verified —
  provenance caveat]**: the text was read from a non-government copy — re-verify against a
  .gov.in copy before quoting it to a customer's counsel). This section builds to the live
  regimes and pre-stages DPDP; the legal analysis lives in §23.
- **ISO 27001:2022 has a seasoning clock (§01, §05.2, [Verified] — Indian Bank RFP).**
  Indian Bank's June 2026 RFP requires a qualifying certification — ISO 27001:2022 is one
  of four it accepts, with CMMI Level 3, ISO 20000:2018 and ISO 9001:2015 (criterion 14,
  r2/06) — to have been *held for at least one year prior to RFP publication*. Acquisition
  takes roughly 3–6 months; the seasoning adds twelve. It is also the standard SPDI r.8 names for reasonable security practices
  (EV-060). The security NFRs below are therefore written to the ISO 27001 Annex A
  control set from month zero, so the audit at month ~6 certifies a system already built
  to it — not a system retrofitted to pass.

**Numbering.** NFRs are numbered `NFR-<AREA>-###`. Each carries a **phase tag**
(P0 = beachhead launch, 20–200 seg; P1 = expansion 200–2,000; P2 = enterprise /
regulated), a one-line requirement, detail, and a **measurable target** with a
**verification method** (how we prove it in a test, an audit, or a dashboard). A
target with no way to measure it is a wish, not a requirement, and is rejected in review.
These are segment-phase tags, not §05.5's priority scale: a §17 P0 is required for the
v1 beachhead launch, P1 maps to v2 and P2 to the vision; where the two differ, §05
governs sequencing, and only the closed R1 capability list (§05.17) says what ships in
R1. A composite tag here ("P0/P1") names the phase in which each part of the target must
first hold; it is not a §05 priority label.

**The measurability rule.** Every NFR in this section states a number and the method
that reads that number. "Highly available" is banned; "≥ 99.95% successful-request ratio
measured at the load balancer across the 25th–2nd critical window, excluding declared
maintenance" is required (NFR-AVAIL-801).

<!-- DIAGRAM: nfr-control-map -->

---

### 17.1 The residency-first architecture premise

One architectural decision sits upstream of nearly every NFR below and cannot be
deferred, per §13.10: **residency is a per-provider matrix, and data-at-rest
residency is a different guarantee from in-country inference.** Regulated buyers ask
about both, separately. The system is therefore built on a **provider-abstraction
layer** from v1 that lets residency be selected *per tenant*, not per deployment.

Neither "India mandates data localisation" nor "India has no localisation requirement" is
true (K-08). DPDP's cross-border rule is a negative list — empty, and not in force (EV-058).
What binds is narrower and live: CERT-In's 180 days of ICT logs within India for every
tenant (EV-062); SPDI r.7's restriction on transferring sensitive personal data abroad
(EV-060); and sectoral rules that reach only customers regulated by RBI, SEBI or IRDAI
(EV-085–087). The legal analysis is in §23.6 (localisation) and §23.12 (sectoral
overlays); this section turns it into selectable
guarantees.

| Layer | What must be swappable per tenant | Why |
| --- | --- | --- |
| **Data at rest** (Postgres, object store, search index) | Region of the primary and its replicas | Every tenant: CERT-In ICT logs in India (EV-062); SPDI r.7 on sensitive data (EV-060). Sectoral overlays: RBI Outsourcing of IT Services Directions — localisation among the obligations a bank or NBFC must secure from its IT outsourcer, **materiality-gated, entity-by-entity, not turnover-gated** (EV-087 [Verified — mirror]); SEBI cloud framework — data resides and is processed in India, and the MeitY-empanelled-infrastructure rule reaches SaaS providers (EV-085); IRDAI — **no** localisation in its 2023 cyber-security guidelines, localisation only for policy records (EV-086); SBI HRMS RFP — "all data functions and processing" within India (r2/06) |
| **LLM inference** | Which of ≥3 backends serves each task class, and in which region it runs | Anthropic's first-party API offers only "us" and "global" inference geos and a US-only, immutable workspace geo; OpenAI offers India data-at-rest, with first-party inference defaulting to the US and OpenAI models on Amazon Bedrock offering in-country inference; Vertex has an India region (§13.10 — provider documentation read in r2, not tested; re-verify before any regulated-tenant commit, §20) |
| **Egress / sub-processors** | The list of third parties any tenant's data touches (email, SMS, WhatsApp BSP, e-sign, payment rails, model providers) | SPDI r.7 transfer conditions (EV-060); RBI prior consent before sub-contracting, para 16(r), and regulator inspection reaching sub-contractors, para 16(o), where the arrangement is material (EV-087); SEBI Principle 7(x) contract terms and audit rights over sub-contractors (EV-085); IRDAI reg 53 regulator-access undertaking reaching sub-contractors (EV-086) |

This is the **same abstraction the model router needs for cost** (§13.5) — one
piece of engineering serving two constraints (residency and margin). It is P0 because
retrofitting per-tenant region selection into a single-region monolith is a re-platform,
not a feature. **[Verified]**

> **Design note — the residency default.** The India-first thesis makes `region=ap-south-1`
> (Mumbai) and `region=ap-south-2` (Hyderabad) the defaults; the abstraction exists so a
> regulated tenant can *pin* both data-at-rest and inference to India and receive a
> written attestation, while an SMB tenant inherits the default without a decision.
> Whether a chosen India region is MeitY-empanelled — required for a SEBI-regulated
> tenant (EV-085) — is unverified and must be confirmed before any hosting decision is
> committed (§20).

**Worked example — onboarding a regulated tenant (an NBFC of 900 employees).** RBI's
Outsourcing of IT Services Directions (RBI/2023-24/102, 10 April 2023, effective
1 October 2023) are addressed to the NBFC — NBFCs are on the addressee list (r4/02) — not
to its IT service provider: where the NBFC determines the
arrangement is **material** — an entity-by-entity determination, not a turnover test —
it must secure data localisation, audit rights including RBI's own, prior consent to
sub-contractors (para 16(r)) and regulator inspection reaching sub-contractors
(para 16(o)) from its IT service provider (EV-087 **[Verified — mirror]**; pull from the
primary source before customer use). Whether our arrangement is material for a given
NBFC is a counsel question (§23). The tenant record is created with
`sector_profile=RBI`, `data_residency=india_pinned` and `inference_residency=india_only`.
Consequences that must be automatic, not manual:

1. Primary Postgres, replicas, object store, search index and **all backups** provision in
   `ap-south-1` with DR in `ap-south-2` — never a foreign region (§17.14).
2. AI features start **off** for the tenant — the per-tenant kill switch defaults off for
   RBI, SEBI and IRDAI profiles (§12, Part E-7). If the NBFC opts in, the model router
   marks every task class `india_inference_required`, so a task whose only capable
   backend is US-only (e.g., the Anthropic geo, §13.10) is **refused with a typed error**,
   not silently sent abroad (NFR-RES-701).
3. The sub-processor manifest for the tenant is generated and frozen; adding a new
   sub-processor — a model provider included — is blocked until the tenant's recorded
   consent exists, and updates the attestation document.
4. The tenant's residency attestation PDF is produced from live config, not hand-authored,
   so it can never drift from what the system actually does — an RBI inspector
   reconciling the attestation against a network-policy dump finds them identical. This
   **supports evidence production** for RBI inspections; it does not discharge the audit,
   access and inspection obligations, which remain contractual (K-21).

The point of the walkthrough: residency is a **property set at tenant creation that
propagates deterministically to every subsystem**, because a regulated buyer's auditor
tests the seams, not the brochure. Retrofitting this after a single-region launch is the
re-platform §17.1 exists to avoid. **[Reversed]** — earlier drafts said the RBI
obligations attach to any SaaS vendor "with no turnover threshold"; they are
materiality-gated and bind the regulated entity (EV-087). The automation of the
attestation is a design commitment, not a claim about the regulator.

<!-- DIAGRAM: residency-provider-matrix -->

---

### 17.2 Security — authentication

**NFR-SEC-101 · Authentication strength** · **P0**
All human logins require a verified factor beyond a password. Admin, payroll-approver
and CA-console roles require phishing-resistant MFA.

| Target | Value | Verification |
| --- | --- | --- |
| MFA coverage on privileged roles | 100% of admin / payroll-approver / CA seats; enforced, not opt-in | Access review, quarterly; login without a second factor is impossible by config |
| Supported second factors | TOTP (RFC 6238), WebAuthn/FIDO2 passkeys; SMS OTP **fallback only**, never sole factor | Config audit; SMS-only accounts = 0 for privileged roles |
| Password storage | Argon2id, per-user salt, memory cost ≥ 19 MiB, ≥ 2 iterations (Source: OWASP Password Storage Cheat Sheet, 2024) | Code review + hash-format inspection in DB |
| Password policy | ≥ 12 chars, screened against a breached-password corpus (HIBP-style k-anonymity), no forced periodic rotation (NIST 800-63B) | Registration test suite |
| Brute-force / credential-stuffing defence | ≥ 5 failed attempts → exponential backoff + CAPTCHA; account lock alert to user | Automated abuse-simulation test |

**NFR-SEC-102 · Employee self-service login for low-literacy / shared-device users** · **P0**
The frontline reality from §09 [Verified] — nine in ten people who do not use a phone
live in a household that owns one (Comprehensive Annual Modular Survey 2023, r2/04), so
worker identity ≠ device identity — forces an auth path that does not assume a personal
smartphone with a password manager.

- **Target:** OTP-to-phone login (with the SMS-fallback caveat above treated as
  acceptable for *non-privileged* employee self-service, since the blast radius is one
  employee's own payslip), plus optional employer-issued short PIN bound to a device.
- **Measurable:** median employee login completes in ≤ 20 seconds on a 3G connection
  (measured in synthetic RUM from a throttled device profile); ≤ 2 taps after OTP entry
  to reach the payslip.

**NFR-SEC-103 · Session management** · **P0**

| Target | Value | Verification |
| --- | --- | --- |
| Session token | Opaque, server-side revocable; not a long-lived stateless JWT for privileged sessions | Design review |
| Idle timeout | Admin/payroll 30 min; employee self-service 24 h; CA console 30 min | Automated session test |
| Absolute session lifetime | 12 h admin; re-auth for approval of any pay run or statutory return regardless of session age (step-up) | Test: approving a return for filing always prompts re-auth |
| Concurrent-session control | Admin can view and revoke all active sessions of any user in their tenant | Manual + API test |

**NFR-SEC-104 · SSO for expansion and enterprise** · **P1/P2**
SAML 2.0 and OIDC SSO with SCIM 2.0 provisioning. SCIM de-provisioning propagates a
disabled/terminated employee to *loss of all access* within **≤ 5 minutes** (measured
end-to-end in a provisioning test). This is a hard enterprise-procurement gate, not a
nicety, and the seasoning-clock logic applies: build the interface early even before a
customer asks.

---

### 17.3 Security — authorization

**NFR-SEC-201 · Tenant isolation** · **P0**
The single most important security property of a multi-tenant payroll system: **no
tenant can ever read or write another tenant's data**, and this must be enforced at the
data layer, not only in application code.

| Target | Value | Verification |
| --- | --- | --- |
| Isolation mechanism | Row-level security (Postgres RLS) keyed on `tenant_id`, enforced in the database; application `tenant_id` scoping is defence-in-depth, not the sole control | Code review + a mandatory automated "cross-tenant read" test in CI that must fail closed |
| Cross-tenant leakage incidents | 0, with a CI gate: every table holding tenant data has an RLS policy or an explicit annotated exemption | CI check counts unguarded tenant tables; build fails if > 0 |
| CA-console cross-client access | A CA sees only clients that have granted access; switching clients re-scopes the session token | Multi-client switch test (CA / bureau console, §15.2; tenancy model, §15.3) |

**NFR-SEC-202 · Role-based + attribute-based access control** · **P0**
RBAC with a small, auditable set of built-in roles (Employee, Manager, HR-Admin,
Payroll-Admin, Payroll-Approver, Auditor/CA-read-only, Owner) plus ABAC constraints
(department, location, cost-centre). **Separation of duties is enforced:** the user who
*prepares* a pay run or a return cannot be the user who *approves it for filing* (the
attended submission itself is §22's).

- **Measurable:** maker ≠ checker on every filing and every pay-run approval — a
  self-approval attempt is rejected 100% of the time (automated SoD test).
- **Least privilege:** default new admin role grants **read-only**; write and
  approve are explicit grants. Verified by a periodic "excess privilege" report that
  lists every seat with approve rights.

**NFR-SEC-203 · CA read-only audit access** · **P0**
Per §15.2, the CA / bureau console offers *read-only audit access*. This is a distinct
permission class that can view registers, payslips and filings but can never mutate a
monetary field. Verified: a CA-role write to any payroll figure returns 403 in 100% of
attempts.

**NFR-SEC-204 · Restricted-field access logging, detection-capable** · **P0**
Read access to Restricted-class fields (§17.4 — Aadhaar token, bank account, PAN,
health/disability, biometric template), and bulk reads or exports of Confidential-class
salary data, are themselves audited events, not only writes. See §17.5. The log must be
able to **detect** unauthorised access, not merely record it — the standard DPDP
r.6(1)(c) will set when it commences (EV-064 **[Verified — not in force]**). It is built
to that standard now because the CERT-In six-hour clock runs from the moment an incident
is noticed (EV-062), and an access log nobody reviews produces no noticing.

---

### 17.4 Security — encryption

Encryption strength is driven by a **data-classification scheme**, because AES-256 on
everything and application-layer envelope encryption on everything are not the same cost,
and the scheme decides where the expensive control applies. Four classes, each with a
default handling rule. The classes are a **product** classification, not a legal one.
The legal position needs both halves in one breath (K-06): DPDP creates **no** sensitive
or special category of personal data (s.2(t), EV-059) — **and** the SPDI Rules 2011,
live today, classify passwords, financial information such as bank account or card
details, health data and biometric information as sensitive personal data (r.3, EV-060).
Nothing in this PRD is described as sensitive "under DPDP" (Part D-19).

| Class | Examples | Handling rule |
| --- | --- | --- |
| **Restricted** | Aadhaar, bank account, PAN, health/disability, biometric attendance template | App-layer envelope encryption (KMS master); Aadhaar in a separate, separately-encrypted, separately-access-controlled token store referenced by an opaque token — never the number or a hash of it in a business table — and biometric templates in their own keyspace, with no image column and no image bucket (Part E-6; §07, §09, §14); masked by default; read is an audited event (§17.5); never in logs, never in a URL, never model input — the §12 redaction chokepoint default-denies Aadhaar, PAN, bank account/IFSC and biometric templates (Part E-7) |
| **Confidential** | Salary, CTC, PF/ESI/TDS figures, appraisal, disciplinary | RLS-scoped, storage-encrypted; write is audited; not exposed to the AI assistant except through approval-gated, ACL-inheriting tools (§12) |
| **Internal** | Org chart, leave balances, attendance summary | RLS-scoped, storage-encrypted |
| **Public** | Statutory form templates, holiday calendar | No special handling |

The classification is a **field-level tag in the data model**, the same tag that drives the
processing-purpose and legal-basis mapping (NFR-DPDP-501) and the Restricted-field access
log (NFR-SEC-204) — one annotation serving encryption, audit and privacy at once. A field
with no classification tag fails the build (a CI lint counts untagged columns; must be 0).

**NFR-SEC-301 · Encryption in transit** · **P0**

| Target | Value | Verification |
| --- | --- | --- |
| TLS floor | TLS 1.2 minimum, TLS 1.3 preferred; TLS 1.0/1.1 disabled | SSL Labs-style scan ≥ grade A; automated in CI |
| HSTS | `max-age ≥ 31536000; includeSubDomains; preload` | Header scan |
| Internal service-to-service | mTLS within the cluster for services carrying tenant data | Service-mesh config audit |
| Device ingest (ADMS/WDMS) | The attendance push receiver (§09 [Verified]) accepts device POSTs over TLS to a tenant-scoped URL; plaintext HTTP ingest is refused | Ingest endpoint test |

> **Device-ingest caveat, [Hypothesis].** Some legacy eSSL/ZKTeco firmware on the
> reverse-engineered port-4370 path (§09 [Verified]) does not do modern TLS. **Kill/validate:**
> during the hardware spike (§09, device integration currently unsized), measure the share
> of the target install base that cannot POST over TLS 1.2+. If it is material, the answer is
> a tenant-side lightweight relay, never downgrading the cloud endpoint. No plaintext ingest
> ships to the internet regardless.

**NFR-SEC-302 · Encryption at rest** · **P0**

| Target | Value | Verification |
| --- | --- | --- |
| Storage-level | AES-256 on all volumes, DB, object store, backups | Provider config attestation |
| Application-level field encryption | Bank account, PAN and health data encrypted at the application layer with envelope encryption (per-tenant data key wrapped by a KMS master key); the Aadhaar token store and biometric templates each under their own keyspace (Part E-6) — so a raw DB dump exposes none of them | Code review + DB dump inspection |
| Key management | Managed KMS (India-region), automatic key rotation ≤ 365 days, per-tenant data keys; erasable classes (biometric templates, consent artefacts, punches, rendered documents) keyed so that the §14 erasure mechanism — crypto-shredding per subject key, or tombstone — can act on one subject without touching the rest (Part E-2) | KMS policy audit |
| Backup encryption | Backups encrypted with keys distinct from primary; restore requires KMS access | Restore drill (§17.14) |

**NFR-SEC-303 · Aadhaar handling** · **P0**
Aadhaar sits under its own statute — the Aadhaar Act 2016 and its regulations — not
under a DPDP category. The product is built as though the criminal-penalty chain in
EV-067 holds, and this PRD says nothing about whether it does (Part D-8, §23.9).
Aadhaar is **optional everywhere**, including the EPF and ESI flows; by default an
employee who declines is excluded-and-flagged on the affected filing, with notices to the
operator and the employee, never blocked from payroll, and no "no Aadhaar, no payroll"
configuration exists (Part D-10, Part E-11; §07 — the final choice of behaviour is with
counsel, §23). Where an employee provides it, it is collected on the Aadhaar (Sharing of
Information) Regulations 2016 reg 5 basis — lawful purpose, disclosure, consent
(EV-068) — and stored **only** in the separate Aadhaar token store (Part E-6); business
tables hold the opaque token. Transmission is encrypted: reg 6(4) makes that a legal
requirement (EV-068). Display is masked (`XXXX XXXX 1234`) by default, grounded in reg
6(2) security and confidentiality and in risk — whether masking is a statutory duty on a
plain employer is under counsel review (Part D-5, §23). A Virtual ID is never stored
(AOVR reg 4A(4)), and the product never verifies Aadhaar on a customer's behalf
(AOVR reg 16A(2), EV-070). Aadhaar is never used as a login identifier or a key.
**[Reversed]** — earlier drafts cited masking as "a published UIDAI requirement" on a
plain employer. Withdrawn: reg 6(1) is a bar on *public* display, and the duty question
stays with counsel (Part D-5, §23.9).

Three further build choices follow the "build it, state nothing" posture of Part D:

- **Vault-ready, not vault-claimed.** UIDAI's current circular and FAQ scope the Aadhaar
  Data Vault and HSM regime to requesting entities, but that position rests on a circular
  and an FAQ, not a notified regulation, and has flipped once before (r4/04). Whether it
  binds a non-requesting entity is under counsel review (Part D-6, §23). The token store's
  keys are therefore held in a KMS key hierarchy that can be moved behind a dedicated HSM
  without a schema change, so a future vault requirement is a migration, not a rewrite.
- **India-only for every tenant, whatever the residency profile.** The Aadhaar token store
  is provisioned in an India region for every tenant, with no per-tenant override, and no
  sub-processor outside India can read it. Whether hosting Aadhaar abroad or exposing it to a foreign sub-processor would be lawful
  for a non-requesting entity is a counsel question (Part D-15, §23); the product does not
  need the answer because it never does either.
- **Portal entry is modelled as the employer's act on a government portal.** The product
  does not design toward requesting-entity (AUA/KUA) status for statutory filing. Whether
  an employer entering Aadhaar into the EPFO or ESIC portal is itself a requesting entity
  is under counsel review (Part D-7, §23).

- **Measurable:** 0 endpoints return an unmasked Aadhaar to any role below a named,
  audited privilege; unmasking is itself a logged, reason-coded event; 0 business-table
  columns holding an Aadhaar number or a hash of one (schema lint in CI); Aadhaar token
  store region = India for 100% of tenants (provider-config audit); 0 sub-processors
  outside India on the token store's egress allow-list (network-policy audit).

**NFR-SEC-304 · Secrets and key material** · **P0**
No secret (DB credential, KMS key, provider API key, BSP token) in source, in an image
layer, or in an environment file committed to a repo. Secrets live in a managed secrets
store with rotation. Verified by a secret-scanning gate in CI (build fails on a detected
secret) plus a quarterly rotation attestation.

**NFR-SEC-305 · Secure SDLC, dependency & supply-chain security** · **P0**
The ISO 27001 Annex A control set and the VAPT expectation of regulated procurement (§17.15)
are not runtime toggles — they are earned in the pipeline. This NFR makes the pipeline itself
a control surface, because a payroll system that ships a known-vulnerable dependency into a
statutory filing path is one CVE away from a CERT-In-reportable incident.

| Target | Value | Verification |
| --- | --- | --- |
| Dependency vulnerability gate | No `Critical`/`High` CVE in a shipped dependency without a logged, time-boxed exception | SCA scan (e.g., dependency audit) in CI; build fails on ungated High+ |
| SBOM | A software bill of materials generated per release | SBOM artefact exists per build tag |
| Static analysis | SAST on every PR; security-relevant findings block merge | CI gate |
| Change control on statutory paths | Any change to the payroll-compute or filing-generation code requires maker≠checker review (mirrors the runtime SoD, NFR-SEC-202) | Branch-protection config; 0 self-merged statutory-path PRs |
| VAPT cadence | Third-party penetration test before first customer, then annually and on major release (§17.15) | VAPT report on file; findings tracked to closure |
| AI-specific review | Prompt-injection and tool-abuse test cases in the release suite for any change to an approval-gated MCP write tool (§12) | Test suite present; ties to NFR-OBS-1105 |

> **Why change-control on statutory paths is a hard gate, not process theatre.** The payroll
> engine's determinism invariant (§08 I4) and the audit trail's completeness (NFR-SEC-401)
> are only trustworthy if the code that computes a statutory figure cannot change without a
> second reviewer. A single unreviewed commit that alters the PT slab lookup logic can
> silently produce a wrong PT figure, and so a wrong return artefact, for every tenant with
> a work location in that state — the maker≠checker rule that
> governs runtime approvals therefore governs the source that produces them. (Slab *data*
> is a published rule object under the two-person review of the §22 compliance data
> pipeline; this NFR governs the code that reads it.)

<!-- DIAGRAM: encryption-key-hierarchy -->

---

### 17.5 Security — audit trail

**NFR-SEC-401 · Immutable audit log** · **P0**
Per the payroll engine invariant I5 (§08) and the retention and custody rules for the
six employer registers and wage slip (EV-053, EV-054; §06), every mutation of a monetary
or statutory field, every access to a Restricted-class field, every login/logout, every
permission change, and every filing action is recorded as an **append-only,
tamper-evident** event.

| Target | Value | Verification |
| --- | --- | --- |
| Fields per event | actor, tenant, timestamp (UTC + IST), source IP, action, entity, before-value, after-value, rule-version applied, evaluation context (disbursal date, as-of decision time, jurisdiction set, tax-regime election — §08 I6), authority/approval reference | Schema review |
| Restricted values in events | Before/after values of Restricted-class fields are recorded as tokens or masked references, never raw values, so the chain survives erasure of the underlying value — the audit chain is never erased; the Restricted values it points at can be (Part E-2, §14) | Schema lint: 0 raw Restricted values in audit payloads |
| Immutability | Append-only store; no application path can UPDATE or DELETE an audit row; tamper-evidence via hash-chaining (each event carries a hash of the prior event) | Attempt-to-mutate test returns error; chain-verification job |
| Retention | Register-linked events: at least the central-sphere register periods — "five years after the date of last entry" (Wages r.51(4)) or "five calendar years from the date of last entry" (OSH r.72(1)(vii), SS r.53(1)(e)) (EV-054); state-sphere periods are configuration pending counsel (§23). ICT/system logs: a rolling 180 days minimum, within India (EV-062). Whichever is longer per event class; anything beyond these is the configurable NFR-DPDP-506 schedule | Retention-policy audit |
| Clock accuracy | Timestamps sourced from NIC/NPL-synced NTP (§17.6); skew ≤ 100 ms | NTP monitoring |
| Completeness | 0 monetary mutations without a corresponding audit event — enforced by writing the audit event in the same DB transaction as the mutation | Transactional test; orphan-mutation detector = 0 |

> **Worked example — a PF recompute under the 50% add-back (§06 [Verified]).** A tenant
> corrects an employee's HRA mid-year; the excluded-components share now exceeds one-half of
> remuneration, so the Code on Wages s.2(y) / Code on Social Security s.2(88) add-back
> re-bases PF for prior periods (§06 [Verified]). The arrears recompute (§08 I3) writes, in
> the *same transaction* as the monetary change, an audit event:
>
> ```
> event_id      : 0x9f3c… (sha256 of this event's canonical form + prev_hash)
> prev_hash     : 0x71ab…            actor: payroll_admin:emp_4471
> tenant        : t_00912             ts: 2026-07-14T09:22:07Z / 14:52:07 IST
> action        : PAYROLL.RECOMPUTE   entity: pf_contribution:emp_88/2026-04
> before_value  : { pf_wages: 18000, ee_pf: 2160 }
> after_value   : { pf_wages: 24500, ee_pf: 2940 }
> rule_version  : wagedef@2025-11-21  approval_ref: run_approval:ra_5521
> eval_context  : { disbursal_date: 2026-07-31, as_of: 2026-07-14T09:22:07Z,
>                   jurisdiction_set: [central, state:MH], tax_regime: new }
> ```
>
> Three properties the schema forces and QA verifies: (1) `rule_version` names the
> effective-dated wage-definition rule *in force for the period being corrected* — here the
> Code's definition from its 21 November 2025 commencement (§06.9), not today's rule — and
> `eval_context` carries the disbursal date from which PF liability on the arrears runs
> (§08, Part E-9), so the recompute is reproducible; (2) `prev_hash` chains the event, so a
> tampered or deleted row breaks the chain and the nightly verification job flags it; (3) the
> event cannot exist without the mutation and the mutation cannot commit without the event
> (single transaction) — which is how "0 un-audited monetary mutations" is guaranteed rather
> than hoped for.

**NFR-SEC-402 · Audit log usability** · **P0**
An audit trail nobody can query is a liability, not a control. Admins and CA-auditors
can filter the log by employee, period, actor, and action, and export a signed
statement for a dispute or an inspection. **Target:** any single employee's full
change history for a tax year (the "financial year" of earlier periods — both labels
accepted, EV-050) returns in ≤ 3 seconds (P95).

**NFR-SEC-403 · Access review** · **P1**
Quarterly access-recertification workflow: owners attest to each privileged grant;
un-attested grants past 90 days are flagged. Verified by a recertification-coverage
report ≥ 95% each quarter.

---

### 17.6 Data protection — CERT-In and the SPDI Rules today, DPDP from ~May 2027

This is where an India-first HRMS diverges from a GDPR-shaped product, and the
divergence is one of **timing** before it is one of substance. Two regimes bind today:
the CERT-In Directions (six-hour reporting, 180-day in-India ICT logs, NTP sync —
EV-062) and the SPDI Rules 2011 under IT Act s.43A (written consent before collecting
biometric or financial information, a cross-border transfer restriction, ISO 27001 as
the named security standard — EV-060). DPDP's substantive provisions — ss.3–17, 27–34
and 44(2), and Rules 3, 5–16, 22 and 23 — commence on or about 13 May 2027 (EV-058
**[Verified — mirror]**; pull G.S.R. 843(E) from the primary source before customer
use). The November 2026 tranche commences only Consent Manager registration (s.6(9),
s.27(1)(d)); an HR SaaS is not a Consent Manager, so nothing new bites on this product in
November 2026 and the Data Protection Board cannot fine it then (K-05). A January 2026
proposal to compress the runway is not gazetted and its scope is unresolved (EV-058) —
a §20 watch item. Across ~May 2027 two consent regimes run concurrently (Part E-6).
The legal analysis is in §23.3 (DPDP), §23.4 (SPDI) and §23.5 (CERT-In); this subsection
states only the engineering consequences.

**Why the controls in this section are sized the way they are — the live exposure, not
the headline.** Today's exposure for a biometric or financial-data breach is compensation
under IT Act s.43A, which is live and has **no statutory cap** (EV-061) — larger in
practice than DPDP's ₹250 crore security-safeguards ceiling, which cannot be enforced
until the Board's powers commence on or about 13 May 2027 (EV-058). From commencement,
the DPDP Schedule caps penalties by head, the largest being failure to take reasonable
security safeguards (s.8(5)); the full schedule, and who bears it — including whether a
processor carries any direct exposure, a counsel question (Part D-3) — is set out in §23.
The consequence for this PRD is the same under both regimes: the security-safeguard NFRs
(SEC-201/301/302/305) are P0 and gated in CI rather than aspirational, and they are built
to the standard SPDI r.8 names for reasonable security practices, ISO 27001 (EV-060,
§17.15); whether that discharges any particular party's s.43A duty is for counsel (§23.4). Once in force, DPDP s.8(1) keeps the data fiduciary
responsible "irrespective of any agreement to the contrary", so the product is not sold
as a transfer of that risk.
**[Reversed]** — earlier drafts presented the DPDP penalty schedule as a live tariff and
the product as "a risk-transfer instrument for the buyer"; the schedule is not in force
and the fiduciary's responsibility cannot be contracted away.

**NFR-DPDP-501 · Processing basis per field; two consent regimes run concurrently** · **P0**
**[Reversed]** — earlier drafts stated, as current law, that DPDP s.7(i) lets an employer
process employee data without consent, and set a target of "0 consent gates" on it.
Withdrawn: s.7(i) is not in force until on or about 13 May 2027 (EV-058), and today the
SPDI Rules require consent in writing before sensitive personal data — biometric and
financial information included — is collected (r.5(1), EV-060).

Every personal-data field carries a **processing-purpose tag** and a **legal-basis tag**
(the same field-level annotation as §17.4). While the SPDI Rules are live — whether they
survive the omission of IT Act s.43A at DPDP commencement is a counsel question (Part
D-12, §23.4), so the product does not switch this gate off on a date of its own choosing —
fields in the SPDI sensitive set (r.3 — biometric information, financial information
such as bank account details, health data, passwords) are collected only after a
written-consent artefact is captured (r.5(1)). The set is SPDI's, not DPDP's: DPDP
creates no sensitive category (s.2(t), EV-059), so the tag never reads "sensitive under
DPDP" (Part D-19). Who owes that duty — the employer, the SaaS, or both — is under counsel
review (Part D-4, §23); the product captures the artefact either way, as the versioned
consent entity of §07. When s.7(i) commences it is expected to disapply consent and notice
for employment purposes only; it does **not** disapply the s.8 duties (security,
accuracy, breach intimation, erasure, grievance). Where the employment purpose ends —
dependants' data for insurance, wellness, optional-benefit marketing — is a counsel
question (§23); the product treats that processing as consent-based under either regime.
The regime switch is a rule change effective from a date set on counsel's opinion, not a
migration (Part E-6). Consent cannot be
backfilled: migrated employees go through §07's migration consent flow (Part E-12).

- **Measurable:** 0 SPDI-set fields stored without a linked, versioned consent artefact
  (schema constraint + flow audit); 0 flows in which a declined consent blocks payroll or
  employment — a declination routes to the non-biometric attendance path (§09) or manual
  payment handling and is recorded (Part D-10); no "biometric only" attendance
  configuration and no "no Aadhaar, no payroll" configuration exists (config-schema audit:
  0 such options).
- Every field's purpose and basis tags are populated (CI lint, untagged = build-fail), so
  the system can show which basis applied to any processing at any date.

**NFR-DPDP-502 · Data-principal rights machinery** · **P0/P1**
DPDP Chapter III contains exactly four rights — access (s.11), correction and erasure
(s.12), grievance (s.13), nomination (s.14) — none in force until on or about 13 May 2027
(EV-066, EV-058). ss.11–12 are textually tied to consent; whether they reach an employer
relying on s.7(i) is under counsel review, and both answers are dangerous to state (Part
D-1, §23). The product builds the machinery as a **capability** regardless — some
processing rests on consent under either regime (NFR-DPDP-503), and buyers ask for it in
security review. For an employee, the system provides:

| Right | Target | Verification |
| --- | --- | --- |
| Access (s.11 when in force) | Employee downloads their own record (profile, payslips, filings, declarations) as a machine-readable export — a product capability; DPDP Chapter III has no portability right (EV-066) | Self-service export test; completes ≤ 60 s |
| Correction | Employee raises a correction request routed to HR-Admin; tracked to closure | Workflow test |
| Erasure, bounded by statute | Erasure honoured **except** where retention is legally required — the six employer registers carry the EV-054 central-sphere periods, and PF, ESI and TDS records carry periods held as configuration pending counsel (NFR-DPDP-506). The system erases what it may and documents the statutory hold on the rest | Erasure test shows retained classes with a cited hold reason or a counsel-review flag |
| Grievance officer | A named grievance contact is configured per deployment; SLA to first response published | Config check |
| Nomination (s.14 when in force) | Employee records a nominee for their data-principal rights, held separately from statutory nominations (PF, gratuity) so neither overwrites the other | Workflow test: nominee record exists and is distinct from the PF and gratuity nomination records |

> **Erasure vs. retention is a real tension, not a checkbox.** A terminated employee's
> erasure request collides with the employer's duty to retain PF/ESI/TDS records and to be
> able to reproduce a filed return under inspection. The design rule: **erase discretionary
> data, retain statutorily-mandated data with a documented hold, and never let an erasure
> request silently break a filing's reproducibility.** Erasure acts on the erasable
> entity classes — punches, rendered documents, biometric templates, consent artefacts,
> discretionary data — through the §14 mechanism; the bitemporal classes (rules, salary
> structures, assignments, statutory attributes) are not erased by an erasure request, and
> what replay returns after an erasure is specified in §14 (Part E-2). The hold periods
> are enumerated in NFR-DPDP-506.

**NFR-DPDP-503 · Consent capture & notice; no Consent Manager dependency** · **P0 (capture) / P1 (notice template)**
Where consent is required — today, the SPDI written-consent set (NFR-DPDP-501), and any
processing outside the employment purpose — capture it with a clear notice, itemised
purpose, withdrawal path, and an audit record of consent version, timestamp and whose
artefact it is (§07 consent entity). An employee privacy notice ships as a configurable
template even where no statutory notice duty may attach — whether one attaches to
s.7(i) processing is a counsel question (§23). **Consent Managers are not a dependency.**
The DPDP Rules are notified (G.S.R. 846(E), 13.11.2025); Consent Manager registration
commences in the November 2026 tranche (s.6(9), s.27(1)(d), EV-058); an HR SaaS is not a
Consent Manager, and the product does not integrate one. **[Reversed]** — earlier drafts
treated the Consent Manager regime as unsettled pending notified rules; the rules are
notified and the regime does not reach this product.

**NFR-DPDP-504 · Data Protection Officer / Significant Data Fiduciary seam** · **P2**
Significant Data Fiduciary status arises **only** by Central Government notification
under s.10(1); no threshold of any kind triggers it, s.10 is not in force, and we are not
aware of any designation as of September 2026 (EV-065). If designated, additional
obligations attach (an India-based DPO, an independent data auditor, periodic DPIA and
audit). The design keeps a DPIA template and a DPO-role seam ready so designation, if it
comes, is a process step, not a re-architecture. **Kill/validate:** watch for a s.10(1)
notification naming this product, a customer, or a class either falls into (§20); do not
incur DPO/DPIA operating cost until a notification or a specific tenant's contract
requires it — but never let the *seam* be closed, since re-opening it is the expensive
part. **[Reversed]** — earlier drafts said SDF "turnover/volume thresholds" would be set by
notified rules; there is no threshold, only notification (EV-065).

**NFR-DPDP-505 · Breach notification — one pipeline to six hours, DPDP pre-staged** · **P0**
The **live Indian breach clock is six hours**, to CERT-In, from noticing the incident
(EV-062, NFR-CERT-601). DPDP r.7 — not in force until on or about 13 May 2027 — will add,
for any personal data breach: intimation without delay to each affected data principal
and to the Board, then a detailed report to the Board within 72 hours or such longer period
as the Board allows on request (r.7(2)(b); r4/02), with
**no materiality threshold** — every breach, a single misdirected payslip included
(EV-063). From commencement those intimations run **in addition to** the six-hour CERT-In
report, never instead of it. The incident runbook (§17.14) fires the CERT-In report today
and carries the DPDP r.7 content fields pre-staged, so commencement is a configuration
switch. Triage routes and prioritises; it never decides not to notify. **[Reversed]** —
earlier drafts treated the DPDP timeline as unknown and bound the runbook to "the stricter
of DPDP and CERT-In"; the Rules are notified and not in force, and any 72-hour figure is a
future DPDP follow-up report, never the Indian obligation (K-07).

**NFR-DPDP-506 · Statutory data-retention schedule (the erasure exceptions, enumerated)** · **P0**
An erasure engine that cannot cite *why* it retained a record is a liability under both the
data-protection regime (retention must be lawful) and inspection (the record must exist).
The system carries a machine-readable retention schedule keyed per data class, so an
erasure request produces an itemised "erased / retained-with-reason" statement
automatically. The only statutory periods this PRD states are EV-054's central-sphere
register periods; every other period is a **named configuration parameter** whose value
is set on counsel's opinion (Part D-11, §23.14) and whose validation sits in §20.

| Data class | Retention rule in the schedule | Basis and status |
| --- | --- | --- |
| Wages registers and wage slip — Forms I, IV, IX and Form V (Wages r.51(1)) | "Five years after the date of last entry" (Wages r.51(4)) | **[Verified — central sphere]** EV-053, EV-054 |
| OSH registers — Forms XIII, XIV, XV, XIX, XX and Form XVI | "Five calendar years from the date of last entry" (OSH r.72(1)(vii)); OSH r.76(2) bars destroying the leave register even after five years unless transferred to a new register, so the engine never auto-purges it | **[Verified — central sphere]** EV-054 |
| Register of Women Employees — Form XXII (SS r.53(1)(a)) | "Five calendar years from the date of last entry" (SS r.53(1)(e)); the maternity Schedule para 11(a)(2) "in ink" requirement contradicts r.53(1)(b)'s electronic permission — counsel (§23) | **[Verified — central sphere]** EV-054 |
| Industrial Relations Rules records | Electronic maintenance compulsory (r.47(1)); r.47(2) sets no period → `retention.ir_records` | EV-054; period under counsel review (§23) |
| State-sphere registers and forms (form numbers per state, EV-053) | `retention.state.<state>.<form>` | Unknown — counsel (§23); validation (§20) |
| Appointment letter — OSH Code s.6(1)(f), establishments of 10 or more workers, form prescribed by the appropriate Government (EV-057) | `retention.appointment_letter` | Statutory basis under counsel review (§23) |
| EPF records — ECR files, returns, challans, contribution records | `retention.epf` | Statutory basis under counsel review (§23) |
| ESI records | `retention.esi` | Statutory basis under counsel review (§23); the ESI position after 22 Nov 2026 per §06.9 |
| TDS records — Form 138 (ex-24Q) returns, challans, Form 130 (ex-Form 16) certificates, Form 124 (ex-12BB) proofs (EV-050) | `retention.income_tax` | Statutory basis under counsel review (§23) |
| Gratuity records and nominations | `retention.gratuity` | Statutory basis under counsel review (§23) |
| ICT/system logs, LLM prompt/completion logs included | A rolling 180 days minimum, within India; any longer period is `retention.ict_logs` | **[Verified — CERT-In domain]** EV-062 |
| DPDP r.8(3) one-year retention of personal data and processing logs | Not in force; whether it is a universal floor is a counsel question, so neither immediate purge nor one-year suppression is hard-coded (Part D-9) → `retention.dpdp_r8_3` | EV-058; counsel (§23) |
| Discretionary data (wellness, optional-benefit marketing, non-mandated survey) | **No statutory hold identified — erase on request** | Product capability today; DPDP s.12 when in force (EV-066) |

- **Measurable:** an erasure request on a terminated employee returns a statement listing
  every retained class with its cited hold — or the flag "statutory basis under counsel
  review" — and its expiry date where one is set, and erases everything with no hold,
  within the published response window; a retained class with *neither* a cited basis nor
  a counsel-review flag is a build-fail (the schedule must be complete).
- **Until counsel sets a period, a counsel-review class is held, never erased** — the
  engine never invents a period and never treats a parameter's absence as permission to
  delete.
- **Reproducibility guard:** erasing discretionary data must never break the ability to
  regenerate a filed return for a retained period (ties to NFR-SEC-401 rule-versioning).
- Every period, the EV-054 figures included, is re-checked for corrigenda before the
  erasure engine treats it as authoritative (the corrigendum standing rule, §02.4).
- **[Reversed]** — earlier drafts listed EPF records at 3 years after settlement, ESI at
  ≥ 5 years, TDS records and Form 130 at ≥ 7 years, and "four consolidated registers" at
  5 years. None of the non-register periods has a source in the evidence register, and the
  registers are six plus a wage slip under three differently worded rules (EV-053,
  EV-054); withdrawn.

<!-- DIAGRAM: erasure-vs-retention-decision -->

#### CERT-In directions (2022) — binding from the first customer

**NFR-CERT-601 · Six-hour incident pipeline** · **P0**
CERT-In requires reporting of the Annexure I cyber incidents **within six hours** of
noticing them or being brought to notice of them, for every body corporate (EV-062
**[Verified — CERT-In domain]**; CERT-In Directions No. 20(3)/2022-CERT-In, 28.04.2022,
under IT Act s.70B(6)). A manual process cannot meet six hours, so this is a pipeline —
detection tooling, pre-staged report fields, a registered point of contact — not a
procedure (Part E-8). The product has three reportable surfaces: attendance terminals
(IoT devices, Annexure I item xiii), the cloud layer (item xviii), and the AI layer
(item xx, attacks on AI/ML systems). An AI-first product *enlarges* the reportable
surface, so the AI/ML incident class is first-class, not a formality.

| Target | Value | Verification |
| --- | --- | --- |
| Detection-to-report capability | The pipeline and on-call produce a CERT-In-format report within six hours of noticing, for every incident class | Tabletop drill measures elapsed time; must be ≤ 6 h |
| CERT-In point of contact | Designated and registered **before the first paying customer** (CERT-In Directions direction (iii); r4/02) | Onboarding checklist gate |
| Reportable-class coverage | Runbook enumerates all 20 Annexure I classes; each maps to a detection signal | Runbook review |
| AI/ML incident class | A distinct class on the six-hour clock covering prompt injection, training- or retrieval-data poisoning, model or data extraction, and unauthorised access to the inference pipeline or vector store (Part E-8) | Each sub-class has a detection rule and a drill scenario |

The reportable classes most likely to fire for an AI-first payroll SaaS, and the detection
each maps to (a subset of the twenty in Annexure I; EV-062). Item numbers are given only
where our research read them from the Directions (iii, xi, xii, xiii, xviii, xx — r4/01,
r4/02); the identity-theft class and the server/database/application class are mapped to
their Annexure I items when the runbook is authored against the Directions text, not from
this list:

- **Unauthorised access to data / data breach / data leak (items iii, xi, xii)** →
  tenant-isolation alerts (NFR-SEC-201), surprise-egress detector (NFR-RES-703),
  Restricted-field access anomalies (NFR-SEC-204).
- **Identity theft, phishing, credential compromise** → brute-force/stuffing signals
  (NFR-SEC-101), impossible-travel and anomalous privileged-login detection.
- **Attacks on servers, databases and applications (SQL injection among them), and on
  cloud systems (item xviii)** → WAF + SAST/DAST signals.
- **Attacks on IoT devices (item xiii)** → anomalies on the ADMS/WDMS attendance-ingest
  endpoint (§09), which is the one internet-facing device surface in the product.
- **Attacks or malicious activity affecting *systems related to AI and Machine Learning*
  (item xx)** → the AI/ML incident class above: prompt-injection, tool-abuse, poisoning,
  extraction and inference-pipeline-access detection (NFR-OBS-1105).

> **Worked timeline — a prompt-injection escalation, today and after ~May 2027.** T+0:
> NFR-OBS-1105 raises a tool-abuse alert (an assistant tool-call attempts a payroll mutation
> outside its ACL). T+4 min: on-call acknowledges (MTTA ≤ 5 min target, NFR-OBS-1104),
> triages, confirms the approval gate held and no monetary field changed (§08 — the model
> never calculates). The incident is now noticed, and the **CERT-In six-hour clock** is
> running: an attack on the AI system is itself reportable whether or not data leaked, and
> the report goes to CERT-In through the registered point of contact. T+45 min: scope
> assessed — was any Restricted-class data (§17.4) exposed? **Today, of the two clocks
> in this runbook, only the CERT-In clock runs.** After DPDP commencement, a personal data breach additionally triggers the r.7
> intimations to each affected employee and to the Board (NFR-DPDP-505) — in addition to
> the CERT-In report, never instead of it, and with no materiality threshold. Tabletop
> drills (NFR-CERT-601, NFR-DR-1405) measure elapsed time against six hours.

**NFR-CERT-602 · 180-day log retention within Indian jurisdiction** · **P0**
ICT system logs are retained for a **rolling 180 days** and stored **within Indian
jurisdiction** (EV-062). This is a residency requirement on *logs*, not only on primary
data — a common miss, and the only express in-India storage requirement in this PRD's
evidence that reaches every tenant today (SPDI r.7 conditions transfers of sensitive data
on equivalent protection and on contract necessity or consent; it does not require
in-India storage, EV-060). LLM prompt/completion logs are treated as ICT logs and kept in
India (§12, §15, Part E-7); whether they are ICT logs in law is under counsel review (§23),
and the product is built as though they are.

The 180-day figure is a floor, not a hard-coded window. DPDP r.6(1)(e) — not in force
until on or about 13 May 2027 — will require logs and personal data to be retained for one
year "for enabling the detection of unauthorised access", unless another law requires
otherwise, with no location constraint of its own (r4/02, r4/03; EV-058). The log store
therefore carries its window as the configuration parameter `retention.ict_logs`
(NFR-DPDP-506), and is sized so that setting it to one year at commencement is a
configuration change, with every log still held in India. Whether that parameter is
set to one year, and how it interacts with the r.8(3) question, is decided on counsel's
opinion (Part D-9, §23) — this NFR hard-codes neither.

- **Measurable:** log store region = India, verified in provider config; retention window
  ≥ 180 days verified by querying the oldest available log; a log-shipping path — the AI
  layer's included — that egresses to a non-India region is a build-fail.

**NFR-CERT-603 · Time synchronisation to NIC/NPL** · **P0**
All systems sync clocks to **NIC or NPL NTP servers** (or servers traceable to them)
(EV-062). Skew tolerance ≤ 100 ms; monitored, alerts on drift. This underpins the
audit-trail timestamp integrity in §17.5.

**NFR-CERT-604 · Assistant actions logged with human-action fidelity** · **P0 (wherever the assistant is enabled)**
The AI assistant's tool-calls (§12; MCP write tools are approval-gated and audited) are
ICT-system events under the CERT-In log direction and are logged with the same fidelity
as human actions, so an AI-initiated change is as reportable and as reconstructable as a
human one. (Earlier drafts attributed "KYC expectations" to CERT-In for any user-facing
service; no such obligation is in the evidence register, and the claim is withdrawn.)

<!-- DIAGRAM: incident-dual-clock -->

---

### 17.7 Data residency & provider abstraction

Extends §17.1 into measurable NFRs. Per §13.10, residency is a *segment-specific
procurement gate*, not a general differentiator — so the requirement is **selectable
guarantees**, sized to who is buying, on top of the two live constraints that apply to
every tenant (CERT-In logs in India, EV-062; SPDI r.7 on sensitive data, EV-060).

**NFR-RES-701 · Per-tenant residency pinning** · **P0 (capability) / P1 (regulated attestation)**

| Target | Value | Verification |
| --- | --- | --- |
| Data-at-rest region control | A tenant can be pinned to India (Mumbai + Hyderabad DR); the default is India | Deploy a tenant with `region=india`; confirm no data object lands outside India |
| In-country inference control | A regulated tenant's task classes route only to backends with India-region inference; a task with no India-region backend is *refused*, not silently sent abroad | Router test: a pinned tenant + a US-only model = task blocked with a clear error |
| Sub-processor transparency | Per-tenant list of every third party its data touches, with region and purpose | Generated report; matches actual egress (verified against network policy) |
| Written attestation | Regulated tenants receive a residency attestation document (data-at-rest India + inference region stated per task class) | Document exists and is accurate for a pinned tenant |

**NFR-RES-702 · Three interchangeable inference backends** · **P0**
Per §13.10: **at least three interchangeable LLM backends**, re-pointable
per task class *without a deploy*. This single requirement serves cost (router), residency
(pin), and resilience (failover) — three constraints, one build.

- **Measurable:** re-pointing a task class from backend A to backend B is a config change
  applied in ≤ 60 seconds with no service restart; a synthetic "provider down" test fails
  over to a second backend within the task's latency budget.
- **Consent-gated for sectoral profiles:** for a tenant with an RBI, SEBI or IRDAI profile,
  re-pointing to a provider outside the tenant's consented sub-processor set is refused
  until the sub-processor-change gate records that tenant's consent (§12, §13.10, Part
  E-7; RBI para 16(r) where material, EV-087). Failover is only ever to a provider already
  in the consented set.
- **Correctness guardrail (rules-first, LLM-last — §12.1, §13.4):** no statutory or monetary figure is ever
  model-generated regardless of backend, so a backend swap can never change a payroll
  number — only the phrasing of an explanation. Verified by the deterministic-replay test
  (§08 I4): the same pay run produces byte-identical monetary output irrespective of which
  model explained it.

**NFR-RES-703 · Data-egress control** · **P0**
Default-deny egress: tenant data leaves the India perimeter only through an
allow-listed, per-tenant-configured sub-processor. Verified by a network-policy audit and
a "surprise egress" detector (any outbound destination not on the allow-list raises an
alert). The detector is a CERT-In detection signal (NFR-CERT-601) and its output supports
evidence production for a regulated customer's inspections (EV-087, K-21).

<!-- DIAGRAM: provider-abstraction-layer -->

**NFR-RES-704 · Sectoral NFR profiles — RBI, SEBI and IRDAI as selectable overlays** · **P0 (profile field, defaults, propagation) / P2 (evidence packs, contract riders)**
Every tenant carries a `sector_profile` ∈ {`none`, `RBI`, `SEBI`, `IRDAI`}, set at tenant
creation and resolved to a fixed bundle of NFR settings that propagates to every
subsystem, exactly as the §17.1 walkthrough shows for RBI. Each overlay's instrument is
addressed to the **regulated customer**, not to us: it is what that customer must secure
from its service provider, and whether it reaches a given arrangement is the customer's determination —
for RBI, materiality is decided entity by entity, never by turnover (EV-087, K-22), and
whether our arrangement is material for a given entity is a counsel question (Part D-14,
CR-14). The product's job is to make the overlay selectable, automatic and evidenced. What
each regulator requires, who it binds and the open legal points are §23.12's; the
questionnaire that sets the profile, the recorded RBI materiality decision, the SEBI lane
declaration and evidence pack, and the IRDAI licence-versus-managed-service record are
FR-LEG-030 to FR-LEG-033. This NFR fixes only the settings each profile resolves to and
how their propagation is verified.

The profile is not an enterprise-only concern. CSCRF reaches a wider population of
SEBI-regulated entities than the cloud circular, and small firms in the 20–200 band sit
inside it — non-individual investment advisers are "Small-size REs" (r5/01) — so a
beachhead tenant can arrive with a SEBI profile.

| Setting | `none` (default) | `RBI` | `SEBI` | `IRDAI` |
| --- | --- | --- | --- | --- |
| Data at rest, backups, DR | India (Mumbai primary, Hyderabad DR) | India-pinned; localisation is among the obligations the entity secures where the arrangement is material (EV-087 **[Verified — mirror]**) | India-pinned: data resides and is processed in India, with a copy-in-India limb (EV-085). On public cloud the underlying infrastructure must be MeitY-empanelled — FAQ Q47/Q50 via clause 2(ii) reach SaaS providers (EV-085); regions expose only region-level selection, so the data-centre assurance is contractual (FAQ Q48, r5/01) | India, as the product default. The 2023 guidelines impose **no** localisation, MeitY or STQC requirement; IRDAI localisation reaches policy records only (reg 3(7), EV-086), which the product does not hold |
| AI features | Per §12 defaults | **Off** until the tenant opts in (Part E-7) | **Off** until opt-in | **Off** until opt-in |
| Inference, once opted in | Router default | `india_only` | `india_only` — an HR/payroll AI feature does not fit the CSCRF offshore exemption, which is drawn for IT and cybersecurity data sent to SOCs and security SaaS (r5/01) | `india_only` as a conservative product default; no IRDAI rule in our evidence requires it (EV-086) |
| Sub-processor change | Notice to the tenant | Blocked until the tenant's recorded consent — para 16(r) where material (EV-087) | Blocked until recorded consent; Principle 7(x) terms include the RE's and SEBI's right to information about our supply chain and our contractual liability for sub-contractors' performance and risk management (items 14–15, EV-085, r5/01) | Blocked until recorded consent as a product default; IRDAI requires no prior sub-processor consent, but the reg 53 access undertaking reaches sub-contractors (EV-086, r5/01) |
| Regulator access (legal scope, §23.12) | — | Inspection-ready: audit and access logs, sub-processor manifest and configuration history for the tenant producible on request, including for sub-contractors (para 16(o), EV-087) | Inspection-ready as for RBI, and every sub-processor contract carries a flow-down access term, because Principle 7(iv) access reaches the provider and its sub-contractors (EV-085) | Inspection-ready for books, records, systems and audit reports scoped to the service (reg 53(1), EV-086) |
| Keys | Platform KMS, per-tenant data keys (NFR-SEC-302) | Platform KMS | BYOK or BYOE with a dedicated, fault-tolerant HSM (circular clause 6.2.9(ii)); key location in India per FAQ Q26 — a supervisory expectation under live consultation, so a change risk (r5/01) | Platform KMS |
| Offshore anything | Never | Never | Never | Never — offshore outsourcing needs Competent Authority permission (reg 53(2), r5/01) and is not offered |
| Exit erasure | §14 mechanism | §14 mechanism | Secure erasure from disks, backups and logs on the RE's instruction, leaving nothing recoverable (expunging clause, Principle 7(vii), r5/01), subject to the RE's own retention duties and NFR-DPDP-506 holds | §14 mechanism |
| Segregation | Tenancy per §15.3 | Tenancy per §15.3 | Demonstrably segregated from the RE's systems under SEBI purview — no shared identity plane, no data path into trading, KYC or reporting stacks — because FAQ Q27 limits audit coverage to properly segregated systems and draws in connected ones (r5/01) | Tenancy per §15.3 |
| Evidence pack | Residency attestation (NFR-RES-701) | Attestation + frozen sub-processor manifest; supports evidence production, does not discharge the audit, access and inspection obligations (K-21) | Attestation + a rider covering the 20 Principle 7(x) terms (EV-085) + the CSCRF PR.IP guideline 5 undertaking that the software is free of known vulnerabilities, malware, malicious code and covert channels (r5/01) + a segregation note | Attestation + the reg 53 undertaking + ISO 27001 statement of applicability covering the supplied services (s.2.14: the insurer *may* except the vendor from periodic audits — discretionary); a Cloud Security Alliance trust certification is the route under s.2.19 cl.3.7.1 where the vendor *shall* be exempt (r5/01) |

**Classification questions the profile cannot answer, routed out.** (1) For an insurer,
IRDAI's outsourcing definition (PPI Regs 2024 reg 2(14)) captures managed payroll but
not a self-service licence (EV-086); whether adding attended filing (§22) to an insurer
tenant's plan turns the arrangement into outsourcing is a counsel question (§23.12, CR-42;
FR-LEG-033), and the plan configurator flags the combination rather than deciding it.
(2) Whether an RE's own employee HR and payroll data is "Regulatory Data" under CSCRF is
unresolved on the text (r5/01) — §20; §23.12, CR-41. (3) Whether the chosen India regions are
MeitY-empanelled at the data-centre level is unverified (§17.17 item 8; CR-41); **no SEBI
profile is activated until it is confirmed in writing.**

- **Measurable:** 100% of tenants carry a non-null `sector_profile` (onboarding gate; the
  customer's authorised signatory confirms regulated status and the answer is recorded);
  a nightly profile-to-config drift check reports 0 drift across storage region, inference
  routing, sub-processor manifest, key mode and AI default; a profile change is a
  two-person action that re-runs propagation and regenerates the attestation; each
  profile's evidence pack is generated from live config, never hand-authored.
- Every sentence in an attestation, evidence pack or contract rider that characterises a
  regulator's requirement is customer-facing legal copy: it carries a named owner and
  clearance under §23.1's representation-control rule before first use (Part D-20), and
  the generator emits only cleared template text around the live-config values.

<!-- DIAGRAM: nfr-sectoral-profile-overlays -->

---

### 17.8 Availability & SLAs

Availability is specified as a **windowed SLO**, because both the load and the harm are
concentrated. A 20–200 employer runs one payroll a month: the product is near-idle for
most of the month and saturated from pay-run preparation to disbursal (§17.9). A flat
99.9% monthly target permits ~43 minutes of downtime and cannot tell a quiet mid-month day
from the day before salaries are paid. Over-promising uptime is paid for out of a price
band with a value floor near ₹50 PEPM and a mid-market clearing band of ₹80–200 (EV-027,
§18) — two anchors, not a single ceiling (K-09). **[Reversed]** — earlier drafts set a flat
99.9% monthly SLA for the beachhead with no source in the 20–200 segment (an earlier
version borrowed it from the PSU tender, a segment §05 excludes from launch), and priced
it against a single "realised ARPU" range that §20.4 treats as a shape, not a level.

**NFR-AVAIL-801 · Windowed availability SLO** · **P0 (windowed SLO) / P2 (contractual SLAs)** · **[Hypothesis]**

| Window | SLO | Error budget | Verification |
| --- | --- | --- | --- |
| **Critical window** — 25th of month M to the 2nd of month M+1 (pay-run, approval, lock, bank file, disbursal, payslips) | **99.95%** | 0.05% of window minutes — ≈ 5.8 min for an 8-day window | Successful-request ratio (non-5xx, within timeout) at the load balancer, per window, excluding declared maintenance |
| **All other days** | **99.5%** | 0.5% of non-window minutes — ≈ 158 min over 22 days | Same measure, per month |
| **P1 — expansion (200–2,000)** | The windowed SLO above, plus a published status page and a root-cause analysis on every SLO breach | As above | Same measure, plus external synthetic monitoring from ≥ 2 Indian regions |
| **P2 — regulated / enterprise** | Negotiated per contract, never below the windowed SLO; service credits contractual | Per contract | Contractual, third-party-verifiable monitoring |

The rationale is the segment's, not the tender's: the practitioner month runs processing
from about the 25th, lock and bank file around the 27th, and disbursal across the 28th–1st
(r3/02 — low confidence: a convention from two vendor-marketing write-ups with no survey
or employer-sourced evidence, usable to frame the proposal, not to fix it), so an outage inside that window delays salaries, and outside it
mostly delays self-service reads. The window boundaries and both SLO values are a
proposal (Part E-13), **[Hypothesis]**: they are replaced by measured values from §20 instrumentation
(per-tenant pay-run timestamps across the first three month-ends) and buyer interviews,
and the window is a configurable parameter (`critical_window = {start_day: 25,
end_day: 2}`), not a constant.

> **Why not 99.99% at launch, [Hypothesis].** Four-nines (~4.3 min/month) needs multi-AZ
> active-active plus a mature on-call, which a price structure anchored by a value floor near
> ₹50 PEPM and an ₹80–200 mid-market clearing band (EV-027, K-09) cannot fund
> and the beachhead buyer does not contractually require. **Kill/validate:** if beachhead
> churn interviews (§20) show uptime is a top-3 loss reason at the windowed SLO, raise it;
> until then spend the reliability budget on *correctness of filings*, which is the actual
> unit of value (§01).

**NFR-AVAIL-802 · Statutory due-date windows — internal objective and deploy freeze** · **P0**
The critical window covers the pay-run; statutory due dates fall outside it. The system
treats the days around each due date in the §06.11 consolidated filing calendar — EPF ECR
and ESI on the 15th; TDS deposit on the 7th (**[Hypothesis]** — a date carried from the
1962 Rules, not yet read against the Income-tax Rules 2026, §06.13, §20); state PT per state — as **statutory windows** with
an internal objective of **99.95%** and a freeze on non-emergency deploys. The width of each
window is a configurable parameter (`statutory_window_days`), set from §20 telemetry. A
missed filing because the platform was down is an existential failure, not an SLA line
item.

- **Measurable:** during declared statutory windows, availability ≥ 99.95% and
  change-freeze compliance = 100% (no non-emergency deploy in the window).

**NFR-AVAIL-803 · Graceful degradation** · **P0**
Per §13.7 (rate limits P0; degrade gracefully): under load or partial outage, the system
**sheds the AI assistant and non-critical features first, and protects the deterministic
payroll and statutory-artefact path last.** AI-off is a supported configuration, not an
error state (§12). A tenant hitting a rate limit gets a queued, explained response — never
a wrong number and never a dropped filing artefact.

- **Measurable:** in a load test at 3× peak, the payroll-compute and statutory-artefact
  generation paths maintain their latency SLA while the assistant is throttled; 0 payroll
  transactions lost.

**NFR-AVAIL-804 · Maintenance windows** · **P0**
Planned maintenance is scheduled in low-usage IST windows (published ≥ 48 h ahead),
never inside the critical window or a statutory window, and excluded from the SLO
denominator only if declared. Verified against the deploy calendar vs. the statutory
calendar (§06.11).

---

### 17.9 Scale targets

Scale is anchored on the government denominator, not an analyst projection. Per §04.2
[Verified]: **96.2 mean contributing employees per establishment** (a right-skewed mean,
used only for aggregate ceilings); the beachhead is 20–200; greytHR's current claim of
"30,000+ companies" (EV-091, captured September 2026) is ≈ 3.9% of 7,66,254 contributing
establishments — a marketing claim over a government count, not a measured share, and
not all of it Indian EPF-contributing establishments (§04.2) — which is the calibration
ceiling on share; the earlier 34,000 capture gave 4.4%, and every share figure carries its
capture date (K-16). So the scale targets below are
*deliberately* modest at P0 and headroom-tested at P2, rather than vanity numbers. They
are **provisional capacity assumptions [Hypothesis]**, stated so that instance classes,
queue depths and database sizing can be chosen now, and replaced by §20 instrumentation
after the first three month-ends.

**NFR-SCALE-901 · Tenant & headcount targets by phase** · **P0/P1/P2** · **[Hypothesis — provisional]**

| Dimension | P0 target | P1 target | P2 headroom (must not architect out) | Verification |
| --- | --- | --- | --- | --- |
| Active tenants | 1,000 | 10,000 | 50,000 | Load test at target tenant count |
| Employees / tenant (typical) | up to 200 | up to 2,000 | up to 30,000 (SBI RFP eligibility floor — a prior implementation at 30,000 employees, §01) | Single-tenant scale test |
| Total employees on platform | ~100,000 | ~1,000,000 | ~10,000,000 | Aggregate load test |
| Concurrent users at month-end peak | 5,000 | 50,000 | 200,000 | Peak-simulation test |
| Devices (attendance ingest) | 10,000 terminals | 100,000 | 500,000 | Ingest-throughput test |

**NFR-SCALE-902 · The month-end concurrency spike is the real scaling problem** · **P0**
Payroll load is not uniform — it concentrates in the 25th–2nd critical window
(NFR-AVAIL-801) and around the §06.11 statutory due dates (§05.9 expects the 15th to be a
load spike). The architecture is sized for the **peak-to-average ratio**, not the
average. **[Hypothesis — provisional]** — assume a peak of **≈ 10×** average daily load
across those windows; which day actually peaks is unmeasured. **Validate** with production
telemetry after the first three month-ends and re-size (§20). A system sized for the mean
will fall over exactly when the customer needs it most.

**NFR-SCALE-903 · Multi-state, effective-dated data at scale** · **P0**
Per the risk register (§20) — uneven state-rule notification under the four Codes — the
data model assumes **per-state, effective-dated rules**, resolved on the work location
(§14), as the norm, not the exception. A single tenant may span every state it has
establishments in; which states levy PT and LWF, and at what slabs, comes from the
gazette-sourced dataset (§06.4, §06.8; §20), never from a competitor's coverage.
**[Reversed]** — earlier drafts sized this from "Frappe HR ships PT across 15+ states and
LWF across 14"; false from source code — Frappe v16's India payroll has no state name,
PT slab or LWF anywhere in the repository (EV-031), and TallyPrime has no state PT slab
table and no LWF engine (EV-032). Multi-state PT and LWF is greenfield in both incumbents
(§21). Scale target: a pay run for a 200-employee tenant spanning 10 states completes
within the batch SLA (§17.10) with correct per-state slabs applied.

**NFR-SCALE-904 · Recruiting cost meters separately from headcount** · **P1**
Per §13.8: recruiting cost does not track headcount — a recruiting-heavy tenant's
résumé-screening inference (15% of headcount hired per month, 50 CVs per hire, 10,000
tokens per CV) costs ~15× a steady-state tenant's (3% per month, 40 CVs, 3,000 tokens) on
identical PEPM (r2/03; the ratio is FX-invariant, the per-CV token sizes are estimates). The scale model meters recruiting load
(requisitions, candidate volume, AI screening calls) on its own axis so a hiring-heavy
tenant does not degrade a hiring-light tenant's service. Verified by per-tenant, per-axis
resource metering (§17.11).

<!-- DIAGRAM: month-end-load-profile -->

---

### 17.10 Performance

**NFR-PERF-1001 · Interactive latency** · **P0**

| Interaction | Target (P95) | Target (P99) | Verification |
| --- | --- | --- | --- |
| Page/API interactive response | ≤ 500 ms | ≤ 1.5 s | RUM + synthetic, measured from Indian networks |
| Employee payslip view | ≤ 800 ms on 3G-throttled profile | ≤ 2 s | Throttled synthetic (frontline reality, §09) |
| Audit-history query (1 employee, 1 tax year) | ≤ 3 s | ≤ 5 s | Query benchmark |
| Assistant first-token | ≤ 2 s | ≤ 4 s | AI-path telemetry; independent of payroll SLA |

**NFR-PERF-1002 · Batch / pay-run throughput** · **P0**

| Batch job | Target | Verification |
| --- | --- | --- |
| Pay run, 200 employees, multi-state | ≤ 60 s end-to-end (compute → payslips → register update) | Batch benchmark |
| Pay run, 2,000 employees | ≤ 5 min | Batch benchmark (P1) |
| ECR / ESI / PT / Form 138 file generation (Form 138 Q1–Q3; the Q4 generator is fenced until its format is released, EV-046) | ≤ 30 s per return for a 200-employee tenant | File-gen benchmark |
| Retro / arrears recompute (§08 I3) | Recompute against period-version rules ≤ 2× the cost of a fresh run | Recompute benchmark |

**NFR-PERF-1003 · Front-end weight for low-bandwidth India** · **P0**
The self-service surface must work on entry-level Android over 3G. **Target:** initial
JS/CSS payload ≤ 200 KB gzipped for the employee app; Largest Contentful Paint ≤ 2.5 s on
a Moto-G-class device on 3G (measured in Lighthouse CI, gated in the build). This is a
first-class requirement, not polish, because the deskless worker (§09) is the user.

**NFR-PERF-1004 · AI cost-per-interaction budget** · **P0**
Model choice sets the **inference** line of cost of goods — the smallest of four lines
(inference, WhatsApp messaging, supervised filing, compliance curation); the dominant
line is supervised filing, which scales per registration × state × filing type and is
unsized (EV-088; §13, §22). This NFR governs inference only. Each task class carries a
**per-task cost ceiling**; a call that would exceed it is routed to a cheaper backend or
degraded. The 52.7× cheapest-to-dearest spread on identical workload (EV-089, FX-invariant)
is the lever. **Target:** median inference cost per assistant interaction stays inside the
per-task ceiling set by the router; breaches are logged and alert. The ₹0.15–3.27 PEPM
absolutes are placeholders pending prototype instrumentation (§13, §20) — the *ratio*
discipline is the requirement, the absolute number is not yet evidence. **[Hypothesis]** —
**kill/validate:** instrument real tokens-per-query against a real HR policy corpus (§20);
if measured inference cost per employee-month lands ≥ 5× the placeholder, PERF-1004's
per-task ceilings tighten or a task class drops to a cheaper model tier. The margin
question is not settled by inference in either direction. **[Reversed]** — earlier drafts
treated model choice as "the margin" and inference as the test of whether bundled AI is
affordable (K-02); inference is the smallest cost line.

---

### 17.11 Observability

**NFR-OBS-1101 · Cost & usage attribution from v1** · **P0**
Per §13.9: build full **token, cache and cost attribution per tenant, user,
agent and model from v1, while the price of AI is still zero** — retrofitting attribution
after pricing exists is far harder. This is the single most strategically important
observability requirement, because it is what lets AI be run as cost-of-goods (§13) and
what lets recruiting be metered separately (§17.9). The attribution stream links queries
to employees, so it is itself an ICT log held in India (NFR-CERT-602).

| Target | Value | Verification |
| --- | --- | --- |
| Attribution granularity | Every inference call tagged with tenant, user, agent, model, task-class, input/output tokens, cache state, INR cost at booked FX | Query the ledger for any dimension; totals reconcile to the provider invoice ± 2% |
| FX in the ledger | Costs booked at ₹94.43/USD baseline (EV-089, Sep 2026) with FX sensitivity at ₹90/95/100 (§13.12); the ₹83.3 figure is banned (§20.4) | Ledger config audit |
| Per-tenant / per-user rate limits | Enforced (§13.7, P0); one heavy user cannot exceed the tenant's budget; the per-user hard threshold degrades gracefully, and the tenant backstop is the named parameter `tenant_token_budget_pct_of_arpu` (§13.7; value routed to §20) | Abuse test: a runaway user is throttled, not billed through the roof |

**NFR-OBS-1102 · The three pillars** · **P0**

| Pillar | Target | Verification |
| --- | --- | --- |
| Metrics | RED (rate/errors/duration) per service + business metrics (filings-on-time, pay-runs-completed) | Dashboard exists; alerts wired |
| Logs | Structured, correlation-ID-linked, rolling 180-day India-resident retention (EV-062, NFR-CERT-602) | Log-store audit |
| Traces | Distributed tracing across the request path incl. assistant tool-calls | Trace sampling verified |

**NFR-OBS-1103 · The headline business SLI is "filings on time"** · **P0**
Per §01: the filing, not the payslip, is the unit of delivery. So the top-line
operational dashboard is not CPU — it is **% of due filings whose portal-accepted artefact
landed on time, per tenant, per statute**, as §19.1 defines it and computed off the filing
state machine, REJECTED included (§08, Part E-1). Submission is attended — by the
customer or by our operator under written authority — and the employer's liability stays
non-delegable (K-13, EV-030; §22). **Target:** ≥ 99% of due filings completed before the
statutory deadline across the tenant base; any tenant trending toward a miss raises an
alert to CS **before** the deadline, not after.

**NFR-OBS-1104 · Alerting & on-call** · **P0**
SLO-based alerting (error-budget burn-rate), not threshold spam. On-call rota with a
runbook per alert. Critical-window and statutory-window alerts (§17.8) page immediately.
**Target:** ≥ 95% of pages are actionable (post-incident review tracks false-page rate);
mean time to acknowledge ≤ 5 min for P0 alerts.

**NFR-OBS-1105 · AI-attack detection feeds the CERT-In clock** · **P0**
Because attacks on AI/ML systems are a reportable class (Annexure I item xx, EV-062;
§17.6), the observability stack has explicit detections for the AI/ML incident class
(Part E-8): prompt injection, tool abuse and anomalous assistant tool-call patterns,
training- or retrieval-data poisoning, model or data extraction, and unauthorised access
to the inference pipeline or vector store — each wired to the incident runbook.
**Target:** a simulated event in each sub-class is detected and raised to the incident
channel within the window that keeps the six-hour CERT-In report achievable.

<!-- DIAGRAM: observability-and-cost-ledger -->

---

### 17.12 Accessibility (WCAG)

**NFR-A11Y-1201 · WCAG 2.2 Level AA** · **P0 (employee self-service) / P1 (admin)**
The employee self-service surface targets **WCAG 2.2 AA**, adopted as the product standard
on its own merits. The India-specific reason it matters is defensibility, not a mandate:
RPwD s.3(3) is an actor-neutral non-discrimination duty that puts the onus on the
employer to show a proportionate means of achieving a legitimate aim (EV-075), so a
self-service surface a disabled employee cannot use to read a payslip or apply for leave
is an exposure for the customer, not only a UX gap; and every establishment needs an
Equal Opportunity Policy under s.21 (EV-077). (Reading RPwD s.20 as a private-sector duty
is wrong: it binds Government establishments only — K-11.) Whether any RPwD
accessibility standard binds a private SaaS directly, and whether GIGW (Guidelines for
Indian Government Websites) is a gate for public-sector-adjacent buyers, is **not
verified** — **[Hypothesis]**, routed to §20 and §23. WCAG conformance is
never represented to customers as a legal requirement. **[Reversed]** — earlier drafts
marked "the RPwD Act 2016 obliges accessibility" and GIGW as **[Verified]** with no
primary source in the evidence register.

| Target | Value | Verification |
| --- | --- | --- |
| Conformance | WCAG 2.2 AA on employee self-service (P0), admin console (P1) | Automated axe-core scan in CI (0 criticals) + manual audit per release |
| Colour contrast | ≥ 4.5:1 normal text, ≥ 3:1 large text/UI | Automated contrast check |
| Keyboard | 100% of flows operable without a mouse | Manual keyboard walkthrough |
| Screen reader | Payslip, leave, and filing-status flows pass with NVDA + TalkBack (Android) | Assistive-tech test matrix |
| Target size | ≥ 24×24 CSS px (WCAG 2.2 new criterion) — matters for shared low-end touch devices (§09) | Automated + manual |

**NFR-A11Y-1202 · Low-literacy & first-time-smartphone accessibility** · **P0**
Beyond WCAG, the frontline reality (§09) demands **icon-plus-vernacular-label** patterns,
minimal text entry, and voice/IVR fallbacks where feasible. Accessibility here overlaps
localization (§17.13): a payslip a worker cannot read in their language is inaccessible
regardless of contrast ratio. **Measurable:** core employee tasks (view payslip, apply
leave, submit a declaration) completable with ≤ 1 free-text field.

---

### 17.13 Localization & vernacular

**NFR-L10N-1301 · Multilingual employee surface** · **P0 (frame) / P1 (breadth)**
India's linguistic reality makes vernacular a functional requirement for the deskless
segment, not a translation afterthought. The system is built **i18n-ready from v1**
(externalised strings, locale-aware formatting) even though the *breadth* of languages
phases in.

| Target | Value | Verification |
| --- | --- | --- |
| Architecture | All UI strings externalised; no hard-coded English in the employee surface; ICU message format for plurals/gender | Pseudo-localization build passes (0 hard-coded strings) |
| P0 languages | English + Hindi on the employee self-service surface | Both ship at launch |
| P1 languages | Add the highest-headcount vernaculars in the customer base (e.g., Tamil, Telugu, Marathi, Bengali, Kannada, Gujarati) — driven by actual tenant geography, not a guess | Language coverage report vs. tenant-employee language distribution |
| Numerals & currency | Indian numbering (lakh/crore grouping, ₹ symbol, `1,00,000` grouping) everywhere a figure is shown to an Indian user | Formatting test |
| Dates | IST, `DD-MM-YYYY` default, tax-year aware (Apr–Mar; "Tax Year" and the older "Financial Year" labels both accepted in search, imports and help, and the six-digit tax-year field rendered correctly, e.g. 202627 — EV-050) | Formatting test |

> **Vernacular is where AI earns its keep as cost-of-goods (§12.6, §13), [Hypothesis].** LLM
> translation of *explanatory* text (not statutory figures — those are deterministic and
> pre-translated) is a natural fit: the assistant can explain a payslip in the worker's
> language cheaply. **Kill/validate:** measure translation quality for payroll terms of art
> in each target language before relying on model translation for anything an employee acts
> on; statutory labels ship as human-reviewed, locked translations, never model-generated.

**NFR-L10N-1302 · Vernacular does not touch the statutory layer** · **P0**
A hard invariant, consistent with rules-first, LLM-last (§12.1, §13.4): **statutory field
names, form labels, and filed-return content are in the language the statute/portal
requires**, regardless of the employee's UI language. Localization is a *presentation*
concern; it never alters what is filed. Verified: a Tamil-UI tenant's ECR / Form 138
(ex-24Q) output is byte-identical to an English-UI tenant's for the same data.

---

### 17.14 Disaster recovery & business continuity

**NFR-DR-1401 · RPO / RTO targets by phase** · **P0/P1/P2** · **[Hypothesis — provisional]**
For a system whose output is money and statutory filings, RPO and RTO are not optional,
so they are set now as **provisional assumptions** and replaced by §20 instrumentation
(measured restore-drill times, and the cost of data loss inside the 25th–2nd critical
window) rather than left blank (Part E-13).

| Phase / segment | RPO (max data loss) | RTO (max downtime) | Verification |
| --- | --- | --- | --- |
| P0 — beachhead | ≤ 15 min | ≤ 4 h | Restore drill, quarterly |
| P1 — expansion | ≤ 5 min | ≤ 1 h | Restore drill + failover test |
| P2 — regulated | ≤ 1 min (sync replica) | ≤ 30 min | Contractual; audited failover |

An RTO of 4 h consumes the whole critical-window error budget of NFR-AVAIL-801 many times
over; the P0 figure is a recovery ceiling for a disaster, not the availability plan, and
§20 instrumentation decides whether the critical window needs a tighter P0 RTO.

**NFR-DR-1402 · Backups** · **P0**

| Target | Value | Verification |
| --- | --- | --- |
| Frequency | Continuous WAL archiving + daily full; all in India region (DR in a second India region: Mumbai primary, Hyderabad DR) | Backup-catalog audit |
| Encryption | Distinct keys from primary (§17.4) | Restore drill confirms |
| Retention | Point-in-time restore for ≥ 35 days; long-term monthly snapshots aligned to the NFR-DPDP-506 retention classes; an erased subject must not be resurrected by a restore — the §14 erasure mechanism has to survive one (a shredded subject key stays shredded; a tombstone is re-applied on restore) | Restore-window test + restore-after-erasure test |
| **Restore is tested, not assumed** | ≥ 1 real restore drill per quarter, timed against RTO/RPO; a backup never restored is not a backup | Drill report with measured RTO/RPO |

**NFR-DR-1403 · DR stays inside India** · **P0**
The DR region is a *second Indian region*, never a foreign one. CERT-In log residency
(EV-062) applies to every tenant's logs, and the sectoral overlays — SEBI (EV-085), and RBI
where the arrangement is material (EV-087) — apply to backups and DR copies exactly as to
primary data; IRDAI's localisation reaches only policy records, which this product does not
hold (EV-086). A DR design that fails over to a non-India region is therefore non-compliant
for every sectoral-profile tenant and for every tenant's logs, and breaks the India-default
attestation for the rest. Verified in the failover drill: the failed-over stack serves
entirely from India.

**NFR-DR-1404 · Statutory-window continuity** · **P0**
Because a missed filing is an existential failure (§17.8), the BCP explicitly covers the
"platform down during a statutory window" scenario (the §06.11 due dates). Every statutory
surface is an attended portal and the employer's liability is non-delegable (K-13, EV-030,
EV-035–038; §22), so the deliverable is always a portal-accepted artefact plus attended,
assisted filing: the ECR, ESI challan data, PT return and Form 138 (ex-24Q) Q1–Q3 files are
exportable at all times, and in a degraded state the customer, the customer's CA or our
operator under written authority to act completes the attended filing from the export, so
a platform outage never becomes a customer's statutory default. (Operator-assisted
submission launches only once the attended-filing legality questions are cleared — Part
D-17, §22, §23; the export path does not depend on them.) **Target:** a tenant's due statutory artefacts are exportable
for attended submission even in a degraded state; drilled once before launch.

**NFR-DR-1405 · One incident runbook, every clock that applies** · **P0**
The single incident runbook drives, in parallel: (a) the CERT-In six-hour report (EV-062,
§17.6) — the clock that is live today; (b) the DPDP r.7 intimations to affected
employees and the Board, pre-staged and armed at commencement on or about 13 May 2027
(EV-063, NFR-DPDP-505); (c) technical containment/recovery; and (d) customer
communication. **Target:** a tabletop exercise, run before the first paying customer and
repeated ≥ annually, completes every armed track within its clock; the DPDP track is
rehearsed from the first exercise so commencement is a switch, not a project.

<!-- DIAGRAM: dr-topology-india-dual-region -->

---

### 17.15 Compliance-certification roadmap (the seasoning clock)

Not a runtime NFR, but the process wrapper that makes the above auditable, and an
evidence-register finding (§01, §05.2) too consequential to leave implicit.

| Certification | When to start | Why / gate | Source |
| --- | --- | --- | --- |
| **ISO 27001:2022** | **Month 0** | 3–6 mo to acquire + 12 mo seasoning before it counts in an RFP; must be in hand by ~month 6 to be useful at month 18. "The cheapest year you will ever buy" (§01). It is also the standard SPDI r.8 names for reasonable security practices (EV-060), so it earns its keep with the first tenant; SEBI's CSCRF mandates it only for MIIs and Qualified REs (EV-085); under IRDAI's 2023 guidelines, ISO 27001 with the supplied services inside the statement of applicability lets an insurer *except* the vendor from periodic audits — discretionary (s.2.14, r5/01; NFR-RES-704) | Indian Bank RFP, held-≥1-yr-prior clause **[Verified]** (r2/06); EV-060; EV-085 |
| **SOC 2 Type II** | Month 6–9 | Type II needs an observation period; private-sector enterprise expects it. Aparajitha/Simpliance reports SOC 2 Type 2 and ISO 27001 certification for its software suite (vendor's own site, read in research round 2, r2/07 — documentation read, not executed; re-capture with a dated snapshot before citing externally) | **[Hypothesis]** — validate which of SOC 2 / ISO the target accounts actually demand |
| **CERT-In-empanelled auditor** | Before first customer | Empanelment is held by audit firms, not by software vendors: we engage an empanelled auditor for security audits (SBI's RFP demands quarterly certificates from one). The CERT-In point of contact for the six-hour path (NFR-CERT-601) is a separate, internal designation | **[Verified]** (r2/06; CERT-In Directions direction (iii)) |
| **VAPT (annual + on major release)** | Before first customer, then continuous | Third-party penetration test; regulated buyers ask for recent VAPT reports — SEBI's CSCRF hosted-services specification requires VAPT report summaries to be available to the RE and SEBI on demand (r5/01), and Indian Bank ties a payment tranche to VAPT clearance (r2/06) | **[Hypothesis]** on cadence — confirm per RFP |

<!-- DIAGRAM: certification-seasoning-timeline -->

---

### 17.16 NFR acceptance summary — the measurable targets in one table

Every target above, collapsed to a single verifiable list so review and QA have one
checklist. If a row cannot be measured, it does not ship.

| NFR | Target | Phase | Verification |
| --- | --- | --- | --- |
| SEC-101 MFA | 100% privileged, phishing-resistant | P0 | Access review |
| SEC-201 Tenant isolation | 0 cross-tenant leaks; DB-level RLS; CI gate | P0 | CI cross-tenant test |
| SEC-202 Separation of duties | maker≠checker, 100% | P0 | SoD test |
| SEC-204 Access logging | Restricted-field reads audited; detection-capable, not record-only | P0 | Detection drill + log review |
| SEC-301 TLS | ≥ TLS 1.2, HSTS 1yr, grade A | P0 | SSL scan in CI |
| SEC-302 Encryption at rest | AES-256 + app-layer field encryption; separate Aadhaar and biometric keyspaces | P0 | DB-dump inspection |
| SEC-303 Aadhaar | Optional everywhere; token store only; masked default; 0 unmasked endpoints below privilege; 0 Aadhaar numbers or hashes in business tables | P0 | Endpoint audit + schema lint |
| SEC-305 Secure SDLC | 0 ungated High+ CVEs; SBOM/SAST; maker≠checker on statutory-path code | P0 | CI gates + VAPT |
| SEC-401 Audit log | Append-only, hash-chained, 0 un-audited monetary mutations; Restricted values tokenised | P0 | Transactional + chain test |
| DPDP-501 Processing basis | 0 SPDI-set fields without a written-consent artefact; 0 flows where a declined consent blocks payroll; 0 "biometric only" or "no Aadhaar, no payroll" configurations; purpose + basis tag on every field | P0 | Schema constraint + flow audit |
| DPDP-502 Rights machinery | Access ≤ 60 s; erasure honours statutory holds | P0/P1 | Rights test |
| DPDP-505 Breach notification | Six-hour CERT-In path live; DPDP r.7 fields pre-staged; no suppress-notification branch | P0 | Tabletop drill |
| DPDP-506 Retention schedule | Itemised erased/retained statement; every retained class cites a basis or a counsel-review flag; no invented period | P0 | Erasure statement audit |
| CERT-601 Six-hour pipeline | Reportable within 6 h for all 20 classes incl. the AI/ML class; PoC registered pre-launch | P0 | Tabletop drill |
| CERT-602 Log residency | 180 days, India region, AI-layer logs included | P0 | Config audit |
| CERT-603 NTP | NIC/NPL sync, skew ≤ 100 ms | P0 | NTP monitor |
| RES-701 Residency pin | India default; regulated pin refuses off-shore inference | P0/P1 | Pinned-tenant test |
| RES-702 Three backends | Re-point ≤ 60 s, no deploy; deterministic monetary output | P0 | Failover + replay test |
| RES-704 Sectoral profiles | 100% tenants profiled; 0 profile-to-config drift; no SEBI profile before written MeitY-empanelment confirmation | P0/P2 | Nightly drift check + onboarding gate |
| AVAIL-801 Windowed SLO | 99.95% across the 25th–2nd window / 99.5% otherwise [Hypothesis] | P0 | LB success ratio, per window |
| AVAIL-802 Statutory windows | 99.95% internal objective + deploy freeze around §06.11 due dates | P0 | Window monitor |
| AVAIL-803 Degradation | AI shed first, payroll and statutory artefacts last; 0 lost pay txns at 3× load | P0 | Load test |
| SCALE-901 Scale | 1k tenants / 100k emp P0; 30k emp/tenant headroom [Hypothesis — provisional] | P0→P2 | Load test |
| SCALE-902 Peak | Size for ~10× peak across the critical and statutory windows [Hypothesis — provisional] | P0 | Peak sim + telemetry |
| PERF-1001 Latency | P95 ≤ 500 ms interactive | P0 | RUM/synthetic |
| PERF-1002 Pay run | 200 emp ≤ 60 s | P0 | Batch benchmark |
| PERF-1003 FE weight | ≤ 200 KB gz, LCP ≤ 2.5 s on 3G | P0 | Lighthouse CI |
| OBS-1101 Cost attribution | Per tenant/user/agent/model from v1; reconciles ±2% | P0 | Ledger vs invoice |
| OBS-1103 Filings-on-time SLI | ≥ 99% due filings on time | P0 | Business dashboard |
| A11Y-1201 WCAG | 2.2 AA, 0 axe criticals | P0/P1 | axe CI + manual |
| L10N-1301 Vernacular | EN+HI P0; i18n-ready; Indian numerals | P0 | Pseudo-loc build |
| L10N-1302 Statutory invariance | Filed output identical across UI languages | P0 | Output diff test |
| DR-1401 RPO/RTO | ≤ 15 min / ≤ 4 h P0 [Hypothesis — provisional] | P0 | Quarterly drill |
| DR-1403 DR in India | Second India region only | P0 | Failover drill |
| DR-1404 Filing continuity | Statutory artefacts exportable for attended submission in a degraded state | P0 | Pre-launch drill |

---

### 17.17 Open NFR questions to validate

Consistent with the evidence discipline that unvalidated claims carry a kill criterion
(§02); each item feeds the §20 validation plan, and legal items the §23 counsel register:

| # | Question | Method | Kill / re-size criterion |
| --- | --- | --- | --- |
| 1 | What is the real month-end **peak-to-average** load ratio, and which day peaks? | Production telemetry, first 3 month-ends | If > 10×, re-size SCALE-902 and the autoscale envelope |
| 2 | Do the **windowed SLO** boundaries and values match how 20–200 employers actually run the month? | Per-tenant pay-run timestamps (first 3 month-ends) + churn/loss interviews (§20) | Move the window to the measured pay-run span; if uptime is a top-3 loss reason at the windowed SLO, raise AVAIL-801 |
| 3 | Does the **DPDP timeline** move — is the January 2026 compression proposal gazetted, for all fiduciaries or only SDFs; 13 or 14 May 2027; any s.10(1) SDF notification? | Primary-source watch on the e-Gazette (§20); counsel (§23) | A gazetted compression re-dates DPDP-501/505 commencement switches; front-load the r.6 security work over the rights machinery |
| 4 | Real **tokens-per-query** and inference cost per interaction | Prototype instrumentation (§20) | If ≥ 5× the placeholder, PERF-1004 ceilings tighten or a task class drops a tier; margin is decided by the supervised-filing line, not this one (EV-088) |
| 5 | Which **certifications** do target accounts actually demand (SOC 2 vs ISO vs both), and VAPT cadence? | RFP corpus review + buyer interviews | Sets the §17.15 roadmap priorities |
| 6 | Share of device fleet that **cannot do TLS 1.2+** on ingest | Hardware spike (§09) | If material, build the tenant-side relay in SEC-301 caveat |
| 7 | What **RPO/RTO** does the data actually need — measured restore times, and the cost of lost data inside the critical window? | Quarterly restore drills + §20 instrumentation | Replace DR-1401's provisional figures |
| 8 | Are the chosen India regions **MeitY-empanelled** (needed for SEBI-profile tenants, EV-085)? | Written provider confirmation (§20) | If not, SEBI-profile tenants need a different hosting lane before any SEBI sale |
| 9 | What **retention periods** apply to EPF, ESI, TDS, gratuity and appointment-letter records, and to state-sphere registers? | Counsel opinion (§23); corrigendum check (§02.4) | Sets the NFR-DPDP-506 parameters; until set, those classes are held, never erased |
| 10 | Does adding **attended filing** to an insurer tenant's plan make the arrangement outsourcing under IRDAI PPI Regs reg 2(14), and is an RE's employee HR data **"Regulatory Data"** under CSCRF? | Counsel opinion (§23); regulated-buyer interviews (§20) | Sets the NFR-RES-704 IRDAI and SEBI overlays; until answered, the configurator flags the combination and the SEBI overlay treats HR data as in scope |
| 11 | Does SEBI harden the **FAQ Q26 India key-location** expectation into a circular? | Primary-source watch on SEBI circulars (§20) | If hardened, the SEBI overlay's India-HSM setting moves from supervisory expectation to binding; no design change, a status change |
| 12 | Do the **SPDI Rules survive** the omission of IT Act s.43A at DPDP commencement (Part D-12)? | Counsel opinion (§23.4) before ~May 2027 | Sets the date, if any, on which NFR-DPDP-501's written-consent gate stops being mandatory; until answered, the gate stays on |
| 13 | What are the TDS deposit due dates under the **Income-tax Rules 2026**? | Primary-source read (§06.13, §20) | Re-dates the 7th-of-month statutory window in NFR-AVAIL-802 and the month-end load profile |
